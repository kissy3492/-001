Attribute VB_Name = "modOutputs"
Option Explicit

Private Type RelationshipDiagramPlan
    CardW As Double
    CardH As Double
    CoupleGap As Double
    BlockGap As Double
    RowGap As Double
    PageLeft As Double
    PageRight As Double
    PageWidth As Double
    PageCenter As Double
    IsLandscape As Boolean
    PersonCount As Long
    MaxDepth As Long
    MaxSiblings As Long
    RootWidth As Double
    FitWideHint As Long
End Type

Private mRelationshipDiagramHasPlan As Boolean
Private mRelationshipDiagramLandscape As Boolean
Private mRelationshipDiagramFitWideHint As Long
Private mOutputFailureSummary As String
Private mRelationshipDiagramLastFailed As Boolean
Private mDiagramCardsOnly As Boolean
Private mDiagramStrictLineMode As Boolean

Public Sub BuildAllOutputs()
    On Error GoTo EH
    Dim failedCount As Long
    AppBegin "�l�����n�̒��[���ꊇ�쐬��..."
    mOutputFailureSummary = vbNullString

    failedCount = failedCount + OutputStepFailureCount("��\�Z���X�V", "RefreshRepresentativeAddresses")
    failedCount = failedCount + OutputStepFailureCount("�������𓯊�", "SyncMarriageHistoryFromLegacyTables")
    failedCount = failedCount + OutputStepFailureCount("���n��C�x���g����", "GenerateEvents")
    failedCount = failedCount + OutputStepFailureCount("���̓`�F�b�N", "RunChecks")
    failedCount = failedCount + OutputStepFailureCount("�Ƒ��������f���\�z", "PrepareFamilyModel")
    failedCount = failedCount + OutputStepFailureCount("�m�F�ꗗ�쐬", "BuildConfirmList")
    failedCount = failedCount + OutputStepFailureCount("�����֌W�}�쐬", "BuildRelationshipDiagram")
    failedCount = failedCount + OutputStepFailureCount("�Z�����𑁌��\�쐬", "BuildAddressHistoryTable")
    failedCount = failedCount + OutputStepFailureCount("��������\�쐬", "BuildCohabitationTable")
    failedCount = failedCount + OutputStepFailureCount("���n��\�쐬", "BuildTimelineTable")
    failedCount = failedCount + OutputStepFailureCount("�l���ꗗ�쐬", "BuildPersonList")
    failedCount = failedCount + OutputStepFailureCount("�o�̓V�[�g�ی�E�\������", "ApplyOutputUsability")
    failedCount = failedCount + OutputStepFailureCount("�o�̓V�[�g�\��", "ShowOutputSheetsCore")

    If failedCount > 0 Then
        AppendOutputFailureSummary "�ꊇ�쐬"
        QuietWarn "�ꊇ�쐬�ňꕔ���[�̍쐬�Ɏ��s���܂����B�쐬�ł������[�͈ێ����Ă��܂��BC_�`�F�b�N�Ŏ��s�H�����m�F���Ă��������B", True, "�ꊇ�쐬"
    End If
CleanExit:
    AppEnd
    Exit Sub
EH:
    Dim errNum As Long, errDesc As String, errSrc As String
    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source
    AppEnd
    RuntimeShowErrorValues "BuildAllOutputs", "�ꊇ�쐬", _
        "�l���E�֌W�E�Z�������E�o�̓V�[�g�ی��Ԃ��m�F���Ă��������B", _
        "", errNum, errDesc, errSrc
End Sub

Private Function OutputStepFailureCount(ByVal stepText As String, ByVal stepKey As String) As Long
    On Error GoTo EH
    Select Case stepKey
        Case "RefreshRepresentativeAddresses": RefreshRepresentativeAddresses
        Case "SyncMarriageHistoryFromLegacyTables": SyncMarriageHistoryFromLegacyTables
        Case "PrepareFamilyModel": PrepareFamilyModelForOutputs
        Case "GenerateEvents": GenerateEvents
        Case "BuildConfirmList": BuildConfirmList
        Case "RunChecks": RunChecks
        Case "BuildRelationshipDiagram": BuildRelationshipDiagram: If mRelationshipDiagramLastFailed Then Err.Raise vbObjectError + 7801, "BuildRelationshipDiagram", "�����֌W�}�̍쐬�Ɏ��s���܂����BC_�`�F�b�N�̒�~�H�����m�F���Ă��������B"
        Case "BuildAddressHistoryTable": BuildAddressHistoryTable
        Case "BuildCohabitationTable": BuildCohabitationTable
        Case "BuildTimelineTable": BuildTimelineTable
        Case "BuildPersonList": BuildPersonList
        Case "ApplyOutputUsability": ApplyOutputUsability
        Case "ShowOutputSheetsCore": ShowOutputSheetsCore True
        Case Else: Err.Raise vbObjectError + 750, "OutputStepFailureCount", "����`�̏o�͍H���ł�: " & stepKey
    End Select
    Exit Function
EH:
    AppendOutputStepFailure stepText, Err.Number, Err.Description, Err.Source
    Err.Clear
    OutputStepFailureCount = 1
End Function

Private Sub PrepareFamilyModelForOutputs()
    Dim decedentId As String
    decedentId = GetDecedentId()
    If Len(decedentId) = 0 Then Exit Sub
    If Not FamilyModelEnsureBuilt(decedentId) Then _
        Err.Raise vbObjectError + 751, "PrepareFamilyModelForOutputs", "�Ƒ��������f�����\�z�ł��܂���ł����B"
End Sub

Private Sub AppendOutputStepFailure(ByVal stepText As String, ByVal errNum As Long, ByVal errDesc As String, ByVal errSrc As String)
    Dim ws As Worksheet, outR As Long
    On Error Resume Next
    RuntimeAppendLog "ERROR", "�l�����ꊇ�쐬", stepText, errDesc, errNum, errDesc, errSrc
    If Len(mOutputFailureSummary) > 0 Then mOutputFailureSummary = mOutputFailureSummary & vbLf
    mOutputFailureSummary = mOutputFailureSummary & stepText & ": " & errDesc
    If SheetExists(SH_CHECK, ThisWorkbook) Then
        Set ws = ThisWorkbook.Worksheets(SH_CHECK)
        outR = LastRow(ws, 1) + 1
        If outR < 4 Then outR = 4
        AddCheck ws, outR, "�G���[", "�ꊇ�쐬�̈ꕔ�H���Ŏ��s���܂����B�H��=" & stepText & " / " & errDesc, _
            "", "", "�ꊇ�쐬", "�쐬�ςݒ��[���m�F���A�Y���H���̓��̓f�[�^���C��"
    End If
    On Error GoTo 0
End Sub

Private Sub AppendOutputFailureSummary(ByVal operationName As String)
    Dim ws As Worksheet, outR As Long
    On Error Resume Next
    If Len(CleanText(mOutputFailureSummary)) = 0 Then Exit Sub
    If Not SheetExists(SH_CHECK, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_CHECK)
    outR = LastRow(ws, 1) + 1
    If outR < 4 Then outR = 4
    AddCheck ws, outR, "����", operationName & "�ňꕔ���s�����H��������܂��B" & vbLf & mOutputFailureSummary, _
        "", "", operationName, "�쐬�ςݒ��[���ێ��B���s�H�������C�����čĎ��s"
    On Error GoTo 0
End Sub

Public Sub BuildConfirmList()
    Dim ws As Worksheet, wp As Worksheet, r As Long, outR As Long, pid As String
    Set ws = ThisWorkbook.Worksheets(SH_CONFIRM)
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    ws.Range("A4:J1000").ClearContents
    outR = 4
    For r = 2 To LastRow(wp, 1)
        If Len(CStr(wp.Cells(r, P_ID).Value)) > 0 And CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            pid = CStr(wp.Cells(r, P_ID).Value)
            ws.Cells(outR, 1).Value = wp.Cells(r, P_ORDER).Value
            ws.Cells(outR, 2).Value = pid
            ws.Cells(outR, 3).Value = wp.Cells(r, P_TYPE).Value
            ws.Cells(outR, 4).Value = DiagramRelationDisplayTextForPersonId(pid)
            ws.Cells(outR, 5).Value = wp.Cells(r, P_DISPLAY).Value
            ws.Cells(outR, 6).Value = wp.Cells(r, P_FORMER).Value
            ws.Cells(outR, 7).Value = wp.Cells(r, P_BIRTH).Value
            ws.Cells(outR, 8).Value = wp.Cells(r, P_DEATH).Value
            ws.Cells(outR, 9).Value = GetCurrentAddressText(pid)
            ws.Cells(outR, 10).Value = wp.Cells(r, P_NOTE).Value
            outR = outR + 1
        End If
    Next r
    ws.Range("G4:H" & Application.Max(4, outR)).NumberFormatLocal = "yyyy/m/d"
    ThemeApplyCompleteBorders ws.Range("A3:K" & Application.Max(4, outR - 1)), "border"
    ws.Range("A4:J" & Application.Max(4, outR - 1)).WrapText = True
    ws.Columns("A:K").AutoFit
    CapColumnWidths ws, 1, 10, 38
End Sub

Public Sub ShowConfirmList()
    On Error GoTo EH
    AppBegin "�l���m�F�ꗗ���X�V��..."
    BuildConfirmList
    ShowOnlyInputCore False
    With ThisWorkbook.Worksheets(SH_CONFIRM)
        .Visible = xlSheetVisible
        .Activate
        .Range("A1").Select
    End With
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowConfirmList", "�l���m�F", "�m�F�ꗗ�V�[�g�A�l���\�A�Z������\���m�F���Ă��������B"
End Sub

Public Sub RunChecks()
    Dim ws As Worksheet, wp As Worksheet, r As Long, outR As Long, decCount As Long, decId As String
    Dim modelReady As Boolean
    '�`�F�b�N�͕ۑ��ς�V2������ǂݒ��������Ƃ��A�f�f���Ɋ֌W�\���ڍs�E�������Ȃ��B
    EnsureMarriageHistoryWorkSheet
    '���l���񂩂�̍��������݊��������K�v�ȏꍇ�́A���f���\�z���O�Ɉ�x�����ς܂���B
    BackfillMarriageHistoryFromLegacyFacts
    FamilyModelInvalidate
    Set ws = ThisWorkbook.Worksheets(SH_CHECK)
    ws.Range("A4:R2000").ClearContents
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    outR = 4
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wp.Cells(r, P_ID).Value)) > 0 Then
            If wp.Cells(r, P_TYPE).Value = MODE_DECEDENT Then decCount = decCount + 1
            If Len(CStr(wp.Cells(r, P_GIVEN).Value)) = 0 Then AddCheck ws, outR, "�G���[", "�����󗓂ł��B", wp.Cells(r, P_ID).Value, wp.Cells(r, P_DISPLAY).Value, "�l��", "�������"
            If Len(CStr(wp.Cells(r, P_REL_DEC).Value)) = 0 Then AddCheck ws, outR, "����", "�������󗓂ł��B", wp.Cells(r, P_ID).Value, wp.Cells(r, P_DISPLAY).Value, "�l��", "�������m�F"
            If Len(GetCurrentAddressText(CStr(wp.Cells(r, P_ID).Value))) = 0 Then AddCheck ws, outR, "����", "�Z�������������͂ł��B", wp.Cells(r, P_ID).Value, wp.Cells(r, P_DISPLAY).Value, "�Z��", "�Z����o�^"
        End If
    Next r

    '�Ȍ�̐������`�F�b�N�Ɛf�f�\�́A�������_�̉Ƒ��������f�������L����B
    If decCount = 1 Then
        decId = GetDecedentId()
        If Len(decId) > 0 Then modelReady = DiagramGraphRebuildFresh(decId, False)
    Else
        DiagramGraphReset
    End If
    CheckAddressHistoryIssues ws, outR
    CheckRelationIntegrityIssues ws, outR
    CheckMarriageHistoryIssues ws, outR
    CheckInputAssistIssues ws, outR
    If decCount = 0 Then AddCheck ws, outR, "�G���[", "�푊���l�����o�^�ł��B", "", "", "�푊���l", "�푊���l��o�^"
    If decCount > 1 Then AddCheck ws, outR, "�G���[", "�푊���l�������o�^����Ă��܂��B", "", "", "�푊���l", "1�l�ɐ���"
    If decCount = 1 Then
        If modelReady Then
            DiagramGraphWriteDiagnostics decId
        Else
            AddCheck ws, outR, "�G���[", "�����֌W�}���f�����\�z�ł��܂���B", decId, GetPersonValue(decId, P_DISPLAY), "�����֌W�}", "���������E�e�q�֌W�E�\���Ώۂ��m�F"
        End If
    Else
        DiagramGraphReset
    End If
    ThemeApplyCompleteBorders ws.Range("A3:R" & Application.Max(4, LastRow(ws, 1))), "border"
    ws.Columns("A:R").AutoFit
    CapColumnWidths ws, 1, 18, 42
End Sub

Private Sub CheckAddressHistoryIssues(ByVal ws As Worksheet, ByRef outR As Long)
    Dim wa As Worksheet, r As Long, pid As String
    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Sub
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    For r = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wa.Cells(r, A_ID).Value)) > 0 Then
            pid = CStr(wa.Cells(r, A_PERSON_ID).Value)
            If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then
                AddCheck ws, outR, "�G���[", "�Z�������̐l��ID���l���ꗗ�ɂ���܂���B", _
                    pid, "", "�Z��", "�l����I�ђ����ďZ����o�^"
            Else
                If Len(CleanText(wa.Cells(r, A_COPY_PERSON_ID).Value)) > 0 And Len(CleanText(wa.Cells(r, A_COPY_ADDR_ID).Value)) = 0 _
                        And InStr(1, CleanText(wa.Cells(r, A_SOURCE).Value), "��l���Z���R�s�[", vbTextCompare) = 0 Then
                    AddCheck ws, outR, "����", "�Z�������ɃR�s�[���l��ID������܂����R�s�[���Z��ID������܂���B����͏Z���ɃR�s�[�����c���Ă��Ȃ����m�F���Ă��������B", _
                        pid, GetPersonValue(pid, P_DISPLAY), "�Z���R�s�[��", "����͂Ȃ�R�s�[�����󗓁A�R�s�[�Ȃ�Z�������R�s�[�@�\�œo�^"
                End If
                If HasInputDate(GetPersonValue(pid, P_DEATH)) Then
                    If Len(CleanText(wa.Cells(r, A_TEXT).Value)) > 0 And Not HasInputDate(wa.Cells(r, A_END).Value) Then
                        AddCheck ws, outR, "����", "���S��������l���̏Z�������ɏI����������܂���B�Ō�̏Z���Ȃ�I�����Ɏ��S���𔽉f���Ă��������B", _
                            pid, GetPersonValue(pid, P_DISPLAY), "���S�ҏZ��", "���S�����I�����A�܂��͏Z���I�������m�F"
                    End If
                End If
            End If
            If HasInputDate(wa.Cells(r, A_START).Value) And HasInputDate(wa.Cells(r, A_END).Value) Then
                If CDate(SameDateOrBlank(wa.Cells(r, A_START).Value)) > CDate(SameDateOrBlank(wa.Cells(r, A_END).Value)) Then
                    AddCheck ws, outR, "�G���[", "�Z���̔c���J�n�����I��������ł��B", _
                        pid, GetPersonValue(pid, P_DISPLAY), "�Z������", "�c���J�n���E�I�������C��"
                End If
            End If
        End If
    Next r
End Sub

Private Sub CheckRelationIntegrityIssues(ByVal ws As Worksheet, ByRef outR As Long)
    Dim wr As Worksheet, wp As Worksheet, r As Long
    Dim pId As String, cId As String, pRow As Long, cRow As Long
    Dim childLevel As Long, modelGeneration As Long, relText As String, parentId As String, personId As String
    If Not SheetExists(SH_W_REL, ThisWorkbook) Or Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)

    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If Not DiagramGraphIsSpouseRelationType(CStr(wr.Cells(r, R_TYPE).Value)) Then
                If HasInputDate(wr.Cells(r, R_MARRIAGE).Value) Or HasInputDate(wr.Cells(r, R_DIVORCE).Value) Then
                    AddCheck ws, outR, "����", "�z��҈ȊO�̊֌W�s�ɍ�����/���������c���Ă��܂��B���n��ł͖������܂��B", _
                        CStr(wr.Cells(r, R_OTHER_ID).Value), "", "�֌W", "�֌W��ʂƓ��t���͈ʒu���m�F"
                End If
            End If
            If DiagramGraphIsParentChildRelationRow(wr, r) Then
                If Not TryResolveDiagramParentChildRelationRow(wr, r, pId, cId) Then
                    AddCheck ws, outR, "�G���[", "�e���q�̐l��ID��ǂݎ��܂���B�����֌W�}�̐�����O���܂��B", _
                        CStr(wr.Cells(r, R_OTHER_ID).Value), "", "�e�q�֌W", "�eID�E�qID���m�F"
                Else
                    If Len(CleanText(wr.Cells(r, R_CHILD_KIND).Value)) = 0 Or Len(CleanText(wr.Cells(r, R_CONFIDENCE).Value)) = 0 Then
                        AddCheck ws, outR, "�G���[", "�e�q�����Ɏq�̋敪�܂��͊m�x������܂���B", _
                            cId, GetPersonValue(cId, P_DISPLAY), "�e�q�֌W", "�q�̋敪��I��Ől�����X�V"
                    End If
                    If CleanText(wr.Cells(r, R_CHILD_KIND).Value) = CHILD_KIND_COUPLE _
                            And Len(CleanText(wr.Cells(r, R_FAMILY_KEY).Value)) = 0 Then
                        AddCheck ws, outR, "�G���[", "�v�w�̎q�ɉƑ��L�[������܂���B�v�w���������m��ł��܂���B", _
                            cId, GetPersonValue(cId, P_DISPLAY), "�e�q�֌W", "�q������Ǎ����A�v�w�̎q�Ƃ��čX�V"
                    End If
                    If CleanText(wr.Cells(r, R_CONFIDENCE).Value) = FACT_REVIEW Then
                        AddCheck ws, outR, "����", "�e�q�敪���v�m�F�ł��B" & CleanText(wr.Cells(r, R_EVIDENCE).Value), _
                            cId, GetPersonValue(cId, P_DISPLAY), "�e�q�֌W", "�q�̋敪���m�F���Đl�����X�V"
                    End If
                End If
            End If
        End If
    Next r

    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            personId = CleanText(wp.Cells(r, P_ID).Value)
            relText = NormalizeDiagramRelationText(CStr(wp.Cells(r, P_REL_DEC).Value))
            childLevel = DiagramDescendantLevel(relText)
            modelGeneration = FamilyModelGenerationLevel(personId)
            If childLevel > 0 And modelGeneration >= 0 And childLevel <> modelGeneration Then
                AddCheck ws, outR, "�G���[", "�ۑ������̐���ƉƑ��������f���̐e�q������v���܂���B�ۑ�=" & relText & _
                    " / ���f������=" & CStr(modelGeneration) & "�i" & RelationshipDescendantLabel(modelGeneration) & "�j", _
                    personId, CStr(wp.Cells(r, P_DISPLAY).Value), "�e������", "�eID���qID�̍����m�F���A�l�������ŕۑ��������X�V"
            End If
            If childLevel >= 2 Then
                parentId = InferredDiagramParentIdForChildRow(r)
                If Len(parentId) = 0 Then
                    AddCheck ws, outR, "�G���[", "���ȉ��̐l���ɐe�q���̐e�����ł��܂���B�}�ł͊֌W�v�m�F�Ƃ��ĕ������܂��B", _
                        CStr(wp.Cells(r, P_ID).Value), CStr(wp.Cells(r, P_DISPLAY).Value), "�����֌W�}", "�e�ƂȂ�l������Ɏq�Ƃ��ēo�^"
                End If
            End If
        End If
    Next r
End Sub

Private Sub CheckMarriageHistoryIssues(ByVal ws As Worksheet, ByRef outR As Long)
    Dim mh As Worksheet, r As Long, pid As String, cpId As String
    EnsureMarriageHistoryWorkSheet
    Set mh = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(mh, 1)
        If CStr(mh.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL And Len(CStr(mh.Cells(r, MH_ID).Value)) > 0 Then
            pid = CStr(mh.Cells(r, MH_PERSON_ID).Value)
            cpId = CStr(mh.Cells(r, MH_COUNTERPART_ID).Value)
            If Left$(pid, 14) = "__PENDING_MH__" Then
                If PendingMarriageHistoryBelongsToActiveInput(pid) Then
                    AddCheck ws, outR, "����", "���͒��l���ɖ����f�̍�������������܂��B�l���o�^���ɐ����l��ID�֔��f���܂��B", _
                        pid, CStr(mh.Cells(r, MH_COUNTERPART_NAME).Value), "��������", "���̐l����o�^���邩�A���̓N���A�Ŕj��"
                Else
                    AddCheck ws, outR, "�G���[", "�o�^�O�����������Ǘ����Ă��܂��B�ʐl�����͂ֈڂ�O�ɓo�^�܂��͔j������Ă��Ȃ��\��������܂��B", _
                        pid, CStr(mh.Cells(r, MH_COUNTERPART_NAME).Value), "��������", "���������m�F�Ŏ���A�܂��͑Ώېl���֍ēo�^"
                End If
                GoTo NextMarriageHistoryCheckRow
            End If
            If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then
                AddCheck ws, outR, "�G���[", "���������̐l��ID���l���ꗗ�ɂ���܂���B", _
                    pid, "", "��������", "�l����I�ђ����������s�𐮗�"
            End If
            If Len(cpId) > 0 And FindPersonRow(cpId) = 0 Then
                AddCheck ws, outR, "�G���[", "���������̑���l��ID���l���ꗗ�ɂ���܂���B", _
                    cpId, "", "��������", "����l����o�^�����������薼�݂̂֐���"
            End If
            If Not HasInputDate(mh.Cells(r, MH_MARRIAGE).Value) And Not HasInputDate(mh.Cells(r, MH_DIVORCE).Value) Then
                AddCheck ws, outR, "����", "���������ɍ������E�������̗���������܂���B���n��ɂ͏o�܂���B", _
                    pid, GetPersonValue(pid, P_DISPLAY), "��������", "��������t��������"
            End If
            If HasInputDate(mh.Cells(r, MH_MARRIAGE).Value) And HasInputDate(mh.Cells(r, MH_DIVORCE).Value) Then
                If CDate(SameDateOrBlank(mh.Cells(r, MH_MARRIAGE).Value)) > CDate(SameDateOrBlank(mh.Cells(r, MH_DIVORCE).Value)) Then
                    AddCheck ws, outR, "�G���[", "������������������ł��B", _
                        pid, GetPersonValue(pid, P_DISPLAY), "��������", "�������E���������C��"
                End If
            End If
            If Len(cpId) = 0 And Len(CleanText(mh.Cells(r, MH_COUNTERPART_NAME).Value)) = 0 Then
                AddCheck ws, outR, "����", "���������̑��肪���w��ł��B�o�^�ςݔz��҂�1�l�Ɋm��ł��闚���͎����⊮�ς݂ł��B�c��s�͕������܂��͊֌W�s���ł��B", _
                    pid, GetPersonValue(pid, P_DISPLAY), "��������", "���������m�F�ő���l���܂��͑��薼���w��"
            End If
            If MarriageHistoryDuplicateExists(mh, r) Then
                AddCheck ws, outR, "����", "���������ɏd����₪����܂��B�����l���E����E������/�������̗�������������܂��B", _
                    pid, GetPersonValue(pid, P_DISPLAY), "��������", "���������m�F�ŏd���s�𐮗�"
            End If
        End If
NextMarriageHistoryCheckRow:
    Next r
End Sub

Private Function OutputMarriageSameDateValueOrBlank(ByVal a As Variant, ByVal b As Variant) As Boolean
    OutputMarriageSameDateValueOrBlank = SameInputDateOrBothBlank(a, b)
End Function

Private Function MarriageHistoryDuplicateExists(ByVal mh As Worksheet, ByVal rowNo As Long) As Boolean
    Dim r As Long, pid As String, cpId As String, cpName As String
    If mh Is Nothing Then Exit Function
    If rowNo <= 1 Then Exit Function
    pid = CleanText(mh.Cells(rowNo, MH_PERSON_ID).Value)
    cpId = CleanText(mh.Cells(rowNo, MH_COUNTERPART_ID).Value)
    cpName = CleanText(mh.Cells(rowNo, MH_COUNTERPART_NAME).Value)
    For r = 2 To LastRow(mh, MH_ID)
        If r <> rowNo Then
            If CleanText(mh.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
                If CleanText(mh.Cells(r, MH_PERSON_ID).Value) = pid Then
                    If OutputMarriageSameDateValueOrBlank(mh.Cells(r, MH_MARRIAGE).Value, mh.Cells(rowNo, MH_MARRIAGE).Value) Then
                        If OutputMarriageSameDateValueOrBlank(mh.Cells(r, MH_DIVORCE).Value, mh.Cells(rowNo, MH_DIVORCE).Value) Then
                            If Len(cpId) > 0 Then
                                If CleanText(mh.Cells(r, MH_COUNTERPART_ID).Value) = cpId Then MarriageHistoryDuplicateExists = True: Exit Function
                            ElseIf Len(CleanText(mh.Cells(r, MH_COUNTERPART_ID).Value)) = 0 Then
                                If Len(cpName) = 0 Or Len(CleanText(mh.Cells(r, MH_COUNTERPART_NAME).Value)) = 0 Or StrComp(CleanText(mh.Cells(r, MH_COUNTERPART_NAME).Value), cpName, vbTextCompare) = 0 Then
                                    MarriageHistoryDuplicateExists = True
                                    Exit Function
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function PendingMarriageHistoryBelongsToActiveInput(ByVal pendingPersonId As String) As Boolean
    Dim ws As Worksheet, activeId As String, k As String
    pendingPersonId = CleanText(pendingPersonId)
    If Len(pendingPersonId) = 0 Then Exit Function
    If Not SheetExists(SH_INPUT, ThisWorkbook) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    k = CleanText(ws.Range(CELL_PENDING_MARRIAGE_KEY).Value)
    If Len(k) = 0 Then Exit Function
    activeId = "__PENDING_MH__" & k
    PendingMarriageHistoryBelongsToActiveInput = (pendingPersonId = activeId)
End Function

Private Sub CheckInputAssistIssues(ByVal ws As Worksheet, ByRef outR As Long)
    Dim wi As Worksheet, wc As Worksheet
    If Not SheetExists(SH_INPUT, ThisWorkbook) Then
        AddCheck ws, outR, "�G���[", "�l�����̓V�[�g������܂���B", "", "", "���͕⏕", "SetupWorkbook�����s"
        Exit Sub
    End If
    Set wi = ThisWorkbook.Worksheets(SH_INPUT)

    If Not HasListValidationLocal(wi.Range(CELL_BASE_SELECT)) Then _
        AddCheck ws, outR, "����", "��l�����̓��͕⏕���O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_SURNAME)) Then _
        AddCheck ws, outR, "����", "���ݐ��̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_FORMER_SURNAME)) Then _
        AddCheck ws, outR, "����", "�����̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_REL_TO_DECEDENT)) Then _
        AddCheck ws, outR, "����", "�����̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_OCCUPATION)) Then _
        AddCheck ws, outR, "����", "�E�Ƃ̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_ADDR_CAND)) Then _
        AddCheck ws, outR, "����", "�Z�����̓��͕⏕���O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_ADDR_START_KIND)) Then _
        AddCheck ws, outR, "����", "�Z���J�n���̈����̑I��⏕���O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_MARRIAGE)) Then _
        AddCheck ws, outR, "����", "�������̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_DIVORCE)) Then _
        AddCheck ws, outR, "����", "�������̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_ADDR_START)) Then _
        AddCheck ws, outR, "����", "�Z���J�n���̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasListValidationLocal(wi.Range(CELL_ADDR_END)) Then _
        AddCheck ws, outR, "����", "�Z���I�����̌����͂��O��Ă��܂��B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"

    If Not HasInputActionButton(wi, "ApplySelectedAddressCandidate") Then _
        AddCheck ws, outR, "�G���[", "�Z�����𔽉f����{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "CopyBaseCurrentAddress") Then _
        AddCheck ws, outR, "�G���[", "��Z���R�s�[�̃{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "CopyBaseAddressHistoryToCurrentOrPending") Then _
        AddCheck ws, outR, "�G���[", "��l���̏Z�������R�s�[�̃{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "CopyLastAddress") Then _
        AddCheck ws, outR, "����", "�O�Z���R�s�[�̃{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "MarkAddressStartConfirmed") Then _
        AddCheck ws, outR, "����", "���Z�J�n�{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "MarkAddressStartObserved") Then _
        AddCheck ws, outR, "����", "�c�����{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "UseBirthDateAsAddressStart") Then _
        AddCheck ws, outR, "����", "�o�����J�n�{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "UseMarriageDateAsAddressStart") Then _
        AddCheck ws, outR, "����", "���������J�n�{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "UseDeathDateAsAddressEnd") Then _
        AddCheck ws, outR, "����", "���S�����I���{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "UseDivorceDateAsAddressEnd") Then _
        AddCheck ws, outR, "����", "���������I���{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "RegisterInputPerson") Then _
        AddCheck ws, outR, "�G���[", "�o�^�E�X�V�{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "AddAddressAndStartNext") Then _
        AddCheck ws, outR, "����", "�Z���ǉ������Z���{�^����������܂���B", "", "", "���͕⏕", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "ReturnToPreviousBasePerson") Then _
        AddCheck ws, outR, "����", "����֖߂�{�^����������܂���B", "", "", "���͓���", "�����܂���SetupWorkbook�����s"
    If Not HasInputActionButton(wi, "ReturnToDecedentBasePerson") Then _
        AddCheck ws, outR, "����", "�푊���l�֖߂�{�^����������܂���B", "", "", "���͓���", "�����܂���SetupWorkbook�����s"
    If wi.Range(CELL_PENDING_MARRIAGE_PANEL_TITLE).MergeArea.Address <> wi.Range("B37:J37").Address Then _
        AddCheck ws, outR, "����", "���͒����������p�l���̌��o���ʒu������Ă��܂��B", "", "", "�����������", "�����܂���SetupWorkbook�����s"
    If wi.Range(CELL_PENDING_MARRIAGE_PANEL_BODY).MergeArea.Address <> wi.Range("B38:J43").Address Then _
        AddCheck ws, outR, "����", "���͒����������p�l���̖{���ʒu������Ă��܂��B", "", "", "�����������", "�����܂���SetupWorkbook�����s"

    If SheetExists(SH_W_CAND, ThisWorkbook) Then
        Set wc = ThisWorkbook.Worksheets(SH_W_CAND)
        If LastRow(wc, 8) < 2 Then _
            AddCheck ws, outR, "����", "������⃊�X�g����ł��B", "", "", "���͕⏕", "RefreshCandidates�܂���SetupWorkbook�����s"
        If LastRow(wc, 14) < 2 Then _
            AddCheck ws, outR, "����", "���Z�J�n����⃊�X�g����ł��B�o�^�ςݓ��t��������ΐ���ł��B", "", "", "���͕⏕", "�K�v�Ȃ�Z�����t�����"
    Else
        AddCheck ws, outR, "�G���[", "���Ǘ��V�[�g W_��� ������܂���B", "", "", "���͕⏕", "SetupWorkbook�����s"
    End If
End Sub

Private Function HasListValidationLocal(ByVal rng As Range) As Boolean
    On Error Resume Next
    HasListValidationLocal = (rng.Validation.Type = xlValidateList)
    If Err.Number <> 0 Then
        Err.Clear
        HasListValidationLocal = False
    End If
    On Error GoTo 0
End Function

Private Function HasInputActionButton(ByVal ws As Worksheet, ByVal macroName As String) As Boolean
    Dim shp As Shape, btn As Button, actionText As String
    On Error Resume Next
    For Each shp In ws.Shapes
        actionText = CStr(shp.OnAction)
        If Err.Number <> 0 Then Err.Clear: actionText = ""
        If InStr(1, actionText, macroName, vbTextCompare) > 0 _
                Or InStr(1, CStr(shp.AlternativeText), macroName, vbTextCompare) > 0 Then
            HasInputActionButton = True
            Exit Function
        End If
    Next shp
    For Each btn In ws.Buttons
        actionText = CStr(btn.OnAction)
        If Err.Number <> 0 Then Err.Clear: actionText = ""
        If InStr(1, actionText, macroName, vbTextCompare) > 0 Then
            HasInputActionButton = True
            Exit Function
        End If
    Next btn
    On Error GoTo 0
End Function

Private Sub AddCheck(ByVal ws As Worksheet, _
        ByRef outR As Long, _
        ByVal level As String, _
        ByVal msg As String, _
        ByVal pid As String, _
        ByVal nameText As String, _
        ByVal target As String, _
        ByVal actionText As String)
    ws.Cells(outR, 1).Value = level
    ws.Cells(outR, 2).Value = msg
    ws.Cells(outR, 3).Value = pid
    ws.Cells(outR, 4).Value = nameText
    ws.Cells(outR, 5).Value = target
    ws.Cells(outR, 6).Value = actionText
    ws.Cells(outR, 7).Value = Now
    outR = outR + 1
End Sub

Private Sub GenerateEvents()
    Dim we As Worksheet, wp As Worksheet, wr As Worksheet, wa As Worksheet, r As Long
    Dim decId As String, inhDate As Variant, pid As String, otherId As String
    Dim decDeathValue As Variant, addInheritanceEvent As Boolean
    Dim manualEvents As Collection
    Dim stepText As String, failedCount As Long
    SyncMarriageHistoryFromLegacyTables
    Set we = ThisWorkbook.Worksheets(SH_W_EVENT)
    Set manualEvents = PreserveManualTimelineEvents(we)
    we.Range("A2:L" & CStr(Application.Max(2, LastRow(we, 1)))).ClearContents
    RestoreManualTimelineEvents we, manualEvents
    AddMarriageHistoryEvents we

    '�o�͐�������W_�֌W�����������Ȃ��B��z��ҍs�̍���/���������c���Ă��Ă��A
    '�֌W�C�x���g�����ł͔z��ҍs������ǂނ��߁AC_�`�F�b�N�Ōx�����Ė�������B

    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wp.Cells(r, P_ID).Value)) > 0 Then
            pid = CStr(wp.Cells(r, P_ID).Value)
            If HasInputDate(wp.Cells(r, P_BIRTH).Value) Then AddEvent pid, SameDateOrBlank(wp.Cells(r, P_BIRTH).Value), "�o��", "�o��", "����", "�l��", pid
            If HasInputDate(wp.Cells(r, P_DEATH).Value) Then AddEvent pid, SameDateOrBlank(wp.Cells(r, P_DEATH).Value), "���S", "�v", "����", "�l��", pid
            If HasInputDate(wp.Cells(r, P_MARRIAGE).Value) Then
                If Not HasSpouseRelationEventForPersonDate(pid, wp.Cells(r, P_MARRIAGE).Value, "����") _
                        And Not HasMarriageHistoryEventForPersonDate(pid, wp.Cells(r, P_MARRIAGE).Value, "����") Then _
                    AddEvent pid, wp.Cells(r, P_MARRIAGE).Value, "����", "����", "����", "�l��", pid & "|����"
            End If
            If HasInputDate(wp.Cells(r, P_DIVORCE).Value) Then
                If Not HasSpouseRelationEventForPersonDate(pid, wp.Cells(r, P_DIVORCE).Value, "����") _
                        And Not HasMarriageHistoryEventForPersonDate(pid, wp.Cells(r, P_DIVORCE).Value, "����") Then _
                    AddEvent pid, wp.Cells(r, P_DIVORCE).Value, "����", "����", "����", "�l��", pid & "|����"
            End If
        End If
    Next r

    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And DiagramGraphIsSpouseRelationType(CStr(wr.Cells(r, R_TYPE).Value)) Then
            pid = CStr(wr.Cells(r, R_BASE_ID).Value)
            otherId = CStr(wr.Cells(r, R_OTHER_ID).Value)
            If Len(pid) > 0 And Len(otherId) > 0 And pid <> otherId _
                    And FindPersonRow(pid) > 0 And FindPersonRow(otherId) > 0 Then
                If HasInputDate(wr.Cells(r, R_MARRIAGE).Value) Then
                    AddEvent pid, wr.Cells(r, R_MARRIAGE).Value, "����", "����", "����", "�֌W", wr.Cells(r, R_ID).Value
                    AddEvent otherId, wr.Cells(r, R_MARRIAGE).Value, "����", "����", "����", "�֌W", wr.Cells(r, R_ID).Value
                End If
                If HasInputDate(wr.Cells(r, R_DIVORCE).Value) Then
                    AddEvent pid, wr.Cells(r, R_DIVORCE).Value, "����", "�����F" & GetPersonValue(otherId, P_DISPLAY), "����", "�֌W", wr.Cells(r, R_ID).Value
                    AddEvent otherId, wr.Cells(r, R_DIVORCE).Value, "����", "�����F" & GetPersonValue(pid, P_DISPLAY), "����", "�֌W", wr.Cells(r, R_ID).Value
                End If
            End If
        End If
    Next r

    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    For r = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
            pid = CStr(wa.Cells(r, A_PERSON_ID).Value)
            If Len(pid) > 0 And FindPersonRow(pid) > 0 Then
                If HasInputDate(wa.Cells(r, A_START).Value) Then
                    AddEvent pid, wa.Cells(r, A_START).Value, _
                        AddressStartEventType(wa, r), AddressStartEventContent(wa, r), "����", "�Z��", wa.Cells(r, A_ID).Value
                End If
                If HasInputDate(wa.Cells(r, A_END).Value) Then
                    If Not IsPersonDeathDate(pid, wa.Cells(r, A_END).Value) Then
                        AddEvent pid, wa.Cells(r, A_END).Value, _
                            "���Z�I��", "���Z�I���F" & wa.Cells(r, A_TEXT).Value, "����", "�Z��", wa.Cells(r, A_ID).Value
                    End If
                End If
            End If
        End If
    Next r
    stepText = "�푊���l�擾"
    decId = GetDecedentId()
    inhDate = GetInheritanceDate()
    If Len(decId) > 0 And HasInputDate(inhDate) Then
        decDeathValue = GetPersonValue(decId, P_DEATH)
        addInheritanceEvent = True
        If HasInputDate(decDeathValue) Then
            If CLng(CDate(SameDateOrBlank(decDeathValue))) = CLng(CDate(SameDateOrBlank(inhDate))) Then addInheritanceEvent = False
        End If
        If addInheritanceEvent Then AddEvent decId, inhDate, "�����J�n", "�����J�n", "����", "�ݒ�", "�����J�n��"
    End If
    CompactTimelineDisplayEvents we
End Sub

Private Sub AddMarriageHistoryEvents(ByVal we As Worksheet)
    Dim mh As Worksheet, r As Long, pid As String, cpId As String, cpName As String, mhId As String
    If we Is Nothing Then Exit Sub
    EnsureMarriageHistoryWorkSheet
    BackfillMarriageHistoryFromLegacyFacts
    Set mh = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(mh, 1)
        If CStr(mh.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL _
                And CStr(mh.Cells(r, MH_SHOW).Value) <> SHOW_NO _
                And Len(CStr(mh.Cells(r, MH_ID).Value)) > 0 Then
            mhId = CStr(mh.Cells(r, MH_ID).Value)
            pid = CStr(mh.Cells(r, MH_PERSON_ID).Value)
            cpId = CStr(mh.Cells(r, MH_COUNTERPART_ID).Value)
            cpName = CleanText(mh.Cells(r, MH_COUNTERPART_NAME).Value)
            If Len(cpName) = 0 And Len(cpId) > 0 Then cpName = GetPersonValue(cpId, P_DISPLAY)
            If HasInputDate(mh.Cells(r, MH_MARRIAGE).Value) Then
                AddEvent pid, mh.Cells(r, MH_MARRIAGE).Value, "����", "����", "����", "��������", mhId
                If Len(cpId) > 0 Then AddEvent cpId, mh.Cells(r, MH_MARRIAGE).Value, "����", "����", "����", "��������", mhId
            End If
            If HasInputDate(mh.Cells(r, MH_DIVORCE).Value) Then
                AddEvent pid, mh.Cells(r, MH_DIVORCE).Value, "����", DivorceContentText(cpName), "����", "��������", mhId
                If Len(cpId) > 0 Then AddEvent cpId, mh.Cells(r, MH_DIVORCE).Value, "����", DivorceContentText(GetPersonValue(pid, P_DISPLAY)), "����", "��������", mhId
            End If
        End If
    Next r
End Sub

Private Function DivorceContentText(ByVal counterpartName As String) As String
    counterpartName = CleanText(counterpartName)
    If Len(counterpartName) > 0 Then
        DivorceContentText = "�����F" & counterpartName
    Else
        DivorceContentText = "����"
    End If
End Function

Private Function HasMarriageHistoryEventForPersonDate(ByVal personId As String, _
        ByVal eventDate As Variant, _
        ByVal eventType As String) As Boolean
    Dim mh As Worksheet, r As Long, d As Variant
    If Len(personId) = 0 Or Not HasInputDate(eventDate) Then Exit Function
    EnsureMarriageHistoryWorkSheet
    BackfillMarriageHistoryFromLegacyFacts
    Set mh = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(mh, 1)
        If CStr(mh.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL _
                And CStr(mh.Cells(r, MH_SHOW).Value) <> SHOW_NO Then
            If CStr(mh.Cells(r, MH_PERSON_ID).Value) = personId Or CStr(mh.Cells(r, MH_COUNTERPART_ID).Value) = personId Then
                If eventType = "����" Then
                    d = mh.Cells(r, MH_MARRIAGE).Value
                Else
                    d = mh.Cells(r, MH_DIVORCE).Value
                End If
                If HasInputDate(d) Then
                    If CLng(CDate(SameDateOrBlank(d))) = CLng(CDate(SameDateOrBlank(eventDate))) Then
                        HasMarriageHistoryEventForPersonDate = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function HasSpouseRelationEventForPersonDate(ByVal personId As String, _
        ByVal eventDate As Variant, _
        ByVal eventType As String) As Boolean

    Dim wr As Worksheet, r As Long, d As Variant
    If Len(personId) = 0 Or Not HasInputDate(eventDate) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL _
                And DiagramGraphIsSpouseRelationType(CStr(wr.Cells(r, R_TYPE).Value)) Then
            If CStr(wr.Cells(r, R_BASE_ID).Value) = personId _
                    Or CStr(wr.Cells(r, R_OTHER_ID).Value) = personId Then
                If eventType = "����" Then
                    d = wr.Cells(r, R_MARRIAGE).Value
                Else
                    d = wr.Cells(r, R_DIVORCE).Value
                End If
                If HasInputDate(d) Then
                    If CLng(CDate(SameDateOrBlank(d))) = CLng(CDate(SameDateOrBlank(eventDate))) Then
                        HasSpouseRelationEventForPersonDate = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r

End Function

Private Sub CompactTimelineDisplayEvents(ByVal ws As Worksheet)
    '�\���㓯��̃C�x���g��1���ɏW�񂷂�B���łō��ꂽ�d���������Ŕ�\��������B
    Dim seen As Object, r As Long, key As String
    If ws Is Nothing Then Exit Sub
    Set seen = CreateObject("Scripting.Dictionary")
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, E_STATUS).Value) <> STATUS_CANCEL _
                And Len(CStr(ws.Cells(r, E_PERSON_ID).Value)) > 0 _
                And HasInputDate(ws.Cells(r, E_DATE).Value) Then
            key = CStr(ws.Cells(r, E_PERSON_ID).Value) & "|" & _
                Format(SameDateOrBlank(ws.Cells(r, E_DATE).Value), "yyyymmdd") & "|" & _
                CStr(ws.Cells(r, E_TYPE).Value) & "|" & CStr(ws.Cells(r, E_CONTENT).Value)
            If seen.Exists(key) Then
                ws.Cells(r, E_STATUS).Value = STATUS_CANCEL
                ws.Cells(r, E_SHOW).Value = SHOW_NO
            Else
                seen.Add key, True
            End If
        End If
    Next r
End Sub

Private Function AddressStartEventType(ByVal wsA As Worksheet, ByVal rowNo As Long) As String
    Dim kindText As String
    kindText = CleanText(wsA.Cells(rowNo, A_START_KIND).Value)
    If kindText = "�c����" Then
        AddressStartEventType = "���Z�c��"
    Else
        AddressStartEventType = "���Z�J�n"
    End If
End Function

Private Function AddressStartEventContent(ByVal wsA As Worksheet, ByVal rowNo As Long) As String
    AddressStartEventContent = AddressStartEventType(wsA, rowNo) & "�F" & wsA.Cells(rowNo, A_TEXT).Value
End Function

Private Function IsFirstAddressHistoryRowForPerson(ByVal wsA As Worksheet, ByVal rowNo As Long) As Boolean
    Dim pid As String, r As Long, st As Variant, bestR As Long
    If wsA Is Nothing Then Exit Function
    pid = CStr(wsA.Cells(rowNo, A_PERSON_ID).Value)
    st = wsA.Cells(rowNo, A_START).Value
    For r = 2 To LastRow(wsA, 1)
        If CStr(wsA.Cells(r, A_PERSON_ID).Value) = pid _
                And CStr(wsA.Cells(r, A_STATUS).Value) <> STATUS_CANCEL _
                And Len(CStr(wsA.Cells(r, A_ID).Value)) > 0 Then
            If bestR = 0 Then
                bestR = r
            ElseIf HasInputDate(wsA.Cells(r, A_START).Value) And HasInputDate(wsA.Cells(bestR, A_START).Value) Then
                If CDate(SameDateOrBlank(wsA.Cells(r, A_START).Value)) < CDate(SameDateOrBlank(wsA.Cells(bestR, A_START).Value)) Then bestR = r
            ElseIf HasInputDate(wsA.Cells(r, A_START).Value) And Not HasInputDate(wsA.Cells(bestR, A_START).Value) Then
                bestR = r
            End If
        End If
    Next r
    IsFirstAddressHistoryRowForPerson = (bestR = rowNo)
End Function

Private Function PreserveManualTimelineEvents(ByVal ws As Worksheet) As Collection
    Dim col As New Collection, r As Long, c As Long
    Dim arr As Variant
    If ws Is Nothing Then
        Set PreserveManualTimelineEvents = col
        Exit Function
    End If
    For r = 2 To LastRow(ws, 1)
        If Len(CStr(ws.Cells(r, E_ID).Value)) > 0 _
                And CStr(ws.Cells(r, E_STATUS).Value) <> STATUS_CANCEL _
                And CStr(ws.Cells(r, E_AUTO).Value) <> "����" Then
            ReDim arr(1 To 12)
            For c = 1 To 12
                arr(c) = ws.Cells(r, c).Value
            Next c
            col.Add arr
        End If
    Next r
    Set PreserveManualTimelineEvents = col
End Function

Private Sub RestoreManualTimelineEvents(ByVal ws As Worksheet, ByVal events As Collection)
    Dim item As Variant, r As Long, c As Long
    If ws Is Nothing Then Exit Sub
    If events Is Nothing Then Exit Sub
    For Each item In events
        r = NextBlankRow(ws, 1)
        For c = 1 To 12
            ws.Cells(r, c).Value = item(c)
        Next c
    Next item
End Sub


Private Function IsPersonDeathDate(ByVal personId As String, ByVal v As Variant) As Boolean
    Dim d As Variant
    If Len(personId) = 0 Or Not HasInputDate(v) Then Exit Function
    d = GetPersonValue(personId, P_DEATH)
    If HasInputDate(d) Then IsPersonDeathDate = (CLng(CDate(SameDateOrBlank(d))) = CLng(CDate(SameDateOrBlank(v))))
End Function

Private Sub AddEvent(ByVal personId As String, _
        ByVal eventDate As Variant, _
        ByVal eventType As String, _
        ByVal content As String, _
        ByVal autoFlag As String, _
        ByVal srcType As String, _
        ByVal srcId As String)
    Dim ws As Worksheet, r As Long
    If Len(CStr(personId)) = 0 Or Not HasInputDate(eventDate) Then Exit Sub
    If FindPersonRow(CStr(personId)) = 0 Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_EVENT)
    If TimelineEventExists(ws, CStr(personId), eventDate, eventType, content, srcType, srcId) Then Exit Sub
    r = NextBlankRow(ws, 1)
    ws.Cells(r, E_ID).Value = NextId("�C�x���g")
    ws.Cells(r, E_PERSON_ID).Value = personId
    ws.Cells(r, E_DATE).Value = SameDateOrBlank(eventDate)
    ws.Cells(r, E_YEAR).Value = Year(CDate(SameDateOrBlank(eventDate)))
    ws.Cells(r, E_TYPE).Value = eventType
    ws.Cells(r, E_CONTENT).Value = content
    ws.Cells(r, E_AUTO).Value = autoFlag
    ws.Cells(r, E_SOURCE_TYPE).Value = srcType
    ws.Cells(r, E_SOURCE_ID).Value = srcId
    ws.Cells(r, E_SHOW).Value = SHOW_YES
    ws.Cells(r, E_STATUS).Value = STATUS_ACTIVE
End Sub

Private Function TimelineEventExists(ByVal ws As Worksheet, _
        ByVal personId As String, _
        ByVal eventDate As Variant, _
        ByVal eventType As String, _
        ByVal content As String, _
        ByVal srcType As String, _
        ByVal srcId As String) As Boolean
    '�����l���E�������t�E������ށE�����\�����e�́A�ۑ��o�H������Ă�1���ɏW�񂷂�B
    '�z��ғo�^�A������ǉ��A�l�����̍������������������d�������Ȃ����߁B
    Dim r As Long
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, E_PERSON_ID).Value) = personId Then
            If HasInputDate(ws.Cells(r, E_DATE).Value) And HasInputDate(eventDate) Then
                If CLng(CDate(SameDateOrBlank(ws.Cells(r, E_DATE).Value))) = CLng(CDate(SameDateOrBlank(eventDate))) Then
                    If CStr(ws.Cells(r, E_TYPE).Value) = eventType _
                            And CStr(ws.Cells(r, E_CONTENT).Value) = content _
                            And CStr(ws.Cells(r, E_STATUS).Value) <> STATUS_CANCEL Then
                        TimelineEventExists = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Public Sub ShowAddressHistoryOutput()
    On Error GoTo EH
    AppBegin
    RefreshRepresentativeAddresses
    BuildAddressHistoryTable
    ApplyOutputUsability
    ShowOnlyInputCore False
    ThisWorkbook.Worksheets(SH_ADDR_TABLE).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_ADDR_TABLE).Activate
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowAddressHistoryOutput", "�Z������\��", "�Z�������V�[�g�E�Z�������f�[�^�̏�Ԃ��m�F���Ă��������B"
End Sub

Public Sub ShowRelationshipDiagramOutput()
    On Error GoTo EH
    AppBegin "�����֌W�}���쐬��..."
    '�o�͎��� W_�l�� �̑����𒼐ڏ��������Ȃ��B�����֌W�}�E���n��E���ʕۑ��͕\���p���f���ŉ��߂���B
    RefreshRepresentativeAddresses
    BuildRelationshipDiagram
    ApplyOutputUsability
    ShowOnlyInputCore False
    ThisWorkbook.Worksheets(SH_DIAGRAM).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_DIAGRAM).Activate
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowRelationshipDiagramOutput", "�����֌W�}�쐬", _
        "�푊���l�A�֌W�ҁA�}�\���ݒ�A�o�̓V�[�g�̏�Ԃ��m�F���Ă��������B"
End Sub

Public Sub ShowTimelineOutput()
    On Error GoTo EH
    AppBegin "���n��\���쐬��..."
    '�o�͎��� W_�l�� �̑����𒼐ڏ��������Ȃ��B�����֌W�}�E���n��E���ʕۑ��͕\���p���f���ŉ��߂���B
    RefreshRepresentativeAddresses
    GenerateEvents
    BuildTimelineTable
    ApplyOutputUsability
    ShowOnlyInputCore False
    ThisWorkbook.Worksheets(SH_TIMELINE).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_TIMELINE).Activate
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowTimelineOutput", "���n��\�쐬", _
        "�l���A���N�����E���S���A�������A�Z���J�n���E�I�����̏�Ԃ��m�F���Ă��������B"
End Sub

Private Sub BuildRelationshipDiagram()
    On Error GoTo EH
    Dim ws As Worksheet
    Dim decId As String, decRow As Long, spouseRow As Long, fatherRow As Long, motherRow As Long
    Dim decShape As Shape, spouseShape As Shape, fatherShape As Shape, motherShape As Shape
    Dim children As Collection, siblings As Collection, drawn As Object
    Dim plan As RelationshipDiagramPlan
    Dim parentY As Double, decY As Double, childTop As Double
    Dim decX As Double, spouseX As Double, parentOriginX As Double, parentOriginY As Double
    Dim coupleOriginX As Double, coupleOriginY As Double
    Dim maxBottom As Double
    Dim hasParents As Boolean, titleLastCol As Long, buttonLeftCol As Long
    Dim stepText As String, failedCount As Long, errNum As Long, errDesc As String, errSrc As String

    mRelationshipDiagramLastFailed = False
    mDiagramCardsOnly = False
    mDiagramStrictLineMode = False
    stepText = "�o�̓V�[�g�擾"
    Set ws = ThisWorkbook.Worksheets(SH_DIAGRAM)
    stepText = "�V�[�g������"
    ClearSheetAll ws
    ApplySheetCanvas ws
    Set drawn = CreateObject("Scripting.Dictionary")
    '�����֌W�}�ł� W_�l�� �̑����𒼐ڏ��������Ȃ��B
    '���̓f�[�^��ǂݎ��A�����֌W�}��p�̊m��e�����f��������Ă���`�悷��B
    mRelationshipDiagramHasPlan = False
    mRelationshipDiagramLandscape = True
    mRelationshipDiagramFitWideHint = 1

    decId = GetDecedentId()
    If Len(decId) > 0 Then
        stepText = "�����֌W�}���f���\�z"
        If Not DiagramGraphRebuildFresh(decId, True) Then Err.Raise vbObjectError + 901, "BuildRelationshipDiagram", "�����֌W�}���f�����\�z�ł��܂���ł����BC_�`�F�b�N�̃��f���f�f���m�F���Ă��������B"
        DiagramGraphWriteDiagnostics decId
    Else
        DiagramGraphReset
    End If
    decRow = FindPersonRow(decId)
    If decRow = 0 Then
        PrepareSimpleRelationshipDiagramPage ws, True
        ws.Range("A1:Q1").Merge
        TitleBannerStyle ws.Range("A1:Q1"), "�����֌W�}"
        ws.Range("A4:Q8").Merge
        ws.Range("A4").Value = "�푊���l�����o�^�ł��B"
        ws.Range("A4").Interior.Color = ThemeColor("danger-soft")
        ws.Range("A4").Font.Color = ThemeColor("red")
        ws.Range("A4").Font.Bold = True
        ThemeApplyMonochromePrint ws, "$A$1:$Q$10", True, "", 1, 0
        Exit Sub
    End If

    stepText = "�l���֌W�擾"
    spouseRow = GetSpouseRowOfPerson(decId)
    fatherRow = GetFatherRowForDiagram(decId)
    motherRow = GetMotherRowForDiagram(decId, fatherRow)
    Set children = GetRootChildRows(decId)
    Set siblings = GetSiblingRowsForPerson(decId)
    AuditRelationshipDiagramBeforeBuild decId
    stepText = "���C�A�E�g�v��"
    plan = BuildRelationshipDiagramPlan(decId, decRow, spouseRow, fatherRow, motherRow, children, siblings)

    stepText = "�y�[�W�ݒ�"
    ApplyRelationshipDiagramPageSetup ws, plan
    PrepareRelationshipDiagramGrid ws, plan
    titleLastCol = Application.Max(16, PrintColumnForRightPoint(ws, Application.Max(plan.PageRight, plan.PageLeft + plan.RootWidth + 42)))
    ws.Range(ws.Cells(1, 1), ws.Cells(1, titleLastCol)).Merge
    TitleBannerStyle ws.Range(ws.Cells(1, 1), ws.Cells(1, titleLastCol)), "�����֌W�}"
    buttonLeftCol = Application.Max(1, titleLastCol - 1)
    '�����֌W�}�͈�����[�ł���A������̍��������₷�邽�ߖ߂�{�^���͐}�ʏ�֔z�u���Ȃ��B
    '��ʑJ�ڂ̓V�[�g�^�u�܂��͓��͉�ʑ��̃i�r�Q�[�V�������g���B

    hasParents = (fatherRow > 0 Or motherRow > 0)
    If hasParents Then
        parentY = 46
        decY = parentY + plan.CardH + plan.RowGap
    Else
        parentY = 0
        decY = 50
    End If
    childTop = decY + plan.CardH + plan.RowGap

    decX = DecedentLeftForRootGeneration(decRow, spouseRow, siblings, plan.PageCenter, plan.CardW, plan.CoupleGap, plan.BlockGap)
    If spouseRow > 0 Then
        spouseX = decX + plan.CardW + plan.CoupleGap
    Else
        spouseX = 0
    End If

    '�������C�A�E�g�����̓J�[�h�̍��W�v�Z�����Ɏg���B
    '���͑S�J�[�h�z�u��A�Ƒ��������f����ID�֌W����ꊇ��������B
    mDiagramCardsOnly = True
    stepText = "�e����`��"
    If fatherRow > 0 And motherRow > 0 Then
        Set fatherShape = DrawTreeCard(ws, fatherRow, ShapeCenterTargetX(decX, plan.CardW) - plan.CardW - plan.CoupleGap / 2, parentY, plan.CardW, plan.CardH, drawn)
        Set motherShape = DrawTreeCard(ws, motherRow, ShapeCenterTargetX(decX, plan.CardW) + plan.CoupleGap / 2, parentY, plan.CardW, plan.CardH, drawn)
        ConnectHorizontalCouple ws, fatherShape, motherShape, parentOriginX, parentOriginY
    ElseIf fatherRow > 0 Then
        Set fatherShape = DrawTreeCard(ws, fatherRow, ShapeCenterTargetX(decX, plan.CardW) - plan.CardW / 2, parentY, plan.CardW, plan.CardH, drawn)
        If Not fatherShape Is Nothing Then
            parentOriginX = ShapeCenterX(fatherShape)
            parentOriginY = fatherShape.Top + fatherShape.Height
        End If
    ElseIf motherRow > 0 Then
        Set motherShape = DrawTreeCard(ws, motherRow, ShapeCenterTargetX(decX, plan.CardW) - plan.CardW / 2, parentY, plan.CardW, plan.CardH, drawn)
        If Not motherShape Is Nothing Then
            parentOriginX = ShapeCenterX(motherShape)
            parentOriginY = motherShape.Top + motherShape.Height
        End If
    End If

    stepText = "�e���ォ��Z��o���ւ̐��`��"
    If hasParents Then
        DrawParentToRootGenerationLines ws, parentOriginX, parentOriginY, decX, decY, plan.CardW, plan.CoupleGap, plan.BlockGap, spouseRow, siblings
    End If

    stepText = "�푊���l�E�z��ҁE�Z��o���`��"
    Set decShape = DrawTreeCard(ws, decRow, decX, decY, plan.CardW, plan.CardH, drawn)
    If decShape Is Nothing Then Err.Raise vbObjectError + 781, "BuildRelationshipDiagram", "�푊���l�J�[�h���쐬�ł��܂���ł����B"
    If spouseRow > 0 Then
        Set spouseShape = DrawTreeCard(ws, spouseRow, spouseX, decY, plan.CardW, plan.CardH, drawn)
        If Not spouseShape Is Nothing Then
            ConnectHorizontalCouple ws, decShape, spouseShape, coupleOriginX, coupleOriginY
        End If
    Else
        coupleOriginX = ShapeCenterX(decShape)
        coupleOriginY = decShape.Top + decShape.Height
    End If
    DrawRootSiblingCards ws, siblings, decRow, decX, decY, plan.CardW, plan.CardH, plan.CoupleGap, plan.BlockGap, spouseRow, drawn, Not hasParents
    maxBottom = decY + plan.CardH

    stepText = "�q���u���b�N�`��"
    maxBottom = DrawRootChildrenRowsSafe(ws, decId, children, plan, childTop, maxBottom, _
        decShape, spouseShape, coupleOriginX, coupleOriginY, drawn)

    stepText = "���ڑ��l���m�F"
    maxBottom = DrawRemainingVisiblePersons(ws, drawn, plan.PageLeft, maxBottom + Application.Max(44, plan.RowGap * 0.48), plan.CardW, plan.CardH, plan.BlockGap, Application.Max(plan.PageRight, plan.PageLeft + plan.RootWidth + 80))
    mDiagramCardsOnly = False
    stepText = "����͈͐��`"
    ShiftPrintableDiagramShapesLeft ws, plan.PageLeft
    stepText = "�Ƒ��������f��������𐶐�"
    DrawFamilyModelDiagramConnectors ws, decId, siblings
    stepText = "�d�グ"
    PolishRelationshipDiagramOutput ws
    WarnDiagramIfCardCollisions ws
    WarnDiagramIfPrintBoundsRisk ws
    ThemeLockShapeLayer ws
    Exit Sub
EH:
    errNum = Err.Number
    errDesc = Err.Description
    errSrc = Err.Source
    mDiagramCardsOnly = False
    mDiagramStrictLineMode = False
    mRelationshipDiagramLastFailed = True
    AppendRelationshipDiagramBuildFailure stepText, errNum, errDesc, errSrc
    On Error Resume Next
    If Not ws Is Nothing Then
        ClearSheetAll ws
        PrepareSimpleRelationshipDiagramPage ws, True
        ws.Range("A1:Q1").Merge
        TitleBannerStyle ws.Range("A1:Q1"), "�����֌W�}"
        ws.Range("A4:Q6").Merge
        ws.Range("A4").Value = "�����֌W�}�̍쐬�Ɏ��s���܂����BC_�`�F�b�N�̒�~�H�����m�F���Ă��������B"
        ws.Range("A4").Interior.Color = ThemeColor("danger-soft")
        ws.Range("A4").Font.Color = ThemeColor("red")
        ws.Range("A4").Font.Bold = True
        ThemeApplyMonochromePrint ws, "$A$1:$Q$8", True, "", 1, 0
    End If
    On Error GoTo 0
End Sub

Private Sub AppendRelationshipDiagramBuildFailure(ByVal stepText As String, ByVal errNum As Long, ByVal errDesc As String, ByVal errSrc As String)
    Dim wsC As Worksheet, outR As Long
    On Error Resume Next
    RuntimeAppendLog "ERROR", "�����֌W�}", stepText, errDesc, errNum, errDesc, errSrc
    If SheetExists(SH_CHECK, ThisWorkbook) Then
        Set wsC = ThisWorkbook.Worksheets(SH_CHECK)
        outR = LastRow(wsC, 1) + 1
        If outR < 4 Then outR = 4
        AddCheck wsC, outR, "�G���[", "�����֌W�}�̍쐬���ɒ�~���܂����B�H��=" & stepText & " / " & errDesc, _
            "", "", "�����֌W�}", "C_�`�F�b�N�̍H���Ɛl���֌W�E�Z���������m�F"
    End If
    On Error GoTo 0
End Sub

Private Sub PrepareSimpleRelationshipDiagramPage(ByVal ws As Worksheet, ByVal landscape As Boolean)
    If ws Is Nothing Then Exit Sub
    With ws.PageSetup
        .PaperSize = xlPaperA4
        If landscape Then
            .Orientation = xlLandscape
        Else
            .Orientation = xlPortrait
        End If
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .LeftMargin = Application.CentimetersToPoints(0.35)
        .RightMargin = Application.CentimetersToPoints(0.35)
        .TopMargin = Application.CentimetersToPoints(0.35)
        .BottomMargin = Application.CentimetersToPoints(0.35)
        .PrintArea = ""
    End With
    ws.Range(ws.Cells(1, 1), ws.Cells(1, 32)).EntireColumn.ColumnWidth = 5.2
    ws.Range(ws.Cells(1, 1), ws.Cells(180, 1)).EntireRow.RowHeight = 14.2
End Sub

Private Function DrawRootChildrenRowsSafe(ByVal ws As Worksheet, _
        ByVal decId As String, _
        ByVal children As Collection, _
        ByRef plan As RelationshipDiagramPlan, _
        ByVal firstChildTop As Double, _
        ByVal currentMaxBottom As Double, _
        ByVal decShape As Shape, _
        ByVal spouseShape As Shape, _
        ByVal coupleOriginX As Double, _
        ByVal coupleOriginY As Double, _
        ByVal drawn As Object) As Double
    Dim childTop As Double, maxBottom As Double
    Dim idx As Long, rowStart As Long, i As Long
    Dim rowW As Double, w As Double, startX As Double, x As Double
    Dim branchY As Double, blockW As Double, blockBottom As Double

    On Error GoTo EH
    maxBottom = currentMaxBottom
    childTop = firstChildTop
    If children Is Nothing Then
        DrawRootChildrenRowsSafe = maxBottom
        Exit Function
    End If

    idx = 1
    Do While idx <= children.Count
        rowStart = idx
        rowW = 0
        Do While idx <= children.Count
            w = SafeRootChildBlockWidth(children(idx), plan.CardW, plan.CardH, plan.CoupleGap, plan.BlockGap)
            If rowW > 0 Then
                If rowW + plan.BlockGap + w > plan.PageWidth Then Exit Do
                rowW = rowW + plan.BlockGap
            End If
            rowW = rowW + w
            idx = idx + 1
        Loop
        If rowW <= 0 Then
            rowW = plan.CardW
            idx = idx + 1
        End If
        startX = plan.PageCenter - rowW / 2
        If startX < plan.PageLeft Then startX = plan.PageLeft
        branchY = childTop - DiagramBranchOffsetForDepth(0)
        x = startX
        For i = rowStart To idx - 1
            blockW = SafeRootChildBlockWidth(children(i), plan.CardW, plan.CardH, plan.CoupleGap, plan.BlockGap)
            blockBottom = DrawRootChildDescendantBlockSafe(ws, decId, children(i), x, childTop, branchY, _
                plan.CardW, plan.CardH, plan.CoupleGap, plan.BlockGap, decShape, spouseShape, _
                coupleOriginX, coupleOriginY, drawn)
            If blockBottom > maxBottom Then maxBottom = blockBottom
            x = x + blockW + plan.BlockGap
        Next i
        childTop = maxBottom + Application.Max(plan.RowGap, 42)
        '�v�w���̒����͏�ɃJ�[�h�Ԃ̌�������ɌŒ肷��B
        '���s�֐i�߂邽�߂� branchY �֍X�V����ƁA2�s�ڈȍ~�̐e�q�����v�w�Ԃ���L�тȂ��Ȃ�B
    Loop

    DrawRootChildrenRowsSafe = maxBottom
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning "�q���u���b�N�`��", "���n�q�S�̂��ꕔ�X�L�b�v���Čp��: " & Err.Description
    Err.Clear
    If currentMaxBottom >= firstChildTop + plan.CardH Then
        DrawRootChildrenRowsSafe = currentMaxBottom
    Else
        DrawRootChildrenRowsSafe = firstChildTop + plan.CardH
    End If
End Function

Private Function BuildRelationshipDiagramPlan(ByVal decId As String, _
        ByVal decRow As Long, _
        ByVal spouseRow As Long, _
        ByVal fatherRow As Long, _
        ByVal motherRow As Long, _
        ByVal children As Collection, _
        ByVal siblings As Collection) As RelationshipDiagramPlan
    Dim plan As RelationshipDiagramPlan
    Dim childWidth As Double, rootOwnWidth As Double, parentWidth As Double, siblingWidth As Double
    Dim compactFamily As Boolean, wideFamily As Boolean, deepFamily As Boolean

    plan.PersonCount = CountVisibleDiagramPersons()
    plan.MaxDepth = MaxDescendantDepthForPerson(decId, CreateObject("Scripting.Dictionary"), 0)
    plan.MaxSiblings = Application.Max(MaxSiblingCountForPerson(decId, CreateObject("Scripting.Dictionary")), SiblingRowsCount(siblings) + 1)

    '6�l���x�̒��n�}�������y�[�W�Ɋ����̂͒��[�Ƃ��ĕs�K�؂Ȃ̂ŁA�܂��R���p�N�g�Ȏ����őg�ށB
    '�������ɒ[�ɏ����������A�J�[�h1����1�}�`�ɂ��č����Ɛ���Ԋu�̔�剻��}����B
    compactFamily = (plan.PersonCount <= 10 And plan.MaxDepth >= 2 And SiblingRowsCount(siblings) <= 1)
    wideFamily = (plan.MaxSiblings >= 5 Or SiblingRowsCount(siblings) >= 3)
    deepFamily = (plan.MaxDepth >= 3)

    If compactFamily Then
        plan.CardW = 156
        plan.CardH = 96
        plan.CoupleGap = 10
        plan.BlockGap = 14
        plan.RowGap = 18
    ElseIf plan.PersonCount <= 14 Then
        plan.CardW = 166
        plan.CardH = 100
        plan.CoupleGap = 12
        plan.BlockGap = 18
        plan.RowGap = 24
    ElseIf plan.PersonCount <= 22 Then
        plan.CardW = 180
        plan.CardH = 108
        plan.CoupleGap = 16
        plan.BlockGap = 26
        plan.RowGap = 34
    Else
        plan.CardW = 190
        plan.CardH = 116
        plan.CoupleGap = 18
        plan.BlockGap = 32
        plan.RowGap = 40
    End If

    '�J�[�h�͏��ʂɉ����ĐL�΂����A���Ƒ��ŉߑ剻���Ȃ��悤�����}����B
    plan.CardH = Application.Max(plan.CardH, DiagramCardHeightFromLines(MaxDiagramCardVisualLineCount(plan.CardW)))
    If compactFamily Then plan.CardH = Application.Min(plan.CardH, 118)

    childWidth = CollectionFamilyTreeWidth(children, plan.CardW, plan.CardH, plan.CoupleGap, plan.BlockGap, 1)
    rootOwnWidth = plan.CardW
    If spouseRow > 0 Then rootOwnWidth = plan.CardW * 2 + plan.CoupleGap
    siblingWidth = RootGenerationWidth(spouseRow, siblings, plan.CardW, plan.CoupleGap, plan.BlockGap)
    parentWidth = 0
    If fatherRow > 0 And motherRow > 0 Then
        parentWidth = plan.CardW * 2 + plan.CoupleGap
    ElseIf fatherRow > 0 Or motherRow > 0 Then
        parentWidth = plan.CardW
    End If
    plan.RootWidth = Application.Max(Application.Max(rootOwnWidth, siblingWidth), Application.Max(parentWidth, childWidth))

    plan.IsLandscape = True
    If deepFamily And Not wideFamily And plan.RootWidth <= 520 And plan.PersonCount > 10 Then plan.IsLandscape = False
    If plan.RootWidth > 620 Or SiblingRowsCount(siblings) >= 2 Then plan.IsLandscape = True

    plan.PageLeft = 30
    If plan.IsLandscape Then
        plan.PageRight = 790
    Else
        plan.PageRight = 560
    End If
    plan.PageWidth = plan.PageRight - plan.PageLeft
    If plan.RootWidth > plan.PageWidth * 1.08 Then
        plan.IsLandscape = True
        plan.PageRight = 790
        plan.PageWidth = plan.PageRight - plan.PageLeft
    End If
    plan.PageCenter = plan.PageLeft + plan.PageWidth / 2
    plan.FitWideHint = PagesNeededForPointWidth(plan.RootWidth + 36, plan.IsLandscape)
    If plan.FitWideHint < 1 Then plan.FitWideHint = 1
    If compactFamily Then plan.FitWideHint = 1

    mRelationshipDiagramHasPlan = True
    mRelationshipDiagramLandscape = plan.IsLandscape
    mRelationshipDiagramFitWideHint = plan.FitWideHint
    BuildRelationshipDiagramPlan = plan
End Function

Private Sub ApplyRelationshipDiagramPageSetup(ByVal ws As Worksheet, ByRef plan As RelationshipDiagramPlan)
    If ws Is Nothing Then Exit Sub
    With ws.PageSetup
        .PaperSize = xlPaperA4
        If plan.IsLandscape Then
            .Orientation = xlLandscape
        Else
            .Orientation = xlPortrait
        End If
        .Zoom = False
        .FitToPagesWide = Application.Max(1, plan.FitWideHint)
        If plan.PersonCount <= 10 Then
            .FitToPagesTall = 1
        Else
            .FitToPagesTall = False
        End If
        .LeftMargin = Application.CentimetersToPoints(0.3)
        .RightMargin = Application.CentimetersToPoints(0.3)
        .TopMargin = Application.CentimetersToPoints(0.3)
        .BottomMargin = Application.CentimetersToPoints(0.3)
        .HeaderMargin = Application.CentimetersToPoints(0.12)
        .FooterMargin = Application.CentimetersToPoints(0.12)
        .PrintArea = ""
    End With
End Sub

Private Sub PrepareRelationshipDiagramGrid(ByVal ws As Worksheet, ByRef plan As RelationshipDiagramPlan)
    Dim initCols As Long, initRows As Long
    If ws Is Nothing Then Exit Sub
    initCols = 30
    If plan.IsLandscape Then initCols = 38
    If plan.RootWidth > plan.PageWidth Then initCols = initCols + CLng((plan.RootWidth - plan.PageWidth) / 32) + 3
    If initCols < 22 Then initCols = 22
    If initCols > 100 Then initCols = 100
    initRows = 110
    If plan.MaxDepth >= 3 Then initRows = 140
    If plan.MaxDepth >= 5 Or plan.PersonCount >= 24 Then initRows = 210
    ws.Range(ws.Cells(1, 1), ws.Cells(1, initCols)).EntireColumn.ColumnWidth = 4.8
    ws.Range(ws.Cells(1, 1), ws.Cells(initRows, 1)).EntireRow.RowHeight = 13.8
End Sub

Private Function RootGenerationWidth(ByVal spouseRow As Long, _
        ByVal siblings As Collection, _
        ByVal cardW As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double) As Double
    Dim rootW As Double, n As Long
    rootW = cardW
    If spouseRow > 0 Then rootW = cardW * 2 + coupleGap
    n = SiblingRowsCount(siblings)
    RootGenerationWidth = rootW
    If n > 0 Then RootGenerationWidth = rootW + n * cardW + n * blockGap
End Function

Private Function SiblingRowsCount(ByVal siblings As Collection) As Long
    If siblings Is Nothing Then
        SiblingRowsCount = 0
    Else
        SiblingRowsCount = siblings.Count
    End If
End Function

Private Function RootOwnWidthForDiagram(ByVal spouseRow As Long, ByVal cardW As Double, ByVal coupleGap As Double) As Double
    RootOwnWidthForDiagram = cardW
    If spouseRow > 0 Then RootOwnWidthForDiagram = cardW * 2 + coupleGap
End Function

Private Function SiblingCollectionWidth(ByVal siblingRows As Collection, ByVal cardW As Double, ByVal blockGap As Double) As Double
    Dim n As Long
    n = SiblingRowsCount(siblingRows)
    If n <= 0 Then Exit Function
    SiblingCollectionWidth = n * cardW
    If n > 1 Then SiblingCollectionWidth = SiblingCollectionWidth + (n - 1) * blockGap
End Function

Private Function DecedentLeftForRootGeneration(ByVal decRow As Long, _
        ByVal spouseRow As Long, _
        ByVal siblings As Collection, _
        ByVal pageCenter As Double, _
        ByVal cardW As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double) As Double
    Dim leftRows As Collection, rightRows As Collection
    Dim rootW As Double, leftPart As Double, rightPart As Double
    rootW = RootOwnWidthForDiagram(spouseRow, cardW, coupleGap)
    SplitSiblingRowsForDiagram siblings, decRow, leftRows, rightRows
    leftPart = SiblingCollectionWidth(leftRows, cardW, blockGap)
    rightPart = SiblingCollectionWidth(rightRows, cardW, blockGap)
    If leftPart > 0 Then leftPart = leftPart + blockGap
    If rightPart > 0 Then rightPart = rightPart + blockGap
    DecedentLeftForRootGeneration = pageCenter - rootW / 2 + (leftPart - rightPart) / 2
End Function

Private Sub SplitSiblingRowsForDiagram(ByVal siblings As Collection, _
        ByVal decRow As Long, _
        ByRef leftRows As Collection, _
        ByRef rightRows As Collection)
    Dim i As Long, sideValue As Long, unknownToLeft As Boolean
    Set leftRows = New Collection
    Set rightRows = New Collection
    unknownToLeft = True
    If siblings Is Nothing Then Exit Sub
    For i = 1 To siblings.Count
        sideValue = SiblingSideForDiagram(CLng(siblings(i)), decRow, unknownToLeft)
        If sideValue < 0 Then
            AddPersonRowUnique leftRows, CLng(siblings(i))
        Else
            AddPersonRowUnique rightRows, CLng(siblings(i))
        End If
    Next i
End Sub

Private Function SiblingSideForDiagram(ByVal personRow As Long, ByVal decRow As Long, ByRef unknownToLeft As Boolean) As Long
    Dim wp As Worksheet, relBase As String
    Dim personBirth As Variant, decBirth As Variant
    If personRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    relBase = DiagramBaseRelationLabel(CleanText(wp.Cells(personRow, P_REL_DEC).Value))
    Select Case relBase
        Case "�Z", "�o"
            SiblingSideForDiagram = -1
            Exit Function
        Case "��", "��"
            SiblingSideForDiagram = 1
            Exit Function
    End Select
    If decRow > 0 Then
        personBirth = wp.Cells(personRow, P_BIRTH).Value
        decBirth = wp.Cells(decRow, P_BIRTH).Value
        If HasInputDate(personBirth) And HasInputDate(decBirth) Then
            If CDate(SameDateOrBlank(personBirth)) < CDate(SameDateOrBlank(decBirth)) Then
                SiblingSideForDiagram = -1
            Else
                SiblingSideForDiagram = 1
            End If
            Exit Function
        End If
    End If
    If unknownToLeft Then
        SiblingSideForDiagram = -1
    Else
        SiblingSideForDiagram = 1
    End If
    unknownToLeft = Not unknownToLeft
End Function

Private Function RootSiblingLeftFromSide(ByVal sideIndex As Long, _
        ByVal isLeftSide As Boolean, _
        ByVal sideCount As Long, _
        ByVal decLeft As Double, _
        ByVal spouseRow As Long, _
        ByVal cardW As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double) As Double
    Dim rootW As Double
    rootW = RootOwnWidthForDiagram(spouseRow, cardW, coupleGap)
    If isLeftSide Then
        RootSiblingLeftFromSide = decLeft - (sideCount - sideIndex + 1) * (cardW + blockGap)
    Else
        RootSiblingLeftFromSide = decLeft + rootW + blockGap + (sideIndex - 1) * (cardW + blockGap)
    End If
End Function

Private Sub DrawParentToRootGenerationLines(ByVal ws As Worksheet, _
        ByVal parentOriginX As Double, _
        ByVal parentOriginY As Double, _
        ByVal decLeft As Double, _
        ByVal rootTop As Double, _
        ByVal cardW As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal spouseRow As Long, _
        ByVal siblings As Collection)
    Dim leftRows As Collection, rightRows As Collection
    Dim i As Long, centerX As Double, minX As Double, maxX As Double, branchY As Double, decRow As Long
    If ws Is Nothing Then Exit Sub
    If parentOriginX < 1 Or parentOriginY < 1 Then Exit Sub
    decRow = FindPersonRow(GetDecedentId())
    SplitSiblingRowsForDiagram siblings, decRow, leftRows, rightRows
    branchY = rootTop - 34
    If branchY <= parentOriginY + 8 Then branchY = rootTop - 22
    centerX = decLeft + cardW / 2
    minX = centerX
    maxX = centerX
    For i = 1 To SiblingRowsCount(leftRows)
        centerX = RootSiblingLeftFromSide(i, True, SiblingRowsCount(leftRows), decLeft, spouseRow, cardW, coupleGap, blockGap) + cardW / 2
        If centerX < minX Then minX = centerX
        If centerX > maxX Then maxX = centerX
    Next i
    For i = 1 To SiblingRowsCount(rightRows)
        centerX = RootSiblingLeftFromSide(i, False, SiblingRowsCount(rightRows), decLeft, spouseRow, cardW, coupleGap, blockGap) + cardW / 2
        If centerX < minX Then minX = centerX
        If centerX > maxX Then maxX = centerX
    Next i
    DrawVLine ws, parentOriginX, parentOriginY, branchY
    DrawHLine ws, minX, branchY, maxX
    DrawVLine ws, decLeft + cardW / 2, branchY, rootTop
    For i = 1 To SiblingRowsCount(leftRows)
        centerX = RootSiblingLeftFromSide(i, True, SiblingRowsCount(leftRows), decLeft, spouseRow, cardW, coupleGap, blockGap) + cardW / 2
        DrawVLine ws, centerX, branchY, rootTop
    Next i
    For i = 1 To SiblingRowsCount(rightRows)
        centerX = RootSiblingLeftFromSide(i, False, SiblingRowsCount(rightRows), decLeft, spouseRow, cardW, coupleGap, blockGap) + cardW / 2
        DrawVLine ws, centerX, branchY, rootTop
    Next i
End Sub

Private Sub DrawRootSiblingCards(ByVal ws As Worksheet, _
        ByVal siblings As Collection, _
        ByVal decRow As Long, _
        ByVal decLeft As Double, _
        ByVal rootTop As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal spouseRow As Long, _
        ByVal drawn As Object, _
        ByVal drawSameGenerationLine As Boolean)
    Dim leftRows As Collection, rightRows As Collection
    Dim i As Long, leftPt As Double, centerX As Double, minX As Double, maxX As Double, branchY As Double
    If ws Is Nothing Then Exit Sub
    SplitSiblingRowsForDiagram siblings, decRow, leftRows, rightRows
    If SiblingRowsCount(leftRows) + SiblingRowsCount(rightRows) <= 0 Then Exit Sub
    centerX = decLeft + cardW / 2
    minX = centerX
    maxX = centerX
    For i = 1 To SiblingRowsCount(leftRows)
        leftPt = RootSiblingLeftFromSide(i, True, SiblingRowsCount(leftRows), decLeft, spouseRow, cardW, coupleGap, blockGap)
        DrawTreeCard ws, CLng(leftRows(i)), leftPt, rootTop, cardW, cardH, drawn
        centerX = leftPt + cardW / 2
        If centerX < minX Then minX = centerX
        If centerX > maxX Then maxX = centerX
    Next i
    For i = 1 To SiblingRowsCount(rightRows)
        leftPt = RootSiblingLeftFromSide(i, False, SiblingRowsCount(rightRows), decLeft, spouseRow, cardW, coupleGap, blockGap)
        DrawTreeCard ws, CLng(rightRows(i)), leftPt, rootTop, cardW, cardH, drawn
        centerX = leftPt + cardW / 2
        If centerX < minX Then minX = centerX
        If centerX > maxX Then maxX = centerX
    Next i
    If drawSameGenerationLine Then
        branchY = rootTop + cardH + 16
        DrawHLine ws, minX, branchY, maxX
        DrawVLine ws, decLeft + cardW / 2, rootTop + cardH, branchY
        For i = 1 To SiblingRowsCount(leftRows)
            leftPt = RootSiblingLeftFromSide(i, True, SiblingRowsCount(leftRows), decLeft, spouseRow, cardW, coupleGap, blockGap)
            DrawVLine ws, leftPt + cardW / 2, rootTop + cardH, branchY
        Next i
        For i = 1 To SiblingRowsCount(rightRows)
            leftPt = RootSiblingLeftFromSide(i, False, SiblingRowsCount(rightRows), decLeft, spouseRow, cardW, coupleGap, blockGap)
            DrawVLine ws, leftPt + cardW / 2, rootTop + cardH, branchY
        Next i
    End If
End Sub

Private Function CollectionFamilyTreeWidth(ByVal personRows As Collection, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal depth As Long) As Double
    Dim i As Long, w As Double, totalW As Double
    If personRows Is Nothing Then Exit Function
    For i = 1 To personRows.Count
        w = FamilyTreeBlockWidth(CLng(personRows(i)), cardW, cardH, coupleGap, blockGap, depth)
        If totalW > 0 Then totalW = totalW + blockGap
        totalW = totalW + w
    Next i
    CollectionFamilyTreeWidth = totalW
End Function

Private Function CountVisibleDiagramPersons() As Long
    Dim wp As Worksheet, r As Long, decId As String, pid As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    decId = GetDecedentId()
    For r = 2 To LastRow(wp, 1)
        pid = CleanText(wp.Cells(r, P_ID).Value)
        If Len(pid) > 0 Then
            If CleanText(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
                If CleanText(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Or pid = decId Then CountVisibleDiagramPersons = CountVisibleDiagramPersons + 1
            End If
        End If
    Next r
End Function

Private Function MaxDescendantDepthForPerson(ByVal parentId As String, ByVal path As Object, ByVal depth As Long) As Long
    Dim childRows As Collection, i As Long, childId As String, childDepth As Long
    If Len(parentId) = 0 Then MaxDescendantDepthForPerson = depth: Exit Function
    If depth > 12 Then MaxDescendantDepthForPerson = depth: Exit Function
    If path.Exists(parentId) Then MaxDescendantDepthForPerson = depth: Exit Function
    path.Add parentId, True
    Set childRows = GetChildRowsForParent(parentId)
    MaxDescendantDepthForPerson = depth
    For i = 1 To childRows.Count
        childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(CLng(childRows(i)), P_ID).Value)
        childDepth = MaxDescendantDepthForPerson(childId, path, depth + 1)
        If childDepth > MaxDescendantDepthForPerson Then MaxDescendantDepthForPerson = childDepth
    Next i
    path.Remove parentId
End Function

Private Function MaxSiblingCountForPerson(ByVal parentId As String, ByVal path As Object) As Long
    Dim childRows As Collection, i As Long, childId As String, childMax As Long
    If Len(parentId) = 0 Then Exit Function
    If path.Exists(parentId) Then Exit Function
    path.Add parentId, True
    Set childRows = GetChildRowsForParent(parentId)
    MaxSiblingCountForPerson = childRows.Count
    For i = 1 To childRows.Count
        childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(CLng(childRows(i)), P_ID).Value)
        childMax = MaxSiblingCountForPerson(childId, path)
        If childMax > MaxSiblingCountForPerson Then MaxSiblingCountForPerson = childMax
    Next i
    path.Remove parentId
End Function

Private Function PagesNeededForPointWidth(ByVal contentWidthPt As Double, ByVal landscape As Boolean) As Long
    Dim usablePt As Double, pages As Long
    If landscape Then
        usablePt = 760
    Else
        usablePt = 515
    End If
    If contentWidthPt <= 0 Then
        PagesNeededForPointWidth = 1
    Else
        pages = CLng(Int((contentWidthPt + usablePt - 1) / usablePt))
        If pages < 1 Then pages = 1
        If pages > 6 Then pages = 6
        PagesNeededForPointWidth = pages
    End If
End Function

Private Sub ShiftPrintableDiagramShapesLeft(ByVal ws As Worksheet, ByVal targetLeft As Double)
    Dim shp As Shape, minLeft As Double, delta As Double
    If ws Is Nothing Then Exit Sub
    minLeft = 0
    For Each shp In ws.Shapes
        If Len(shp.OnAction) = 0 Then
            If minLeft = 0 Or shp.Left < minLeft Then minLeft = shp.Left
        End If
    Next shp
    If minLeft = 0 Then Exit Sub
    delta = minLeft - targetLeft
    If delta <= 1 Then Exit Sub
    For Each shp In ws.Shapes
        If Len(shp.OnAction) = 0 Then shp.Left = shp.Left - delta
    Next shp
End Sub

Private Function ShapeCenterTargetX(ByVal leftPt As Double, ByVal widthPt As Double) As Double
    ShapeCenterTargetX = leftPt + widthPt / 2
End Function

Private Function DrawTreeCard(ByVal ws As Worksheet, _
        ByVal personRow As Long, _
        ByVal leftPt As Double, _
        ByVal topPt As Double, _
        ByVal widthPt As Double, _
        ByVal heightPt As Double, _
        ByVal drawn As Object) As Shape
    Dim pid As String, existingShape As Shape
    If personRow <= 0 Then Exit Function
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    If Len(pid) > 0 Then
        If Not drawn Is Nothing Then
            If drawn.Exists(pid) Then
                Set existingShape = FindPersonCardShape(ws, pid)
                If Not existingShape Is Nothing Then
                    Set DrawTreeCard = existingShape
                    Exit Function
                End If
            End If
        End If
    End If

    Set DrawTreeCard = DrawPersonCardShape(ws, personRow, leftPt, topPt, widthPt, heightPt)
    If DrawTreeCard Is Nothing Then Exit Function
    If Len(pid) > 0 Then
        If Not drawn Is Nothing Then
            If Not drawn.Exists(pid) Then drawn.Add pid, True
        End If
    End If
End Function

Private Function IsDrawnPerson(ByVal drawn As Object, ByVal personRow As Long) As Boolean
    Dim pid As String
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    If Len(pid) = 0 Then Exit Function
    IsDrawnPerson = drawn.Exists(pid)
End Function

Private Function FamilyTreeBlockWidth(ByVal personRow As Long, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal depth As Long) As Double
    Dim path As Object
    Set path = CreateObject("Scripting.Dictionary")
    FamilyTreeBlockWidth = FamilyTreeBlockWidthCore(personRow, cardW, cardH, coupleGap, blockGap, depth, path)
End Function

Private Function FamilyTreeBlockWidthCore(ByVal personRow As Long, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal depth As Long, _
        ByVal path As Object) As Double
    Dim pid As String, spouseRow As Long, ownW As Double, childW As Double, i As Long
    Dim childRows As Collection, w As Double

    If personRow <= 0 Or depth > 12 Then
        FamilyTreeBlockWidthCore = cardW
        Exit Function
    End If

    pid = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    If Len(pid) > 0 Then
        If Not path Is Nothing Then
            If path.Exists(pid) Then
                FamilyTreeBlockWidthCore = cardW
                Exit Function
            End If
            path.Add pid, True
        End If
    End If

    spouseRow = GetSpouseRowOfPerson(pid)
    ownW = cardW
    If spouseRow > 0 Then ownW = cardW * 2 + coupleGap

    Set childRows = GetChildRowsForParent(pid)
    childW = 0
    For i = 1 To childRows.Count
        w = FamilyTreeBlockWidthCore(CLng(childRows(i)), cardW, cardH, coupleGap, blockGap, depth + 1, path)
        If childW > 0 Then childW = childW + blockGap
        childW = childW + w
    Next i

    If Len(pid) > 0 Then
        If Not path Is Nothing Then
            If path.Exists(pid) Then path.Remove pid
        End If
    End If

    FamilyTreeBlockWidthCore = Application.Max(ownW, childW)
End Function

Private Function DescendantIncomingY(ByVal personRow As Long, ByVal blockTop As Double, ByVal cardH As Double) As Double
    '�e�q���́A�q�{�l�J�[�h�̏㒆���֒��ړ����B
    '�q���������ĉ��ɔz��҃J�[�h�������Ă��Ă��A�v�w�u���b�N�����֓������Ȃ��B
    DescendantIncomingY = blockTop
End Function

Private Function DescendantChildCardCenterX(ByVal personRow As Long, _
        ByVal blockLeft As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal depth As Long) As Double
    Dim pid As String, spouseRow As Long, ownW As Double, blockW As Double, ownLeft As Double
    If personRow <= 0 Then
        DescendantChildCardCenterX = blockLeft + cardW / 2
        Exit Function
    End If
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    blockW = SafeFamilyTreeBlockWidth(personRow, cardW, cardH, coupleGap, blockGap, depth, "�q���u���b�N��")
    spouseRow = GetSpouseRowOfPerson(pid)
    ownW = cardW
    If spouseRow > 0 Then ownW = cardW * 2 + coupleGap
    ownLeft = blockLeft + (blockW - ownW) / 2
    DescendantChildCardCenterX = ownLeft + cardW / 2
End Function


Private Function SafeRootChildBlockWidth(ByVal childRowValue As Variant, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double) As Double
    On Error GoTo EH
    SafeRootChildBlockWidth = SafeFamilyTreeBlockWidth(CLng(childRowValue), cardW, cardH, coupleGap, blockGap, 1, "���n�q�u���b�N��")
    If SafeRootChildBlockWidth < cardW Then SafeRootChildBlockWidth = cardW
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning "���n�q�u���b�N��", "���v�Z������l�Ōp��: " & Err.Description
    Err.Clear
    SafeRootChildBlockWidth = cardW
End Function

Private Function DrawRootChildDescendantBlockSafe(ByVal ws As Worksheet, _
        ByVal decId As String, _
        ByVal childRowValue As Variant, _
        ByVal blockLeft As Double, _
        ByVal childTop As Double, _
        ByVal branchY As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal decShape As Shape, _
        ByVal spouseShape As Shape, _
        ByVal coupleOriginX As Double, _
        ByVal coupleOriginY As Double, _
        ByVal drawn As Object) As Double
    Dim childRow As Long, childRootX As Double, childOriginX As Double, childOriginY As Double
    On Error GoTo EH
    childRow = CLng(childRowValue)
    If Not mDiagramCardsOnly Then
        childRootX = SafeDescendantChildCardCenterX(childRow, blockLeft, cardW, cardH, coupleGap, blockGap, 1, "���n�q�J�[�h���S")
        SafeChildLinkOriginForDiagram decId, childRow, decShape, spouseShape, coupleOriginX, coupleOriginY, childOriginX, childOriginY
        DrawVLine ws, childOriginX, childOriginY, branchY
        DrawHLine ws, MinDouble(childOriginX, childRootX), branchY, MaxDouble(childOriginX, childRootX)
        DrawVLine ws, childRootX, branchY, DescendantIncomingY(childRow, childTop, cardH)
    End If
    DrawRootChildDescendantBlockSafe = SafeDrawDescendantFamilyBlock(ws, childRow, blockLeft, childTop, cardW, cardH, coupleGap, blockGap, drawn, 1)
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning "�q���u���b�N�`��", "���n�q�u���b�N���ꕔ�X�L�b�v���Čp��: " & Err.Description
    Err.Clear
    DrawRootChildDescendantBlockSafe = childTop + cardH
End Function

Private Function SafeDrawDescendantFamilyBlock(ByVal ws As Worksheet, _
        ByVal personRow As Long, _
        ByVal blockLeft As Double, _
        ByVal blockTop As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal drawn As Object, _
        ByVal depth As Long) As Double
    On Error GoTo EH
    SafeDrawDescendantFamilyBlock = DrawDescendantFamilyBlock(ws, personRow, blockLeft, blockTop, cardW, cardH, coupleGap, blockGap, drawn, depth)
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning "�q���u���b�N�`��", "�`����p��: row=" & CStr(personRow) & " / depth=" & CStr(depth) & " / " & Err.Description
    Err.Clear
    SafeDrawDescendantFamilyBlock = blockTop + cardH
End Function

Private Function SafeFamilyTreeBlockWidth(ByVal personRow As Long, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal depth As Long, _
        Optional ByVal phaseText As String = "�u���b�N��") As Double
    On Error GoTo EH
    SafeFamilyTreeBlockWidth = FamilyTreeBlockWidth(personRow, cardW, cardH, coupleGap, blockGap, depth)
    If SafeFamilyTreeBlockWidth < cardW Then SafeFamilyTreeBlockWidth = cardW
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning phaseText, "���v�Z������l�Ōp��: row=" & CStr(personRow) & " / depth=" & CStr(depth) & " / " & Err.Description
    Err.Clear
    SafeFamilyTreeBlockWidth = cardW
End Function

Private Function SafeDescendantChildCardCenterX(ByVal personRow As Long, _
        ByVal blockLeft As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal depth As Long, _
        Optional ByVal phaseText As String = "�q�J�[�h���S") As Double
    On Error GoTo EH
    SafeDescendantChildCardCenterX = DescendantChildCardCenterX(personRow, blockLeft, cardW, cardH, coupleGap, blockGap, depth)
    If SafeDescendantChildCardCenterX < 1 Then SafeDescendantChildCardCenterX = blockLeft + cardW / 2
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning phaseText, "���S�v�Z������l�Ōp��: row=" & CStr(personRow) & " / depth=" & CStr(depth) & " / " & Err.Description
    Err.Clear
    SafeDescendantChildCardCenterX = blockLeft + cardW / 2
End Function

Private Sub SafeChildLinkOriginForDiagram(ByVal parentId As String, _
        ByVal childRow As Long, _
        ByVal parentShape As Shape, _
        ByVal spouseShape As Shape, _
        ByVal coupleOriginX As Double, _
        ByVal coupleOriginY As Double, _
        ByRef originX As Double, _
        ByRef originY As Double)
    On Error GoTo EH
    ChildLinkOriginForDiagram parentId, childRow, parentShape, spouseShape, coupleOriginX, coupleOriginY, originX, originY
    If originX < 1 Then originX = coupleOriginX
    If originY < 1 Then originY = coupleOriginY
    Exit Sub
EH:
    AppendRelationshipDiagramDrawWarning "�e�q���N�_", "�Аe/�v�w���N�_������l�Ōp��: row=" & CStr(childRow) & " / " & Err.Description
    Err.Clear
    originX = coupleOriginX
    originY = coupleOriginY
End Sub

Private Function MinDouble(ByVal a As Double, ByVal b As Double) As Double
    If a < b Then
        MinDouble = a
    Else
        MinDouble = b
    End If
End Function

Private Function MaxDouble(ByVal a As Double, ByVal b As Double) As Double
    If a > b Then
        MaxDouble = a
    Else
        MaxDouble = b
    End If
End Function

Private Function DiagramVerticalGapForDepth(ByVal depth As Long) As Double
    If depth <= 0 Then
        DiagramVerticalGapForDepth = 36
    ElseIf depth <= 2 Then
        DiagramVerticalGapForDepth = 34
    Else
        DiagramVerticalGapForDepth = 32
    End If
End Function

Private Function DiagramBranchOffsetForDepth(ByVal depth As Long) As Double
    If depth <= 0 Then
        DiagramBranchOffsetForDepth = 18
    ElseIf depth <= 2 Then
        DiagramBranchOffsetForDepth = 17
    Else
        DiagramBranchOffsetForDepth = 16
    End If
End Function

Private Function DrawDescendantFamilyBlock(ByVal ws As Worksheet, _
        ByVal personRow As Long, _
        ByVal blockLeft As Double, _
        ByVal blockTop As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal drawn As Object, _
        ByVal depth As Long) As Double
    Dim pid As String, spouseRow As Long, ownW As Double, blockW As Double, ownLeft As Double
    Dim personShape As Shape, spouseShape As Shape, originX As Double, originY As Double
    Dim childRows As Collection, childTop As Double, branchY As Double, rowW As Double, x As Double
    Dim i As Long, childBlockW As Double, childRootX As Double, bottomY As Double, childBottom As Double
    Dim childOriginX As Double, childOriginY As Double
    On Error GoTo EH

    If personRow <= 0 Or depth > 12 Then
        DrawDescendantFamilyBlock = blockTop + cardH
        Exit Function
    End If
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    blockW = SafeFamilyTreeBlockWidth(personRow, cardW, cardH, coupleGap, blockGap, depth, "�q���u���b�N��")
    On Error Resume Next
    spouseRow = GetSpouseRowOfPerson(pid)
    If Err.Number <> 0 Then
        AppendRelationshipDiagramDrawWarning "�q���u���b�N�`��", "�z��Ҏ擾���X�L�b�v���Čp��: row=" & CStr(personRow) & " / depth=" & CStr(depth) & " / " & Err.Description
        Err.Clear
        spouseRow = 0
    End If
    On Error GoTo EH
    ownW = cardW
    If spouseRow > 0 And Not IsDrawnPerson(drawn, spouseRow) Then ownW = cardW * 2 + coupleGap
    ownLeft = blockLeft + (blockW - ownW) / 2

    If IsDrawnPerson(drawn, personRow) Then
        DrawDescendantFamilyBlock = blockTop + cardH
        Exit Function
    End If
    Set personShape = DrawTreeCard(ws, personRow, ownLeft, blockTop, cardW, cardH, drawn)
    If personShape Is Nothing Then
        AppendRelationshipDiagramDrawWarning "�q���u���b�N�`��", "�l���J�[�h�쐬���s row=" & CStr(personRow)
        DrawDescendantFamilyBlock = blockTop + cardH
        Exit Function
    End If
    originX = ShapeCenterX(personShape)
    originY = personShape.Top + personShape.Height
    If spouseRow > 0 Then
        If Not IsDrawnPerson(drawn, spouseRow) Then
            Set spouseShape = DrawTreeCard(ws, spouseRow, ownLeft + cardW + coupleGap, blockTop, cardW, cardH, drawn)
            If Not spouseShape Is Nothing Then
                ConnectHorizontalCouple ws, personShape, spouseShape, originX, originY
            End If
        End If
    End If
    bottomY = blockTop + cardH

    On Error Resume Next
    Set childRows = GetChildRowsForParent(pid)
    If Err.Number <> 0 Then
        AppendRelationshipDiagramDrawWarning "�q���u���b�N�`��", "�q�擾���X�L�b�v���Čp��: row=" & CStr(personRow) & " / depth=" & CStr(depth) & " / " & Err.Description
        Err.Clear
        Set childRows = New Collection
    End If
    On Error GoTo EH
    If childRows Is Nothing Then Set childRows = New Collection
    If childRows.Count > 0 Then
        rowW = 0
        For i = 1 To childRows.Count
            On Error Resume Next
            childBlockW = SafeFamilyTreeBlockWidth(CLng(childRows(i)), cardW, cardH, coupleGap, blockGap, depth + 1, "�q���s��")
            If Err.Number <> 0 Then
                AppendRelationshipDiagramDrawWarning "�q���u���b�N�`��", "�q�s��������l�Ōp��: row=" & CStr(childRows(i)) & " / depth=" & CStr(depth + 1) & " / " & Err.Description
                Err.Clear
                childBlockW = cardW
            End If
            On Error GoTo EH
            If rowW > 0 Then rowW = rowW + blockGap
            rowW = rowW + childBlockW
        Next i
        x = blockLeft + (blockW - rowW) / 2
        childTop = bottomY + DiagramVerticalGapForDepth(depth)
        branchY = childTop - DiagramBranchOffsetForDepth(depth)
        For i = 1 To childRows.Count
            On Error Resume Next
            childBlockW = SafeFamilyTreeBlockWidth(CLng(childRows(i)), cardW, cardH, coupleGap, blockGap, depth + 1, "�q���u���b�N��")
            If Not mDiagramCardsOnly Then
                childRootX = SafeDescendantChildCardCenterX(CLng(childRows(i)), x, cardW, cardH, coupleGap, blockGap, depth + 1, "�q���J�[�h���S")
                SafeChildLinkOriginForDiagram pid, CLng(childRows(i)), personShape, spouseShape, originX, originY, childOriginX, childOriginY
                DrawVLine ws, childOriginX, childOriginY, branchY
                DrawHLine ws, MinDouble(childOriginX, childRootX), branchY, MaxDouble(childOriginX, childRootX)
                DrawVLine ws, childRootX, branchY, DescendantIncomingY(CLng(childRows(i)), childTop, cardH)
            End If
            childBottom = SafeDrawDescendantFamilyBlock(ws, CLng(childRows(i)), x, childTop, cardW, cardH, coupleGap, blockGap, drawn, depth + 1)
            If Err.Number <> 0 Then
                AppendRelationshipDiagramDrawWarning "�q���u���b�N�`��", "�q�P�ʂŌp��: row=" & CStr(childRows(i)) & " / depth=" & CStr(depth + 1) & " / " & Err.Description
                Err.Clear
                childBottom = childTop + cardH
            End If
            On Error GoTo EH
            If childBottom > bottomY Then bottomY = childBottom
            x = x + childBlockW + blockGap
        Next i
    End If

    DrawDescendantFamilyBlock = bottomY
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning "�q���u���b�N�`��", "�u���b�N�P�ʂŌp��: row=" & CStr(personRow) & " / depth=" & CStr(depth) & " / " & Err.Description
    Err.Clear
    DrawDescendantFamilyBlock = blockTop + cardH
End Function



Private Function GetFatherRowForDiagram(ByVal decId As String) As Long
    If DiagramGraphEnsureBuilt(decId) Then
        GetFatherRowForDiagram = DiagramGraphFatherRow(decId)
    End If
End Function

Private Function GetMotherRowForDiagram(ByVal decId As String, ByVal fatherRow As Long) As Long
    If DiagramGraphEnsureBuilt(decId) Then
        GetMotherRowForDiagram = DiagramGraphMotherRow(decId)
    End If
End Function

Private Function GetParentSpouseRowForDiagram(ByVal parentRow As Long, ByVal expectedParentLabel As String) As Long
    Dim parentId As String, spouseRow As Long
    If parentRow <= 0 Then Exit Function
    parentId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(parentRow, P_ID).Value)
    If Len(parentId) = 0 Then Exit Function

    spouseRow = GetSpouseRowOfPerson(parentId)
    If spouseRow <= 0 Then spouseRow = GetAnySpouseRowOfPerson(parentId)
    If spouseRow > 0 Then
        If DiagramPersonLooksLikeParentSpouse(spouseRow, parentId, expectedParentLabel) Then
            GetParentSpouseRowForDiagram = spouseRow
        End If
    End If
End Function

Private Function GetAnySpouseRowOfPerson(ByVal personId As String) As Long
    Dim wr As Worksheet, r As Long, otherId As String
    personId = CleanText(personId)
    If Len(personId) = 0 Or Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If DiagramGraphIsSpouseRelationType(CleanText(wr.Cells(r, R_TYPE).Value)) Then
                otherId = ""
                If CleanText(wr.Cells(r, R_BASE_ID).Value) = personId Then
                    otherId = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                ElseIf CleanText(wr.Cells(r, R_OTHER_ID).Value) = personId Then
                    otherId = CleanText(wr.Cells(r, R_BASE_ID).Value)
                End If
                If Len(otherId) > 0 Then
                    GetAnySpouseRowOfPerson = FindPersonRow(otherId)
                    Exit Function
                End If
            End If
        End If
    Next r
End Function

Private Function GetFirstVisibleParentSpouseRelationRow(ByVal baseParentLabel As String, ByVal expectedParentLabel As String) As Long
    Dim wp As Worksheet, r As Long, relText As String, srcId As String, srcRel As String
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, P_ID)
        If VisibleDiagramPersonRow(r) Then
            relText = DiagramRelationAndNoteForPersonRow(r)
            If InStr(1, relText, baseParentLabel & "�̔z���", vbTextCompare) > 0 Then
                If Not DiagramChildHasSeparateParentNote(relText) Then
                    GetFirstVisibleParentSpouseRelationRow = r
                    Exit Function
                End If
            End If
            srcId = CleanText(wp.Cells(r, P_SUR_SRC).Value)
            If Len(srcId) > 0 Then
                srcRel = NormalizeDiagramRelationText(CleanText(GetPersonValue(srcId, P_REL_DEC)))
                If srcRel = baseParentLabel And InStr(1, relText, "�z���", vbTextCompare) > 0 Then
                    If Not DiagramChildHasSeparateParentNote(relText) Then
                        GetFirstVisibleParentSpouseRelationRow = r
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function DiagramPersonLooksLikeParentSpouse(ByVal personRow As Long, ByVal parentId As String, ByVal expectedParentLabel As String) As Boolean
    Dim relText As String, storedBaseId As String, normText As String, personId As String
    If personRow <= 0 Then Exit Function
    parentId = CleanText(parentId)
    relText = DiagramRelationAndNoteForPersonRow(personRow)
    personId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    storedBaseId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_SUR_SRC).Value)
    normText = NormalizeDiagramRelationText(relText)

    If normText = expectedParentLabel Then
        DiagramPersonLooksLikeParentSpouse = True
    ElseIf DiagramPersonRowIsPureSpouse(personRow) Then
        '���̔z��ҁE��̔z��҂��ߋ��łŕʃ��x���ɉ��Ă��Ă��A
        'W_�֌W/P_SUR_SRC ����e����̔z��҂Ƃ��ĕ�������B
        If storedBaseId = parentId Or DiagramSpouseRelationExists(personId, parentId) Then
            If Not DiagramChildHasSeparateParentNote(relText) Then DiagramPersonLooksLikeParentSpouse = True
        End If
    ElseIf InStr(1, relText, "�z���", vbTextCompare) > 0 Then
        If storedBaseId = parentId _
                Or (expectedParentLabel = "��" And InStr(1, relText, "���̔z���", vbTextCompare) > 0) _
                Or (expectedParentLabel = "��" And InStr(1, relText, "��̔z���", vbTextCompare) > 0) _
                Or expectedParentLabel = "��" _
                Or expectedParentLabel = "��" Then
            If Not DiagramChildHasSeparateParentNote(relText) Then DiagramPersonLooksLikeParentSpouse = True
        End If
    End If
End Function

Private Function GetSiblingRowsForPerson(ByVal personId As String) As Collection
    Dim col As New Collection
    Dim wr As Worksheet, wp As Worksheet
    Dim r As Long, baseId As String, otherId As String, targetId As String
    If Len(personId) = 0 Then
        Set GetSiblingRowsForPerson = col
        Exit Function
    End If

    If SheetExists(SH_W_REL, ThisWorkbook) Then
        Set wr = ThisWorkbook.Worksheets(SH_W_REL)
        For r = 2 To LastRow(wr, R_ID)
            If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
                If CleanText(wr.Cells(r, R_TYPE).Value) = "�Z��o��" Then
                    baseId = CleanText(wr.Cells(r, R_BASE_ID).Value)
                    otherId = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                    targetId = ""
                    If baseId = personId Then
                        targetId = otherId
                    ElseIf otherId = personId Then
                        targetId = baseId
                    End If
                    If Len(targetId) > 0 Then AddPersonRowUnique col, FindPersonRow(targetId)
                End If
            End If
        Next r
    End If

    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, P_ID)
        If VisibleDiagramPersonRow(r) Then
            If CleanText(wp.Cells(r, P_ID).Value) <> personId Then
                If IsSiblingRelationText(wp.Cells(r, P_REL_DEC).Value) Then AddPersonRowUnique col, r
            End If
        End If
    Next r
    Set GetSiblingRowsForPerson = col
End Function

Private Function IsSiblingRelationText(ByVal relText As String) As Boolean
    relText = DiagramBaseRelationLabel(CleanText(relText))
    Select Case relText
        Case "�Z", "��", "�o", "��", "�Z��", "�o��", "�Z��o��"
            IsSiblingRelationText = True
    End Select
End Function


Private Function FirstPersonMarriageFieldDate(ByVal leftId As String, ByVal rightId As String, ByVal wantMarriage As Boolean) As Variant
    Dim wp As Worksheet, ids As Variant, i As Long, rowNo As Long, v As Variant
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    ids = Array(CleanText(leftId), CleanText(rightId))
    For i = LBound(ids) To UBound(ids)
        If Len(CStr(ids(i))) > 0 Then
            rowNo = FindPersonRow(CStr(ids(i)))
            If rowNo > 0 Then
                If wantMarriage Then
                    v = wp.Cells(rowNo, P_MARRIAGE).Value
                Else
                    v = wp.Cells(rowNo, P_DIVORCE).Value
                End If
                If HasInputDate(v) Then
                    FirstPersonMarriageFieldDate = SameDateOrBlank(v)
                    Exit Function
                End If
            End If
        End If
    Next i
End Function

Private Function DiagramBloodlineDescendantLevelForRow(ByVal personRow As Long) As Long
    Dim relText As String
    If personRow <= 0 Then Exit Function
    If DiagramPersonRowIsPureSpouse(personRow) Then Exit Function
    relText = DiagramRelationAndNoteForPersonRow(personRow)
    If InStr(1, relText, "�z���", vbTextCompare) > 0 Then Exit Function
    DiagramBloodlineDescendantLevelForRow = DiagramDescendantLevel(relText)
End Function

Private Function DiagramConfirmedParentIdForChildRow(ByVal childRow As Long) As String
    Dim wp As Worksheet, childId As String, srcId As String, parentId As String
    Dim wr As Worksheet, r As Long, b As String, o As String, bestId As String, bestScore As Long, scoreValue As Long
    If childRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    childId = CleanText(wp.Cells(childRow, P_ID).Value)
    If Len(childId) = 0 Then Exit Function

    srcId = CleanText(wp.Cells(childRow, P_SUR_SRC).Value)
    If Len(srcId) > 0 Then
        parentId = DiagramNormalizeParentCandidateByMarriage(srcId, childRow)
        If Len(parentId) > 0 Then
            DiagramConfirmedParentIdForChildRow = parentId
            Exit Function
        End If
    End If

    If SheetExists(SH_W_REL, ThisWorkbook) Then
        Set wr = ThisWorkbook.Worksheets(SH_W_REL)
        For r = 2 To LastRow(wr, R_ID)
            If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
                If DiagramGraphIsParentChildRelationRow(wr, r) Then
                    b = CleanText(wr.Cells(r, R_BASE_ID).Value)
                    o = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                    parentId = ""
                    If o = childId Then
                        parentId = b
                    ElseIf b = childId Then
                        parentId = o
                    End If
                    If Len(parentId) > 0 Then
                        parentId = DiagramNormalizeParentCandidateByMarriage(parentId, childRow)
                        If Len(parentId) > 0 Then
                            scoreValue = DiagramParentCandidateScore(parentId, childRow, 1250)
                            If scoreValue > bestScore Then
                                bestScore = scoreValue
                                bestId = parentId
                            End If
                        End If
                    End If
                End If
            End If
        Next r
    End If
    DiagramConfirmedParentIdForChildRow = bestId
End Function

Private Function DiagramNormalizeParentCandidateByMarriage(ByVal candidateParentId As String, ByVal childRow As Long) As String
    Dim candidateRow As Long, bloodId As String
    candidateParentId = CleanText(candidateParentId)
    If Len(candidateParentId) = 0 Or childRow <= 0 Then Exit Function
    candidateRow = FindPersonRow(candidateParentId)
    If candidateRow <= 0 Then Exit Function
    If Not VisibleDiagramPersonRow(candidateRow) Then Exit Function
    If DiagramPersonIsOtherRelationOnly(candidateRow) Then Exit Function

    '�ʏ�̌����e�͂��̂܂܍̗p����B
    '�z��ҍs�́A���Ƃ��\���������ߋ��łŁu���v�u�]���v�ɉ��Ă��Ă��A
    'W_�֌W/P_SUR_SRC ����z��ҍs�Ƃ��Č������Č������֖߂��B
    If Not DiagramPersonRowIsPureSpouse(candidateRow) Then
        DiagramNormalizeParentCandidateByMarriage = candidateParentId
        Exit Function
    End If

    If DiagramChildHasSeparateParentNote(DiagramRelationAndNoteForPersonRow(childRow)) Then
        DiagramNormalizeParentCandidateByMarriage = candidateParentId
        Exit Function
    End If

    bloodId = DiagramBloodlinePartnerForSpouseCandidate(candidateParentId, childRow)
    If Len(bloodId) > 0 Then
        DiagramNormalizeParentCandidateByMarriage = bloodId
    Else
        DiagramNormalizeParentCandidateByMarriage = candidateParentId
    End If
End Function

Private Function DiagramBloodlinePartnerForSpouseCandidate(ByVal spouseId As String, ByVal childRow As Long) As String
    Dim wr As Worksheet, r As Long, b As String, o As String, partnerId As String, partnerRow As Long
    Dim storedId As String, spouseRow As Long
    spouseId = CleanText(spouseId)
    If Len(spouseId) = 0 Then Exit Function

    If SheetExists(SH_W_REL, ThisWorkbook) Then
        Set wr = ThisWorkbook.Worksheets(SH_W_REL)
        For r = 2 To LastRow(wr, R_ID)
            If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
                If DiagramGraphIsSpouseRelationType(CleanText(wr.Cells(r, R_TYPE).Value)) Then
                    b = CleanText(wr.Cells(r, R_BASE_ID).Value)
                    o = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                    partnerId = ""
                    If b = spouseId Then
                        partnerId = o
                    ElseIf o = spouseId Then
                        partnerId = b
                    End If
                    If Len(partnerId) > 0 Then
                        partnerRow = FindPersonRow(partnerId)
                        If DiagramBloodlineDescendantLevelForRow(partnerRow) >= 1 Then
                            If DiagramSpouseRelationRowCoversChild(wr, r, childRow) Then
                                DiagramBloodlinePartnerForSpouseCandidate = partnerId
                                Exit Function
                            End If
                        End If
                    End If
                End If
            End If
        Next r
    End If

    spouseRow = FindPersonRow(spouseId)
    If spouseRow > 0 Then
        storedId = DiagramStoredBaseIdForPersonRow(spouseRow)
        partnerRow = FindPersonRow(storedId)
        If DiagramBloodlineDescendantLevelForRow(partnerRow) >= 1 Then
            If DiagramSpouseRelationAllowsChild(spouseId, storedId, childRow) Then
                DiagramBloodlinePartnerForSpouseCandidate = storedId
            End If
        End If
    End If
End Function

Private Sub EnsureDiagramRelationRow(ByVal baseId As String, ByVal otherId As String, ByVal relationType As String, ByVal displayText As String, ByVal marriageDate As Variant, ByVal divorceDate As Variant)
    Dim ws As Worksheet, r As Long
    baseId = CleanText(baseId)
    otherId = CleanText(otherId)
    relationType = CleanText(relationType)
    If Len(baseId) = 0 Or Len(otherId) = 0 Or Len(relationType) = 0 Then Exit Sub
    If baseId = otherId Then Exit Sub
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_REL)
    r = FindDiagramRelationRow(baseId, otherId, relationType)
    If r = 0 And (relationType = "�z���" Or relationType = "�Z��o��" Or relationType = "�e�q") Then r = FindDiagramRelationRow(otherId, baseId, relationType)
    If r = 0 Then
        r = NextBlankRow(ws, R_ID)
        ws.Cells(r, R_ID).Value = NextId("�֌W")
        ws.Cells(r, R_CREATED).Value = Now
    End If
    ws.Cells(r, R_BASE_ID).Value = baseId
    ws.Cells(r, R_OTHER_ID).Value = otherId
    ws.Cells(r, R_TYPE).Value = relationType
    If Len(CleanText(displayText)) > 0 Then ws.Cells(r, R_DISPLAY).Value = CleanText(displayText)
    If relationType = "�z���" Then
        If HasInputDate(marriageDate) Then ws.Cells(r, R_MARRIAGE).Value = SameDateOrBlank(marriageDate)
        If HasInputDate(divorceDate) Then ws.Cells(r, R_DIVORCE).Value = SameDateOrBlank(divorceDate)
    End If
    ws.Cells(r, R_AUTO).Value = "����"
    ws.Cells(r, R_STATUS).Value = STATUS_ACTIVE
    ws.Cells(r, R_UPDATED).Value = Now
End Sub

Private Function FindDiagramRelationRow(ByVal baseId As String, ByVal otherId As String, ByVal relationType As String) As Long
    Dim ws As Worksheet, r As Long
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(ws, R_ID)
        If CleanText(ws.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If CleanText(ws.Cells(r, R_BASE_ID).Value) = baseId Then
                If CleanText(ws.Cells(r, R_OTHER_ID).Value) = otherId Then
                    If CleanText(ws.Cells(r, R_TYPE).Value) = relationType Then
                        FindDiagramRelationRow = r
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function DiagramAddressTextForCard(ByVal personId As String, ByVal inheritanceValue As Variant, ByVal deathValue As Variant) As String
    Dim addressText As String
    personId = CleanText(personId)
    If Len(personId) = 0 Then Exit Function
    If HasInputDate(deathValue) Then
        addressText = GetAddressTextAtDate(personId, deathValue)
        If Len(CleanText(addressText)) = 0 Then addressText = GetLastAddressHistoryTextForCard(personId)
    ElseIf HasInputDate(inheritanceValue) Then
        addressText = GetAddressTextAtDate(personId, inheritanceValue)
        If Len(CleanText(addressText)) = 0 Then addressText = GetCurrentAddressText(personId)
        If Len(CleanText(addressText)) = 0 Then addressText = GetLastAddressHistoryTextForCard(personId)
    Else
        addressText = GetCurrentAddressText(personId)
        If Len(CleanText(addressText)) = 0 Then addressText = GetLastAddressHistoryTextForCard(personId)
    End If
    DiagramAddressTextForCard = addressText
End Function

Private Function GetLastAddressHistoryTextForCard(ByVal personId As String) As String
    Dim wa As Worksheet, r As Long, bestR As Long, bestScore As Double, score As Double
    Dim st As Variant, en As Variant
    personId = CleanText(personId)
    If Len(personId) = 0 Or Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Function
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    bestScore = -1E+20
    For r = 2 To LastRow(wa, A_ID)
        If CleanText(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
            If CleanText(wa.Cells(r, A_PERSON_ID).Value) = personId Then
                score = r
                st = wa.Cells(r, A_START).Value
                en = wa.Cells(r, A_END).Value
                If CleanText(wa.Cells(r, A_TYPE).Value) = "���Z�n" Then score = score + 100000
                If HasInputDate(st) Then score = score + CDbl(CDate(SameDateOrBlank(st))) / 100
                If HasInputDate(en) Then score = score + CDbl(CDate(SameDateOrBlank(en)))
                If score > bestScore Then
                    bestScore = score
                    bestR = r
                End If
            End If
        End If
    Next r
    If bestR > 0 Then GetLastAddressHistoryTextForCard = CStr(wa.Cells(bestR, A_TEXT).Value)
End Function

Private Function GetChildRowsForParent(ByVal parentId As String) As Collection
    Dim col As New Collection
    parentId = CleanText(parentId)
    If Len(parentId) > 0 Then
        If DiagramGraphEnsureBuilt(GetDecedentId()) Then
            Set GetChildRowsForParent = DiagramGraphChildRows(parentId)
            Exit Function
        End If
    End If
    Set GetChildRowsForParent = col
End Function

Private Function TryResolveDiagramParentChildRelationRow(ByVal wr As Worksheet, ByVal relRow As Long, ByRef parentId As String, ByRef childId As String) As Boolean
    parentId = ""
    childId = ""
    If wr Is Nothing Then Exit Function
    If relRow <= 0 Then Exit Function
    If CStr(wr.Cells(relRow, R_STATUS).Value) = STATUS_CANCEL Then Exit Function
    If Not DiagramGraphIsParentChildRelationRow(wr, relRow) Then Exit Function
    'V2�̕ۑ������͏�ɐe���q�B���[���ő��������񂩂甽�]���Ȃ��B
    parentId = CleanText(wr.Cells(relRow, R_BASE_ID).Value)
    childId = CleanText(wr.Cells(relRow, R_OTHER_ID).Value)
    If Len(parentId) = 0 Or Len(childId) = 0 Or parentId = childId Then Exit Function
    If FindPersonRow(parentId) = 0 Or FindPersonRow(childId) = 0 Then Exit Function
    TryResolveDiagramParentChildRelationRow = True
End Function

Private Function DiagramExplicitParentChildRowDirectionCanBeTrusted(ByVal parentRow As Long, ByVal childRow As Long) As Boolean
    Dim wp As Worksheet, parentId As String, childId As String
    Dim parentRel As String, childRel As String, childSourceId As String
    If parentRow <= 0 Or childRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    parentId = CleanText(wp.Cells(parentRow, P_ID).Value)
    childId = CleanText(wp.Cells(childRow, P_ID).Value)
    If Len(parentId) = 0 Or Len(childId) = 0 Then Exit Function
    If parentId = childId Then Exit Function
    If DiagramPersonIsOtherRelationOnly(parentRow) Then Exit Function
    If DiagramPersonIsOtherRelationOnly(childRow) Then Exit Function

    parentRel = CleanText(wp.Cells(parentRow, P_REL_DEC).Value)
    childRel = CleanText(wp.Cells(childRow, P_REL_DEC).Value)
    If IsExpectedChildRelation(parentRel, childRel) Then
        DiagramExplicitParentChildRowDirectionCanBeTrusted = True
        Exit Function
    End If
    If DiagramDescendantLevel(childRel) > 0 Then
        DiagramExplicitParentChildRowDirectionCanBeTrusted = True
        Exit Function
    End If
    If IsDirectChildRelationText(childRel) Then
        DiagramExplicitParentChildRowDirectionCanBeTrusted = True
        Exit Function
    End If
    childSourceId = CleanText(wp.Cells(childRow, P_SUR_SRC).Value)
    If childSourceId = parentId Then DiagramExplicitParentChildRowDirectionCanBeTrusted = True
End Function

Private Function DiagramPersonIsOtherRelationOnly(ByVal personRow As Long) As Boolean
    Dim wp As Worksheet, relText As String, displayRel As String, noteText As String, rawText As String, normText As String
    If personRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    relText = CleanText(wp.Cells(personRow, P_REL_DEC).Value)
    displayRel = CleanText(wp.Cells(personRow, P_REL_DISP).Value)
    noteText = CleanText(wp.Cells(personRow, P_NOTE).Value)
    normText = NormalizeDiagramRelationText(relText)
    If normText = "�푊���l" Or normText = "�z���" Or normText = "�O�z���" Or normText = "��" Or normText = "��" Then Exit Function
    If IsSiblingRelationText(normText) Then Exit Function
    If IsDirectChildRelationText(normText) Then Exit Function
    If DiagramDescendantLevel(normText) > 0 Then Exit Function
    If InStr(normText, "�z���") > 0 Then Exit Function
    rawText = relText & " " & displayRel & " " & noteText
    DiagramPersonIsOtherRelationOnly = DiagramRelationTextIsOtherParty(rawText)
End Function

Private Function DiagramRelationTextIsOtherParty(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    If Len(relText) = 0 Then Exit Function
    If InStr(relText, "����") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "����") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "������") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "��") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "����") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "����") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "�㗝�l") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "�֌W�l") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "�֌W��") > 0 Then DiagramRelationTextIsOtherParty = True: Exit Function
    If InStr(relText, "���̑�") > 0 Then DiagramRelationTextIsOtherParty = True
End Function

Private Function DiagramExplicitParentChildDirectionIsUsable(ByVal parentRel As String, ByVal childRel As String) As Boolean
    Dim parentLevel As Long, childLevel As Long
    parentLevel = DiagramParentLevelForChildren(parentRel)
    childLevel = DiagramDescendantLevel(childRel)
    If childLevel <= 0 Then Exit Function
    If parentLevel = 0 Then
        DiagramExplicitParentChildDirectionIsUsable = (childLevel = 1)
    ElseIf parentLevel > 0 Then
        If childLevel = parentLevel + 1 Then
            DiagramExplicitParentChildDirectionIsUsable = True
        ElseIf childLevel <= parentLevel Then
            DiagramExplicitParentChildDirectionIsUsable = True
        End If
    End If
End Function

Private Function DiagramExplicitParentChildRowExists(ByVal parentId As String, ByVal childId As String) As Boolean
    Dim childRow As Long
    parentId = CleanText(parentId)
    childId = CleanText(childId)
    If Len(parentId) = 0 Or Len(childId) = 0 Then Exit Function
    If parentId = childId Then Exit Function
    childRow = FindPersonRow(childId)
    If childRow <= 0 Then Exit Function
    DiagramExplicitParentChildRowExists = (DiagramBestExplicitParentIdForChildRow(childRow) = parentId)
End Function

Private Function DiagramParentIdForChildRow(ByVal childRow As Long) As String
    If childRow <= 0 Then Exit Function
    If DiagramGraphEnsureBuilt(GetDecedentId()) Then
        DiagramParentIdForChildRow = DiagramGraphParentIdForChildRow(childRow)
    End If
End Function

Private Function DiagramPersonIsChildOfParent(ByVal childRow As Long, ByVal parentId As String) As Boolean
    Dim wr As Worksheet, r As Long, pId As String, cId As String
    Dim childId As String
    If childRow <= 0 Or Len(parentId) = 0 Then Exit Function
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    If Len(childId) = 0 Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If TryResolveDiagramParentChildRelationRow(wr, r, pId, cId) Then
            If pId = parentId And cId = childId Then
                DiagramPersonIsChildOfParent = True
                Exit Function
            End If
        End If
    Next r
End Function

Private Function InferredDiagramParentIdForChildRow(ByVal childRow As Long) As String
    If childRow <= 0 Then Exit Function
    If DiagramGraphEnsureBuilt(GetDecedentId()) Then
        InferredDiagramParentIdForChildRow = DiagramGraphParentIdForChildRow(childRow)
    End If
End Function

Private Function DiagramBestExplicitParentIdForChildRow(ByVal childRow As Long) As String
    Dim wp As Worksheet, wr As Worksheet, r As Long
    Dim childId As String, rawBaseId As String, rawOtherId As String
    Dim resolvedParentId As String, resolvedChildId As String
    Dim bestId As String, bestScore As Long
    If childRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    childId = CleanText(wp.Cells(childRow, P_ID).Value)
    If Len(childId) = 0 Then Exit Function
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function

    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If DiagramGraphIsParentChildRelationRow(wr, r) Then
                rawBaseId = CleanText(wr.Cells(r, R_BASE_ID).Value)
                rawOtherId = CleanText(wr.Cells(r, R_OTHER_ID).Value)

                If TryResolveDiagramParentChildRelationRow(wr, r, resolvedParentId, resolvedChildId) Then
                    If resolvedChildId = childId Then
                        DiagramEvaluateParentCandidate resolvedParentId, childId, childRow, 1000, bestId, bestScore
                    End If
                End If

                '�o�^�����̐��K�` R_BASE_ID=�e / R_OTHER_ID=�q ���ʌ��Ƃ��ĕK������B
                'TryResolve ���������̐󂳂Ɉ��������Ă��A�o�^���̌������~�ς���B
                If rawOtherId = childId Then DiagramEvaluateParentCandidate rawBaseId, childId, childRow, 950, bestId, bestScore
                If rawBaseId = childId Then DiagramEvaluateParentCandidate rawOtherId, childId, childRow, 700, bestId, bestScore
            End If
        End If
    Next r
    DiagramBestExplicitParentIdForChildRow = bestId
End Function

Private Function DiagramStoredBaseParentIdForDrawing(ByVal childRow As Long) As String
    Dim wp As Worksheet, childId As String, storedId As String
    Dim bestId As String, bestScore As Long
    If childRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    childId = CleanText(wp.Cells(childRow, P_ID).Value)
    storedId = CleanText(wp.Cells(childRow, P_SUR_SRC).Value)
    If Len(childId) = 0 Or Len(storedId) = 0 Then Exit Function
    DiagramEvaluateParentCandidate storedId, childId, childRow, 900, bestId, bestScore
    DiagramStoredBaseParentIdForDrawing = bestId
End Function

Private Sub DiagramEvaluateParentCandidate(ByVal candidateParentId As String, _
        ByVal childId As String, _
        ByVal childRow As Long, _
        ByVal sourceScore As Long, _
        ByRef bestId As String, _
        ByRef bestScore As Long)
    Dim primaryId As String, scoreValue As Long, rawScore As Long
    candidateParentId = CleanText(candidateParentId)
    childId = CleanText(childId)
    If Len(candidateParentId) = 0 Or Len(childId) = 0 Then Exit Sub
    If candidateParentId = childId Then Exit Sub

    primaryId = DiagramPrimaryParentIdForDrawing(candidateParentId, childId, childRow)
    If Len(primaryId) > 0 Then
        scoreValue = DiagramParentCandidateScore(primaryId, childRow, sourceScore)
        If scoreValue > bestScore Then
            bestScore = scoreValue
            bestId = primaryId
        End If
    End If

    If primaryId <> candidateParentId Then
        rawScore = DiagramParentCandidateScore(candidateParentId, childRow, sourceScore - 80)
        If rawScore > bestScore Then
            bestScore = rawScore
            bestId = candidateParentId
        End If
    End If
End Sub

Private Function DiagramParentCandidateScore(ByVal parentId As String, ByVal childRow As Long, ByVal sourceScore As Long) As Long
    Dim wp As Worksheet, parentRow As Long
    Dim parentRel As String, childRel As String
    Dim parentLevel As Long, childLevel As Long
    If sourceScore <= 0 Then Exit Function
    parentId = CleanText(parentId)
    If Len(parentId) = 0 Or childRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    parentRow = FindPersonRow(parentId)
    If parentRow <= 0 Then Exit Function
    If Not VisibleDiagramPersonRow(parentRow) Then Exit Function
    If Not VisibleDiagramPersonRow(childRow) Then Exit Function
    If CleanText(wp.Cells(childRow, P_ID).Value) = parentId Then Exit Function
    If DiagramPersonIsOtherRelationOnly(parentRow) Then Exit Function
    If DiagramPersonIsOtherRelationOnly(childRow) Then Exit Function
    If DiagramPersonRowIsPureSpouse(childRow) Then Exit Function
    If DiagramPersonRowIsPureSpouse(parentRow) Then DiagramParentCandidateScore = sourceScore - 300

    parentRel = NormalizeDiagramRelationText(DiagramRelationAndNoteForPersonRow(parentRow))
    childRel = NormalizeDiagramRelationText(DiagramRelationAndNoteForPersonRow(childRow))
    If Len(childRel) = 0 Then Exit Function

    parentLevel = DiagramParentLevelForChildren(parentRel)
    childLevel = DiagramDescendantLevel(childRel)

    If IsExpectedChildRelation(parentRel, childRel) Then
        DiagramParentCandidateScore = sourceScore + 520
    ElseIf parentLevel >= 0 And childLevel > 0 And childLevel = parentLevel + 1 Then
        DiagramParentCandidateScore = sourceScore + 450
    ElseIf sourceScore >= 850 And parentLevel >= 1 And childLevel > 0 And childLevel <= parentLevel Then
        '���łŁu���̔z��҂���ɓo�^�����q�v���u�q�v�̂܂܎c�����ꍇ�����A
        'P_SUR_SRC/W_�֌W�Ƃ��������؋���D�悵�Đe�q����߂��B�\���͐e���ォ��Čv�Z����B
        DiagramParentCandidateScore = sourceScore + 260
    ElseIf sourceScore >= 1200 And parentLevel >= 0 Then
        DiagramParentCandidateScore = sourceScore + 120
    ElseIf childLevel = 1 And parentLevel = 0 And parentId = GetDecedentId() Then
        DiagramParentCandidateScore = sourceScore + 220
    End If
End Function

Private Function DiagramRelationAndNoteForPersonRow(ByVal personRow As Long) As String
    Dim wp As Worksheet
    Dim relText As String, displayText As String, noteText As String, outText As String
    If personRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    relText = CleanText(wp.Cells(personRow, P_REL_DEC).Value)
    displayText = CleanText(wp.Cells(personRow, P_REL_DISP).Value)
    noteText = CleanText(wp.Cells(personRow, P_NOTE).Value)

    'P_REL_DEC �� P_REL_DISP �������l�̂Ƃ��Ɂu�� ���v�u�� ��v�̂悤��
    '�d������������ƁA�����֌W�}�̐��㔻�肪���s����B
    '�֌W�̐c��1�ɍi��A�\�������ʒl�̂Ƃ������⏕���Ƃ��đ����B
    If Len(relText) = 0 Then relText = displayText
    outText = relText
    If Len(displayText) > 0 And displayText <> relText Then
        If Len(outText) > 0 Then outText = outText & " "
        outText = outText & displayText
    End If
    If Len(noteText) > 0 Then
        If Len(outText) > 0 Then outText = outText & " "
        outText = outText & noteText
    End If
    DiagramRelationAndNoteForPersonRow = CleanText(outText)
End Function

Private Function DiagramRelationAndNoteForPersonId(ByVal personId As String) As String
    DiagramRelationAndNoteForPersonId = DiagramRelationAndNoteForPersonRow(FindPersonRow(CleanText(personId)))
End Function

Private Function DiagramStoredBaseIdForPersonRow(ByVal personRow As Long) As String
    If personRow <= 0 Then Exit Function
    DiagramStoredBaseIdForPersonRow = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_SUR_SRC).Value)
End Function

Private Function DiagramSpouseStoredBloodlineBaseId(ByVal spouseId As String, Optional ByVal childRow As Long = 0) As String
    Dim spouseRow As Long, baseId As String, baseRow As Long
    spouseRow = FindPersonRow(CleanText(spouseId))
    If spouseRow <= 0 Then Exit Function
    If Not DiagramPersonRowIsPureSpouse(spouseRow) Then Exit Function
    baseId = DiagramStoredBaseIdForPersonRow(spouseRow)
    baseRow = FindPersonRow(baseId)
    If baseRow <= 0 Then Exit Function
    If DiagramParentLevelForChildren(DiagramRelationDisplayTextForPersonRow(baseRow)) <= 0 Then Exit Function
    If Not DiagramSpouseRelationAllowsChild(spouseId, baseId, childRow) Then Exit Function
    DiagramSpouseStoredBloodlineBaseId = baseId
End Function

Private Function DiagramPrimaryParentIdForDrawing(ByVal candidateParentId As String, ByVal childId As String, ByVal childRow As Long) As String
    Dim partnerId As String, childLevel As Long, expectedParentLevel As Long
    Dim storedBloodlineId As String, candidateRow As Long, candidateRel As String
    candidateParentId = CleanText(candidateParentId)
    childId = CleanText(childId)
    If Len(candidateParentId) = 0 Or Len(childId) = 0 Then Exit Function
    DiagramPrimaryParentIdForDrawing = candidateParentId
    candidateRow = FindPersonRow(candidateParentId)
    If candidateRow <= 0 Then Exit Function
    If Not DiagramPersonRowIsPureSpouse(candidateRow) Then Exit Function
    If DiagramChildHasSeparateParentNote(DiagramRelationAndNoteForPersonRow(childRow)) Then Exit Function

    storedBloodlineId = DiagramSpouseStoredBloodlineBaseId(candidateParentId, childRow)
    If Len(storedBloodlineId) > 0 Then
        DiagramPrimaryParentIdForDrawing = storedBloodlineId
        Exit Function
    End If

    candidateRel = DiagramRelationAndNoteForPersonId(candidateParentId)
    expectedParentLevel = DiagramParentLevelForChildren(candidateRel)
    If expectedParentLevel <= 0 Then
        childLevel = DiagramDescendantLevel(DiagramRelationAndNoteForPersonId(childId))
        If childLevel <= 0 Then childLevel = DiagramDescendantLevel(DiagramRelationDisplayTextForPersonRow(childRow))
        If childLevel > 1 Then expectedParentLevel = childLevel - 1
    End If
    partnerId = DiagramSpousePartnerAtParentLevel(candidateParentId, expectedParentLevel, childRow)
    If Len(partnerId) > 0 Then DiagramPrimaryParentIdForDrawing = partnerId
End Function

Private Function DiagramSpousePartnerAtParentLevel(ByVal spouseId As String, ByVal expectedParentLevel As Long, Optional ByVal childRow As Long = 0) As String
    Dim wr As Worksheet, r As Long, baseId As String, otherId As String, partnerId As String
    Dim partnerRel As String
    spouseId = CleanText(spouseId)
    If Len(spouseId) = 0 Or expectedParentLevel < 0 Then Exit Function
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If DiagramGraphIsSpouseRelationType(CleanText(wr.Cells(r, R_TYPE).Value)) Then
                baseId = CleanText(wr.Cells(r, R_BASE_ID).Value)
                otherId = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                partnerId = ""
                If baseId = spouseId Then
                    partnerId = otherId
                ElseIf otherId = spouseId Then
                    partnerId = baseId
                End If
                If Len(partnerId) > 0 Then
                    partnerRel = DiagramRelationAndNoteForPersonId(partnerId)
                    If InStr(1, partnerRel, "�z���", vbTextCompare) = 0 Then
                        If DiagramSpouseRelationRowCoversChild(wr, r, childRow) Then
                            If expectedParentLevel <= 0 Then
                                If DiagramParentLevelForChildren(partnerRel) > 0 Then
                                    DiagramSpousePartnerAtParentLevel = partnerId
                                    Exit Function
                                End If
                            ElseIf DiagramParentLevelForChildren(partnerRel) = expectedParentLevel Then
                                DiagramSpousePartnerAtParentLevel = partnerId
                                Exit Function
                            End If
                        End If
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function DiagramSpouseRelationAllowsChild(ByVal spouseId As String, ByVal partnerId As String, ByVal childRow As Long) As Boolean
    Dim wr As Worksheet, r As Long, b As String, o As String, foundRelation As Boolean
    Dim m As Variant, d As Variant
    spouseId = CleanText(spouseId)
    partnerId = CleanText(partnerId)
    If Len(spouseId) = 0 Or Len(partnerId) = 0 Then Exit Function

    '�v�w���Ԃ��s���Ȃ�J�����ԂƂ��Ĉ������A�l�����ɍ������E������������ΕK���o���N�����Əƍ�����B
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then
        DiagramEffectiveSpouseDatesForPair spouseId, partnerId, Empty, Empty, m, d
        DiagramSpouseRelationAllowsChild = DiagramSpouseRelationCoversChildRow(m, d, childRow)
        Exit Function
    End If

    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If DiagramGraphIsSpouseRelationType(CleanText(wr.Cells(r, R_TYPE).Value)) Then
                b = CleanText(wr.Cells(r, R_BASE_ID).Value)
                o = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                If (b = spouseId And o = partnerId) Or (b = partnerId And o = spouseId) Then
                    foundRelation = True
                    DiagramSpouseRelationAllowsChild = DiagramSpouseRelationRowCoversChild(wr, r, childRow)
                    Exit Function
                End If
            End If
        End If
    Next r

    If Not foundRelation Then
        DiagramEffectiveSpouseDatesForPair spouseId, partnerId, Empty, Empty, m, d
        DiagramSpouseRelationAllowsChild = DiagramSpouseRelationCoversChildRow(m, d, childRow)
    End If
End Function

Private Function DiagramSpouseRelationCoversChildRow(ByVal marriageDate As Variant, ByVal divorceDate As Variant, ByVal childRow As Long) As Boolean
    Dim birthValue As Variant
    If childRow > 0 Then birthValue = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_BIRTH).Value
    DiagramSpouseRelationCoversChildRow = DiagramDateWithinOpenPeriod(birthValue, marriageDate, divorceDate)
End Function

Private Function DiagramSpouseRelationRowCoversChild(ByVal wr As Worksheet, ByVal relRow As Long, ByVal childRow As Long) As Boolean
    Dim b As String, o As String, m As Variant, d As Variant
    If wr Is Nothing Or relRow <= 0 Then
        DiagramSpouseRelationRowCoversChild = True
        Exit Function
    End If
    b = CleanText(wr.Cells(relRow, R_BASE_ID).Value)
    o = CleanText(wr.Cells(relRow, R_OTHER_ID).Value)
    DiagramEffectiveSpouseDatesForPair b, o, wr.Cells(relRow, R_MARRIAGE).Value, wr.Cells(relRow, R_DIVORCE).Value, m, d
    DiagramSpouseRelationRowCoversChild = DiagramSpouseRelationCoversChildRow(m, d, childRow)
End Function

Private Sub DiagramEffectiveSpouseDatesForPair(ByVal leftId As String, _
        ByVal rightId As String, _
        ByVal relationMarriageDate As Variant, _
        ByVal relationDivorceDate As Variant, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant)
    marriageDate = Empty
    divorceDate = Empty
    If HasInputDate(relationMarriageDate) Then marriageDate = SameDateOrBlank(relationMarriageDate)
    If HasInputDate(relationDivorceDate) Then divorceDate = SameDateOrBlank(relationDivorceDate)
    If Not HasInputDate(marriageDate) Then marriageDate = FirstPersonMarriageFieldDate(leftId, rightId, True)
    If Not HasInputDate(divorceDate) Then divorceDate = FirstPersonMarriageFieldDate(leftId, rightId, False)
End Sub

Private Function DiagramDateWithinOpenPeriod(ByVal targetDate As Variant, ByVal startDate As Variant, ByVal endDate As Variant) As Boolean
    If Not HasInputDate(targetDate) Then
        DiagramDateWithinOpenPeriod = True
        Exit Function
    End If
    If HasInputDate(startDate) Then
        If CDate(SameDateOrBlank(targetDate)) < CDate(SameDateOrBlank(startDate)) Then Exit Function
    End If
    If HasInputDate(endDate) Then
        If CDate(SameDateOrBlank(targetDate)) > CDate(SameDateOrBlank(endDate)) Then Exit Function
    End If
    DiagramDateWithinOpenPeriod = True
End Function

Private Function DiagramParentIsSpousePartnerForChild(ByVal candidateParentId As String, ByVal requestedParentId As String, ByVal childRow As Long) As Boolean
    Dim childId As String, primaryId As String
    candidateParentId = CleanText(candidateParentId)
    requestedParentId = CleanText(requestedParentId)
    If Len(candidateParentId) = 0 Or Len(requestedParentId) = 0 Or childRow <= 0 Then Exit Function
    If candidateParentId = requestedParentId Then Exit Function
    childId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    If Len(childId) = 0 Then Exit Function
    primaryId = DiagramPrimaryParentIdForDrawing(candidateParentId, childId, childRow)
    DiagramParentIsSpousePartnerForChild = (primaryId = requestedParentId)
End Function

Private Function CandidateParentMatchesChildLevel(ByVal candidateId As String, _
        ByVal childId As String, _
        ByVal childLevel As Long, _
        ByVal allowSpouseParent As Boolean, _
        Optional ByVal allowStaleChildLevel As Boolean = False) As Boolean
    Dim parentRow As Long, rawParentRel As String, parentLevel As Long
    candidateId = CleanText(candidateId)
    childId = CleanText(childId)
    If Len(candidateId) = 0 Or Len(childId) = 0 Then Exit Function
    If candidateId = childId Then Exit Function
    parentRow = FindPersonRow(candidateId)
    If parentRow = 0 Then Exit Function
    If Not VisibleDiagramPersonRow(parentRow) Then Exit Function
    rawParentRel = DiagramRelationAndNoteForPersonRow(parentRow)
    If Not allowSpouseParent And InStr(1, rawParentRel, "�z���", vbTextCompare) > 0 Then Exit Function
    parentLevel = DiagramParentLevelForChildren(rawParentRel)
    If childLevel = 1 Then
        CandidateParentMatchesChildLevel = (parentLevel = 0 And candidateId = GetDecedentId())
    ElseIf parentLevel > 0 Then
        If childLevel = parentLevel + 1 Then
            CandidateParentMatchesChildLevel = True
        ElseIf allowStaleChildLevel Then
            '�o�^���̊�l��ID���c���Ă���ꍇ�����A���ł̂܂ܓ�����E�󂢐���Ɏc�����q���~�ς���B
            '��Ӑ���ł͂�����������A���E�]�����t�����Ɍ�ڑ����Ȃ��B
            CandidateParentMatchesChildLevel = (childLevel <= parentLevel)
        End If
    End If
End Function

Private Function UniqueDiagramParentCandidateId(ByVal childId As String, ByVal childLevel As Long, ByVal allowSpouseParent As Boolean) As String
    Dim wp As Worksheet, r As Long, candidateId As String, foundId As String, countFound As Long
    If childLevel <= 1 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        candidateId = CleanText(wp.Cells(r, P_ID).Value)
        If CandidateParentMatchesChildLevel(candidateId, childId, childLevel, allowSpouseParent) Then
            countFound = countFound + 1
            foundId = candidateId
            If countFound > 1 Then
                UniqueDiagramParentCandidateId = ""
                Exit Function
            End If
        End If
    Next r
    If countFound = 1 Then UniqueDiagramParentCandidateId = foundId
End Function

Private Function VisibleDiagramPersonRow(ByVal personRow As Long) As Boolean
    Dim wp As Worksheet
    If personRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    If Len(CleanText(wp.Cells(personRow, P_ID).Value)) = 0 Then Exit Function
    If CleanText(wp.Cells(personRow, P_STATUS).Value) = STATUS_CANCEL Then Exit Function
    If CleanText(wp.Cells(personRow, P_SHOW).Value) = SHOW_NO Then Exit Function
    VisibleDiagramPersonRow = True
End Function

Private Sub ChildLinkOriginForDiagram(ByVal parentId As String, _
        ByVal childRow As Long, _
        ByVal parentShape As Shape, _
        ByVal spouseShape As Shape, _
        ByVal coupleOriginX As Double, _
        ByVal coupleOriginY As Double, _
        ByRef originX As Double, _
        ByRef originY As Double)
    Dim spouseId As String
    If parentShape Is Nothing Then Exit Sub
    originX = ShapeCenterX(parentShape)
    originY = parentShape.Top + parentShape.Height
    If spouseShape Is Nothing Then Exit Sub
    spouseId = ShapePersonId(spouseShape)
    If Len(spouseId) = 0 Then Exit Sub

    If ChildShouldUseSpouseCardOriginForDiagram(childRow, spouseId) Then
        originX = ShapeCenterX(spouseShape)
        originY = spouseShape.Top + spouseShape.Height
        Exit Sub
    End If

    '�v�w�u���b�N������ʏ�P�[�X�ł́A�q�ւ̐��͕v�w���������牺�낷�B
    '�O�z��ҁE�ʕ���E�A��q�ȂǁA���ݔz��҂ƕ�����ׂ����L������ꍇ�����Аe�J�[�h�N�_�ɖ߂��B
    If ChildShouldUseCoupleOriginForDiagram(childRow, parentId, spouseId) Then
        originX = coupleOriginX
        originY = coupleOriginY
    End If
End Sub

Private Function ChildShouldUseSpouseCardOriginForDiagram(ByVal childRow As Long, ByVal spouseId As String) As Boolean
    Dim childParentId As String
    spouseId = CleanText(spouseId)
    If childRow <= 0 Or Len(spouseId) = 0 Then Exit Function
    If DiagramGraphIsBuilt() Then
        childParentId = DiagramGraphParentIdForChildRow(childRow)
        ChildShouldUseSpouseCardOriginForDiagram = (childParentId = spouseId)
    End If
End Function

Private Function ChildShouldUseCoupleOriginForDiagram(ByVal childRow As Long, ByVal parentId As String, ByVal spouseId As String) As Boolean
    Dim graphChildId As String
    If childRow > 0 And DiagramGraphEnsureBuilt(GetDecedentId()) Then
        graphChildId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
        ChildShouldUseCoupleOriginForDiagram = DiagramGraphChildUsesCoupleOrigin(graphChildId, parentId, spouseId)
    End If
End Function

Private Function DiagramChildHasSeparateParentNote(ByVal relAndNote As String) As Boolean
    relAndNote = CleanText(relAndNote)
    DiagramChildHasSeparateParentNote = (InStr(relAndNote, "�O�z���") > 0 _
        Or InStr(relAndNote, "�O��") > 0 _
        Or InStr(relAndNote, "�O�v") > 0 _
        Or InStr(relAndNote, "�ʕ�") > 0 _
        Or InStr(relAndNote, "�ʕ�") > 0 _
        Or InStr(relAndNote, "�A��q") > 0)
End Function

Private Function ShapePersonId(ByVal shp As Shape) As String
    Dim altText As String
    If shp Is Nothing Then Exit Function
    On Error Resume Next
    altText = CStr(shp.AlternativeText)
    On Error GoTo 0
    If Left$(altText, 9) = "personId=" Then
        ShapePersonId = Mid$(altText, 10)
    ElseIf Left$(shp.Name, 5) = "card_" Then
        ShapePersonId = Mid$(shp.Name, 6)
    End If
End Function

Private Function FindPersonCardShape(ByVal ws As Worksheet, ByVal personId As String) As Shape
    Dim shp As Shape
    If ws Is Nothing Then Exit Function
    If Len(personId) = 0 Then Exit Function
    For Each shp In ws.Shapes
        If ShapePersonId(shp) = personId Then
            Set FindPersonCardShape = shp
            Exit Function
        End If
    Next shp
End Function

Private Function UniqueShapeName(ByVal ws As Worksheet, ByVal baseName As String) As String
    Dim i As Long, candidate As String, rootName As String
    rootName = SafeShapeNameToken(baseName)
    If Len(rootName) = 0 Then rootName = "shape"
    If Len(rootName) > 120 Then rootName = Left$(rootName, 120)
    candidate = rootName
    i = 1
    Do While ShapeNameExists(ws, candidate)
        i = i + 1
        candidate = Left$(rootName, 110) & "_" & CStr(i)
        If i > 9999 Then
            candidate = Left$(rootName, 90) & "_" & Format$(Now, "hhmmss") & "_" & CStr(i)
            Exit Do
        End If
    Loop
    UniqueShapeName = candidate
End Function

Private Function SafeShapeNameToken(ByVal rawText As String) As String
    Dim i As Long, ch As String, outText As String
    rawText = CleanText(rawText)
    If Len(rawText) = 0 Then
        SafeShapeNameToken = "shape"
        Exit Function
    End If
    For i = 1 To Len(rawText)
        ch = Mid$(rawText, i, 1)
        If ch Like "[A-Za-z0-9_]" Then
            outText = outText & ch
        Else
            outText = outText & "_"
        End If
    Next i
    Do While InStr(outText, "__") > 0
        outText = Replace(outText, "__", "_")
    Loop
    If Left$(outText, 1) = "_" Then outText = "sh" & outText
    SafeShapeNameToken = outText
End Function

Private Function SafeDiagramPoint(ByVal valuePt As Double, Optional ByVal fallbackPt As Double = 1) As Double
    If valuePt < 1 Or valuePt > 30000 Then
        SafeDiagramPoint = fallbackPt
    Else
        SafeDiagramPoint = valuePt
    End If
End Function

Private Function SafeDiagramSize(ByVal valuePt As Double, Optional ByVal fallbackPt As Double = 120) As Double
    If valuePt < 8 Or valuePt > 3000 Then
        SafeDiagramSize = fallbackPt
    Else
        SafeDiagramSize = valuePt
    End If
End Function

Private Sub AppendRelationshipDiagramDrawWarning(ByVal phaseText As String, ByVal detailText As String)
    Dim wsC As Worksheet, outR As Long
    On Error Resume Next
    RuntimeAppendLog "WARN", "�����֌W�}", phaseText, detailText, 0, detailText, ""
    If SheetExists(SH_CHECK, ThisWorkbook) Then
        Set wsC = ThisWorkbook.Worksheets(SH_CHECK)
        outR = LastRow(wsC, 1) + 1
        If outR < 4 Then outR = 4
        AddCheck wsC, outR, "�x��", "�����֌W�}�̕`����ꕔ�X�L�b�v���܂����B" & detailText, "", "", "�����֌W�}", "�l���֌W�ƏZ���������m�F"
    End If
    On Error GoTo 0
End Sub

Private Function ShapeNameExists(ByVal ws As Worksheet, ByVal shapeName As String) As Boolean
    Dim tmp As Shape
    If ws Is Nothing Then Exit Function
    If Len(shapeName) = 0 Then Exit Function
    On Error Resume Next
    Set tmp = ws.Shapes(shapeName)
    ShapeNameExists = Not tmp Is Nothing
    Set tmp = Nothing
    On Error GoTo 0
End Function

Private Function ChildRowCanAppearUnderParent(ByVal childRow As Long, ByVal parentId As String) As Boolean
    Dim wp As Worksheet, childId As String
    parentId = CleanText(parentId)
    If childRow <= 0 Or Len(parentId) = 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    If CleanText(wp.Cells(childRow, P_STATUS).Value) = STATUS_CANCEL Then Exit Function
    If CleanText(wp.Cells(childRow, P_SHOW).Value) = SHOW_NO Then Exit Function
    childId = CleanText(wp.Cells(childRow, P_ID).Value)
    If Len(childId) = 0 Or childId = parentId Then Exit Function
    If DiagramPersonRowIsPureSpouse(childRow) Then Exit Function
    If DiagramPersonIsOtherRelationOnly(childRow) Then Exit Function
    If DiagramRelationIsParentOrSiblingForDiagram(DiagramRelationAndNoteForPersonRow(childRow)) Then Exit Function

    '�����o�����ǂ����́A�m��ς݂̐}��eID�����Ō��߂�B
    '���������Ō�ǂ����肷��ƁA�����q���e�J�[�h�����ƕv�w�����̓�d���ɂȂ�B
    ChildRowCanAppearUnderParent = (InferredDiagramParentIdForChildRow(childRow) = parentId)
End Function

Private Function DiagramPersonRowIsPureSpouse(ByVal personRow As Long) As Boolean
    Dim graphPid As String
    If personRow <= 0 Then Exit Function
    graphPid = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    If Len(graphPid) = 0 Then Exit Function
    If DiagramGraphEnsureBuilt(GetDecedentId()) Then _
        DiagramPersonRowIsPureSpouse = DiagramGraphIsPureSpouseId(graphPid)
End Function

Private Function DiagramSpouseRelationExists(ByVal personA As String, ByVal personB As String) As Boolean
    Dim wr As Worksheet, r As Long, b As String, o As String
    personA = CleanText(personA)
    personB = CleanText(personB)
    If Len(personA) = 0 Or Len(personB) = 0 Or personA = personB Then Exit Function
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If DiagramGraphIsSpouseRelationType(CleanText(wr.Cells(r, R_TYPE).Value)) Then
                b = CleanText(wr.Cells(r, R_BASE_ID).Value)
                o = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                If (b = personA And o = personB) Or (b = personB And o = personA) Then
                    DiagramSpouseRelationExists = True
                    Exit Function
                End If
            End If
        End If
    Next r
End Function

Private Function DiagramRelationIsParentOrSiblingForDiagram(ByVal relText As String) As Boolean
    Dim n As String
    n = NormalizeDiagramRelationText(relText)
    Select Case n
        Case "��", "��", "�Z", "��", "�o", "��", "�Z��", "�o��", "�Z��o��"
            DiagramRelationIsParentOrSiblingForDiagram = True
    End Select
End Function

Private Function DiagramRelationTextIsSpouseChild(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    If Len(relText) = 0 Then Exit Function
    DiagramRelationTextIsSpouseChild = (InStr(1, relText, "�z��҂̎q", vbTextCompare) > 0 _
        Or InStr(1, relText, "�z��ҁE�q", vbTextCompare) > 0 _
        Or InStr(1, relText, "�z��҂̂�", vbTextCompare) > 0)
End Function

Private Function DiagramChildBelongsUnderParentBySpouseMarriage(ByVal childRow As Long, ByVal parentId As String) As Boolean
    Dim wp As Worksheet, childId As String, srcId As String
    Dim wr As Worksheet, r As Long, b As String, o As String, candidateId As String
    parentId = CleanText(parentId)
    If childRow <= 0 Or Len(parentId) = 0 Then Exit Function
    If DiagramPersonRowIsPureSpouse(childRow) Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    childId = CleanText(wp.Cells(childRow, P_ID).Value)
    If Len(childId) = 0 Or childId = parentId Then Exit Function

    srcId = CleanText(wp.Cells(childRow, P_SUR_SRC).Value)
    If Len(srcId) > 0 Then
        If DiagramBloodlinePartnerForSpouseCandidate(srcId, childRow) = parentId Then
            DiagramChildBelongsUnderParentBySpouseMarriage = True
            Exit Function
        End If
    End If

    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If DiagramGraphIsParentChildRelationRow(wr, r) Then
                b = CleanText(wr.Cells(r, R_BASE_ID).Value)
                o = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                candidateId = ""
                If o = childId Then
                    candidateId = b
                ElseIf b = childId Then
                    candidateId = o
                End If
                If Len(candidateId) > 0 Then
                    If DiagramBloodlinePartnerForSpouseCandidate(candidateId, childRow) = parentId Then
                        DiagramChildBelongsUnderParentBySpouseMarriage = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function NormalizeDiagramRelationText(ByVal relText As String) As String
    Dim rawText As String, baseText As String, directToken As String
    rawText = CleanText(relText)
    baseText = RelationshipStructuralText(RelationshipCanonicalStoredLabel(rawText))
    If Len(baseText) = 0 Then Exit Function

    '�d���\������l���������Ă��A�܂�������̊֌W���x�������o���B
    '��: �u�� ���v�����A�u�� ��v����A�u�]���i�O�z��҂Ƃ̎q�j�v���]���B
    If InStr(1, baseText, "���̔z���", vbTextCompare) > 0 Then
        NormalizeDiagramRelationText = "��"
        Exit Function
    End If
    If InStr(1, baseText, "��̔z���", vbTextCompare) > 0 Then
        NormalizeDiagramRelationText = "��"
        Exit Function
    End If
    If DiagramRelationStartsWithToken(baseText, "�푊���l") Then NormalizeDiagramRelationText = "�푊���l": Exit Function
    If DiagramRelationStartsWithToken(baseText, "��") Then NormalizeDiagramRelationText = "��": Exit Function
    If DiagramRelationStartsWithToken(baseText, "��") Then NormalizeDiagramRelationText = "��": Exit Function

    '�z��҂̎q�́A�\����͔푊���l���猩������֗��Ƃ��B
    '�O�z��Ғ��L�͕\���֐����Ŗ߂��B�����ł͐���v�Z�����肳���邱�Ƃ�D�悷��B
    If DiagramRelationContainsSpouseChildChain(baseText, "�]��") Then
        NormalizeDiagramRelationText = "����"
        Exit Function
    End If
    If DiagramRelationContainsSpouseChildChain(baseText, "�\��") Then
        NormalizeDiagramRelationText = "����"
        Exit Function
    End If
    If DiagramRelationContainsSpouseChildChain(baseText, "�Б�") Then
        NormalizeDiagramRelationText = "����"
        Exit Function
    End If
    If DiagramRelationContainsSpouseChildChain(baseText, "��") Then
        NormalizeDiagramRelationText = "�]��"
        Exit Function
    End If
    If DiagramRelationContainsSpouseChildChain(baseText, "�q") Then
        NormalizeDiagramRelationText = "��"
        Exit Function
    End If

    If InStr(baseText, "�]���̎q") > 0 Or InStr(baseText, "�\���̎q") > 0 Or InStr(baseText, "�Б��̎q") > 0 Then
        NormalizeDiagramRelationText = "����"
        Exit Function
    End If
    If InStr(baseText, "���̎q") > 0 Then
        NormalizeDiagramRelationText = "�]��"
        Exit Function
    End If

    '�u���̔z��ҁv�Ȃǂ͌����{�l�ł͂Ȃ����߁A�����ő��ׂ֒��Ȃ��B
    If DiagramRelationStartsWithToken(baseText, "����") And InStr(1, baseText, "�̔z���", vbTextCompare) = 0 Then
        NormalizeDiagramRelationText = "����"
        Exit Function
    End If
    If RelationTextContainsGreatGrandchild(baseText) And InStr(1, baseText, "�̔z���", vbTextCompare) = 0 Then
        NormalizeDiagramRelationText = "�]��"
        Exit Function
    End If
    If DiagramRelationStartsWithToken(baseText, "��") And InStr(1, baseText, "�̔z���", vbTextCompare) = 0 Then
        NormalizeDiagramRelationText = "��"
        Exit Function
    End If

    directToken = DiagramDirectChildRelationToken(baseText)
    If Len(directToken) > 0 Then
        NormalizeDiagramRelationText = directToken
        Exit Function
    End If

    If DiagramRelationStartsWithToken(baseText, "�O�z���") Then
        NormalizeDiagramRelationText = "�O�z���"
    ElseIf DiagramRelationStartsWithToken(baseText, "�z���") Then
        NormalizeDiagramRelationText = "�z���"
    ElseIf DiagramRelationStartsWithToken(baseText, "�Z") Then
        NormalizeDiagramRelationText = "�Z"
    ElseIf DiagramRelationStartsWithToken(baseText, "��") Then
        NormalizeDiagramRelationText = "��"
    ElseIf DiagramRelationStartsWithToken(baseText, "�o") Then
        NormalizeDiagramRelationText = "�o"
    ElseIf DiagramRelationStartsWithToken(baseText, "��") Then
        NormalizeDiagramRelationText = "��"
    ElseIf DiagramRelationStartsWithToken(baseText, "�Z��o��") Then
        NormalizeDiagramRelationText = "�Z��o��"
    Else
        NormalizeDiagramRelationText = baseText
    End If
End Function

Private Function DiagramRelationStartsWithToken(ByVal relText As String, ByVal tokenText As String) As Boolean
    Dim n As Long, nextChar As String
    relText = CleanText(relText)
    tokenText = CleanText(tokenText)
    n = Len(tokenText)
    If n = 0 Or Len(relText) < n Then Exit Function
    If Left$(relText, n) <> tokenText Then Exit Function
    If Len(relText) = n Then
        DiagramRelationStartsWithToken = True
    Else
        nextChar = Mid$(relText, n + 1, 1)
        DiagramRelationStartsWithToken = (nextChar = " " Or nextChar = "�@" Or nextChar = "�i" Or nextChar = "(" Or nextChar = "�E" Or nextChar = "�A")
    End If
End Function

Private Function DiagramRelationContainsSpouseChildChain(ByVal relText As String, ByVal baseLabel As String) As Boolean
    relText = CleanText(relText)
    baseLabel = CleanText(baseLabel)
    If Len(relText) = 0 Or Len(baseLabel) = 0 Then Exit Function
    DiagramRelationContainsSpouseChildChain = (InStr(1, relText, baseLabel & "�̔z��҂̎q", vbTextCompare) > 0 _
        Or InStr(1, relText, baseLabel & "�̔z��ҁE�q", vbTextCompare) > 0 _
        Or InStr(1, relText, baseLabel & "�̔z��҂̂�", vbTextCompare) > 0)
End Function

Private Function DiagramDirectChildRelationToken(ByVal relText As String) As String
    Dim labels As Variant, i As Long, labelText As String
    relText = CleanText(relText)
    If InStr(1, relText, "�̔z���", vbTextCompare) > 0 Then Exit Function
    labels = Array("���j", "��j", "�O�j", "�l�j", "�ܒj", "�Z�j", _
        "����", "��", "�O��", "�l��", "�܏�", "�Z��", "�{�q", "�q")
    For i = LBound(labels) To UBound(labels)
        labelText = CStr(labels(i))
        If DiagramRelationStartsWithToken(relText, labelText) Then
            DiagramDirectChildRelationToken = labelText
            Exit Function
        End If
    Next i
End Function

Private Function DiagramRelationDisplayText(ByVal relationText As String) As String
    Dim rawText As String, baseText As String
    rawText = CleanText(relationText)
    baseText = NormalizeDiagramRelationText(rawText)
    If Len(baseText) = 0 Then baseText = rawText
    If Len(baseText) = 0 Then Exit Function
    If InStr(rawText, "�O�z���") > 0 Then
        If InStr(baseText, "�O�z���") = 0 Then baseText = baseText & "�i�O�z��҂Ƃ̎q�j"
    End If
    If InStr(rawText, "�������ԗv�m�F") > 0 Then
        If InStr(baseText, "�������ԗv�m�F") = 0 Then baseText = baseText & "�i�������ԗv�m�F�j"
    End If
    DiagramRelationDisplayText = baseText
End Function

Private Function DiagramRelationDisplayTextForPersonRow(ByVal personRow As Long) As String
    Dim graphPid As String, graphRel As String, graphRawStored As String, graphNote As String
    If personRow > 0 Then
        graphPid = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
        If DiagramGraphEnsureBuilt(GetDecedentId()) Then
            graphRel = DiagramGraphDisplayRelation(graphPid, vbNullString)
            If Len(graphRel) > 0 Then
                graphRawStored = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_REL_DEC).Value)
                graphNote = RelationshipNoteSuffix(graphRawStored)
                If Len(graphNote) > 0 And InStr(1, graphRel, graphNote, vbTextCompare) = 0 Then graphRel = graphRel & graphNote
                DiagramRelationDisplayTextForPersonRow = DiagramRelationDisplayText(graphRel)
                Exit Function
            End If
        End If
    End If
    Dim wp As Worksheet, rawText As String, displayText As String
    Dim childLevel As Long, parentId As String, parentLevel As Long, derivedText As String
    If personRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    rawText = DiagramRelationAndNoteForPersonRow(personRow)
    displayText = DiagramParentSpouseDisplayLabel(personRow, rawText)
    If Len(displayText) = 0 Then displayText = DiagramDisplayLabelForPureSpouseRow(personRow)
    If Len(displayText) = 0 Then displayText = DiagramRelationDisplayText(CleanText(wp.Cells(personRow, P_REL_DEC).Value))

    '�z��҃J�[�h�͎q�����x���֕ϊ����Ȃ��B
    '�u�q�̔z��ҁv���u���v�A�u���̔z��ҁv���u�]���v�Ƃ�����\���̌����͂����������B
    If DiagramPersonRowIsPureSpouse(personRow) Then
        DiagramRelationDisplayTextForPersonRow = displayText
        Exit Function
    End If

    '�q���J�[�h�́A�ۑ��ς݃��x���ł͂Ȃ��m��eID�̐��ォ��\����␳����B
    '���łŁu�]���v���u�����v�ւ���ĕۑ��ς݂ł��A���̉��ɕ`���Ȃ�\���͑]���֖߂��B
    parentId = InferredDiagramParentIdForChildRow(personRow)
    If Len(parentId) > 0 Then
        parentLevel = DiagramResolvedDescendantLevelForPersonId(parentId, 0)
        If parentLevel >= 1 Then
            derivedText = DiagramDescendantLabelFromLevel(parentLevel + 1)
            If Len(derivedText) > 0 Then displayText = derivedText
        ElseIf parentLevel = 0 Then
            childLevel = DiagramDescendantLevel(displayText)
            If childLevel <> 1 Then
                If IsDirectChildRelationText(CleanText(wp.Cells(personRow, P_REL_DEC).Value)) Then
                    displayText = DiagramRelationDisplayText(CleanText(wp.Cells(personRow, P_REL_DEC).Value))
                Else
                    displayText = "�q"
                End If
            End If
        End If
    End If
    DiagramRelationDisplayTextForPersonRow = displayText
End Function

Private Function DiagramDisplayLabelForPureSpouseRow(ByVal personRow As Long) As String
    Dim partnerId As String, partnerLevel As Long, rawText As String
    If personRow <= 0 Then Exit Function
    If Not DiagramPersonRowIsPureSpouse(personRow) Then Exit Function
    rawText = DiagramRelationAndNoteForPersonRow(personRow)

    '�e����̔z��҂͕���֖߂��B
    DiagramDisplayLabelForPureSpouseRow = DiagramParentSpouseDisplayLabel(personRow, rawText)
    If Len(DiagramDisplayLabelForPureSpouseRow) > 0 Then Exit Function

    partnerId = DiagramBloodlinePartnerForPureSpouseRow(personRow)
    partnerLevel = DiagramResolvedDescendantLevelForPersonId(partnerId, 0)
    Select Case partnerLevel
        Case 0
            DiagramDisplayLabelForPureSpouseRow = "�z���"
        Case 1
            DiagramDisplayLabelForPureSpouseRow = "�q�̔z���"
        Case 2
            DiagramDisplayLabelForPureSpouseRow = "���̔z���"
        Case 3
            DiagramDisplayLabelForPureSpouseRow = "�]���̔z���"
        Case 4
            DiagramDisplayLabelForPureSpouseRow = "�����̔z���"
        Case Else
            DiagramDisplayLabelForPureSpouseRow = DiagramRelationDisplayText(CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_REL_DEC).Value))
    End Select
End Function

Private Function DiagramBloodlinePartnerForPureSpouseRow(ByVal personRow As Long) As String
    Dim wp As Worksheet, personId As String, storedId As String, wr As Worksheet
    Dim r As Long, b As String, o As String, partnerId As String
    If personRow <= 0 Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    personId = CleanText(wp.Cells(personRow, P_ID).Value)
    If Len(personId) = 0 Then Exit Function

    storedId = CleanText(wp.Cells(personRow, P_SUR_SRC).Value)
    If Len(storedId) > 0 And storedId <> personId Then
        If FindPersonRow(storedId) > 0 Then
            If DiagramSpouseRelationExists(personId, storedId) Or InStr(1, DiagramRelationAndNoteForPersonRow(personRow), "�z���", vbTextCompare) > 0 Then
                DiagramBloodlinePartnerForPureSpouseRow = storedId
                Exit Function
            End If
        End If
    End If

    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If DiagramGraphIsSpouseRelationType(CleanText(wr.Cells(r, R_TYPE).Value)) Then
                b = CleanText(wr.Cells(r, R_BASE_ID).Value)
                o = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                partnerId = ""
                If b = personId Then
                    partnerId = o
                ElseIf o = personId Then
                    partnerId = b
                End If
                If Len(partnerId) > 0 Then
                    DiagramBloodlinePartnerForPureSpouseRow = partnerId
                    Exit Function
                End If
            End If
        End If
    Next r
End Function

Private Function DiagramResolvedDescendantLevelForPersonId(ByVal personId As String, Optional ByVal depth As Long = 0) As Long
    Dim rowNo As Long, decId As String, rawRel As String, parentId As String, parentLevel As Long, partnerId As String
    personId = CleanText(personId)
    DiagramResolvedDescendantLevelForPersonId = -9
    If Len(personId) = 0 Or depth > 8 Then Exit Function
    decId = GetDecedentId()
    If Len(decId) > 0 And personId = decId Then
        DiagramResolvedDescendantLevelForPersonId = 0
        Exit Function
    End If
    rowNo = FindPersonRow(personId)
    If rowNo <= 0 Then Exit Function

    If DiagramPersonRowIsPureSpouse(rowNo) Then
        partnerId = DiagramBloodlinePartnerForPureSpouseRow(rowNo)
        If Len(partnerId) > 0 And partnerId <> personId Then
            DiagramResolvedDescendantLevelForPersonId = DiagramResolvedDescendantLevelForPersonId(partnerId, depth + 1)
            Exit Function
        End If
    End If

    parentId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(rowNo, P_SUR_SRC).Value)
    If Len(parentId) > 0 And parentId <> personId Then
        parentId = DiagramNormalizeParentCandidateByMarriage(parentId, rowNo)
        If Len(parentId) > 0 And parentId <> personId Then
            parentLevel = DiagramResolvedDescendantLevelForPersonId(parentId, depth + 1)
            If parentLevel >= 0 Then
                DiagramResolvedDescendantLevelForPersonId = parentLevel + 1
                Exit Function
            End If
        End If
    End If

    rawRel = DiagramRelationAndNoteForPersonRow(rowNo)
    If NormalizeDiagramRelationText(rawRel) = "�푊���l" Then
        DiagramResolvedDescendantLevelForPersonId = 0
    Else
        DiagramResolvedDescendantLevelForPersonId = DiagramDescendantLevel(rawRel)
        If DiagramResolvedDescendantLevelForPersonId = 0 Then DiagramResolvedDescendantLevelForPersonId = -9
    End If
End Function

Private Function DiagramParentSpouseDisplayLabel(ByVal personRow As Long, ByVal relationAndNoteText As String) As String
    Dim srcId As String, srcRel As String, inferredLabel As String, personId As String
    relationAndNoteText = CleanText(relationAndNoteText)
    If DiagramChildHasSeparateParentNote(relationAndNoteText) Then Exit Function
    srcId = DiagramStoredBaseIdForPersonRow(personRow)
    If Len(srcId) > 0 Then srcRel = NormalizeDiagramRelationText(CleanText(GetPersonValue(srcId, P_REL_DEC)))
    If InStr(1, relationAndNoteText, "���̔z���", vbTextCompare) > 0 Or (srcRel = "��" And InStr(1, relationAndNoteText, "�z���", vbTextCompare) > 0) Then
        DiagramParentSpouseDisplayLabel = "��"
        Exit Function
    ElseIf InStr(1, relationAndNoteText, "��̔z���", vbTextCompare) > 0 Or (srcRel = "��" And InStr(1, relationAndNoteText, "�z���", vbTextCompare) > 0) Then
        DiagramParentSpouseDisplayLabel = "��"
        Exit Function
    End If

    personId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    inferredLabel = DiagramParentSpouseLabelFromRelation(personId)
    If Len(inferredLabel) > 0 Then DiagramParentSpouseDisplayLabel = inferredLabel
End Function

Private Function DiagramParentSpouseLabelFromRelation(ByVal personId As String) As String
    Dim wr As Worksheet, r As Long, baseId As String, otherId As String, partnerId As String, partnerRel As String
    personId = CleanText(personId)
    If Len(personId) = 0 Or Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If DiagramGraphIsSpouseRelationType(CleanText(wr.Cells(r, R_TYPE).Value)) Then
                baseId = CleanText(wr.Cells(r, R_BASE_ID).Value)
                otherId = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                partnerId = ""
                If baseId = personId Then
                    partnerId = otherId
                ElseIf otherId = personId Then
                    partnerId = baseId
                End If
                If Len(partnerId) > 0 Then
                    partnerRel = NormalizeDiagramRelationText(DiagramRelationAndNoteForPersonId(partnerId))
                    If partnerRel = "��" Then
                        DiagramParentSpouseLabelFromRelation = "��"
                        Exit Function
                    ElseIf partnerRel = "��" Then
                        DiagramParentSpouseLabelFromRelation = "��"
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function DiagramRelationDisplayTextForPersonId(ByVal personId As String) As String
    On Error GoTo Fallback
    personId = CleanText(personId)
    If DiagramGraphEnsureBuilt(GetDecedentId()) Then
        DiagramRelationDisplayTextForPersonId = DiagramGraphDisplayRelation(personId, vbNullString)
        If Len(DiagramRelationDisplayTextForPersonId) > 0 Then Exit Function
    End If
    DiagramRelationDisplayTextForPersonId = DiagramRelationDisplayTextForPersonRow(FindPersonRow(personId))
    Exit Function
Fallback:
    Err.Clear
    On Error Resume Next
    DiagramRelationDisplayTextForPersonId = DiagramRelationDisplayTextForPersonRow(FindPersonRow(personId))
    If Len(DiagramRelationDisplayTextForPersonId) = 0 Then DiagramRelationDisplayTextForPersonId = DiagramRelationDisplayText(CleanText(GetPersonValue(personId, P_REL_DEC)))
    On Error GoTo 0
End Function

Private Function DiagramDescendantLabelFromLevel(ByVal levelNo As Long) As String
    DiagramDescendantLabelFromLevel = RelationshipDescendantLabel(levelNo)
End Function

Private Function RelationTextContainsGreatGrandchild(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    If InStr(relText, "�]��") > 0 Then
        RelationTextContainsGreatGrandchild = True
    ElseIf InStr(relText, "�\��") > 0 Then
        RelationTextContainsGreatGrandchild = True
    ElseIf InStr(relText, "�Б�") > 0 Then
        RelationTextContainsGreatGrandchild = True
    End If
End Function

Private Function IsGreatGrandchildRelationBase(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    If relText = "�]��" Or Left$(relText, 2) = "�]��" Then
        IsGreatGrandchildRelationBase = True
    ElseIf relText = "�\��" Or Left$(relText, 2) = "�\��" Then
        IsGreatGrandchildRelationBase = True
    ElseIf relText = "�Б�" Or Left$(relText, 3) = "�Б�" Then
        IsGreatGrandchildRelationBase = True
    End If
End Function

Private Function DiagramBaseRelationLabel(ByVal relText As String) As String
    DiagramBaseRelationLabel = RelationshipStructuralText(relText)
End Function

Private Function IsExpectedChildRelation(ByVal parentRel As String, ByVal childRel As String) As Boolean
    Dim pLevel As Long, cLevel As Long
    pLevel = DiagramParentLevelForChildren(parentRel)
    cLevel = DiagramDescendantLevel(childRel)
    If pLevel = 0 Then
        IsExpectedChildRelation = (cLevel = 1)
    ElseIf pLevel > 0 Then
        IsExpectedChildRelation = (cLevel = pLevel + 1)
    End If
End Function

Private Function DiagramParentLevelForChildren(ByVal relText As String) As Long
    Dim rawText As String, normText As String
    rawText = CleanText(relText)
    normText = NormalizeDiagramRelationText(rawText)

    If normText = "�푊���l" Or normText = "�z���" Or normText = "�O�z���" Then
        DiagramParentLevelForChildren = 0
        Exit Function
    End If

    If InStr(rawText, "�z���") > 0 Then
        If InStr(rawText, "����") > 0 Then
            DiagramParentLevelForChildren = 4
        ElseIf RelationTextContainsGreatGrandchild(rawText) Then
            DiagramParentLevelForChildren = 3
        ElseIf InStr(rawText, "��") > 0 Then
            DiagramParentLevelForChildren = 2
        ElseIf DiagramRelationContainsDirectChildLabel(rawText) Then
            DiagramParentLevelForChildren = 1
        End If
        Exit Function
    End If

    DiagramParentLevelForChildren = DiagramDescendantLevel(normText)
End Function

Private Function DiagramRelationContainsDirectChildLabel(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    If InStr(relText, "���j") > 0 Or InStr(relText, "��j") > 0 Or InStr(relText, "�O�j") > 0 _
            Or InStr(relText, "�l�j") > 0 Or InStr(relText, "�ܒj") > 0 Or InStr(relText, "�Z�j") > 0 _
            Or InStr(relText, "����") > 0 Or InStr(relText, "��") > 0 Or InStr(relText, "�O��") > 0 _
            Or InStr(relText, "�l��") > 0 Or InStr(relText, "�܏�") > 0 Or InStr(relText, "�Z��") > 0 _
            Or InStr(relText, "�{�q") > 0 Or InStr(relText, "�q") > 0 Then
        DiagramRelationContainsDirectChildLabel = True
    End If
End Function

Private Function DiagramDescendantLevel(ByVal relText As String) As Long
    relText = NormalizeDiagramRelationText(relText)
    DiagramDescendantLevel = RelationshipDescendantLevel(relText)
End Function

Private Sub AddPersonRowUnique(ByVal col As Collection, ByVal personRow As Long)
    Dim i As Long, pid As String, existingId As String
    If personRow <= 0 Then Exit Sub
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    If Len(pid) = 0 Then Exit Sub
    For i = 1 To col.Count
        existingId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(CLng(col(i)), P_ID).Value)
        If existingId = pid Then Exit Sub
    Next i
    col.Add personRow
End Sub

Private Function FamilyBlockWidth(ByVal childRow As Long, ByVal cardW As Double, ByVal coupleGap As Double) As Double
    Dim childId As String, spouseRow As Long
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    spouseRow = GetSpouseRowOfPerson(childId)
    If spouseRow > 0 Then
        FamilyBlockWidth = cardW * 2 + coupleGap
    Else
        FamilyBlockWidth = cardW
    End If
End Function

Private Function DrawRemainingVisiblePersons(ByVal ws As Worksheet, _
        ByVal drawn As Object, _
        ByVal leftPt As Double, _
        ByVal topPt As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal gapPt As Double, _
        ByVal rightLimit As Double) As Double
    Dim nextTop As Double
    On Error GoTo EH
    nextTop = topPt
    nextTop = DrawRemainingPersonGroup(ws, drawn, False, "���̑��̔z��ҁi��\�ȊO�j", leftPt, nextTop, cardW, cardH, gapPt, rightLimit, True)
    nextTop = DrawRemainingPersonGroup(ws, drawn, True, "�֌W�������̐e���i�v�m�F�j", leftPt, nextTop, cardW, cardH, gapPt, rightLimit)
    nextTop = DrawRemainingPersonGroup(ws, drawn, False, "���̑��̊֌W�l", leftPt, nextTop, cardW, cardH, gapPt, rightLimit)
    DrawRemainingVisiblePersons = nextTop
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning "���ڑ��l���m�F", "���ڑ��l���`��𒆒f���Ďd�グ�֌p��: " & Err.Description
    Err.Clear
    DrawRemainingVisiblePersons = topPt
End Function

Private Function DrawRemainingPersonGroup(ByVal ws As Worksheet, _
        ByVal drawn As Object, _
        ByVal unresolvedOnly As Boolean, _
        ByVal labelText As String, _
        ByVal leftPt As Double, _
        ByVal topPt As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal gapPt As Double, _
        ByVal rightLimit As Double, _
        Optional ByVal spouseOnly As Boolean = False) As Double
    Dim wp As Worksheet, r As Long, x As Double, y As Double, maxBottom As Double
    Dim hasAny As Boolean, labelShape As Shape, labelW As Double, isUnresolved As Boolean, pid As String
    Dim cardShape As Shape, partnerShape As Shape, partnerId As String
    On Error GoTo EH
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    x = SafeDiagramPoint(leftPt, 12)
    y = SafeDiagramPoint(topPt, 12)
    cardW = SafeDiagramSize(cardW, 190)
    cardH = SafeDiagramSize(cardH, 180)
    gapPt = SafeDiagramSize(gapPt, 40)
    maxBottom = y

    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            If CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
                If Not IsDrawnPerson(drawn, r) Then
                    pid = CleanText(wp.Cells(r, P_ID).Value)
                    If spouseOnly Then
                        hasAny = DiagramPersonRowIsPureSpouse(r)
                    Else
                        isUnresolved = DiagramRowIsUnresolvedKin(r)
                        hasAny = (isUnresolved = unresolvedOnly)
                    End If
                    If hasAny Then
                        hasAny = True
                        Exit For
                    End If
                End If
            End If
        End If
    Next r
    If Not hasAny Then
        DrawRemainingPersonGroup = topPt
        Exit Function
    End If

    labelW = rightLimit - leftPt
    If labelW < 120 Then labelW = Application.Min(cardW, 360)
    If labelW > 460 Then labelW = 460
    labelW = SafeDiagramSize(labelW, Application.Min(cardW, 360))
    On Error Resume Next
    Set labelShape = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, labelW, 28)
    If Err.Number <> 0 Then
        AppendRelationshipDiagramDrawWarning "���ڑ��l���m�F", labelText & "���x�����X�L�b�v���Čp��: " & Err.Description
        Err.Clear
        Set labelShape = Nothing
    End If
    On Error GoTo EH
    If Not labelShape Is Nothing Then
        On Error Resume Next
        With labelShape
            .Name = UniqueShapeName(ws, "diagram_remaining_label")
            .Placement = xlFreeFloating
            .Locked = True
            If unresolvedOnly Then
                .Fill.ForeColor.RGB = ThemeColor("danger-soft")
                .Line.ForeColor.RGB = ThemeColor("red")
                SafeApplyShapeText labelShape, labelText, 9.2, ThemeColor("red"), True, msoAlignCenter, msoAnchorMiddle, 2, 2, 0, 0, True, 0
            ElseIf spouseOnly Then
                .Fill.ForeColor.RGB = ThemeColor("warning-soft")
                .Line.ForeColor.RGB = ThemeColor("orange")
                SafeApplyShapeText labelShape, labelText, 9.2, ThemeColor("warning-text"), True, msoAlignCenter, msoAnchorMiddle, 2, 2, 0, 0, True, 0
            Else
                .Fill.ForeColor.RGB = ThemeColor("surface-soft")
                .Line.ForeColor.RGB = ThemeColor("border-strong")
                SafeApplyShapeText labelShape, labelText, 9.2, ThemeColor("muted-strong"), True, msoAlignCenter, msoAnchorMiddle, 2, 2, 0, 0, True, 0
            End If
            .Line.Weight = 0.9
            .PrintObject = True
        End With
        Err.Clear
        On Error GoTo EH
    End If
    y = y + 42
    maxBottom = y

    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            If CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
                If Not IsDrawnPerson(drawn, r) Then
                    pid = CleanText(wp.Cells(r, P_ID).Value)
                    If spouseOnly Then
                        hasAny = DiagramPersonRowIsPureSpouse(r)
                    Else
                        isUnresolved = DiagramRowIsUnresolvedKin(r)
                        hasAny = (isUnresolved = unresolvedOnly)
                    End If
                    If hasAny Then
                        If x + cardW > rightLimit Then
                            x = SafeDiagramPoint(leftPt, 12)
                            y = y + cardH + 28
                        End If
                        If unresolvedOnly Or DiagramPersonRequiresLine(r) Then AppendDiagramUnresolvedCheck r
                        On Error Resume Next
                        Set cardShape = DrawTreeCard(ws, r, x, y, cardW, cardH, drawn)
                        If Err.Number <> 0 Then
                            AppendRelationshipDiagramDrawWarning "���ڑ��l���m�F", labelText & "�J�[�h���X�L�b�v���Čp��: row=" & CStr(r) & " / " & Err.Description
                            Err.Clear
                        End If
                        On Error GoTo EH
                        If spouseOnly And Not cardShape Is Nothing And Not mDiagramCardsOnly Then
                            partnerId = DiagramGraphSpouseId(pid)
                            If Len(partnerId) > 0 Then Set partnerShape = FindPersonCardShape(ws, partnerId)
                            If Not partnerShape Is Nothing Then DrawSecondarySpouseConnector ws, partnerShape, cardShape
                            Set partnerShape = Nothing
                        End If
                        If y + cardH > maxBottom Then maxBottom = y + cardH
                        x = x + cardW + gapPt
                    End If
                End If
            End If
        End If
    Next r
    DrawRemainingPersonGroup = maxBottom + 28
    Exit Function
EH:
    AppendRelationshipDiagramDrawWarning "���ڑ��l���m�F", labelText & "�`��𒆒f���Ďd�グ�֌p��: " & Err.Description
    Err.Clear
    If maxBottom < topPt Then maxBottom = topPt
    DrawRemainingPersonGroup = maxBottom + 28
End Function

Private Sub DrawSecondarySpouseConnector(ByVal ws As Worksheet, ByVal partnerShape As Shape, ByVal spouseShape As Shape)
    Dim startX As Double, endX As Double, startY As Double, endY As Double, branchY As Double
    If ws Is Nothing Then Exit Sub
    If partnerShape Is Nothing Then Exit Sub
    If spouseShape Is Nothing Then Exit Sub
    startX = ShapeCenterX(partnerShape)
    endX = ShapeCenterX(spouseShape)
    startY = partnerShape.Top + partnerShape.Height
    endY = spouseShape.Top
    If endY <= startY + 4 Then Exit Sub
    branchY = startY + 14
    If branchY >= endY - 8 Then branchY = startY + (endY - startY) / 2
    DrawVLine ws, startX, startY, branchY
    DrawHLine ws, MinDouble(startX, endX), branchY, MaxDouble(startX, endX)
    DrawVLine ws, endX, branchY, endY
End Sub

Private Function DiagramRowIsUnresolvedKin(ByVal personRow As Long) As Boolean
    Dim pid As String
    If personRow <= 0 Then Exit Function
    pid = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    If Len(pid) = 0 Then Exit Function
    If DiagramGraphEnsureBuilt(GetDecedentId()) Then
        DiagramRowIsUnresolvedKin = DiagramGraphIsUnresolvedKinId(pid)
    End If
End Function

Private Function DiagramPersonRequiresLine(ByVal personRow As Long) As Boolean
    Dim relText As String, normRel As String
    If personRow <= 0 Then Exit Function
    relText = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_REL_DEC).Value)
    normRel = NormalizeDiagramRelationText(relText)
    Select Case normRel
        Case "��", "��", "�z���", "�O�z���"
            DiagramPersonRequiresLine = True
            Exit Function
    End Select
    If DiagramDescendantLevel(relText) > 0 Then
        DiagramPersonRequiresLine = True
    ElseIf IsSiblingRelationText(relText) Then
        DiagramPersonRequiresLine = True
    End If
End Function

Private Sub AppendDiagramUnresolvedCheck(ByVal personRow As Long)
    Dim wsC As Worksheet, outR As Long, pid As String, nameText As String
    On Error GoTo SafeExit
    If personRow <= 0 Then Exit Sub
    If Not SheetExists(SH_CHECK, ThisWorkbook) Then Exit Sub
    Set wsC = ThisWorkbook.Worksheets(SH_CHECK)
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    nameText = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_DISPLAY).Value)
    outR = LastRow(wsC, 1) + 1
    If outR < 4 Then outR = 4
    AddCheck wsC, outR, "�G���[", "�����֌W�}�Őe�q�����m��ł��������\�����܂����B", _
        pid, nameText, "�����֌W�}", "��l������q�Ƃ��ēo�^���������֌W�\���m�F"
SafeExit:
End Sub

Private Sub DrawFamilyModelDiagramConnectors(ByVal ws As Worksheet, _
        ByVal decedentId As String, _
        ByVal siblings As Collection)
    On Error GoTo EH
    Dim spouseLineCount As Long, parentLineCount As Long
    Dim rootSiblingHandled As Boolean, rootParentHandled As Boolean
    Dim errNum As Long, errDesc As String

    If ws Is Nothing Then Err.Raise vbObjectError + 9750, "DrawFamilyModelDiagramConnectors", "�����֌W�}�V�[�g������܂���B"
    If Not FamilyModelEnsureBuilt(decedentId) Then _
        Err.Raise vbObjectError + 9751, "DrawFamilyModelDiagramConnectors", "�Ƒ��������f����ǂݍ��߂܂���B"

    mDiagramStrictLineMode = True
    spouseLineCount = DrawModelSpouseConnectors(ws)
    rootSiblingHandled = DrawModelRootSiblingConnector(ws, decedentId, siblings, rootParentHandled)
    parentLineCount = DrawModelParentChildConnectors(ws, decedentId, rootParentHandled)
    mDiagramStrictLineMode = False

    AppendDiagramConnectorAudit spouseLineCount, parentLineCount, rootSiblingHandled
    Exit Sub
EH:
    errNum = Err.Number
    errDesc = Err.Description
    mDiagramStrictLineMode = False
    If errNum = 0 Then errNum = vbObjectError + 9752
    Err.Raise errNum, "DrawFamilyModelDiagramConnectors", errDesc
End Sub

Private Function DrawModelSpouseConnectors(ByVal ws As Worksheet) As Long
    Dim wp As Worksheet, donePairs As Object, spouses As Collection
    Dim r As Long, i As Long, spouseRow As Long, pid As String, spouseId As String, pairKey As String
    Dim personShape As Shape, spouseShape As Shape
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    Set donePairs = CreateObject("Scripting.Dictionary")

    For r = 2 To LastRow(wp, P_ID)
        If VisibleDiagramPersonRow(r) Then
            pid = CleanText(wp.Cells(r, P_ID).Value)
            If Len(pid) > 0 And FamilyModelPersonRow(pid) > 0 Then
                Set spouses = FamilyModelSpouseIds(pid)
                For i = 1 To spouses.Count
                    spouseId = CleanText(CStr(spouses(i)))
                    spouseRow = FamilyModelPersonRow(spouseId)
                    pairKey = FamilyModelPairKey(pid, spouseId)
                    If Len(pairKey) > 0 And spouseRow > 0 Then
                        If Not VisibleDiagramPersonRow(spouseRow) Then
                            AppendDiagramHiddenSpouseWarning pid, spouseId
                            GoTo NextSpousePair
                        End If
                        If Not donePairs.Exists(pairKey) Then
                            Set personShape = FindPersonCardShape(ws, pid)
                            Set spouseShape = FindPersonCardShape(ws, spouseId)
                            If personShape Is Nothing Or spouseShape Is Nothing Then
                                Err.Raise vbObjectError + 9753, "DrawModelSpouseConnectors", _
                                    "�z��Ҏ����̃J�[�h������܂���: " & pid & " / " & spouseId
                            End If
                            DrawModelSpousePairConnector ws, personShape, spouseShape
                            donePairs.Add pairKey, True
                            DrawModelSpouseConnectors = DrawModelSpouseConnectors + 1
                            Set personShape = Nothing
                            Set spouseShape = Nothing
                        End If
                    End If
NextSpousePair:
                Next i
            End If
        End If
    Next r
End Function

Private Sub DrawModelSpousePairConnector(ByVal ws As Worksheet, _
        ByVal firstShape As Shape, _
        ByVal secondShape As Shape)
    Dim leftShape As Shape, rightShape As Shape, upperShape As Shape, lowerShape As Shape
    Dim originX As Double, originY As Double, startX As Double, startY As Double
    Dim endX As Double, endY As Double, branchY As Double, routeX As Double
    If firstShape Is Nothing Or secondShape Is Nothing Then _
        Err.Raise vbObjectError + 9754, "DrawModelSpousePairConnector", "�z��҃J�[�h���s�����Ă��܂��B"

    If Abs(ShapeCenterY(firstShape) - ShapeCenterY(secondShape)) <= 4 Then
        If firstShape.Left <= secondShape.Left Then
            Set leftShape = firstShape
            Set rightShape = secondShape
        Else
            Set leftShape = secondShape
            Set rightShape = firstShape
        End If
        If rightShape.Left <= leftShape.Left + leftShape.Width + 0.5 Then _
            Err.Raise vbObjectError + 9762, "DrawModelSpousePairConnector", "�z��҃J�[�h���d�Ȃ�A�v�w�����쐬�ł��܂���B"
        ConnectHorizontalCouple ws, leftShape, rightShape, originX, originY
        Exit Sub
    End If

    If firstShape.Top <= secondShape.Top Then
        Set upperShape = firstShape
        Set lowerShape = secondShape
    Else
        Set upperShape = secondShape
        Set lowerShape = firstShape
    End If
    startX = ShapeCenterX(upperShape)
    startY = upperShape.Top + upperShape.Height
    endX = ShapeCenterX(lowerShape)
    endY = lowerShape.Top
    If endY > startY + 8 Then
        branchY = startY + (endY - startY) / 2
        DrawVLine ws, startX, startY, branchY
        DrawHLine ws, MinDouble(startX, endX), branchY, MaxDouble(startX, endX)
        DrawVLine ws, endX, branchY, endY
    Else
        routeX = MaxDouble(upperShape.Left + upperShape.Width, lowerShape.Left + lowerShape.Width) + 14
        DrawHLine ws, upperShape.Left + upperShape.Width, ShapeCenterY(upperShape), routeX
        DrawVLine ws, routeX, ShapeCenterY(upperShape), ShapeCenterY(lowerShape)
        DrawHLine ws, lowerShape.Left + lowerShape.Width, ShapeCenterY(lowerShape), routeX
    End If
End Sub

Private Function DrawModelRootSiblingConnector(ByVal ws As Worksheet, _
        ByVal decedentId As String, _
        ByVal siblings As Collection, _
        ByRef rootParentHandled As Boolean) As Boolean
    Dim cards As New Collection, seen As Object, parents As Collection
    Dim decShape As Shape, siblingShape As Shape, parentShape As Shape, shp As Shape
    Dim i As Long, siblingRow As Long, parentRow As Long, siblingId As String, primaryParentId As String
    Dim minX As Double, maxX As Double, minTop As Double, maxBottom As Double
    Dim originX As Double, originY As Double, branchY As Double, hasParentOrigin As Boolean

    Set seen = CreateObject("Scripting.Dictionary")
    Set decShape = FindPersonCardShape(ws, decedentId)
    If decShape Is Nothing Then Err.Raise vbObjectError + 9755, "DrawModelRootSiblingConnector", "�푊���l�J�[�h������܂���B"
    cards.Add decShape
    seen.Add decedentId, True

    If Not siblings Is Nothing Then
        For i = 1 To siblings.Count
            siblingRow = CLng(siblings(i))
            siblingId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(siblingRow, P_ID).Value)
            If Len(siblingId) > 0 And Not seen.Exists(siblingId) Then
                Set siblingShape = FindPersonCardShape(ws, siblingId)
                If siblingShape Is Nothing Then
                    Err.Raise vbObjectError + 9756, "DrawModelRootSiblingConnector", _
                        "�Z��o�������̃J�[�h������܂���: " & siblingId
                End If
                cards.Add siblingShape
                seen.Add siblingId, True
                Set siblingShape = Nothing
            End If
        Next i
    End If
    If cards.Count <= 1 Then Exit Function

    Set shp = cards(1)
    minX = ShapeCenterX(shp)
    maxX = minX
    minTop = shp.Top
    maxBottom = shp.Top + shp.Height
    For i = 2 To cards.Count
        Set shp = cards(i)
        If ShapeCenterX(shp) < minX Then minX = ShapeCenterX(shp)
        If ShapeCenterX(shp) > maxX Then maxX = ShapeCenterX(shp)
        If shp.Top < minTop Then minTop = shp.Top
        If shp.Top + shp.Height > maxBottom Then maxBottom = shp.Top + shp.Height
    Next i

    Set parents = FamilyModelParentIds(decedentId)
    hasParentOrigin = TryModelCoupleOriginForChild(ws, decedentId, parents, originX, originY)
    If Not hasParentOrigin And parents.Count = 1 Then
        primaryParentId = FamilyModelParentId(decedentId)
        parentRow = FamilyModelPersonRow(primaryParentId)
        If parentRow > 0 Then
            If VisibleDiagramPersonRow(parentRow) Then
                Set parentShape = FindPersonCardShape(ws, primaryParentId)
                If parentShape Is Nothing Then Set parentShape = FirstExistingModelParentShape(ws, parents)
                If parentShape Is Nothing Then
                    Err.Raise vbObjectError + 9757, "DrawModelRootSiblingConnector", "�푊���l�̐e�J�[�h������܂���B"
                End If
                originX = ShapeCenterX(parentShape)
                originY = parentShape.Top + parentShape.Height
                hasParentOrigin = True
            End If
        End If
    End If
    rootParentHandled = hasParentOrigin

    If hasParentOrigin Then
        branchY = minTop - 20
        If branchY <= originY + 8 Then branchY = originY + (minTop - originY) / 2
        If branchY <= originY Or branchY >= minTop Then _
            Err.Raise vbObjectError + 9758, "DrawModelRootSiblingConnector", "�e����ƌZ��o������̔z�u�Ԋu���s�����Ă��܂��B"
        DrawVLine ws, originX, originY, branchY
        DrawHLine ws, minX, branchY, maxX
        For i = 1 To cards.Count
            Set shp = cards(i)
            DrawVLine ws, ShapeCenterX(shp), branchY, shp.Top
        Next i
    Else
        branchY = maxBottom + 16
        DrawHLine ws, minX, branchY, maxX
        For i = 1 To cards.Count
            Set shp = cards(i)
            DrawVLine ws, ShapeCenterX(shp), shp.Top + shp.Height, branchY
        Next i
    End If
    DrawModelRootSiblingConnector = True
End Function

Private Function DrawModelParentChildConnectors(ByVal ws As Worksheet, _
        ByVal decedentId As String, _
        ByVal rootParentHandled As Boolean) As Long
    Dim wp As Worksheet, parents As Collection, childShape As Shape, parentShape As Shape
    Dim r As Long, i As Long, parentRow As Long, childId As String, parentId As String
    Dim originX As Double, originY As Double, targetX As Double, targetY As Double
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)

    For r = 2 To LastRow(wp, P_ID)
        If VisibleDiagramPersonRow(r) Then
            childId = CleanText(wp.Cells(r, P_ID).Value)
            If Len(childId) > 0 And FamilyModelPersonRow(childId) > 0 Then
                Set parents = FamilyModelParentIds(childId)
                If parents.Count > 0 Then
                    If Not (rootParentHandled And childId = decedentId) Then
                        Set childShape = FindPersonCardShape(ws, childId)
                        If childShape Is Nothing Then
                            Err.Raise vbObjectError + 9759, "DrawModelParentChildConnectors", _
                                "�e�q�����̎q�J�[�h������܂���: " & childId
                        End If

                        If TryModelCoupleOriginForChild(ws, childId, parents, originX, originY) Then
                            targetX = ShapeCenterX(childShape)
                            targetY = childShape.Top
                            DrawModelParentChildPath ws, originX, originY, targetX, targetY, childId
                            DrawModelParentChildConnectors = DrawModelParentChildConnectors + 1
                        Else
                            For i = 1 To parents.Count
                                parentId = CleanText(CStr(parents(i)))
                                parentRow = FamilyModelPersonRow(parentId)
                                If parentRow <= 0 Then
                                    Err.Raise vbObjectError + 9760, "DrawModelParentChildConnectors", _
                                        "�e�q�����̐e�l��������܂���: parent=" & parentId & " / child=" & childId
                                ElseIf Not VisibleDiagramPersonRow(parentRow) Then
                                    AppendDiagramHiddenRelationWarning parentId, childId, "�e�J�[�h���}��\���̂��߁A���̐e����̐��͕\�����܂���B"
                                Else
                                    Set parentShape = FindPersonCardShape(ws, parentId)
                                    If parentShape Is Nothing Then
                                        Err.Raise vbObjectError + 9760, "DrawModelParentChildConnectors", _
                                            "�e�q�����̐e�J�[�h������܂���: parent=" & parentId & " / child=" & childId
                                    End If
                                    DrawModelParentChildBetweenShapes ws, parentShape, childShape, childId
                                    DrawModelParentChildConnectors = DrawModelParentChildConnectors + 1
                                    Set parentShape = Nothing
                                End If
                            Next i
                        End If
                        Set childShape = Nothing
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Sub DrawModelParentChildBetweenShapes(ByVal ws As Worksheet, _
        ByVal parentShape As Shape, _
        ByVal childShape As Shape, _
        ByVal childId As String)
    Dim upperShape As Shape, lowerShape As Shape
    Dim startX As Double, startY As Double, endX As Double, endY As Double
    Dim routeX As Double
    If parentShape Is Nothing Or childShape Is Nothing Then _
        Err.Raise vbObjectError + 9763, "DrawModelParentChildBetweenShapes", "�e�q�J�[�h���s�����Ă��܂�: " & childId

    If childShape.Top > parentShape.Top + parentShape.Height + 6 Then
        DrawModelParentChildPath ws, ShapeCenterX(parentShape), parentShape.Top + parentShape.Height, _
            ShapeCenterX(childShape), childShape.Top, childId
        Exit Sub
    End If

    If parentShape.Top > childShape.Top + childShape.Height + 6 Then
        Set upperShape = childShape
        Set lowerShape = parentShape
        DrawModelParentChildPath ws, ShapeCenterX(upperShape), upperShape.Top + upperShape.Height, _
            ShapeCenterX(lowerShape), lowerShape.Top, childId
        Exit Sub
    End If

    '���������֕����z�u���ꂽ��O�֌W�́A�J�[�h�E�����񂵂Ċm���Ɍ��ԁB
    startX = parentShape.Left + parentShape.Width
    startY = ShapeCenterY(parentShape)
    endX = childShape.Left + childShape.Width
    endY = ShapeCenterY(childShape)
    routeX = MaxDouble(startX, endX) + 14
    DrawHLine ws, startX, startY, routeX
    DrawVLine ws, routeX, startY, endY
    DrawHLine ws, endX, endY, routeX
End Sub

Private Function TryModelCoupleOriginForChild(ByVal ws As Worksheet, _
        ByVal childId As String, _
        ByVal parents As Collection, _
        ByRef originX As Double, _
        ByRef originY As Double) As Boolean
    Dim familyKey As String, kindText As String, parentA As String, parentB As String
    Dim i As Long, j As Long, shapeA As Shape, shapeB As Shape
    If parents Is Nothing Then Exit Function
    If parents.Count < 2 Then Exit Function
    familyKey = FamilyModelChildFamilyKey(childId)
    kindText = FamilyModelChildKind(childId)
    If Len(familyKey) = 0 Then Exit Function
    If kindText <> CHILD_KIND_COUPLE And kindText <> CHILD_KIND_PREVIOUS Then Exit Function

    For i = 1 To parents.Count - 1
        parentA = CleanText(CStr(parents(i)))
        For j = i + 1 To parents.Count
            parentB = CleanText(CStr(parents(j)))
            If familyKey = FamilyModelPairKey(parentA, parentB) Then
                Set shapeA = FindPersonCardShape(ws, parentA)
                Set shapeB = FindPersonCardShape(ws, parentB)
                If Not shapeA Is Nothing And Not shapeB Is Nothing Then
                    '�v�w�������g���̂́A���ۂ̃J�[�h�������v�w�s�ɔz�u���ꂽ�������B
                    If Abs(ShapeCenterY(shapeA) - ShapeCenterY(shapeB)) <= 4 Then
                        originX = (ShapeCenterX(shapeA) + ShapeCenterX(shapeB)) / 2
                        originY = (ShapeCenterY(shapeA) + ShapeCenterY(shapeB)) / 2
                        TryModelCoupleOriginForChild = True
                        Exit Function
                    End If
                End If
                Exit Function
            End If
        Next j
    Next i
End Function

Private Function FirstExistingModelParentShape(ByVal ws As Worksheet, _
        ByVal parents As Collection) As Shape
    Dim i As Long, parentId As String, shp As Shape
    If parents Is Nothing Then Exit Function
    For i = 1 To parents.Count
        parentId = CleanText(CStr(parents(i)))
        Set shp = FindPersonCardShape(ws, parentId)
        If Not shp Is Nothing Then
            Set FirstExistingModelParentShape = shp
            Exit Function
        End If
    Next i
End Function

Private Sub DrawModelParentChildPath(ByVal ws As Worksheet, _
        ByVal originX As Double, _
        ByVal originY As Double, _
        ByVal targetX As Double, _
        ByVal targetY As Double, _
        ByVal childId As String)
    Dim branchY As Double
    If targetY <= originY + 6 Then
        Err.Raise vbObjectError + 9761, "DrawModelParentChildPath", _
            "�e�J�[�h��艺�Ɏq�J�[�h��z�u�ł��Ă��܂���: " & childId
    End If
    branchY = originY + (targetY - originY) / 2
    If branchY < originY + 10 Then branchY = originY + 10
    If branchY > targetY - 8 Then branchY = targetY - 8
    DrawVLine ws, originX, originY, branchY
    DrawHLine ws, MinDouble(originX, targetX), branchY, MaxDouble(originX, targetX)
    DrawVLine ws, targetX, branchY, targetY
End Sub

Private Sub AppendDiagramConnectorAudit(ByVal spouseLineCount As Long, _
        ByVal parentLineCount As Long, _
        ByVal rootSiblingHandled As Boolean)
    On Error GoTo SafeExit
    Dim ws As Worksheet, outR As Long, r As Long, messageText As String
    If Not SheetExists(SH_CHECK, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_CHECK)
    For r = 4 To LastRow(ws, 1)
        If CleanText(ws.Cells(r, 5).Value) = "�����֌W�}���č�" Then _
            ws.Range(ws.Cells(r, 1), ws.Cells(r, 8)).ClearContents
    Next r
    outR = LastRow(ws, 1) + 1
    If outR < 4 Then outR = 4
    messageText = "�Ƒ��������f������z��Ґ�" & CStr(spouseLineCount) & _
        "�g�A�e�q��" & CStr(parentLineCount) & "�g�����J�[�h���W�֐������܂����B"
    If rootSiblingHandled Then messageText = messageText & " �Z��o����������Đ����ς݂ł��B"
    AddCheck ws, outR, "OK", messageText, "", "", "�����֌W�}���č�", _
        "�eID�E�qID�E�z���ID�Ɛ}�̐��𓯂����f���ŏƍ��ς�"
SafeExit:
End Sub

Private Sub AppendDiagramHiddenRelationWarning(ByVal parentId As String, _
        ByVal childId As String, _
        ByVal messageText As String)
    On Error GoTo SafeExit
    Dim ws As Worksheet, outR As Long
    If Not SheetExists(SH_CHECK, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_CHECK)
    outR = LastRow(ws, 1) + 1
    If outR < 4 Then outR = 4
    AddCheck ws, outR, "����", messageText, childId, GetPersonValue(childId, P_DISPLAY), _
        "�����֌W�}���č�", "�e=" & GetPersonValue(parentId, P_DISPLAY) & "�B�K�v�Ȃ�}�\�����u�\���v�ɕύX"
SafeExit:
End Sub

Private Sub AppendDiagramHiddenSpouseWarning(ByVal personId As String, ByVal spouseId As String)
    On Error GoTo SafeExit
    Dim ws As Worksheet, outR As Long
    If Not SheetExists(SH_CHECK, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_CHECK)
    outR = LastRow(ws, 1) + 1
    If outR < 4 Then outR = 4
    AddCheck ws, outR, "����", "�z��Ҏ����͂���܂����A����J�[�h���}��\���̂��ߕv�w����\�����܂���B", _
        personId, GetPersonValue(personId, P_DISPLAY), "�����֌W�}���č�", _
        "�z���=" & GetPersonValue(spouseId, P_DISPLAY) & "�B�K�v�Ȃ�}�\�����u�\���v�ɕύX"
SafeExit:
End Sub

Private Sub ConnectHorizontalCouple(ByVal ws As Worksheet, ByVal leftShape As Shape, ByVal rightShape As Shape, ByRef originX As Double, ByRef originY As Double)
    On Error GoTo EH
    If leftShape Is Nothing Then Exit Sub
    If rightShape Is Nothing Then Exit Sub
    originY = ShapeCenterY(leftShape)
    originX = (leftShape.Left + leftShape.Width + rightShape.Left) / 2
    DrawHLine ws, leftShape.Left + leftShape.Width, originY, rightShape.Left
    Exit Sub
EH:
    AppendRelationshipDiagramDrawWarning "�v�w���`��", "�v�w�����X�L�b�v: " & Err.Description
    Err.Clear
End Sub

Private Sub WarnDiagramIfCardCollisions(ByVal ws As Worksheet)
    Dim i As Long, j As Long, a As Shape, b As Shape, msg As String, nr As Long
    If ws Is Nothing Then Exit Sub
    For i = 1 To ws.Shapes.Count
        Set a = ws.Shapes(i)
        If Left$(a.Name, 5) = "card_" Then
            For j = i + 1 To ws.Shapes.Count
                Set b = ws.Shapes(j)
                If Left$(b.Name, 5) = "card_" Then
                    If ShapesOverlap(a, b, 14) Then
                        msg = "�����֌W�}�̃J�[�h�d�Ȃ��₪����܂��B�l���������ꍇ�͏o�̓v���r���[�Ŋm�F���Ă�������: " & a.Name & " / " & b.Name
                        If SheetExists(SH_CHECK) Then
                            nr = LastRow(ThisWorkbook.Worksheets(SH_CHECK), 1) + 1
                            If nr < 2 Then nr = 2
                            ThisWorkbook.Worksheets(SH_CHECK).Cells(nr, 1).Value = "�x��"
                            ThisWorkbook.Worksheets(SH_CHECK).Cells(nr, 2).Value = "�����֌W�����}"
                            ThisWorkbook.Worksheets(SH_CHECK).Cells(nr, 3).Value = msg
                        End If
                        AddDiagramLayoutWarning ws, msg
                        Exit Sub
                    End If
                End If
            Next j
        End If
    Next i
End Sub

Private Function ShapesOverlap(ByVal a As Shape, ByVal b As Shape, Optional ByVal marginPt As Double = 0) As Boolean
    ShapesOverlap = Not (a.Left + a.Width + marginPt < b.Left Or b.Left + b.Width + marginPt < a.Left Or _
                         a.Top + a.Height + marginPt < b.Top Or b.Top + b.Height + marginPt < a.Top)
End Function

Private Sub WarnDiagramIfPrintBoundsRisk(ByVal ws As Worksheet)
    Dim shp As Shape
    Dim maxRight As Double, maxBottom As Double
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For Each shp In ws.Shapes
        If Not ThemeIsButtonShape(shp) Then
            If shp.Left + shp.Width > maxRight Then maxRight = shp.Left + shp.Width
            If shp.Top + shp.Height > maxBottom Then maxBottom = shp.Top + shp.Height
        End If
    Next shp
    If maxRight > 1100 Or maxBottom > 1500 Then
        AddDiagramLayoutWarning ws, "�����֌W�}���傫�����߁A�����A4���̕����y�[�W�ɂȂ�\��������܂��B�}���������ׂ����ǐ���D�悵�܂��B"
    End If
    On Error GoTo 0
End Sub

Private Sub AddDiagramLayoutWarning(ByVal ws As Worksheet, ByVal msg As String)
    RuntimeAppendLog "WARN", "�����֌W�}", "���C�A�E�g", msg, 0, "", ""
End Sub

Private Function IsRelationshipDiagramNonPrintableControl(ByVal shp As Shape) As Boolean
    Dim textValue As String, nm As String, actionText As String
    Dim isFormButton As Boolean
    If shp Is Nothing Then Exit Function
    On Error Resume Next
    nm = LCase$(shp.Name)
    textValue = CleanText(SafeGetShapeText(shp))
    actionText = CleanText(shp.OnAction)
    isFormButton = (shp.Type = msoFormControl)
    If isFormButton Then isFormButton = (shp.FormControlType = xlButtonControl)
    On Error GoTo 0
    If ThemeIsButtonShape(shp) Then
        IsRelationshipDiagramNonPrintableControl = True
    ElseIf isFormButton Then
        IsRelationshipDiagramNonPrintableControl = True
    ElseIf Len(actionText) > 0 Then
        IsRelationshipDiagramNonPrintableControl = True
    ElseIf InStr(1, nm, "btn", vbTextCompare) > 0 Then
        IsRelationshipDiagramNonPrintableControl = True
    ElseIf InStr(1, textValue, "���֖͂߂�", vbTextCompare) > 0 Then
        IsRelationshipDiagramNonPrintableControl = True
    ElseIf InStr(1, textValue, "�߂�", vbTextCompare) > 0 And InStr(1, textValue, "����", vbTextCompare) > 0 Then
        IsRelationshipDiagramNonPrintableControl = True
    End If
End Function

Private Sub PolishRelationshipDiagramOutput(ByVal ws As Worksheet)
    Dim shp As Shape
    Dim maxBottom As Double, maxRight As Double
    Dim printRows As Long, printCols As Long, decId As String, fitWide As Long
    Dim useLandscape As Boolean, fitTall As Long
    If ws Is Nothing Then Exit Sub
    decId = GetDecedentId()
    maxBottom = 0
    maxRight = 0
    On Error Resume Next
    For Each shp In ws.Shapes
        If IsRelationshipDiagramNonPrintableControl(shp) Then
            shp.PrintObject = False
        Else
            shp.PrintObject = True
            If shp.Top + shp.Height > maxBottom Then maxBottom = shp.Top + shp.Height
            If shp.Left + shp.Width > maxRight Then maxRight = shp.Left + shp.Width
            If shp.Type = msoLine Then
                shp.Line.ForeColor.RGB = ThemeColor("text")
                shp.Line.Weight = 1.05
            ElseIf Left$(shp.Name, 5) = "card_" Or Left$(shp.Name, 9) = "cardname_" Then
                If ShapePersonId(shp) = decId Then
                    shp.Line.ForeColor.RGB = ThemeColor("title")
                    shp.Line.Weight = 2.4
                Else
                    shp.Line.ForeColor.RGB = ThemeColor("text")
                    If Left$(shp.Name, 9) = "cardname_" Then
                        shp.Line.Weight = 0.8
                    Else
                        shp.Line.Weight = 1.35
                    End If
                End If
                shp.Shadow.Visible = msoFalse
            End If
        End If
    Next shp
    If maxBottom < 120 Then maxBottom = 120
    If maxRight < 420 Then maxRight = 420
    printRows = Application.Max(18, CLng((maxBottom + 30) / 14.2) + 1)
    If printRows > 520 Then printRows = 520
    printCols = PrintColumnForRightPoint(ws, maxRight + 30)
    If printCols < 16 Then printCols = 16

    If mRelationshipDiagramHasPlan Then
        useLandscape = mRelationshipDiagramLandscape
    Else
        useLandscape = (maxRight >= maxBottom * 0.72)
    End If
    fitWide = PagesNeededForPointWidth(maxRight + 30, useLandscape)
    If mRelationshipDiagramFitWideHint > fitWide Then fitWide = mRelationshipDiagramFitWideHint
    If fitWide < 1 Then fitWide = 1

    fitTall = 0
    If CountVisibleDiagramPersons() <= 10 Then
        If maxBottom <= 980 And fitWide = 1 Then fitTall = 1
    End If
    MarkOutputNavigationShapesNonPrintable ws
    ThemeApplyMonochromePrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(printRows, printCols)).Address, useLandscape, "", fitWide, fitTall
    MarkOutputNavigationShapesNonPrintable ws
    ws.PageSetup.CenterHorizontally = True
    ws.PageSetup.CenterVertically = False
    ThemeLockShapeLayer ws
    MarkOutputNavigationShapesNonPrintable ws
    On Error GoTo 0
End Sub

Private Sub MarkOutputNavigationShapesNonPrintable(ByVal ws As Worksheet)
    Dim shp As Shape, captionText As String
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For Each shp In ws.Shapes
        captionText = ""
        captionText = SafeGetShapeText(shp)
        If IsRelationshipDiagramNonPrintableControl(shp) Or Len(shp.OnAction) > 0 Or InStr(1, captionText, "���֖͂߂�", vbTextCompare) > 0 Or InStr(1, shp.Name, "btn_", vbTextCompare) > 0 Then
            shp.PrintObject = False
            shp.Placement = xlMoveAndSize
        End If
    Next shp
    On Error GoTo 0
End Sub

Private Function PrintColumnForRightPoint(ByVal ws As Worksheet, ByVal rightPt As Double) As Long
    Dim c As Long, maxScan As Long
    If ws Is Nothing Then Exit Function
    maxScan = 256
    If ws.Columns.Count < maxScan Then maxScan = ws.Columns.Count
    For c = 1 To maxScan
        If ws.Cells(1, c).Left + ws.Cells(1, c).Width >= rightPt Then
            PrintColumnForRightPoint = c
            Exit Function
        End If
    Next c
    PrintColumnForRightPoint = maxScan
End Function

Private Function DrawPersonCardShape(ByVal ws As Worksheet, _
        ByVal personRow As Long, _
        ByVal leftPt As Double, _
        ByVal topPt As Double, _
        ByVal widthPt As Double, _
        ByVal heightPt As Double) As Shape
    Dim wp As Worksheet
    Dim cardBase As Shape
    Dim displayName As String, bodyText As String, pid As String, relText As String, cardText As String
    Dim titleLen As Long, bodyFontSize As Double, titleFontSize As Double
    Dim shapeToken As String, createErr As String, isDecedent As Boolean

    If ws Is Nothing Then Exit Function
    If personRow <= 0 Then Exit Function

    '�J�[�h�쐬�͑����֌W�}�̍ŏ��̗v�Ȃ̂ŁA�f�[�^���`�E�����̎��s�Ŗ{�̍쐬���~�߂Ȃ��B
    'Office 365�ł��A�Â��u�b�N�R���̐}�`�v���p�e�B��438��Ԃ����Ƃ����邽�߁A
    '�����ł́u�}�`�����v���Ƃ�����v�������ɂ���B
    On Error Resume Next
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    If Not wp Is Nothing Then
        pid = CleanText(wp.Cells(personRow, P_ID).Value)
        displayName = DiagramCardTitleText(personRow)
        relText = CleanText(wp.Cells(personRow, P_REL_DEC).Value)
        bodyText = DiagramCardBodyText(personRow)
    End If
    If Err.Number <> 0 Then
        AppendRelationshipDiagramDrawWarning "�l���J�[�h�`��", "�l����񐮌`���ꕔ�ȗ����ăJ�[�h�쐬���p��: row=" & CStr(personRow) & " / " & Err.Description
        Err.Clear
    End If
    On Error GoTo 0

    displayName = CleanText(displayName)
    If Len(displayName) = 0 Then displayName = "�l��" & CStr(personRow)
    cardText = displayName
    If Len(CleanText(bodyText)) > 0 Then cardText = cardText & vbLf & bodyText

    leftPt = SafeDiagramPoint(leftPt, 12)
    topPt = SafeDiagramPoint(topPt, 12)
    widthPt = SafeDiagramSize(widthPt, 160)
    heightPt = SafeDiagramSize(heightPt, 104)
    titleFontSize = CardTitleFontSizeForName(displayName, widthPt)
    bodyFontSize = CardFontSizeForShape(cardText, widthPt, heightPt)
    shapeToken = pid
    If Len(shapeToken) = 0 Then shapeToken = "row" & CStr(personRow)
    isDecedent = (NormalizeDiagramRelationText(relText) = "�푊���l")

    On Error Resume Next
    Set cardBase = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt, topPt, widthPt, heightPt)
    If cardBase Is Nothing Then
        createErr = Err.Description
        Err.Clear
        Set cardBase = ws.Shapes.AddShape(msoShapeRectangle, leftPt, topPt, widthPt, heightPt)
    End If
    If cardBase Is Nothing Then
        If Len(createErr) = 0 Then createErr = Err.Description
        Err.Clear
        Set cardBase = ws.Shapes.AddTextbox(msoTextOrientationHorizontal, leftPt, topPt, widthPt, heightPt)
    End If
    If cardBase Is Nothing Then
        If Len(createErr) = 0 Then createErr = Err.Description
        If Len(createErr) = 0 Then createErr = "�}�`���쐬�ł��܂���ł����B"
        AppendRelationshipDiagramDrawWarning "�l���J�[�h�`��", "�l��ID=" & pid & " / row=" & CStr(personRow) & " / " & createErr
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If

    '�ȉ��͂��ׂĔ�v���̑����B���s���Ă��J�[�h�{�͕̂Ԃ��B
    Err.Clear
    cardBase.Name = UniqueShapeName(ws, "card_" & shapeToken)
    Err.Clear
    cardBase.AlternativeText = "personId=" & pid
    Err.Clear
    cardBase.Placement = xlFreeFloating
    Err.Clear
    cardBase.Locked = True
    Err.Clear
    cardBase.Fill.Visible = msoTrue
    cardBase.Fill.ForeColor.RGB = CardFillColor(relText)
    Err.Clear
    If isDecedent Then
        cardBase.Line.ForeColor.RGB = ThemeColor("title")
        cardBase.Line.Weight = 1.7
    Else
        cardBase.Line.ForeColor.RGB = ThemeColor("border-strong")
        cardBase.Line.Weight = 0.85
    End If
    Err.Clear
    cardBase.Shadow.Visible = msoFalse
    Err.Clear
    cardBase.PrintObject = True
    Err.Clear
    cardBase.ZOrder msoBringToFront
    Err.Clear

    SafeApplyShapeText cardBase, cardText, bodyFontSize, ThemeColor("text"), False, msoAlignLeft, msoAnchorTop, 7, 7, 6, 7, True, 0

    titleLen = Len(displayName)
    If titleLen > 0 Then
        cardBase.TextFrame.Characters(1, titleLen).Font.Bold = True
        cardBase.TextFrame.Characters(1, titleLen).Font.Size = titleFontSize
        cardBase.TextFrame.Characters(1, titleLen).Font.Color = ThemeColor("title")
        Err.Clear
    End If
    If Len(bodyText) > 0 Then EmphasizeCardBodyLabels cardBase, bodyText
    Err.Clear
    On Error GoTo 0

    Set DrawPersonCardShape = cardBase
End Function

Private Sub SafeClearShapeText(ByVal shp As Shape)
    If shp Is Nothing Then Exit Sub
    On Error Resume Next
    shp.TextFrame.Characters.Text = ""
    Err.Clear
    On Error GoTo 0
End Sub

Private Sub SafeApplyShapeText(ByVal shp As Shape, _
        ByVal textValue As String, _
        ByVal fontSize As Double, _
        ByVal fontColor As Long, _
        Optional ByVal isBold As Boolean = False, _
        Optional ByVal horizontalAlign As Long = msoAlignLeft, _
        Optional ByVal verticalAnchor As Long = msoAnchorTop, _
        Optional ByVal marginLeftPt As Double = 0, _
        Optional ByVal marginRightPt As Double = 0, _
        Optional ByVal marginTopPt As Double = 0, _
        Optional ByVal marginBottomPt As Double = 0, _
        Optional ByVal useWordWrap As Boolean = True, _
        Optional ByVal spaceAfterPt As Double = 0)
    If shp Is Nothing Then Exit Sub
    If fontSize <= 0 Then fontSize = 9

    '�����֌W�}�͎��@�݊�����D�悵�A�V�����}�`����API�ɂ͈ˑ����Ȃ��B
    'Office 365�ł��A�Â��u�b�N�R���̐}�`��ꕔ���ł͐V�����}�`����API��438��Ԃ����Ƃ�����B
    On Error Resume Next
    With shp.TextFrame
        .Characters.Text = CStr(textValue)
        .Characters.Font.Name = THEME_FONT
        .Characters.Font.Size = fontSize
        .Characters.Font.Bold = isBold
        .Characters.Font.Color = fontColor
        .HorizontalAlignment = LegacyHorizontalAlignmentForShapeText(horizontalAlign)
        .VerticalAlignment = LegacyVerticalAlignmentForShapeText(verticalAnchor)
        .MarginLeft = marginLeftPt
        .MarginRight = marginRightPt
        .MarginTop = marginTopPt
        .MarginBottom = marginBottomPt
        .AutoSize = False
        .WordWrap = useWordWrap
    End With
    Err.Clear
    On Error GoTo 0
End Sub

Private Function SafeGetShapeText(ByVal shp As Shape) As String
    If shp Is Nothing Then Exit Function
    On Error Resume Next
    SafeGetShapeText = CStr(shp.TextFrame.Characters.Text)
    Err.Clear
    On Error GoTo 0
End Function

Private Function LegacyHorizontalAlignmentForShapeText(ByVal horizontalAlign As Long) As Long
    Select Case horizontalAlign
        Case msoAlignCenter
            LegacyHorizontalAlignmentForShapeText = xlHAlignCenter
        Case msoAlignRight
            LegacyHorizontalAlignmentForShapeText = xlHAlignRight
        Case Else
            LegacyHorizontalAlignmentForShapeText = xlHAlignLeft
    End Select
End Function

Private Function LegacyVerticalAlignmentForShapeText(ByVal verticalAnchor As Long) As Long
    Select Case verticalAnchor
        Case msoAnchorMiddle
            LegacyVerticalAlignmentForShapeText = xlVAlignCenter
        Case msoAnchorBottom
            LegacyVerticalAlignmentForShapeText = xlVAlignBottom
        Case Else
            LegacyVerticalAlignmentForShapeText = xlVAlignTop
    End Select
End Function

Private Function DiagramCardText(ByVal personRow As Long) As String
    Dim titleText As String, bodyText As String
    titleText = DiagramCardTitleText(personRow)
    bodyText = DiagramCardBodyText(personRow)
    If Len(bodyText) > 0 Then
        DiagramCardText = titleText & vbLf & bodyText
    Else
        DiagramCardText = titleText
    End If
End Function

Private Function DiagramCardTitleText(ByVal personRow As Long) As String
    Dim wp As Worksheet, displayName As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    displayName = CleanText(wp.Cells(personRow, P_DISPLAY).Value)
    If Len(displayName) = 0 Then displayName = CleanText(CStr(wp.Cells(personRow, P_SURNAME).Value) & " " & CStr(wp.Cells(personRow, P_GIVEN).Value))
    If Len(displayName) = 0 Then displayName = "�������o�^"
    DiagramCardTitleText = displayName
End Function

Private Function DiagramCardBodyText(ByVal personRow As Long) As String
    Dim wp As Worksheet, pid As String, relText As String, genderText As String, s As String
    Dim inh As Variant, birthValue As Variant, deathValue As Variant
    Dim addressText As String, deathPlace As String, occText As String, noteText As String
    Dim mText As String, dText As String, relGenderText As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    pid = CleanText(wp.Cells(personRow, P_ID).Value)
    relText = DiagramRelationDisplayTextForPersonRow(personRow)
    genderText = CleanText(wp.Cells(personRow, P_GENDER).Value)
    birthValue = wp.Cells(personRow, P_BIRTH).Value
    deathValue = wp.Cells(personRow, P_DEATH).Value
    inh = GetInheritanceDate()

    relGenderText = relText
    If Len(genderText) > 0 Then
        If Len(relGenderText) > 0 Then relGenderText = relGenderText & " / "
        relGenderText = relGenderText & genderText
    End If
    If Len(relGenderText) > 0 Then AppendCardLineLimited s, "����/����: " & relGenderText, 8

    If HasInputDate(birthValue) Then
        If ShouldShowInheritanceAgeOnCard(birthValue, deathValue, inh, relText) Then
            AppendCardLineLimited s, "��: " & DateWithEraYear(birthValue) & "�i������" & CStr(AgeOnDate(birthValue, inh)) & "�j", 8
        Else
            AppendCardLineLimited s, "��: " & DateWithEraYear(birthValue), 8
        End If
    End If
    If HasInputDate(deathValue) Then
        If HasInputDate(birthValue) Then
            AppendCardLineLimited s, "�v: " & DateWithEraYear(deathValue) & "�i" & CStr(AgeOnDate(birthValue, deathValue)) & "�v�j", 8
        Else
            AppendCardLineLimited s, "�v: " & DateWithEraYear(deathValue), 8
        End If
    End If

    '�������E�������͐l���J�[�h�̒��j���B�Z���E�E�ƁE��������Ɋm�ۂ��A
    '8�s����ɒB�������ߓ��͍ςݓ��t�����������Ԃ�h���B
    mText = PersonMarriageDateListForCard(pid, True)
    dText = PersonMarriageDateListForCard(pid, False)
    If Len(mText) > 0 Then AppendCardLineLimited s, "��: " & CompactCardText(mText, 36), 8
    If Len(dText) > 0 Then AppendCardLineLimited s, "��: " & CompactCardText(dText, 36), 8

    If Len(pid) > 0 Then
        If DiagramGraphChildIsSpouseSideUnconfirmed(pid) Then
            If Len(DiagramGraphUnconfirmedReason(pid)) > 0 Then
                AppendCardLineLimited s, "�m�F: " & CompactCardText(DiagramGraphUnconfirmedReason(pid), 28), 8
            Else
                AppendCardLineLimited s, "�m�F: �e�q�֌W�v�m�F", 8
            End If
        End If
    End If

    deathPlace = CleanText(wp.Cells(personRow, P_DEATH_PLACE).Value)
    If NormalizeDiagramRelationText(relText) = "�푊���l" Then
        If Len(deathPlace) > 0 Then AppendCardLineLimited s, "���S�ꏊ: " & CompactCardText(AddressForCard(deathPlace), 24), 8
    End If

    addressText = DiagramAddressTextForCard(pid, inh, deathValue)
    If Len(CleanText(addressText)) > 0 Then AppendCardLineLimited s, "�Z: " & CompactCardText(AddressForCard(addressText), 34), 8

    occText = CleanText(wp.Cells(personRow, P_OCC).Value)
    If Len(occText) > 0 Then AppendCardLineLimited s, "�E: " & CompactCardText(occText, 22), 8

    noteText = CleanText(wp.Cells(personRow, P_NOTE).Value)
    If Len(noteText) > 0 Then AppendCardLineLimited s, "����: " & CompactCardText(noteText, 28), 8

    DiagramCardBodyText = s
End Function

Private Function ShouldShowInheritanceAgeOnCard(ByVal birthValue As Variant, _
        ByVal deathValue As Variant, _
        ByVal inheritanceValue As Variant, _
        ByVal relText As String) As Boolean
    '�푊���l�͖v�N�����\������B�����J�n���N��͏o���Ȃ��B
    If NormalizeDiagramRelationText(relText) = "�푊���l" Then Exit Function
    If Not HasInputDate(birthValue) Then Exit Function
    If Not HasInputDate(inheritanceValue) Then Exit Function
    If HasInputDate(deathValue) Then
        '�����J�n���ȑO�Ɏ��S���Ă���l���ɂ́A�������N����o���Ȃ��B
        If CDate(SameDateOrBlank(deathValue)) <= CDate(SameDateOrBlank(inheritanceValue)) Then Exit Function
    End If
    ShouldShowInheritanceAgeOnCard = True
End Function

Private Sub AppendCardLine(ByRef s As String, ByVal lineText As String)
    lineText = CleanText(lineText)
    If Len(lineText) = 0 Then Exit Sub
    If Len(s) > 0 Then s = s & vbLf
    s = s & lineText
End Sub

Private Sub AppendCardLineLimited(ByRef s As String, ByVal lineText As String, ByVal maxLines As Long)
    If maxLines <= 0 Then Exit Sub
    If CardLogicalLineCount(s) >= maxLines Then Exit Sub
    AppendCardLine s, lineText
End Sub

Private Function CardLogicalLineCount(ByVal s As String) As Long
    s = CleanText(s)
    If Len(s) = 0 Then Exit Function
    CardLogicalLineCount = UBound(Split(s, vbLf)) + 1
End Function

Private Sub EmphasizeCardBodyLabels(ByVal shp As Shape, ByVal bodyText As String)
    Dim lines As Variant, i As Long, pos As Long, labelLen As Long, lineText As String
    If shp Is Nothing Then Exit Sub
    lines = Split(CStr(bodyText) & vbLf, vbLf)
    pos = Len(SafeGetShapeTextFirstLine(shp)) + 2
    On Error Resume Next
    For i = LBound(lines) To UBound(lines) - 1
        lineText = CStr(lines(i))
        labelLen = InStr(1, lineText, ":", vbTextCompare)
        If labelLen > 1 Then
            shp.TextFrame.Characters(pos, labelLen).Font.Bold = True
            shp.TextFrame.Characters(pos, labelLen).Font.Color = ThemeColor("muted-strong")
            Err.Clear
        End If
        pos = pos + Len(lineText) + 1
    Next i
    On Error GoTo 0
End Sub

Private Function SafeGetShapeTextFirstLine(ByVal shp As Shape) As String
    Dim s As String, p As Long
    s = SafeGetShapeText(shp)
    p = InStr(1, s, vbLf, vbBinaryCompare)
    If p > 0 Then
        SafeGetShapeTextFirstLine = Left$(s, p - 1)
    Else
        SafeGetShapeTextFirstLine = s
    End If
End Function

Private Function CompactCardText(ByVal s As String, ByVal maxLen As Long) As String
    s = CleanText(s)
    If Len(s) = 0 Then
        CompactCardText = "���o�^"
    ElseIf Len(s) > maxLen Then
        If maxLen <= 1 Then
            CompactCardText = Left$(s, maxLen)
        Else
            CompactCardText = Left$(s, maxLen - 1) & "�c"
        End If
    Else
        CompactCardText = s
    End If
End Function

Private Function AddressForCard(ByVal s As String) As String
    s = CleanText(s)
    s = Replace(s, vbCrLf, " ")
    s = Replace(s, vbCr, " ")
    s = Replace(s, vbLf, " ")
    Do While InStr(s, "  ") > 0
        s = Replace(s, "  ", " ")
    Loop
    If Len(s) = 0 Then
        AddressForCard = "���o�^"
    Else
        AddressForCard = s
    End If
End Function

Private Function SameAddressForCard(ByVal leftAddress As String, ByVal rightAddress As String) As Boolean
    SameAddressForCard = (NormalizeAddressForCardCompare(leftAddress) = NormalizeAddressForCardCompare(rightAddress))
End Function

Private Function NormalizeAddressForCardCompare(ByVal s As String) As String
    s = AddressForCard(s)
    If s = "���o�^" Then s = ""
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    NormalizeAddressForCardCompare = s
End Function

Private Function PersonMarriageDateListForCard(ByVal personId As String, ByVal wantMarriage As Boolean) As String
    Dim d As Object, result As String
    Set d = CreateObject("Scripting.Dictionary")
    '���������𐳂Ƃ���B�l���\�E�֌W�\�̓��t�͋��`���݊��̕⏕�Ƃ��āA�����������ꍇ�����g���B
    AddMarriageHistoryDateForCard d, personId, wantMarriage
    If d.Count = 0 Then AddLegacyPersonMarriageDateForCard d, personId, wantMarriage
    If d.Count = 0 Then AddRelationMarriageDateForCard d, personId, wantMarriage
    result = JoinDictionaryKeysForCard(d, "�A")
    PersonMarriageDateListForCard = result
End Function

Private Sub AddLegacyPersonMarriageDateForCard(ByVal d As Object, ByVal personId As String, ByVal wantMarriage As Boolean)
    Dim wp As Worksheet, r As Long, v As Variant
    If Len(personId) = 0 Or Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, P_ID)
        If CleanText(wp.Cells(r, P_ID).Value) = personId Then
            If wantMarriage Then
                v = wp.Cells(r, P_MARRIAGE).Value
            Else
                v = wp.Cells(r, P_DIVORCE).Value
            End If
            AddDateToCardDictionary d, v
            Exit For
        End If
    Next r
End Sub

Private Sub AddMarriageHistoryDateForCard(ByVal d As Object, ByVal personId As String, ByVal wantMarriage As Boolean)
    Dim ws As Worksheet, r As Long, v As Variant, cp As String, cpId As String, ownerId As String
    If Len(personId) = 0 Or Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(ws, MH_ID)
        If CleanText(ws.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL And CleanText(ws.Cells(r, MH_SHOW).Value) <> SHOW_NO Then
            ownerId = CleanText(ws.Cells(r, MH_PERSON_ID).Value)
            cpId = CleanText(ws.Cells(r, MH_COUNTERPART_ID).Value)
            '����������1�s�͕v�w�o���̎����B�l��ID�������łȂ�����l��ID����
            '�J�[�h�ɂ��������Ԃ��o���i�Б��o�^�̗����ł��\�����������Ȃ��j�B
            If ownerId = personId Or cpId = personId Then
                If wantMarriage Then
                    v = ws.Cells(r, MH_MARRIAGE).Value
                Else
                    v = ws.Cells(r, MH_DIVORCE).Value
                End If
                If ownerId = personId Then
                    cp = CleanText(ws.Cells(r, MH_COUNTERPART_NAME).Value)
                    If Len(cp) = 0 And Len(cpId) > 0 Then cp = GetPersonValue(cpId, P_DISPLAY)
                Else
                    cp = GetPersonValue(ownerId, P_DISPLAY)
                End If
                AddDateToCardDictionary d, v, cp
            End If
        End If
    Next r
End Sub

Private Sub AddRelationMarriageDateForCard(ByVal d As Object, ByVal personId As String, ByVal wantMarriage As Boolean)
    Dim wr As Worksheet, r As Long, relType As String, v As Variant
    If Len(personId) = 0 Or Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            relType = CleanText(wr.Cells(r, R_TYPE).Value)
            If DiagramGraphIsSpouseRelationType(relType) Then
                If CleanText(wr.Cells(r, R_BASE_ID).Value) = personId Or CleanText(wr.Cells(r, R_OTHER_ID).Value) = personId Then
                    If wantMarriage Then
                        v = wr.Cells(r, R_MARRIAGE).Value
                    Else
                        v = wr.Cells(r, R_DIVORCE).Value
                    End If
                    AddDateToCardDictionary d, v
                End If
            End If
        End If
    Next r
End Sub

Private Sub AddDateToCardDictionary(ByVal d As Object, ByVal v As Variant, Optional ByVal counterpartName As String = "")
    Dim key As String, dateKey As String, k As Variant
    If d Is Nothing Then Exit Sub
    If Not HasInputDate(v) Then Exit Sub
    dateKey = DateWithEraYear(v)
    If Len(dateKey) = 0 Then Exit Sub
    counterpartName = CleanText(counterpartName)
    If Len(counterpartName) > 0 Then
        key = dateKey & " " & counterpartName
        If d.Exists(dateKey) Then d.Remove dateKey
    Else
        For Each k In d.Keys
            If Left$(CStr(k), Len(dateKey) + 1) = dateKey & " " Then Exit Sub
        Next k
        key = dateKey
    End If
    If Not d.Exists(key) Then d.Add key, True
End Sub

Private Function JoinDictionaryKeysForCard(ByVal d As Object, ByVal delimiterText As String) As String
    Dim k As Variant, s As String
    If d Is Nothing Then Exit Function
    For Each k In d.Keys
        If Len(s) > 0 Then s = s & delimiterText
        s = s & CStr(k)
    Next k
    JoinDictionaryKeysForCard = s
End Function

Private Function GetAddressTextAtDate(ByVal personId As String, ByVal baseDate As Variant) As String
    Dim wa As Worksheet, r As Long, bestR As Long, bestScore As Double, score As Double
    Dim st As Variant, en As Variant
    If Len(personId) = 0 Or Not HasInputDate(baseDate) Then Exit Function
    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Function
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    bestScore = -1E+20
    For r = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r, A_PERSON_ID).Value) = personId And CStr(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
            st = wa.Cells(r, A_START).Value
            en = wa.Cells(r, A_END).Value
            If AddressRowCoversDate(st, en, baseDate) Then
                score = r
                If CleanText(wa.Cells(r, A_TYPE).Value) = "���Z�n" Then score = score + 100000
                If HasInputDate(st) Then score = score + CDbl(CDate(SameDateOrBlank(st))) / 100
                If score > bestScore Then
                    bestScore = score
                    bestR = r
                End If
            End If
        End If
    Next r
    If bestR > 0 Then GetAddressTextAtDate = CStr(wa.Cells(bestR, A_TEXT).Value)
End Function

Private Function AddressRowCoversDate(ByVal startValue As Variant, ByVal endValue As Variant, ByVal baseDate As Variant) As Boolean
    If Not HasInputDate(baseDate) Then Exit Function
    If HasInputDate(startValue) Then
        If CDate(SameDateOrBlank(startValue)) > CDate(SameDateOrBlank(baseDate)) Then Exit Function
    End If
    If HasInputDate(endValue) Then
        If CDate(SameDateOrBlank(endValue)) < CDate(SameDateOrBlank(baseDate)) Then Exit Function
    End If
    AddressRowCoversDate = True
End Function

Private Function DateWithEraYear(ByVal v As Variant) As String
    Dim parsed As Variant
    parsed = SameDateOrBlank(v)
    If Not HasInputDate(parsed) Then Exit Function
    DateWithEraYear = EraCodeForDate(parsed) & " " & Format(CDate(parsed), "yyyy/m/d")
End Function

Private Function EraCodeForDate(ByVal v As Variant) As String
    Dim d As Date, y As Long
    If Not HasInputDate(v) Then Exit Function
    d = CDate(SameDateOrBlank(v))
    If d >= DateSerial(2019, 5, 1) Then
        y = Year(d) - 2018
        EraCodeForDate = "R" & CStr(y)
    ElseIf d >= DateSerial(1989, 1, 8) Then
        y = Year(d) - 1988
        EraCodeForDate = "H" & CStr(y)
    ElseIf d >= DateSerial(1926, 12, 25) Then
        y = Year(d) - 1925
        EraCodeForDate = "S" & CStr(y)
    ElseIf d >= DateSerial(1912, 7, 30) Then
        y = Year(d) - 1911
        EraCodeForDate = "T" & CStr(y)
    ElseIf d >= DateSerial(1868, 1, 25) Then
        y = Year(d) - 1867
        EraCodeForDate = "M" & CStr(y)
    Else
        EraCodeForDate = CStr(Year(d))
    End If
End Function

Private Function MaxDiagramCardVisualLineCount(ByVal cardWidthPt As Double) As Long
    Dim wp As Worksheet, r As Long, n As Long, lineCount As Long
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then
        MaxDiagramCardVisualLineCount = 9
        Exit Function
    End If
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            If Len(CStr(wp.Cells(r, P_ID).Value)) > 0 Then
                If CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
                    n = DiagramCardVisualLineCount(r, cardWidthPt)
                    If n > lineCount Then lineCount = n
                End If
            End If
        End If
    Next r
    If lineCount < 8 Then lineCount = 8
    If lineCount > 18 Then lineCount = 18
    MaxDiagramCardVisualLineCount = lineCount
End Function

Private Function DiagramCardVisualLineCount(ByVal personRow As Long, ByVal cardWidthPt As Double) As Long
    DiagramCardVisualLineCount = EstimateCardTextVisualLines(DiagramCardText(personRow), cardWidthPt)
End Function

Private Function EstimateCardTextVisualLines(ByVal text As String, ByVal cardWidthPt As Double) As Long
    Dim arr As Variant, i As Long, capacity As Long, n As Long, total As Long
    arr = Split(text & vbLf, vbLf)
    capacity = CLng((cardWidthPt - 16) / 6.0)
    If capacity < 12 Then capacity = 12
    For i = LBound(arr) To UBound(arr) - 1
        n = Len(CStr(arr(i)))
        If n < 1 Then n = 1
        total = total + Application.Max(1, Int((n - 1) / capacity) + 1)
    Next i
    If total < 1 Then total = 1
    EstimateCardTextVisualLines = total
End Function

Private Function DiagramCardHeightFromLines(ByVal lineCount As Long) As Double
    If lineCount < 5 Then lineCount = 5
    If lineCount > 12 Then lineCount = 12
    '���ʂ̑����l��1�l�ɍ��킹�đS�J�[�h�����剻���Ȃ��悤�A�{����������Ɉ��k����B
    DiagramCardHeightFromLines = Application.Max(94, Application.Min(126, lineCount * 9.2 + 24))
End Function

Private Function CardHeaderHeight(ByVal widthPt As Double, ByVal heightPt As Double) As Double
    CardHeaderHeight = 0
End Function

Private Function CardTitleFontSizeForName(ByVal displayName As String, ByVal widthPt As Double) As Double
    If Len(displayName) >= 30 Or widthPt < 165 Then
        CardTitleFontSizeForName = 8.6
    ElseIf Len(displayName) >= 22 Or widthPt < 185 Then
        CardTitleFontSizeForName = 9.0
    ElseIf Len(displayName) >= 14 Then
        CardTitleFontSizeForName = 9.4
    Else
        CardTitleFontSizeForName = 9.8
    End If
End Function

Private Function HeaderFontSizeForName(ByVal displayName As String, ByVal widthPt As Double) As Double
    HeaderFontSizeForName = CardTitleFontSizeForName(displayName, widthPt)
End Function

Private Function CardFontSizeForText(ByVal text As String, ByVal widthPt As Double, ByVal heightPt As Double) As Double
    CardFontSizeForText = CardFontSizeForShape(text, widthPt, heightPt)
End Function

Private Function CardFontSizeForShape(ByVal text As String, ByVal cardW As Double, ByVal cardH As Double) As Double
    Dim lineCount As Long, sizeFromHeight As Double, targetSize As Double
    lineCount = EstimateWrappedLineCount(text, cardW)
    sizeFromHeight = (cardH - 30) / Application.Max(1, lineCount * 1.22)

    If lineCount >= 12 Or Len(text) >= 230 Then
        targetSize = 7.7
    ElseIf lineCount >= 9 Or Len(text) >= 155 Then
        targetSize = 8.0
    Else
        targetSize = 8.4
    End If
    CardFontSizeForShape = Application.Min(targetSize, Application.Max(7.4, sizeFromHeight))
End Function

Private Function EstimateWrappedLineCount(ByVal text As String, ByVal cardW As Double) As Long
    Dim arr As Variant, i As Long, charsPerLine As Long, s As String, n As Long, total As Long
    charsPerLine = CLng(Application.Max(12, (cardW - 18) / 6.2))
    arr = Split(CStr(text) & vbLf, vbLf)
    For i = LBound(arr) To UBound(arr)
        s = CleanText(arr(i))
        n = Len(s)
        If n = 0 Then
            total = total + 1
        Else
            total = total + Application.Max(1, WorksheetFunction.RoundUp(n / charsPerLine, 0))
        End If
    Next i
    If total < 1 Then total = 1
    EstimateWrappedLineCount = total
End Function

Private Function CardBadgeText(ByVal relationText As String) As String
    Dim baseText As String
    baseText = NormalizeDiagramRelationText(relationText)
    If Len(baseText) = 0 Then baseText = CleanText(relationText)
    If Len(baseText) = 0 Then Exit Function
    If InStr(baseText, "�i") > 0 Then baseText = Left$(baseText, InStr(baseText, "�i") - 1)
    If InStr(baseText, "(") > 0 Then baseText = Left$(baseText, InStr(baseText, "(") - 1)
    CardBadgeText = baseText
End Function

Private Function CardBadgeWidth(ByVal badgeText As String) As Double
    Dim n As Long
    n = Len(CleanText(badgeText))
    If n = 0 Then
        CardBadgeWidth = 0
    ElseIf n <= 2 Then
        CardBadgeWidth = 46
    ElseIf n <= 4 Then
        CardBadgeWidth = 58
    Else
        CardBadgeWidth = Application.Min(88, 34 + n * 9)
    End If
End Function

Private Function CardBadgeFontSize(ByVal badgeText As String) As Double
    If Len(CleanText(badgeText)) >= 5 Then
        CardBadgeFontSize = 8.4
    Else
        CardBadgeFontSize = 9.1
    End If
End Function

Private Function CardHeaderFillColor(ByVal relationText As String) As Long
    Select Case NormalizeDiagramRelationText(relationText)
        Case "�푊���l"
            CardHeaderFillColor = ThemeColor("teal-soft")
        Case "�z���", "�O�z���"
            CardHeaderFillColor = ThemeColor("warning-soft")
        Case "��", "��"
            CardHeaderFillColor = ThemeColor("success-soft")
        Case "�Z", "��", "�o", "��", "�Z��", "�o��", "�Z��o��"
            CardHeaderFillColor = ThemeColor("orange-soft")
        Case "��", "�]��", "����"
            CardHeaderFillColor = ThemeColor("purple-soft")
        Case Else
            If IsDirectChildRelationText(relationText) Then
                CardHeaderFillColor = ThemeColor("info-soft")
            Else
                CardHeaderFillColor = ThemeColor("surface-soft")
            End If
    End Select
End Function

Private Function CardAccentColor(ByVal relationText As String) As Long
    Select Case NormalizeDiagramRelationText(relationText)
        Case "�푊���l"
            CardAccentColor = ThemeColor("teal")
        Case "�z���", "�O�z���"
            CardAccentColor = ThemeColor("orange")
        Case "��", "��"
            CardAccentColor = ThemeColor("green")
        Case "�Z", "��", "�o", "��", "�Z��", "�o��", "�Z��o��"
            CardAccentColor = ThemeColor("orange")
        Case "��", "�]��", "����"
            CardAccentColor = ThemeColor("purple")
        Case Else
            If IsDirectChildRelationText(relationText) Then
                CardAccentColor = ThemeColor("accent")
            Else
                CardAccentColor = ThemeColor("muted-strong")
            End If
    End Select
End Function

Private Function CardBadgeFillColor(ByVal relationText As String) As Long
    CardBadgeFillColor = CardHeaderFillColor(relationText)
End Function

Private Function CardBadgeFontColor(ByVal relationText As String) As Long
    Select Case NormalizeDiagramRelationText(relationText)
        Case "�푊���l"
            CardBadgeFontColor = ThemeColor("teal-text")
        Case "�z���", "�O�z���"
            CardBadgeFontColor = ThemeColor("warning-text")
        Case "��", "��"
            CardBadgeFontColor = ThemeColor("success-text")
        Case "�Z", "��", "�o", "��", "�Z��", "�o��", "�Z��o��"
            CardBadgeFontColor = ThemeColor("warning-text")
        Case "��", "�]��", "����"
            CardBadgeFontColor = ThemeColor("purple")
        Case Else
            If IsDirectChildRelationText(relationText) Then
                CardBadgeFontColor = ThemeColor("accent")
            Else
                CardBadgeFontColor = ThemeColor("muted-strong")
            End If
    End Select
End Function

Private Function CardFillColor(ByVal relationText As String) As Long
    relationText = NormalizeDiagramRelationText(relationText)
    Select Case relationText
        Case "�푊���l"
            CardFillColor = ThemeColor("info-very-soft")
        Case "�z���"
            CardFillColor = ThemeColor("warning-soft")
        Case "��", "��"
            CardFillColor = ThemeColor("success-soft")
        Case "�Z", "��", "�o", "��", "�Z��", "�o��", "�Z��o��"
            CardFillColor = ThemeColor("orange-soft")
        Case "��", "�]��", "����"
            CardFillColor = ThemeColor("purple-soft")
        Case Else
            If IsDirectChildRelationText(relationText) Then
                CardFillColor = ThemeColor("info-very-soft")
            ElseIf InStr(relationText, "�z���") > 0 Then
                CardFillColor = ThemeColor("warning-soft")
            Else
                CardFillColor = ThemeColor("canvas")
            End If
    End Select
End Function

Private Function GetFirstVisiblePersonRowByRelation(ByVal relationText As String) As Long
    Dim wp As Worksheet, r As Long, targetText As String, relText As String, parentSpouseText As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    targetText = NormalizeDiagramRelationText(relationText)
    For r = 2 To LastRow(wp, 1)
        If VisibleDiagramPersonRow(r) Then
            relText = NormalizeDiagramRelationText(DiagramRelationAndNoteForPersonRow(r))
            If relText = targetText Then
                GetFirstVisiblePersonRowByRelation = r
                Exit Function
            End If
            '�u���̔z��ҁv�u��̔z��ҁv��A�\�����E���l�������������f�[�^�ł��e����֖߂��B
            parentSpouseText = DiagramParentSpouseDisplayLabel(r, DiagramRelationAndNoteForPersonRow(r))
            If Len(parentSpouseText) > 0 Then
                If parentSpouseText = targetText Then
                    GetFirstVisiblePersonRowByRelation = r
                    Exit Function
                End If
            End If
        End If
    Next r
End Function

Private Function GetRootChildRows(ByVal decId As String) As Collection
    Set GetRootChildRows = GetChildRowsForParent(decId)
End Function

Private Function GetDirectChildRows(ByVal decId As String) As Collection
    Set GetDirectChildRows = GetRootChildRows(decId)
End Function

Private Function IsDirectChildRelationText(ByVal relText As String) As Boolean
    relText = DiagramBaseRelationLabel(relText)
    Select Case relText
        Case "���j", "��j", "�O�j", "�l�j", "�ܒj", "�Z�j", "����", "��", "�O��", "�l��", "�܏�", "�Z��", "�q", "�{�q"
            IsDirectChildRelationText = True
    End Select
End Function

Private Function GetSpouseRowOfPerson(ByVal personId As String) As Long
    If DiagramGraphEnsureBuilt(GetDecedentId()) Then
        GetSpouseRowOfPerson = DiagramGraphSpouseRow(personId)
    End If
End Function

Private Function ShouldListAsOther(ByVal relText As String) As Boolean
    Dim rawText As String
    rawText = CleanText(relText)
    relText = NormalizeDiagramRelationText(rawText)
    If relText = "�푊���l" Or relText = "�z���" Or relText = "��" Or relText = "��" Then Exit Function
    If IsSiblingRelationText(relText) Then Exit Function
    If IsDirectChildRelationText(relText) Then Exit Function
    If DiagramDescendantLevel(relText) > 0 Then Exit Function
    If InStr(relText, "�z���") > 0 Then Exit Function
    If DiagramRelationTextIsOtherParty(rawText) Then
        ShouldListAsOther = True
    ElseIf Len(relText) > 0 Then
        ShouldListAsOther = True
    End If
End Function

Private Sub DrawHLine(ByVal ws As Worksheet, ByVal x1 As Double, ByVal y As Double, ByVal x2 As Double)
    Dim shp As Shape, errNum As Long, errDesc As String
    If mDiagramCardsOnly Then Exit Sub
    If ws Is Nothing Then Exit Sub
    x1 = SafeDiagramPoint(x1, 1)
    x2 = SafeDiagramPoint(x2, 1)
    y = SafeDiagramPoint(y, 1)
    If Abs(x2 - x1) < 0.5 Then Exit Sub
    On Error GoTo EH
    Set shp = ws.Shapes.AddLine(x1, y, x2, y)
    shp.Placement = xlFreeFloating
    shp.Locked = True
    With shp.Line
        .ForeColor.RGB = ThemeColor("muted-strong")
        .Weight = 1.5
        .EndArrowheadStyle = msoArrowheadNone
        .BeginArrowheadStyle = msoArrowheadNone
    End With
    shp.ZOrder msoSendToBack
    Exit Sub
EH:
    errNum = Err.Number
    errDesc = Err.Description
    AppendRelationshipDiagramDrawWarning "���`��", "�������X�L�b�v: " & Err.Description
    Err.Clear
    If mDiagramStrictLineMode Then Err.Raise errNum, "DrawHLine", errDesc
End Sub

Private Sub DrawVLine(ByVal ws As Worksheet, ByVal x As Double, ByVal y1 As Double, ByVal y2 As Double)
    Dim shp As Shape, errNum As Long, errDesc As String
    If mDiagramCardsOnly Then Exit Sub
    If ws Is Nothing Then Exit Sub
    x = SafeDiagramPoint(x, 1)
    y1 = SafeDiagramPoint(y1, 1)
    y2 = SafeDiagramPoint(y2, 1)
    If Abs(y2 - y1) < 0.5 Then Exit Sub
    On Error GoTo EH
    Set shp = ws.Shapes.AddLine(x, y1, x, y2)
    shp.Placement = xlFreeFloating
    shp.Locked = True
    With shp.Line
        .ForeColor.RGB = ThemeColor("muted-strong")
        .Weight = 1.5
        .EndArrowheadStyle = msoArrowheadNone
        .BeginArrowheadStyle = msoArrowheadNone
    End With
    shp.ZOrder msoSendToBack
    Exit Sub
EH:
    errNum = Err.Number
    errDesc = Err.Description
    AppendRelationshipDiagramDrawWarning "���`��", "�c�����X�L�b�v: " & Err.Description
    Err.Clear
    If mDiagramStrictLineMode Then Err.Raise errNum, "DrawVLine", errDesc
End Sub

Private Function ShapeCenterX(ByVal shp As Shape) As Double
    On Error GoTo EH
    If shp Is Nothing Then Exit Function
    ShapeCenterX = shp.Left + shp.Width / 2
    Exit Function
EH:
    Err.Clear
End Function

Private Function ShapeCenterY(ByVal shp As Shape) As Double
    On Error GoTo EH
    If shp Is Nothing Then Exit Function
    ShapeCenterY = shp.Top + shp.Height / 2
    Exit Function
EH:
    Err.Clear
End Function


Public Sub BuildAddressHistoryTable()
    Dim ws As Worksheet, wa As Worksheet, outR As Long, r As Long, pid As String, endDate As Variant
    Dim headerRow As Long, firstDataRow As Long, lastDataRow As Long
    Set ws = ThisWorkbook.Worksheets(SH_ADDR_TABLE)
    ClearSheetAll ws
    ApplySheetCanvas ws
    headerRow = 8
    firstDataRow = headerRow + 1

    ws.Range("A1:I1").Merge
    TitleBannerStyle ws.Range("A1:I1"), "�Z���ꗗ�E�Z�����𑁌��\"
    AddButton ws, "K1", "�I���Z�������", "LoadSelectedAddressHistoryForEdit", 118, 26
    AddButton ws, "L1", "�I���Z�����폜", "DeleteSelectedAddressFromTable", 118, 26
    AddButton ws, "M1", "���֖͂߂�", "ShowOnlyInput", 96, 26
    ws.Range("A7:I7").Merge
    SectionStyle ws.Range("A7:I7"), "�l���ʏZ���ꗗ"

    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    outR = firstDataRow
    For r = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wa.Cells(r, A_ID).Value)) > 0 Then
            pid = CleanText(wa.Cells(r, A_PERSON_ID).Value)
            endDate = EffectiveEndDate(r)
            ws.Cells(outR, 1).Value = pid
            ws.Cells(outR, 2).Value = GetPersonValue(pid, P_DISPLAY)
            ws.Cells(outR, 3).Value = DiagramRelationDisplayTextForPersonId(pid)
            ws.Cells(outR, 4).Value = wa.Cells(r, A_START).Value
            ws.Cells(outR, 5).Value = EffectiveAddressStartKind(wa, r)
            ws.Cells(outR, 6).Value = endDate
            ws.Cells(outR, 7).Value = PeriodText(wa.Cells(r, A_START).Value, endDate)
            ws.Cells(outR, 8).Value = wa.Cells(r, A_TEXT).Value
            ws.Cells(outR, 9).Value = AddressHistoryStatusText(pid, r, endDate)
            ws.Cells(outR, 10).Value = wa.Cells(r, A_ID).Value
            outR = outR + 1
        End If
    Next r
    lastDataRow = Application.Max(firstDataRow, outR - 1)
    SetRowValues ws.Cells(headerRow, 1), Array("�l��ID", "����", "����", "�J�n��", "�J�n�敪", "�I����", "����", "�Z��", "���", "�Z��ID")
    HeaderStyle ws.Range(ws.Cells(headerRow, 1), ws.Cells(headerRow, 10))
    If outR > firstDataRow Then SortAddressHistoryOutput ws, lastDataRow, headerRow
    BuildAddressSummaryBand ws, lastDataRow, firstDataRow
    SetRowValues ws.Cells(headerRow, 1), Array("�l��ID", "����", "����", "�J�n��", "�J�n�敪", "�I����", "����", "�Z��", "���", "�Z��ID")
    HeaderStyle ws.Range(ws.Cells(headerRow, 1), ws.Cells(headerRow, 10))
    ws.Range(ws.Cells(firstDataRow, 4), ws.Cells(Application.Max(firstDataRow, lastDataRow), 4)).NumberFormatLocal = "yyyy/m/d"
    ws.Range(ws.Cells(firstDataRow, 6), ws.Cells(Application.Max(firstDataRow, lastDataRow), 6)).NumberFormatLocal = "yyyy/m/d"
    PolishAddressHistoryOutput ws, headerRow, firstDataRow, lastDataRow
End Sub

Private Sub PolishAddressHistoryOutput(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow Then lastDataRow = firstDataRow
    With ws.Range(ws.Cells(headerRow, 1), ws.Cells(lastDataRow, 10))
        .Font.Name = THEME_FONT
        .Font.Size = 10.6
        .VerticalAlignment = xlTop
        .WrapText = True
    End With
    ThemeApplyZebraTable ws.Range(ws.Cells(headerRow, 1), ws.Cells(lastDataRow, 10)), 1
    ThemeApplyPrintTable ws.Range(ws.Cells(headerRow, 1), ws.Cells(lastDataRow, 10)), 1
    ws.Columns("A:A").ColumnWidth = 9
    ws.Columns("B:B").ColumnWidth = 20
    ws.Columns("C:C").ColumnWidth = 11
    ws.Columns("D:D").ColumnWidth = 12
    ws.Columns("E:E").ColumnWidth = 12
    ws.Columns("F:F").ColumnWidth = 12
    ws.Columns("G:G").ColumnWidth = 17
    ws.Columns("H:H").ColumnWidth = 74
    ws.Columns("I:I").ColumnWidth = 15
    ws.Columns("J:J").ColumnWidth = 14
    ws.Columns("J:J").Hidden = True
    ws.Rows("1:1").RowHeight = 30
    ws.Rows("3:5").RowHeight = 25
    ws.Rows("6:6").RowHeight = 12
    ws.Rows("7:7").RowHeight = 25
    ws.Rows(CStr(headerRow) & ":" & CStr(headerRow)).RowHeight = 28
    If lastDataRow >= firstDataRow Then
        FitAddressHistoryRowHeights ws, firstDataRow, lastDataRow
        HighlightAddressHistorySemantics ws, firstDataRow, lastDataRow
        PolishAddressPersonColumns ws, firstDataRow, lastDataRow
        MarkAddressPersonBreaks ws, firstDataRow, lastDataRow
    End If
    ThemeMarkMacroButtonsNonPrintable ws
    ApplyAdaptiveOutputPrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(lastDataRow, 9)).Address, "$8:$8", lastDataRow, 9, False
End Sub

Private Sub FitAddressHistoryRowHeights(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long, visualLines As Long, targetHeight As Double
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow Then Exit Sub
    For r = firstDataRow To lastDataRow
        visualLines = Application.Max(1, WorksheetFunction.RoundUp(Application.Max(1, Len(CleanText(ws.Cells(r, 8).Value))) / 34, 0))
        targetHeight = 42 + visualLines * 16
        If targetHeight < 58 Then targetHeight = 58
        If targetHeight > 178 Then targetHeight = 178
        ws.Rows(r).RowHeight = targetHeight
    Next r
End Sub

Private Sub HighlightAddressHistorySemantics(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long, kindText As String, statusText As String
    If ws Is Nothing Then Exit Sub
    For r = firstDataRow To lastDataRow
        kindText = CleanText(ws.Cells(r, 5).Value)
        statusText = CleanText(ws.Cells(r, 9).Value)
        If kindText = "�c����" Then
            ws.Cells(r, 5).Interior.Color = ThemeColor("warning-soft")
            ws.Cells(r, 5).Font.Color = ThemeColor("warning-text")
            ws.Cells(r, 5).Font.Bold = True
        ElseIf kindText = "���Z�J�n" Then
            ws.Cells(r, 5).Interior.Color = ThemeColor("info-soft")
            ws.Cells(r, 5).Font.Color = ThemeColor("accent")
            ws.Cells(r, 5).Font.Bold = True
        End If
        If Len(CleanText(ws.Cells(r, 8).Value)) = 0 Or CleanText(ws.Cells(r, 8).Value) = "���o�^" Then
            ws.Cells(r, 8).Interior.Color = ThemeColor("danger-soft")
            ws.Cells(r, 8).Font.Color = ThemeColor("danger-text")
        End If
        ws.Cells(r, 7).Font.Color = ThemeColor("muted-strong")
        If InStr(statusText, "�v�m�F") > 0 Then
            ws.Cells(r, 9).Interior.Color = ThemeColor("warning-soft")
            ws.Cells(r, 9).Font.Color = ThemeColor("warning-text")
            ws.Cells(r, 9).Font.Bold = True
        ElseIf InStr(statusText, "���Z��") > 0 Then
            ws.Cells(r, 9).Interior.Color = ThemeColor("success-soft")
            ws.Cells(r, 9).Font.Color = ThemeColor("success-text")
            ws.Cells(r, 9).Font.Bold = True
        ElseIf InStr(statusText, "������") > 0 Then
            ws.Cells(r, 9).Interior.Color = ThemeColor("teal-soft")
            ws.Cells(r, 9).Font.Color = ThemeColor("teal-text")
            ws.Cells(r, 9).Font.Bold = True
        Else
            ws.Cells(r, 9).Interior.Color = ThemeColor("surface-soft")
            ws.Cells(r, 9).Font.Color = ThemeColor("muted-strong")
        End If
    Next r
End Sub

Private Sub MarkAddressPersonBreaks(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow + 1 Then Exit Sub
    On Error Resume Next
    For r = firstDataRow + 1 To lastDataRow
        If CleanText(ws.Cells(r, 1).Value) <> CleanText(ws.Cells(r - 1, 1).Value) Then
            With ws.Range(ws.Cells(r, 1), ws.Cells(r, 9)).Borders(xlEdgeTop)
                .LineStyle = xlContinuous
                .Color = ThemeColor("border-strong")
                .Weight = xlMedium
            End With
            ws.Rows(r).RowHeight = ws.Rows(r).RowHeight + 8
        End If
    Next r
    On Error GoTo 0
End Sub

Private Sub PolishAddressPersonColumns(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long, isNewPerson As Boolean
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow Then Exit Sub
    On Error Resume Next
    For r = firstDataRow To lastDataRow
        isNewPerson = (r = firstDataRow)
        If Not isNewPerson Then isNewPerson = (CleanText(ws.Cells(r, 1).Value) <> CleanText(ws.Cells(r - 1, 1).Value))
        With ws.Range(ws.Cells(r, 1), ws.Cells(r, 3))
            .Interior.Color = ThemeColor("surface-soft")
            .Font.Color = ThemeColor("title")
            .Font.Bold = isNewPerson
            .VerticalAlignment = xlTop
        End With
        If Not isNewPerson Then
            ws.Cells(r, 2).Font.Color = ThemeColor("muted")
            ws.Cells(r, 3).Font.Color = ThemeColor("muted")
        End If
        ws.Cells(r, 8).Font.Size = 10.4
        ws.Cells(r, 8).HorizontalAlignment = xlLeft
        ws.Cells(r, 8).VerticalAlignment = xlTop
        ws.Cells(r, 9).HorizontalAlignment = xlCenter
        ws.Cells(r, 9).VerticalAlignment = xlCenter
    Next r
    On Error GoTo 0
End Sub

Private Sub BuildAddressSummaryBand(ByVal ws As Worksheet, ByVal lastDataRow As Long, ByVal firstDataRow As Long)
    Dim totalCount As Long, personCount As Long, currentCount As Long, reviewCount As Long
    totalCount = CountNonBlankTextInRange(ws.Range(ws.Cells(firstDataRow, 1), ws.Cells(Application.Max(firstDataRow, lastDataRow), 1)))
    personCount = CountDistinctTextInRange(ws.Range(ws.Cells(firstDataRow, 1), ws.Cells(Application.Max(firstDataRow, lastDataRow), 1)))
    currentCount = CountTextContainsInRange(ws.Range(ws.Cells(firstDataRow, 9), ws.Cells(Application.Max(firstDataRow, lastDataRow), 9)), "���Z��")
    reviewCount = CountTextContainsInRange(ws.Range(ws.Cells(firstDataRow, 9), ws.Cells(Application.Max(firstDataRow, lastDataRow), 9)), "�v�m�F")
    WriteMetricCard ws.Range("A3:B5"), "�Z������", CStr(totalCount) & "��"
    WriteMetricCard ws.Range("C3:D5"), "�o�^�l��", CStr(personCount) & "��"
    WriteMetricCard ws.Range("E3:F5"), "���Z��", CStr(currentCount) & "��"
    WriteMetricCard ws.Range("G3:I5"), "�v�m�F", CStr(reviewCount) & "��"
End Sub

Private Function AddressHistoryStatusText(ByVal personId As String, ByVal addrRow As Long, ByVal endDate As Variant) As String
    Dim wa As Worksheet, inh As Variant, s As String, coversInh As Boolean, isCurrent As Boolean
    If Len(personId) = 0 Or addrRow <= 0 Then
        AddressHistoryStatusText = "�v�m�F"
        Exit Function
    End If
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    If Len(CleanText(wa.Cells(addrRow, A_TEXT).Value)) = 0 Then
        AddressHistoryStatusText = "�v�m�F"
        Exit Function
    End If
    If Not HasInputDate(wa.Cells(addrRow, A_START).Value) Then
        AddressHistoryStatusText = "�v�m�F"
        Exit Function
    End If
    inh = GetInheritanceDate()
    If HasInputDate(inh) Then coversInh = AddressRowCoversEffectiveDate(wa.Cells(addrRow, A_START).Value, endDate, inh)
    isCurrent = AddressHistoryIsCurrentRow(personId, addrRow)
    If coversInh And isCurrent Then
        s = "�������E���Z��"
    ElseIf coversInh Then
        s = "�������Z��"
    ElseIf isCurrent Then
        s = "���Z��"
    Else
        s = "����"
    End If
    If EffectiveAddressStartKind(wa, addrRow) = "�c����" Then s = s & "�E�c����"
    AddressHistoryStatusText = s
End Function

Private Function AddressRowCoversEffectiveDate(ByVal startValue As Variant, ByVal endValue As Variant, ByVal targetDate As Variant) As Boolean
    If Not HasInputDate(targetDate) Then Exit Function
    If HasInputDate(startValue) Then
        If CDate(SameDateOrBlank(startValue)) > CDate(SameDateOrBlank(targetDate)) Then Exit Function
    End If
    If HasInputDate(endValue) Then
        If CDate(SameDateOrBlank(endValue)) < CDate(SameDateOrBlank(targetDate)) Then Exit Function
    End If
    AddressRowCoversEffectiveDate = True
End Function

Private Function AddressHistoryIsCurrentRow(ByVal personId As String, ByVal addrRow As Long) As Boolean
    Dim wa As Worksheet, r As Long, baseStart As Variant, otherStart As Variant, deathValue As Variant
    If Len(personId) = 0 Or addrRow <= 0 Then Exit Function
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    If HasInputDate(wa.Cells(addrRow, A_END).Value) Then Exit Function
    deathValue = GetPersonValue(personId, P_DEATH)
    If HasInputDate(deathValue) Then Exit Function
    baseStart = wa.Cells(addrRow, A_START).Value
    If Not HasInputDate(baseStart) Then Exit Function
    For r = 2 To LastRow(wa, A_ID)
        If r <> addrRow Then
            If CleanText(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
                If CleanText(wa.Cells(r, A_PERSON_ID).Value) = personId Then
                    otherStart = wa.Cells(r, A_START).Value
                    If HasInputDate(otherStart) Then
                        If CDate(SameDateOrBlank(otherStart)) > CDate(SameDateOrBlank(baseStart)) Then Exit Function
                    End If
                End If
            End If
        End If
    Next r
    AddressHistoryIsCurrentRow = True
End Function

Private Sub PolishCohabitationOutput(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow Then lastDataRow = firstDataRow
    With ws.Range(ws.Cells(headerRow, 1), ws.Cells(lastDataRow, 11))
        .Font.Name = THEME_FONT
        .Font.Size = 10.4
        .VerticalAlignment = xlTop
        .WrapText = True
    End With
    ThemeApplyZebraTable ws.Range(ws.Cells(headerRow, 1), ws.Cells(lastDataRow, 11)), 1
    ThemeApplyPrintTable ws.Range(ws.Cells(headerRow, 1), ws.Cells(lastDataRow, 11)), 1
    ws.Columns("A:A").ColumnWidth = 9
    ws.Columns("B:B").ColumnWidth = 18
    ws.Columns("C:C").ColumnWidth = 10
    ws.Columns("D:D").ColumnWidth = 18
    ws.Columns("E:E").ColumnWidth = 10
    ws.Columns("F:F").ColumnWidth = 52
    ws.Columns("G:H").ColumnWidth = 12
    ws.Columns("I:I").ColumnWidth = 18
    ws.Columns("J:J").ColumnWidth = 15
    ws.Columns("K:K").ColumnWidth = 34
    ws.Rows("1:1").RowHeight = 30
    ws.Rows("3:5").RowHeight = 25
    ws.Rows("6:6").RowHeight = 12
    ws.Rows("7:7").RowHeight = 25
    ws.Rows(CStr(headerRow) & ":" & CStr(headerRow)).RowHeight = 28
    If lastDataRow >= firstDataRow Then
        FitCohabitationRowHeights ws, firstDataRow, lastDataRow
        HighlightCohabitationJudgement ws, firstDataRow, lastDataRow
        PolishCohabitationNameColumns ws, firstDataRow, lastDataRow
        MarkCohabitationAddressBreaks ws, firstDataRow, lastDataRow
    End If
    ThemeMarkMacroButtonsNonPrintable ws
    ApplyAdaptiveOutputPrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(lastDataRow, 11)).Address, "$8:$8", lastDataRow, 11, True
End Sub

Private Sub FitCohabitationRowHeights(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long, addressLines As Long, evidenceLines As Long, targetHeight As Double
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow Then Exit Sub
    For r = firstDataRow To lastDataRow
        addressLines = Application.Max(1, WorksheetFunction.RoundUp(Application.Max(1, Len(CleanText(ws.Cells(r, 6).Value))) / 28, 0))
        evidenceLines = Application.Max(1, WorksheetFunction.RoundUp(Application.Max(1, Len(CleanText(ws.Cells(r, 11).Value))) / 18, 0))
        targetHeight = 42 + Application.Max(addressLines, evidenceLines) * 16
        If targetHeight < 58 Then targetHeight = 58
        If targetHeight > 164 Then targetHeight = 164
        ws.Rows(r).RowHeight = targetHeight
    Next r
End Sub

Private Sub SortCohabitationOutput(ByVal ws As Worksheet, ByVal lastDataRow As Long, Optional ByVal headerRow As Long = 8)
    If ws Is Nothing Then Exit Sub
    If lastDataRow <= headerRow + 1 Then Exit Sub
    On Error Resume Next
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range("F" & CStr(headerRow + 1) & ":F" & lastDataRow), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("G" & CStr(headerRow + 1) & ":G" & lastDataRow), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("B" & CStr(headerRow + 1) & ":B" & lastDataRow), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("D" & CStr(headerRow + 1) & ":D" & lastDataRow), Order:=xlAscending
        .SetRange ws.Range("A" & CStr(headerRow) & ":K" & lastDataRow)
        .Header = xlYes
        .Apply
    End With
    On Error GoTo 0
End Sub

Private Sub MarkCohabitationAddressBreaks(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow + 1 Then Exit Sub
    On Error Resume Next
    For r = firstDataRow + 1 To lastDataRow
        If CleanText(ws.Cells(r, 6).Value) <> CleanText(ws.Cells(r - 1, 6).Value) Then
            With ws.Range(ws.Cells(r, 1), ws.Cells(r, 11)).Borders(xlEdgeTop)
                .LineStyle = xlContinuous
                .Color = ThemeColor("border-strong")
                .Weight = xlMedium
            End With
            ws.Rows(r).RowHeight = ws.Rows(r).RowHeight + 8
        End If
    Next r
    On Error GoTo 0
End Sub

Private Sub PolishCohabitationNameColumns(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow Then Exit Sub
    On Error Resume Next
    For r = firstDataRow To lastDataRow
        With ws.Range(ws.Cells(r, 2), ws.Cells(r, 5))
            .Interior.Color = ThemeColor("surface-soft")
            .Font.Color = ThemeColor("title")
        End With
        ws.Cells(r, 2).Font.Bold = True
        ws.Cells(r, 4).Font.Bold = True
        ws.Cells(r, 3).Font.Color = ThemeColor("muted-strong")
        ws.Cells(r, 5).Font.Color = ThemeColor("muted-strong")
        ws.Cells(r, 6).Font.Size = 10.2
        ws.Cells(r, 6).HorizontalAlignment = xlLeft
        ws.Cells(r, 6).VerticalAlignment = xlTop
        ws.Cells(r, 9).Font.Color = ThemeColor("muted-strong")
        ws.Cells(r, 10).HorizontalAlignment = xlCenter
        ws.Cells(r, 10).VerticalAlignment = xlCenter
        ws.Cells(r, 11).Font.Size = 9.8
        ws.Cells(r, 11).Font.Color = ThemeColor("muted-strong")
    Next r
    On Error GoTo 0
End Sub

Private Sub BuildCohabitationSummaryBand(ByVal ws As Worksheet, ByVal lastDataRow As Long, ByVal firstDataRow As Long)
    Dim totalCount As Long, needReviewCount As Long, addressCount As Long, strongCount As Long
    totalCount = CountNonBlankTextInRange(ws.Range(ws.Cells(firstDataRow, 1), ws.Cells(Application.Max(firstDataRow, lastDataRow), 1)))
    needReviewCount = CountTextContainsInRange(ws.Range(ws.Cells(firstDataRow, 10), ws.Cells(Application.Max(firstDataRow, lastDataRow), 10)), "�m�F")
    addressCount = CountDistinctTextInRange(ws.Range(ws.Cells(firstDataRow, 6), ws.Cells(Application.Max(firstDataRow, lastDataRow), 6)))
    strongCount = CountTextContainsInRange(ws.Range(ws.Cells(firstDataRow, 10), ws.Cells(Application.Max(firstDataRow, lastDataRow), 10)), "��������")
    WriteMetricCard ws.Range("A3:C5"), "��������", CStr(totalCount) & "��"
    WriteMetricCard ws.Range("D3:F5"), "����Z��", CStr(addressCount) & "��"
    WriteMetricCard ws.Range("G3:H5"), "����", CStr(strongCount) & "��"
    WriteMetricCard ws.Range("I3:K5"), "�v�m�F", CStr(needReviewCount) & "��"
End Sub

Private Sub HighlightCohabitationJudgement(ByVal ws As Worksheet, ByVal firstDataRow As Long, ByVal lastDataRow As Long)
    Dim r As Long, judgeText As String
    If ws Is Nothing Then Exit Sub
    If lastDataRow < firstDataRow Then Exit Sub
    For r = firstDataRow To lastDataRow
        judgeText = CleanText(ws.Cells(r, 10).Value)
        If InStr(judgeText, "�m�F") > 0 Then
            ws.Cells(r, 10).Interior.Color = ThemeColor("warning-soft")
            ws.Cells(r, 10).Font.Color = ThemeColor("warning-text")
            ws.Cells(r, 10).Font.Bold = True
            ws.Cells(r, 11).Interior.Color = ThemeColor("warning-soft")
        ElseIf Len(judgeText) > 0 Then
            ws.Cells(r, 10).Interior.Color = ThemeColor("success-soft")
            ws.Cells(r, 10).Font.Color = ThemeColor("success-text")
            ws.Cells(r, 10).Font.Bold = True
        End If
    Next r
End Sub







Private Sub SortAddressHistoryOutput(ByVal ws As Worksheet, ByVal lastDataRow As Long, Optional ByVal headerRow As Long = 3)
    If ws Is Nothing Then Exit Sub
    If lastDataRow <= headerRow + 1 Then Exit Sub
    On Error Resume Next
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range("A" & CStr(headerRow + 1) & ":A" & lastDataRow), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("D" & CStr(headerRow + 1) & ":D" & lastDataRow), Order:=xlAscending
        .SetRange ws.Range("A" & CStr(headerRow) & ":J" & lastDataRow)
        .Header = xlYes
        .Apply
    End With
    On Error GoTo 0
End Sub


Private Function EffectiveAddressStartKind(ByVal wsA As Worksheet, ByVal rowNo As Long) As String
    Dim kindText As String
    kindText = CleanText(wsA.Cells(rowNo, A_START_KIND).Value)
    If kindText = "���Z�J�n" Or kindText = "�c����" Then
        EffectiveAddressStartKind = kindText
    Else
        EffectiveAddressStartKind = "���Z�J�n"
    End If
End Function

Private Function EffectiveEndDate(ByVal addrRow As Long) As Variant
    Dim wa As Worksheet, pid As String, r As Long, bestNext As Variant, baseDate As Variant, death As Variant, candidateEnd As Variant
    Dim baseStart As Variant, otherStart As Variant
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    If HasInputDate(wa.Cells(addrRow, A_END).Value) Then
        EffectiveEndDate = wa.Cells(addrRow, A_END).Value
        Exit Function
    End If
    pid = CleanText(wa.Cells(addrRow, A_PERSON_ID).Value)
    baseStart = wa.Cells(addrRow, A_START).Value
    If HasInputDate(baseStart) Then
        For r = 2 To LastRow(wa, 1)
            If r <> addrRow Then
                If CleanText(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL _
                        And CleanText(wa.Cells(r, A_PERSON_ID).Value) = pid Then
                    otherStart = wa.Cells(r, A_START).Value
                    If HasInputDate(otherStart) Then
                        If CDate(SameDateOrBlank(otherStart)) > CDate(SameDateOrBlank(baseStart)) Then
                            If Not HasInputDate(bestNext) Then
                                bestNext = otherStart
                            ElseIf CDate(SameDateOrBlank(otherStart)) < CDate(SameDateOrBlank(bestNext)) Then
                                bestNext = otherStart
                            End If
                        End If
                    End If
                End If
            End If
        Next r
    End If
    If HasInputDate(bestNext) Then
        candidateEnd = DateAdd("d", -1, CDate(SameDateOrBlank(bestNext)))
        death = GetPersonValue(pid, P_DEATH)
        If HasInputDate(death) Then
            If CDate(SameDateOrBlank(death)) < CDate(SameDateOrBlank(candidateEnd)) Then candidateEnd = SameDateOrBlank(death)
        End If
        If HasInputDate(baseStart) Then
            If CDate(SameDateOrBlank(candidateEnd)) < CDate(SameDateOrBlank(baseStart)) Then
                EffectiveEndDate = ""
                Exit Function
            End If
        End If
        EffectiveEndDate = candidateEnd
        Exit Function
    End If
    death = GetPersonValue(pid, P_DEATH)
    If HasInputDate(death) Then
        If HasInputDate(baseStart) Then
            If CDate(SameDateOrBlank(death)) < CDate(SameDateOrBlank(baseStart)) Then
                EffectiveEndDate = ""
                Exit Function
            End If
        End If
        EffectiveEndDate = SameDateOrBlank(death)
        Exit Function
    End If
    baseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value
    If HasInputDate(baseDate) Then
        EffectiveEndDate = SameDateOrBlank(baseDate)
    Else
        EffectiveEndDate = ""
    End If
End Function

Private Sub BuildCohabitationTable()
    Dim ws As Worksheet, wa As Worksheet, r1 As Long, r2 As Long, outR As Long, coNo As Long
    Dim s1 As Variant, e1 As Variant, s2 As Variant, e2 As Variant, st As Variant, en As Variant
    Dim headerRow As Long, firstDataRow As Long, lastDataRow As Long
    Dim matchKind As String, judgeText As String, evidenceText As String
    Dim p1 As String, p2 As String, dupKey As String, written As Object, endCache As Object
    Dim overlapDays As Long, periodComparable As Boolean, reliablePeriod As Boolean
    Set ws = ThisWorkbook.Worksheets(SH_COHAB)
    ClearSheetAll ws
    ApplySheetCanvas ws
    headerRow = 8
    firstDataRow = headerRow + 1
    ws.Range("A1:K1").Merge
    TitleBannerStyle ws.Range("A1:K1"), "��������\"
    AddButton ws, "L1", "���֖͂߂�", "ShowOnlyInput", 90, 24
    ws.Range("A7:K7").Merge
    SectionStyle ws.Range("A7:K7"), "�������薾��"
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    Set written = CreateObject("Scripting.Dictionary")
    Set endCache = CreateObject("Scripting.Dictionary")
    For r1 = 2 To LastRow(wa, 1)
        If CleanText(wa.Cells(r1, A_STATUS).Value) <> STATUS_CANCEL Then endCache(CStr(r1)) = EffectiveEndDate(r1)
    Next r1
    outR = firstDataRow
    coNo = 1

    For r1 = 2 To LastRow(wa, 1)
        If CleanText(wa.Cells(r1, A_STATUS).Value) <> STATUS_CANCEL Then
            For r2 = r1 + 1 To LastRow(wa, 1)
                If CleanText(wa.Cells(r2, A_STATUS).Value) <> STATUS_CANCEL Then
                    p1 = CleanText(wa.Cells(r1, A_PERSON_ID).Value)
                    p2 = CleanText(wa.Cells(r2, A_PERSON_ID).Value)
                    If Len(p1) > 0 Then
                        If Len(p2) > 0 Then
                            If p1 <> p2 And FindPersonRow(p1) > 0 And FindPersonRow(p2) > 0 Then
                                matchKind = CohabRowsAddressMatchKind(wa, r1, r2)
                                If Len(matchKind) > 0 Then
                                    s1 = wa.Cells(r1, A_START).Value
                                    e1 = endCache(CStr(r1))
                                    s2 = wa.Cells(r2, A_START).Value
                                    e2 = endCache(CStr(r2))
                                    periodComparable = CohabRowsHaveComparablePeriod(s1, e1, s2, e2)
                                    If periodComparable Then
                                        If CDate(SameDateOrBlank(s1)) > CDate(SameDateOrBlank(s2)) Then st = SameDateOrBlank(s1) Else st = SameDateOrBlank(s2)
                                        If CDate(SameDateOrBlank(e1)) < CDate(SameDateOrBlank(e2)) Then en = SameDateOrBlank(e1) Else en = SameDateOrBlank(e2)
                                        overlapDays = CohabitationOverlapDays(st, en)
                                        If overlapDays > 0 Then
                                            reliablePeriod = CohabAddressPeriodIsReliable(wa, r1) And CohabAddressPeriodIsReliable(wa, r2)
                                            If reliablePeriod Then
                                                judgeText = "��������"
                                            Else
                                                judgeText = "��������i���Ԋm�F�j"
                                            End If
                                            evidenceText = matchKind & "�E�d������ " & FormatDateOnly(st) & "�`" & FormatDateOnly(en) & "�i" & CStr(overlapDays) & "���j"
                                            If Not reliablePeriod Then evidenceText = evidenceText & "�E�c����/�⊮�I�������܂ނ��ߊ��Ԋm�F"
                                            dupKey = CohabPairKey(p1, p2, CohabRowsAddressPairKey(wa, r1, r2), st, en)
                                            If Not written.Exists(dupKey) Then
                                                WriteCohab ws, outR, "CO" & Format(coNo, "000000"), p1, p2, wa.Cells(r1, A_TEXT).Value, st, en, judgeText, evidenceText
                                                written.Add dupKey, True
                                                coNo = coNo + 1
                                                outR = outR + 1
                                            End If
                                        End If
                                    Else
                                        judgeText = "���ԗv�m�F"
                                        evidenceText = matchKind & "�E�J�n���܂��͏I�������s��"
                                        dupKey = CohabPairKey(p1, p2, CohabRowsAddressPairKey(wa, r1, r2), "", "")
                                        If Not written.Exists(dupKey) Then
                                            WriteCohab ws, outR, "CO" & Format(coNo, "000000"), p1, p2, wa.Cells(r1, A_TEXT).Value, "", "", judgeText, evidenceText
                                            written.Add dupKey, True
                                            coNo = coNo + 1
                                            outR = outR + 1
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            Next r2
        End If
    Next r1
    lastDataRow = Application.Max(firstDataRow, outR - 1)
    SetRowValues ws.Cells(headerRow, 1), Array("����ID", "����Ώېl��", "����", "��������l��", "����", "����Z��", "�d���J�n��", "�d���I����", "�d������", "����", "�m�F�|�C���g")
    If outR > firstDataRow Then SortCohabitationOutput ws, lastDataRow, headerRow
    BuildCohabitationSummaryBand ws, lastDataRow, firstDataRow
    SetRowValues ws.Cells(headerRow, 1), Array("����ID", "����Ώېl��", "����", "��������l��", "����", "����Z��", "�d���J�n��", "�d���I����", "�d������", "����", "�m�F�|�C���g")
    HeaderStyle ws.Range(ws.Cells(headerRow, 1), ws.Cells(headerRow, 11))
    ws.Range(ws.Cells(firstDataRow, 7), ws.Cells(Application.Max(firstDataRow, lastDataRow), 8)).NumberFormatLocal = "yyyy/m/d"
    PolishCohabitationOutput ws, headerRow, firstDataRow, lastDataRow
End Sub

Private Function CohabRowsHaveComparablePeriod(ByVal s1 As Variant, ByVal e1 As Variant, ByVal s2 As Variant, ByVal e2 As Variant) As Boolean
    If Not HasInputDate(s1) Then Exit Function
    If Not HasInputDate(e1) Then Exit Function
    If Not HasInputDate(s2) Then Exit Function
    If Not HasInputDate(e2) Then Exit Function
    CohabRowsHaveComparablePeriod = True
End Function

Private Sub WriteMetricCard(ByVal rng As Range, ByVal labelText As String, ByVal valueText As String)
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    rng.Merge
    With rng
        .Interior.Color = ThemeColor("surface-raised")
        .Font.Name = THEME_FONT
        .Font.Color = ThemeColor("text")
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = True
        .Value = labelText & vbLf & valueText
        .Characters(1, Len(labelText)).Font.Size = 9
        .Characters(1, Len(labelText)).Font.Color = ThemeColor("muted-strong")
        .Characters(Len(labelText) + 2, Len(valueText)).Font.Size = 16
        .Characters(Len(labelText) + 2, Len(valueText)).Font.Bold = True
        .Characters(Len(labelText) + 2, Len(valueText)).Font.Color = ThemeColor("title")
    End With
    ThemeApplyCompleteBorders rng, "border"
    With rng.Borders(xlEdgeTop)
        .LineStyle = xlContinuous
        .Color = ThemeColor("accent")
        .Weight = xlMedium
    End With
    On Error GoTo 0
End Sub

Private Function CountDistinctTextInRange(ByVal rng As Range) As Long
    Dim d As Object, c As Range, key As String
    Set d = CreateObject("Scripting.Dictionary")
    If rng Is Nothing Then Exit Function
    For Each c In rng.Cells
        key = CleanText(c.Value)
        If Len(key) > 0 Then
            If Not d.Exists(key) Then d.Add key, True
        End If
    Next c
    CountDistinctTextInRange = d.Count
End Function

Private Function CountNonBlankTextInRange(ByVal rng As Range) As Long
    Dim c As Range
    If rng Is Nothing Then Exit Function
    For Each c In rng.Cells
        If Len(CleanText(c.Value)) > 0 Then CountNonBlankTextInRange = CountNonBlankTextInRange + 1
    Next c
End Function

Private Function CountTextContainsInRange(ByVal rng As Range, ByVal needleText As String) As Long
    Dim c As Range
    If rng Is Nothing Then Exit Function
    For Each c In rng.Cells
        If InStr(CleanText(c.Value), needleText) > 0 Then CountTextContainsInRange = CountTextContainsInRange + 1
    Next c
End Function

Private Function CountVisiblePersonsWithoutCurrentAddress() As Long
    Dim wp As Worksheet, r As Long, pid As String
    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Function
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, P_ID)
        If VisibleDiagramPersonRow(r) Then
            pid = CleanText(wp.Cells(r, P_ID).Value)
            If Len(pid) > 0 Then
                If Len(CleanText(GetCurrentAddressText(pid))) = 0 Then CountVisiblePersonsWithoutCurrentAddress = CountVisiblePersonsWithoutCurrentAddress + 1
            End If
        End If
    Next r
End Function

Private Sub WriteCohab(ByVal ws As Worksheet, _
        ByVal outR As Long, _
        ByVal cohabId As String, _
        ByVal p1 As String, _
        ByVal p2 As String, _
        ByVal addr As String, _
        ByVal st As Variant, _
        ByVal en As Variant, _
        ByVal judge As String, _
        ByVal evidenceText As String)
    ws.Cells(outR, 1).Value = cohabId
    ws.Cells(outR, 2).Value = PersonNameWithFormerSurnameBreak(p1)
    ws.Cells(outR, 3).Value = DiagramRelationDisplayTextForPersonId(p1)
    ws.Cells(outR, 4).Value = PersonNameWithFormerSurnameBreak(p2)
    ws.Cells(outR, 5).Value = DiagramRelationDisplayTextForPersonId(p2)
    ws.Cells(outR, 6).Value = addr
    ws.Cells(outR, 7).Value = st
    ws.Cells(outR, 8).Value = en
    ws.Cells(outR, 9).Value = CohabOverlapPeriodText(st, en)
    ws.Cells(outR, 10).Value = judge
    ws.Cells(outR, 11).Value = evidenceText
End Sub

Private Function PersonNameWithFormerSurnameBreak(ByVal personId As String) As String
    Dim surnameText As String, givenText As String, formerText As String, displayText As String
    personId = CleanText(personId)
    If Len(personId) = 0 Then Exit Function
    surnameText = CleanText(GetPersonValue(personId, P_SURNAME))
    givenText = CleanText(GetPersonValue(personId, P_GIVEN))
    formerText = CleanText(GetPersonValue(personId, P_FORMER))
    displayText = CleanText(surnameText & " " & givenText)
    If Len(displayText) = 0 Then displayText = CleanText(GetPersonValue(personId, P_DISPLAY))
    If Len(formerText) > 0 Then
        PersonNameWithFormerSurnameBreak = displayText & vbLf & "����: " & formerText
    Else
        PersonNameWithFormerSurnameBreak = displayText
    End If
End Function

Private Function CohabOverlapPeriodText(ByVal st As Variant, ByVal en As Variant) As String
    If Not HasInputDate(st) Or Not HasInputDate(en) Then
        CohabOverlapPeriodText = "���ԗv�m�F"
        Exit Function
    End If
    If CDate(SameDateOrBlank(en)) < CDate(SameDateOrBlank(st)) Then
        CohabOverlapPeriodText = "���ԗv�m�F"
        Exit Function
    End If
    CohabOverlapPeriodText = FormatDateOnly(st) & "�`" & FormatDateOnly(en) & vbLf & PeriodText(st, en)
End Function

Private Function FormatDateOnly(ByVal v As Variant) As String
    If HasInputDate(v) Then FormatDateOnly = Format$(SameDateOrBlank(v), "yyyy/m/d")
End Function

Private Function CohabAddressPeriodIsReliable(ByVal wa As Worksheet, ByVal rowNo As Long) As Boolean
    Dim kindText As String
    If wa Is Nothing Then Exit Function
    If rowNo <= 0 Then Exit Function
    If Not HasInputDate(wa.Cells(rowNo, A_START).Value) Then Exit Function
    kindText = EffectiveAddressStartKind(wa, rowNo)
    If kindText <> "���Z�J�n" Then Exit Function
    If HasInputDate(wa.Cells(rowNo, A_END).Value) Then
        CohabAddressPeriodIsReliable = True
    ElseIf HasInputDate(GetPersonValue(CleanText(wa.Cells(rowNo, A_PERSON_ID).Value), P_DEATH)) Then
        CohabAddressPeriodIsReliable = True
    End If
End Function

Private Function CohabAddressCompareKey(ByVal wa As Worksheet, ByVal rowNo As Long) As String
    Dim keyText As String, addrText As String
    If wa Is Nothing Then Exit Function
    If rowNo <= 0 Then Exit Function
    If CleanText(wa.Cells(rowNo, A_STATUS).Value) = STATUS_CANCEL Then Exit Function
    addrText = NormalizeAddressForCohabCompare(CleanText(wa.Cells(rowNo, A_TEXT).Value))
    If Len(addrText) = 0 Then Exit Function
    keyText = CleanText(wa.Cells(rowNo, A_KEY).Value)
    If Len(keyText) > 0 Then
        CohabAddressCompareKey = "K|" & keyText
        Exit Function
    End If
    If Len(addrText) >= 8 Then CohabAddressCompareKey = "T|" & addrText
End Function

Private Function CohabRowsAddressMatchKind(ByVal wa As Worksheet, ByVal row1 As Long, ByVal row2 As Long) As String
    Dim key1 As String, key2 As String, addr1 As String, addr2 As String
    If wa Is Nothing Then Exit Function
    If row1 <= 0 Then Exit Function
    If row2 <= 0 Then Exit Function
    key1 = CleanText(wa.Cells(row1, A_KEY).Value)
    key2 = CleanText(wa.Cells(row2, A_KEY).Value)
    addr1 = NormalizeAddressForCohabCompare(CleanText(wa.Cells(row1, A_TEXT).Value))
    addr2 = NormalizeAddressForCohabCompare(CleanText(wa.Cells(row2, A_TEXT).Value))
    If Len(addr1) = 0 Or Len(addr2) = 0 Then Exit Function

    If Len(key1) > 0 And key1 = key2 Then
        '�L�[�������ł��Z�������񂪖��炩�ɈႤ���͓̂����������Ȃ��B
        If addr1 = addr2 Then
            CohabRowsAddressMatchKind = "�Z���L�[��v"
        End If
        Exit Function
    End If
    If Len(addr1) >= 8 And addr1 = addr2 Then CohabRowsAddressMatchKind = "�Z���������v"
End Function

Private Function CohabRowsAddressPairKey(ByVal wa As Worksheet, ByVal row1 As Long, ByVal row2 As Long) As String
    Dim keyText As String, addrText As String
    keyText = CleanText(wa.Cells(row1, A_KEY).Value)
    If Len(keyText) > 0 Then
        If keyText = CleanText(wa.Cells(row2, A_KEY).Value) Then
            CohabRowsAddressPairKey = "K|" & keyText
            Exit Function
        End If
    End If
    addrText = NormalizeAddressForCohabCompare(CleanText(wa.Cells(row1, A_TEXT).Value))
    CohabRowsAddressPairKey = "T|" & addrText
End Function

Private Function CohabAddressMatchKind(ByVal compareKey As String) As String
    If Left$(compareKey, 2) = "K|" Then
        CohabAddressMatchKind = "�Z���L�[��v"
    Else
        CohabAddressMatchKind = "�Z���������v"
    End If
End Function

Private Function NormalizeAddressForCohabCompare(ByVal addrText As String) As String
    addrText = CleanText(addrText)
    On Error Resume Next
    addrText = StrConv(addrText, vbNarrow)
    Err.Clear
    On Error GoTo 0
    addrText = Replace(addrText, " ", "")
    addrText = Replace(addrText, "�@", "")
    addrText = Replace(addrText, "����", "-")
    addrText = Replace(addrText, "�Ԓn", "-")
    addrText = Replace(addrText, "��", "-")
    addrText = Replace(addrText, "��", "")
    addrText = Replace(addrText, "�|", "-")
    addrText = Replace(addrText, "�[", "-")
    Do While InStr(addrText, "--") > 0
        addrText = Replace(addrText, "--", "-")
    Loop
    NormalizeAddressForCohabCompare = addrText
End Function

Private Function CohabPairKey(ByVal p1 As String, ByVal p2 As String, ByVal addrKey As String, ByVal st As Variant, ByVal en As Variant) As String
    Dim leftId As String, rightId As String
    p1 = CleanText(p1)
    p2 = CleanText(p2)
    If StrComp(p1, p2, vbTextCompare) <= 0 Then
        leftId = p1
        rightId = p2
    Else
        leftId = p2
        rightId = p1
    End If
    CohabPairKey = leftId & "|" & rightId & "|" & addrKey & "|" & CohabDateKey(st) & "|" & CohabDateKey(en)
End Function

Private Function CohabDateKey(ByVal v As Variant) As String
    If HasInputDate(v) Then CohabDateKey = Format$(SameDateOrBlank(v), "yyyymmdd")
End Function

Private Function CohabitationOverlapDays(ByVal st As Variant, ByVal en As Variant) As Long
    If Not HasInputDate(st) Then Exit Function
    If Not HasInputDate(en) Then Exit Function
    If CDate(SameDateOrBlank(en)) >= CDate(SameDateOrBlank(st)) Then CohabitationOverlapDays = DateDiff("d", CDate(SameDateOrBlank(st)), CDate(SameDateOrBlank(en))) + 1
End Function

Private Sub BuildTimelineTable()
    Dim ws As Worksheet, wp As Worksheet, we As Worksheet
    Dim minY As Long, maxY As Long, r As Long, c As Long, y As Long
    Dim rowOut As Long, lastCol As Long, lastDataRow As Long, baseDate As Variant
    Set ws = ThisWorkbook.Worksheets(SH_TIMELINE)
    ClearSheetAll ws
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    Set we = ThisWorkbook.Worksheets(SH_W_EVENT)

    baseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value
    If HasInputDate(baseDate) Then
        maxY = Year(CDate(SameDateOrBlank(baseDate)))
    Else
        maxY = Year(Date)
    End If
    minY = maxY
    For r = 2 To LastRow(we, 1)
        If IsNumeric(we.Cells(r, E_YEAR).Value) And CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL Then
            If CLng(we.Cells(r, E_YEAR).Value) < minY Then minY = CLng(we.Cells(r, E_YEAR).Value)
            If CLng(we.Cells(r, E_YEAR).Value) > maxY Then maxY = CLng(we.Cells(r, E_YEAR).Value)
        End If
    Next r
    If minY > maxY Then minY = maxY

    ApplySheetCanvas ws

    c = 3
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then c = c + 2
    Next r
    lastCol = Application.Max(5, c - 1)

    ws.Range(ws.Cells(1, 1), ws.Cells(1, lastCol)).Merge
    TitleBannerStyle ws.Range(ws.Cells(1, 1), ws.Cells(1, lastCol)), "���n��\"
    AddButton ws, ws.Cells(1, lastCol).Address(False, False), "���֖͂߂�", "ShowOnlyInput", 90, 24

    ws.Cells(3, 1).Value = "����"
    ws.Range("A3:A5").Merge
    HeaderStyle ws.Range("A3:A5"), ThemeColor("blue")
    ws.Cells(3, 2).Value = "�a��"
    ws.Range("B3:B5").Merge
    HeaderStyle ws.Range("B3:B5"), ThemeColor("blue")

    c = 3
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            ws.Range(ws.Cells(3, c), ws.Cells(3, c + 1)).Merge
            ws.Cells(3, c).Value = wp.Cells(r, P_DISPLAY).Value
            ws.Range(ws.Cells(4, c), ws.Cells(4, c + 1)).Merge
            ws.Cells(4, c).Value = DiagramRelationDisplayTextForPersonId(CleanText(wp.Cells(r, P_ID).Value))
            ws.Cells(5, c).Value = "�N��"
            ws.Cells(5, c + 1).Value = "�o����"
            HeaderStyle ws.Range(ws.Cells(3, c), ws.Cells(5, c + 1)), ThemeColor("muted-strong")
            c = c + 2
        End If
    Next r

    rowOut = 6
    For y = minY To maxY
        ws.Cells(rowOut, 1).Value = y
        ws.Cells(rowOut, 2).Value = EraYearText(y)
        c = 3
        For r = 2 To LastRow(wp, 1)
            If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
                ws.Cells(rowOut, c).Value = AgeForYear(wp.Cells(r, P_BIRTH).Value, wp.Cells(r, P_DEATH).Value, y)
                ws.Cells(rowOut, c + 1).Value = EventsForPersonYear(wp.Cells(r, P_ID).Value, y)
                ws.Cells(rowOut, c).HorizontalAlignment = xlCenter
                ws.Cells(rowOut, c + 1).WrapText = True
                ws.Cells(rowOut, c + 1).VerticalAlignment = xlTop
                c = c + 2
            End If
        Next r
        If rowOut Mod 2 = 0 Then ws.Range(ws.Cells(rowOut, 1), ws.Cells(rowOut, lastCol)).Interior.Color = ThemeColor("canvas")
        rowOut = rowOut + 1
    Next y
    lastDataRow = Application.Max(6, rowOut - 1)
    With ws.Range(ws.Cells(3, 1), ws.Cells(lastDataRow, lastCol))
        .VerticalAlignment = xlTop
    End With
    ThemeApplyCompleteBorders ws.Range(ws.Cells(3, 1), ws.Cells(lastDataRow, lastCol)), "border"
    ws.Columns("A:A").ColumnWidth = 8
    ws.Columns("B:B").ColumnWidth = 16
    For c = 3 To lastCol
        If (c - 3) Mod 2 = 0 Then ws.Columns(c).ColumnWidth = 9 Else ws.Columns(c).ColumnWidth = 34
    Next c
    ws.Rows("1:5").RowHeight = 23
    ws.Rows("6:" & lastDataRow).RowHeight = 42
    PolishTimelineOutput ws, lastDataRow, lastCol
End Sub

Private Sub PolishTimelineOutput(ByVal ws As Worksheet, ByVal lastDataRow As Long, ByVal lastCol As Long)
    If ws Is Nothing Then Exit Sub
    ThemeMarkMacroButtonsNonPrintable ws
    ThemeApplyPrintTable ws.Range(ws.Cells(3, 1), ws.Cells(lastDataRow, lastCol)), 3
    ThemeCapRowHeights ws.Range(ws.Cells(6, 1), ws.Cells(lastDataRow, lastCol)), 32, 84
    ApplyAdaptiveOutputPrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(lastDataRow, lastCol)).Address, "$1:$5", lastDataRow, lastCol, True
    On Error Resume Next
    ws.PageSetup.PrintTitleColumns = "$A:$B"
    On Error GoTo 0
End Sub

Private Function AgeForYear(ByVal birthDate As Variant, ByVal deathDate As Variant, ByVal y As Long) As String
    If Not HasInputDate(birthDate) Then AgeForYear = "": Exit Function
    If Year(CDate(SameDateOrBlank(birthDate))) > y Then AgeForYear = "�o���O": Exit Function
    If HasInputDate(deathDate) Then
        If Year(CDate(SameDateOrBlank(deathDate))) < y Then AgeForYear = "���S��": Exit Function
    End If
    Dim baseDate As Date
    baseDate = DateSerial(y, 12, 31)
    If HasInputDate(deathDate) Then
        If Year(CDate(SameDateOrBlank(deathDate))) = y Then baseDate = CDate(SameDateOrBlank(deathDate))
    End If
    AgeForYear = AgeOnDate(birthDate, baseDate)
End Function

Private Function EventsForPersonYear(ByVal personId As String, ByVal y As Long) As String
    Dim we As Worksheet, r As Long, s As String, lineText As String
    Dim seen As Object
    Set seen = CreateObject("Scripting.Dictionary")
    Set we = ThisWorkbook.Worksheets(SH_W_EVENT)
    For r = 2 To LastRow(we, 1)
        If CStr(we.Cells(r, E_PERSON_ID).Value) = personId And CLng(Val(we.Cells(r, E_YEAR).Value)) = y And CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL Then
            lineText = ""
            If HasInputDate(we.Cells(r, E_DATE).Value) Then lineText = Format(SameDateOrBlank(we.Cells(r, E_DATE).Value), "m/d") & " "
            lineText = lineText & CStr(we.Cells(r, E_CONTENT).Value)
            If Not seen.Exists(lineText) Then
                seen.Add lineText, True
                If Len(s) > 0 Then s = s & vbLf
                s = s & lineText
            End If
        End If
    Next r
    EventsForPersonYear = s
End Function

Private Sub BuildPersonList()
    Dim ws As Worksheet, src As Worksheet, r As Long, pid As String
    Dim lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_PERSON_LIST)
    Set src = ThisWorkbook.Worksheets(SH_W_PERSON)
    ClearSheetAll ws
    ws.Range("A1:V1").Merge
    SectionStyle ws.Range("A1:V1"), "�l���ꗗ"
    AddButton ws, "W1", "���֖͂߂�", "ShowOnlyInput", 90, 24
    lastR = LastRow(src, 1)
    If lastR < 1 Then lastR = 1
    ws.Range("A3").Resize(lastR, 22).Value = src.Range("A1:V" & CStr(lastR)).Value
    '�ꗗ�͕ۑ������󂳂��A�֌W�}�E�`�F�b�N�Ɠ����m�胂�f���̑�����\������B
    For r = 4 To lastR + 2
        pid = CleanText(ws.Cells(r, P_ID).Value)
        If Len(pid) > 0 Then ws.Cells(r, P_REL_DEC).Value = DiagramRelationDisplayTextForPersonId(pid)
    Next r
    HeaderStyle ws.Range("A3:V3")
    ws.Columns.AutoFit
    CapColumnWidths ws, 1, 22, 34
    PolishSimplePersonOutput ws, lastR + 2, 22, "$3:$3"
End Sub


Private Sub PolishSimplePersonOutput(ByVal ws As Worksheet, ByVal lastR As Long, ByVal lastC As Long, ByVal repeatRows As String)
    If ws Is Nothing Then Exit Sub
    ThemeMarkMacroButtonsNonPrintable ws
    If lastR < 1 Or lastC < 1 Then Exit Sub
    On Error Resume Next
    ThemeApplyPrintTable ws.Range(ws.Cells(3, 1), ws.Cells(lastR, lastC)), 1
    ThemeCapRowHeights ws.Range(ws.Cells(4, 1), ws.Cells(lastR, lastC)), 18, 72
    ApplyAdaptiveOutputPrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC)).Address, repeatRows, lastR, lastC, False
    On Error GoTo 0
End Sub

Private Sub ApplyAdaptiveOutputPrint(ByVal ws As Worksheet, _
        ByVal printAreaAddress As String, _
        ByVal repeatRows As String, _
        ByVal lastR As Long, _
        ByVal lastC As Long, _
        Optional ByVal preferWideBecauseMatrix As Boolean = False)
    Dim useLandscape As Boolean, fitWide As Long
    If ws Is Nothing Then Exit Sub
    useLandscape = ShouldUseLandscapeForOutput(lastR, lastC, preferWideBecauseMatrix)
    fitWide = FitWideForOutput(lastC, useLandscape)
    ThemeApplyMonochromePrint ws, printAreaAddress, useLandscape, repeatRows, fitWide, 0
End Sub

Private Function ShouldUseLandscapeForOutput(ByVal lastR As Long, ByVal lastC As Long, ByVal preferWideBecauseMatrix As Boolean) As Boolean
    If preferWideBecauseMatrix Then
        ShouldUseLandscapeForOutput = (lastC >= 7)
    ElseIf lastC >= 10 Then
        ShouldUseLandscapeForOutput = True
    ElseIf lastC <= 8 And lastR >= 36 Then
        ShouldUseLandscapeForOutput = False
    Else
        ShouldUseLandscapeForOutput = (lastC >= 8)
    End If
End Function

Private Function FitWideForOutput(ByVal lastC As Long, ByVal landscape As Boolean) As Long
    Dim baseCols As Long
    If landscape Then
        baseCols = 12
    Else
        baseCols = 8
    End If
    FitWideForOutput = CLng(Int((lastC + baseCols - 1) / baseCols))
    If FitWideForOutput < 1 Then FitWideForOutput = 1
    If FitWideForOutput > 4 Then FitWideForOutput = 4
End Function

Public Sub SaveCommonData()

    On Error GoTo EH

    Dim folderPath As String, outPath As String, wb As Workbook, shNames As Variant, tNames As Variant, i As Long
    Dim stepText As String, failedCount As Long

    folderPath = EnsureWorkbookLocalBaseFolder("���ʃf�[�^�ۑ�")

    If Len(folderPath) = 0 Then

        QuietWarn "���ʃf�[�^�̕ۑ��惍�[�J���t�H���_��I�����Ă��������BSharePoint/OneDrive��URL�ŊJ���Ă���ꍇ�Ahttps�̏ꏊ�֒��ڕۑ��ł��܂���B", True, "�o�͑O�m�F"

        GoTo CleanExit

    End If

    AppBegin

    '�o�͎��� W_�l�� �̑����𒼐ڏ��������Ȃ��B�����֌W�}�E���n��E���ʕۑ��͕\���p���f���ŉ��߂���B

    mOutputFailureSummary = vbNullString

    failedCount = failedCount + OutputStepFailureCount("���ʕۑ�:��\�Z���X�V", "RefreshRepresentativeAddresses")

    failedCount = failedCount + OutputStepFailureCount("���ʕۑ�:�������𓯊�", "SyncMarriageHistoryFromLegacyTables")

    failedCount = failedCount + OutputStepFailureCount("���ʕۑ�:�Ƒ��������f���\�z", "PrepareFamilyModel")

    failedCount = failedCount + OutputStepFailureCount("���ʕۑ�:���n��C�x���g����", "GenerateEvents")

    failedCount = failedCount + OutputStepFailureCount("���ʕۑ�:��������\�쐬", "BuildCohabitationTable")

    failedCount = failedCount + OutputStepFailureCount("���ʕۑ�:�o�̓V�[�g�ی�E�\������", "ApplyOutputUsability")

    outPath = RuntimeCombinePath(folderPath, "00_���ʃf�[�^.xlsx")

    stepText = "�o�͗p�u�b�N�쐬"
    Set wb = Workbooks.Add(xlWBATWorksheet)

    shNames = Array(SH_CONFIG, SH_W_PERSON, SH_W_REL, SH_W_MARRIAGE_HIST, SH_W_ADDR_CAND, SH_W_ADDR_HIST, SH_COHAB, SH_W_EVENT)

    tNames = Array("T_�ݒ�_���{", "T_�l��", "T_�֌W", "T_��������", "T_�Z�����", "T_�Z������", "T_��������", "T_�C�x���g")

    For i = LBound(shNames) To UBound(shNames)

        If i = 0 Then

            wb.Worksheets(1).Name = tNames(i)

        Else

            wb.Worksheets.Add After:=wb.Worksheets(wb.Worksheets.Count)

            wb.Worksheets(wb.Worksheets.Count).Name = tNames(i)

        End If

        If CStr(tNames(i)) = "T_��������" Then

            WriteCohabCommonTable wb.Worksheets(tNames(i))

        Else

            CopySheetValuesToCommonWorkbook ThisWorkbook.Worksheets(shNames(i)), wb.Worksheets(tNames(i))

            If CStr(tNames(i)) = "T_�l��" Then RewriteCommonPersonRelationDisplay wb.Worksheets(tNames(i))

            wb.Worksheets(tNames(i)).Columns.AutoFit
            CapUsedColumnWidths wb.Worksheets(tNames(i)), 42

        End If

    Next i

    AddCommonDataControlSheets wb

    Application.CutCopyMode = False

    RuntimeSafeSaveAsXlsxAndClose wb, outPath, "SaveCommonData", "00_���ʃf�[�^.xlsx�ۑ�"

    LogAction "���ʃf�[�^�ۑ�", outPath

CleanExit:

    AppEnd

    If Len(outPath) > 0 Then
        If failedCount > 0 Then
            AppendOutputFailureSummary "���ʃf�[�^�ۑ�"
            QuietWarn "���ʃf�[�^�͕ۑ����܂������A�ꕔ�̑O�����Ɏ��s������܂��BC_�`�F�b�N�Ŏ��s�H�����m�F���Ă��������B" & vbCrLf & outPath, True, "���ʃf�[�^�ۑ�"
        Else
            NotifyInfo "���ʃf�[�^��ۑ����܂����B�㑱�c�[���͂��̃t�@�C����T_�l���AT_�Z�������AT_��������AT_�A�g�ݒ��ǂݍ��݂܂��B" & vbCrLf & outPath
        End If
    End If

    Exit Sub

EH:

    Dim errNum As Long, errDesc As String, errSrc As String
    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppEnd
    On Error GoTo 0
    RuntimeShowErrorValues "SaveCommonData", "���ʃf�[�^�ۑ�", "�ۑ��悪�J���Ă��Ȃ����A�o�̓t�H���_�֏������߂邩�m�F���Ă��������B", outPath, errNum, errDesc, errSrc

End Sub




Private Sub CopySheetValuesToCommonWorkbook(ByVal src As Worksheet, ByVal dst As Worksheet)
    'UsedRange/Clipboard���g�킸�A���f�[�^�͈͂�����z��]�L����B
    Dim lastR As Long, lastC As Long
    If src Is Nothing Then Exit Sub
    If dst Is Nothing Then Exit Sub
    lastR = LastNonEmptyRow(src)
    lastC = LastNonEmptyColumn(src)
    If lastR < 1 Or lastC < 1 Then Exit Sub
    With dst.Range("A1").Resize(lastR, lastC)
        .Value = src.Range(src.Cells(1, 1), src.Cells(lastR, lastC)).Value
        .NumberFormat = src.Range(src.Cells(1, 1), src.Cells(lastR, lastC)).NumberFormat
    End With
End Sub

Private Sub RewriteCommonPersonRelationDisplay(ByVal dst As Worksheet)
    'T_�l���̑����\�����A�֌W�}�E�l���ꗗ�Ɠ������f�����ʂ�ۑ�����B
    'W_�l���̌�����͎c���A���ʃf�[�^���������㑱�c�[�������̕\���l�֐�����B
    Dim r As Long, pid As String, relText As String
    If dst Is Nothing Then Exit Sub
    For r = 2 To LastNonEmptyRow(dst)
        pid = CleanText(dst.Cells(r, P_ID).Value)
        If Len(pid) > 0 Then
            relText = DiagramRelationDisplayTextForPersonId(pid)
            If Len(relText) > 0 Then dst.Cells(r, P_REL_DEC).Value = relText
        End If
    Next r
End Sub

Private Function LastNonEmptyRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If Not f Is Nothing Then LastNonEmptyRow = f.Row
End Function

Private Function LastNonEmptyColumn(ByVal ws As Worksheet) As Long
    Dim f As Range
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If Not f Is Nothing Then LastNonEmptyColumn = f.Column
End Function

Private Sub WriteCohabCommonTable(ByVal dst As Worksheet)
    '�㑱���̓c�[�����m���ɐl��ID�œ���������Q�Ƃł���悤�A�\���p�̓�������\�ł͂Ȃ��AID�t���ŕۑ�����B
    Dim wa As Worksheet, r1 As Long, r2 As Long, outR As Long, coNo As Long
    Dim s1 As Variant, e1 As Variant, s2 As Variant, e2 As Variant, st As Variant, en As Variant
    Dim p1 As String, p2 As String, judge As String, matchKind As String, endCache As Object
    Dim overlapDays As Long, reliablePeriod As Boolean

    dst.Cells.Clear
    SetRowValues dst.Range("A1"), Array("��������ID", "�l��ID_A", "����Ώېl��", "����A", "�l��ID_B", "��������l��", "����B", "�Z��", "�Z���L�[", "�d���J�n��", "�d���I����", "�d������", "����")
    HeaderStyle dst.Range("A1:M1")

    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    Set endCache = CreateObject("Scripting.Dictionary")
    For r1 = 2 To LastRow(wa, 1)
        If CleanText(wa.Cells(r1, A_STATUS).Value) <> STATUS_CANCEL Then endCache(CStr(r1)) = EffectiveEndDate(r1)
    Next r1
    outR = 2
    coNo = 1
    For r1 = 2 To LastRow(wa, 1)
        If CleanText(wa.Cells(r1, A_STATUS).Value) <> STATUS_CANCEL Then
            For r2 = r1 + 1 To LastRow(wa, 1)
                If CleanText(wa.Cells(r2, A_STATUS).Value) <> STATUS_CANCEL Then
                    p1 = CleanText(wa.Cells(r1, A_PERSON_ID).Value)
                    p2 = CleanText(wa.Cells(r2, A_PERSON_ID).Value)
                    If Len(p1) > 0 Then
                        If Len(p2) > 0 Then
                            If p1 <> p2 And FindPersonRow(p1) > 0 And FindPersonRow(p2) > 0 Then
                                matchKind = CohabRowsAddressMatchKind(wa, r1, r2)
                                If Len(matchKind) > 0 Then
                                    s1 = wa.Cells(r1, A_START).Value
                                    e1 = endCache(CStr(r1))
                                    s2 = wa.Cells(r2, A_START).Value
                                    e2 = endCache(CStr(r2))
                                    judge = "���ԗv�m�F"
                                    st = ""
                                    en = ""
                                    If CohabRowsHaveComparablePeriod(s1, e1, s2, e2) Then
                                        If CDate(SameDateOrBlank(s1)) > CDate(SameDateOrBlank(s2)) Then st = SameDateOrBlank(s1) Else st = SameDateOrBlank(s2)
                                        If CDate(SameDateOrBlank(e1)) < CDate(SameDateOrBlank(e2)) Then en = SameDateOrBlank(e1) Else en = SameDateOrBlank(e2)
                                        overlapDays = CohabitationOverlapDays(st, en)
                                        If overlapDays > 0 Then
                                            reliablePeriod = CohabAddressPeriodIsReliable(wa, r1) And CohabAddressPeriodIsReliable(wa, r2)
                                            If reliablePeriod Then
                                                judge = "��������"
                                            Else
                                                judge = "��������i���Ԋm�F�j"
                                            End If
                                        Else
                                            GoTo NextPair
                                        End If
                                    End If
                                    dst.Cells(outR, 1).Value = "CO" & Format(coNo, "000000")
                                    dst.Cells(outR, 2).Value = p1
                                    dst.Cells(outR, 3).Value = GetPersonValue(p1, P_DISPLAY)
                                    dst.Cells(outR, 4).Value = DiagramRelationDisplayTextForPersonId(p1)
                                    dst.Cells(outR, 5).Value = p2
                                    dst.Cells(outR, 6).Value = GetPersonValue(p2, P_DISPLAY)
                                    dst.Cells(outR, 7).Value = DiagramRelationDisplayTextForPersonId(p2)
                                    dst.Cells(outR, 8).Value = wa.Cells(r1, A_TEXT).Value
                                    dst.Cells(outR, 9).Value = CleanText(wa.Cells(r1, A_KEY).Value)
                                    dst.Cells(outR, 10).Value = st
                                    dst.Cells(outR, 11).Value = en
                                    dst.Cells(outR, 12).Value = CohabOverlapPeriodText(st, en)
                                    dst.Cells(outR, 13).Value = judge
                                    coNo = coNo + 1
                                    outR = outR + 1
                                End If
                            End If
                        End If
                    End If
                End If
NextPair:
            Next r2
        End If
    Next r1
    If outR > 2 Then dst.Range("J2:K" & CStr(outR - 1)).NumberFormatLocal = "yyyy/m/d"
    dst.Columns.AutoFit
    CapUsedColumnWidths dst, 42
End Sub

Private Sub AddCommonDataControlSheets(ByVal wb As Workbook)

    Dim ws As Worksheet, decId As String, inheritDate As Variant, baseDate As Variant

    decId = GetDecedentId()

    inheritDate = GetInheritanceDate()

    baseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value



    Set ws = wb.Worksheets.Add(Before:=wb.Worksheets(1))

    ws.Name = "T_�A�g�ݒ�"

    ws.Range("A1:C1").Value = Array("�L�[", "�l", "����")

    ws.Range("A2:C2").Value = Array("���ʃf�[�^�d�l", "common-data", "�݊��p�B���ʃf�[�^�S�̂̎d�l")

    ws.Range("A3:C3").Value = Array("���ʃf�[�^�d�l", "common-data", "4�c�[�����ʂ̌Œ�d�l")

    ws.Range("A4:C4").Value = Array("�l���f�[�^�d�l", "PERSON_INFO", "�l���Z�����n��c�[���̏o�͎d�l")

    ws.Range("A5:C5").Value = Array("�����f�[�^�d�l", "���쐬", "02�c�[���ۑ���� T_�����A�g�ݒ� �ōX�V�E�m�F����")

    ws.Range("A6:C6").Value = Array("���̓f�[�^�d�l", "���쐬", "03�c�[���ۑ���� T_���͘A�g�ݒ� �ōX�V�E�m�F����")

    ws.Range("A7:C7").Value = Array("�`�[�˗��f�[�^�d�l", "���쐬", "04�c�[���ۑ���� T_�`�[�˗��A�g�ݒ� �ōX�V�E�m�F����")

    ws.Range("A8:C8").Value = Array("�Č�ID", "�g�p���Ȃ�", "1�Č�1�t�H���_�^�p�̂��߈Č�ID�͎����Ȃ�")

    ws.Range("A9:C9").Value = Array("�푊���l�l��ID", decId, "T_�l���̐l��ID�B�����n�Ŕ푊���l�����𔻒肷��")

    ws.Range("A10:C10").Value = Array("�����J�n��", inheritDate, "�����֘A�V�t�g����Ɏg��")

    ws.Range("A11:C11").Value = Array("�쐬���", baseDate, "�Z���I�����⊮�E���n��ŏI�N�Ɏg��")

    ws.Range("A12:C12").Value = Array("�ۑ�����", Now, "���̋��ʃf�[�^���쐬��������")

    ws.Range("A13:C13").Value = Array("�㑱�c�[��", "02_��������\_�c�����ڕ\�쐬�⏕�c�[��;03_�����ړ����̓c�[��;04_�`�[�˗��\�쐬�c�[��", "�ǂݍ��ݑ��̑z��")

    ws.Range("A14:C14").Value = Array("��v�L�[", "�l��ID;��������ID;�Z���L�[;����ID;���ID;��������ID", "�e�c�[���Ԃ̘A�g�L�[")

    ws.Range("A1:C1").Font.Bold = True

    ws.Range("A1:C1").Interior.Color = ThemeColor("text")

    ws.Range("A1:C1").Font.Color = vbWhite

    ws.Columns("A:C").AutoFit



    Set ws = wb.Worksheets.Add(After:=wb.Worksheets("T_�A�g�ݒ�"))

    ws.Name = "T_���ʃf�[�^����"

    ws.Range("A1:D1").Value = Array("�e�[�u����", "��L�[", "��ȗp�r", "�㑱�c�[��")

    ws.Range("A2:D2").Value = Array("T_�l��", "�l��ID", "�������`�l���A�����\���A�푊���l����", "�����֌W�E���́E�˗�")

    ws.Range("A3:D3").Value = Array("T_�֌W", "�֌WID", "�e���qID�A�v�w�A�q�̋敪�E�m�x�E�����E�Ƒ��L�[", "���́E���n��")

    ws.Range("A4:D4").Value = Array("T_��������", "��������ID", "���������E�����E���薢�o�^�̍�������", "���́E���n��")

    ws.Range("A5:D5").Value = Array("T_�Z�����", "�Z�����ID", "�Z���ė��p�E�Z���L�[�Ǘ�", "����")

    ws.Range("A6:D6").Value = Array("T_�Z������", "�Z��ID", "�Z�������E��������E�����J�n���Z��", "����")

    ws.Range("A7:D7").Value = Array("T_��������", "��������ID", "�Z���L�[��v�����ԏd���̌���", "����")

    ws.Range("A8:D8").Value = Array("T_�C�x���g", "�C�x���gID", "���n��E�㑱�C�x���g�ǉ��̓y��", "����")

    ws.Range("A9:D9").Value = Array("T_�A�g�ݒ�", "�L�[", "�����J�n���A�푊���l�l��ID�A���ʁE�l���ʃf�[�^�d�l", "�S�c�[��")

    ws.Range("A1:D1").Font.Bold = True

    ws.Range("A1:D1").Interior.Color = ThemeColor("text")

    ws.Range("A1:D1").Font.Color = vbWhite

    ws.Columns("A:D").AutoFit

End Sub



Public Sub ExportPersonInfoWorkbook()
    On Error GoTo EH
    Dim outFolder As String, outPath As String, wb As Workbook, shNames As Variant, i As Long
    Dim oldVis As Object, shName As String, stepText As String, failedCount As Long
    Set oldVis = CreateObject("Scripting.Dictionary")
    stepText = "�o�̓t�H���_�m�F"
    outFolder = EnsureOutputFolder()
    If Len(outFolder) = 0 Then
        QuietWarn "��ɂ��̃u�b�N���Č��t�H���_�֕ۑ����Ă��������B", True, "�o�͑O�m�F"
        GoTo CleanExit
    End If
    AppBegin
    mOutputFailureSummary = vbNullString
    outPath = RuntimeCombinePath(outFolder, "01_�l����񐮗�����.xlsx")
    stepText = "�o�͒��[�č\�z"
    failedCount = failedCount + OutputStepFailureCount("��\�Z���X�V", "RefreshRepresentativeAddresses")
    failedCount = failedCount + OutputStepFailureCount("�������𓯊�", "SyncMarriageHistoryFromLegacyTables")
    failedCount = failedCount + OutputStepFailureCount("���n��C�x���g����", "GenerateEvents")
    failedCount = failedCount + OutputStepFailureCount("�m�F�ꗗ�쐬", "BuildConfirmList")
    failedCount = failedCount + OutputStepFailureCount("���̓`�F�b�N", "RunChecks")
    failedCount = failedCount + OutputStepFailureCount("�����֌W�}�쐬", "BuildRelationshipDiagram")
    failedCount = failedCount + OutputStepFailureCount("�Z�����𑁌��\�쐬", "BuildAddressHistoryTable")
    failedCount = failedCount + OutputStepFailureCount("��������\�쐬", "BuildCohabitationTable")
    failedCount = failedCount + OutputStepFailureCount("���n��\�쐬", "BuildTimelineTable")
    failedCount = failedCount + OutputStepFailureCount("�l���ꗗ�쐬", "BuildPersonList")
    failedCount = failedCount + OutputStepFailureCount("�o�̓V�[�g�ی�E�\������", "ApplyOutputUsability")
    If failedCount > 0 Then AppendOutputFailureSummary "�l����񐮗������o��"
    shNames = Array(SH_DIAGRAM, SH_ADDR_TABLE, SH_COHAB, SH_TIMELINE, SH_PERSON_LIST, SH_CONFIRM, SH_CHECK)
    For i = LBound(shNames) To UBound(shNames)
        shName = CStr(shNames(i))
        oldVis(shName) = ThisWorkbook.Worksheets(shName).Visible
        ThisWorkbook.Worksheets(shName).Visible = xlSheetVisible
    Next i

    stepText = "�o�͗p�u�b�N�쐬"
    Set wb = Workbooks.Add(xlWBATWorksheet)
    For i = LBound(shNames) To UBound(shNames)
        shName = CStr(shNames(i))
        stepText = "�V�[�g�R�s�[: " & shName
        ThisWorkbook.Worksheets(shName).Copy After:=wb.Worksheets(wb.Worksheets.Count)
        wb.Worksheets(wb.Worksheets.Count).Name = shName
        wb.Worksheets(wb.Worksheets.Count).Visible = xlSheetVisible
    Next i
    Application.DisplayAlerts = False
    If wb.Worksheets.Count > 1 Then wb.Worksheets(1).Delete
    Application.DisplayAlerts = True
    stepText = "�o�̓u�b�N����"
    DeleteUiButtonsInWorkbook wb
    Application.CutCopyMode = False
    stepText = "�l����񐮗������ۑ�"
    RuntimeSafeSaveAsXlsxAndClose wb, outPath, "ExportPersonInfoWorkbook", "�l����񐮗������ۑ�"
    LogAction "�l����񐮗������o��", outPath
CleanExit:
    RestoreExportSourceSheetVisibility shNames, oldVis
    AppEnd
    If Len(outPath) > 0 Then
        If failedCount > 0 Then
            QuietWarn "�l����񐮗������͏o�͂��܂������A�ꕔ���[�͎��s�y�[�W�܂��͖��X�V�̉\��������܂��BC_�`�F�b�N���m�F���Ă��������B", True, "�l����񐮗������o��"
        Else
            NotifyInfo "�l����񐮗��������o�͂��܂���: " & outPath
        End If
    End If
    Exit Sub
EH:
    Dim errNum As Long, errDesc As String, errSrc As String
    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source
    On Error Resume Next
    Application.DisplayAlerts = True
    RestoreExportSourceSheetVisibility shNames, oldVis
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppEnd
    On Error GoTo 0
    RuntimeShowErrorValues "ExportPersonInfoWorkbook", "�l����񐮗������o��", _
        "�����i�K: " & stepText & vbCrLf & "�o�͐�t�@�C�����J���Ă��Ȃ����A�o�̓t�H���_�֏������߂邩�m�F���Ă��������B", _
        outPath, errNum, errDesc, errSrc
End Sub

Private Sub RestoreExportSourceSheetVisibility(ByVal shNames As Variant, ByVal oldVis As Object)
    Dim i As Long, shName As String
    On Error Resume Next
    If oldVis Is Nothing Then Exit Sub
    If IsEmpty(shNames) Then Exit Sub
    For i = LBound(shNames) To UBound(shNames)
        shName = CStr(shNames(i))
        If oldVis.Exists(shName) Then ThisWorkbook.Worksheets(shName).Visible = oldVis(shName)
    Next i
    On Error GoTo 0
End Sub

Private Sub DeleteUiButtonsInWorkbook(ByVal wb As Workbook)
    Dim ws As Worksheet, i As Long, shp As Shape
    On Error Resume Next
    For Each ws In wb.Worksheets
        ws.Unprotect Password:=TOOL_PASSWORD
        For i = ws.Shapes.Count To 1 Step -1
            Set shp = ws.Shapes(i)
            If Left$(shp.Name, 4) = "btn_" Or Len(shp.OnAction) > 0 Then shp.Delete
        Next i
        ws.Cells.Locked = False
        ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=True, UserInterfaceOnly:=True
    Next ws
    On Error GoTo 0
End Sub

Private Sub LogAction(ByVal actionName As String, ByVal detail As String)
    Dim ws As Worksheet, r As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_LOG)
    r = NextBlankRow(ws, 1)
    ws.Cells(r, 1).Value = Now
    ws.Cells(r, 2).Value = actionName
    ws.Cells(r, 3).Value = detail
End Sub

Private Sub PrepareOutputPathWithBackup(ByVal filePath As String)
    If Len(filePath) = 0 Then Exit Sub
    If Len(Dir$(filePath)) = 0 Then Exit Sub
    RuntimeBackupAndRemoveExistingFile filePath, "PrepareOutputPathWithBackup"
    AppendLinkLog "�����o�͑ޔ�", "�쐬", filePath
End Sub

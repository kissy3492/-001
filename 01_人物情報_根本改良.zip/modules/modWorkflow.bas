Attribute VB_Name = "modWorkflow"

Option Explicit

Public Sub BeginDecedentEntry()

    PrepareInput MODE_DECEDENT

End Sub

Public Sub BeginAddSpouse()

    PrepareInput MODE_SPOUSE

End Sub

Public Sub BeginAddFather()

    PrepareInput MODE_FATHER

End Sub

Public Sub BeginAddMother()

    PrepareInput MODE_MOTHER

End Sub

Public Sub BeginAddChild()

    PrepareInput MODE_CHILD

End Sub

Public Sub BeginAddSibling()

    PrepareInput MODE_SIBLING

End Sub

Public Sub BeginAddGrandchild()

    PrepareInput MODE_GRANDCHILD

End Sub

Public Sub BeginAddOther()

    PrepareInput MODE_OTHER

End Sub

Private Sub PrepareInput(ByVal modeName As String)

    On Error GoTo EH

    Dim ws As Worksheet, baseId As String, autoSurname As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    ws.Unprotect Password:=TOOL_PASSWORD

    If Not GuardTransientInputBeforeNewMode(ws, modeName) Then GoTo CleanExit

    If modeName <> MODE_DECEDENT Then

        baseId = CleanText(ws.Range(CELL_BASE_ID).Value)

        If Len(baseId) = 0 Then

            QuietWarn "��Ɋ�l����I��ł��������B�푊���l�o�^��͎����Ŋ�l���ɂȂ�܂��B", False, "�l������"

            GoTo CleanExit

        End If

    End If

    ws.Range(CELL_PERSON_ID & ":" & CELL_DEATH_PLACE).ClearContents
    ws.Range(CELL_MARRIAGE_COUNTERPART & ":" & CELL_MARRIAGE_HIST_NOTE).ClearContents

    ws.Range(CELL_PENDING_ADDR_KEY).ClearContents
    ws.Range(CELL_PENDING_MARRIAGE_KEY).ClearContents
    ws.Range(CELL_ADDR_EDIT_ID).ClearContents

    ws.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents
    ws.Range(CELL_ADDR_KEY).ClearContents
    ws.Range(CELL_ADDR_SOURCE).ClearContents
    ws.Range(CELL_ADDR_COPY_SOURCE_ID).ClearContents
    ws.Range(CELL_ADDR_EDIT_ID).ClearContents
    ws.Range(CELL_ADDR_TYPE).Value = "���Z�n"

    ws.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"
    RefreshPendingMarriageHistoryPanel

    ws.Range(CELL_MODE).Value = modeName

    ws.Range(CELL_SHOW_DIAGRAM).Value = SHOW_YES

    autoSurname = SuggestSurname(modeName, baseId)

    ws.Range(CELL_AUTO_SURNAME).Value = autoSurname

    ws.Range(CELL_SURNAME).Value = autoSurname

    ws.Range(CELL_GENDER).Value = SuggestedGender(modeName, baseId)

    Select Case modeName

        Case MODE_DECEDENT

            ws.Range(CELL_REL_TO_DECEDENT).Value = MODE_DECEDENT

            ws.Range(CELL_SURNAME).ClearContents

        Case Else

            ws.Range(CELL_REL_TO_DECEDENT).Value = ResolveRelationTextForRegistration(modeName, baseId, "", _
                CleanText(ws.Range(CELL_GENDER).Value), ws.Range(CELL_BIRTH).Value)

    End Select

    '�Z���͐V�l�����͊J�n���Ɏ����R�s�[���Ȃ��B
    '�Z���E��������������Ȃ����߁A��l���Z���̃R�s�[�͖����{�^��/���I���������s���B

    EnsureCandidatesWarmForInputMode

    UpdateInputGuide modeName
    RefreshInputContextGuidance

    ws.Range(CELL_GIVEN_NAME).Select

CleanExit:

    On Error Resume Next

    EnsurePersonInputValidationOnly ws

    ApplyInputUsability

    On Error GoTo 0

    Exit Sub

EH:

    Dim errNum As Long, errDesc As String, errSrc As String

    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source

    On Error Resume Next

    EnsurePersonInputValidationOnly ws

    ApplyInputUsability

    On Error GoTo 0

    RuntimeShowErrorValues "PrepareInput", "�l�����͊J�n", _
        "��l���E���͌��E�V�[�g�ی��Ԃ��m�F���Ă��������B", "", errNum, errDesc, errSrc

End Sub

Public Sub ClearPersonInput(Optional ByVal suppressConfirm As Boolean = False)

    On Error GoTo EH

    Dim ws As Worksheet, pendingKey As String, pendingMarriageKey As String
    Dim addrCount As Long, mhCount As Long, lastText As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    ws.Unprotect Password:=TOOL_PASSWORD

    pendingKey = CleanText(ws.Range(CELL_PENDING_ADDR_KEY).Value)
    pendingMarriageKey = CleanText(ws.Range(CELL_PENDING_MARRIAGE_KEY).Value)
    addrCount = PendingAddressCount(pendingKey)
    mhCount = PendingMarriageHistoryCount(PendingMarriagePersonId(pendingMarriageKey), lastText)
    If Not suppressConfirm Then
        If addrCount > 0 Or mhCount > 0 Or CurrentInputHasUnsavedPerson(ws) Then
            If MsgBox("���͒��̐l�����܂��͖��o�^������j�����܂��B" & vbCrLf & _
                      "�Z������: " & CStr(addrCount) & "��" & vbCrLf & _
                      "��������: " & CStr(mhCount) & "��" & vbCrLf & vbCrLf & _
                      "��낵���ł����H", vbExclamation + vbYesNo, "���̓N���A�m�F") <> vbYes Then GoTo CleanExit
        End If
    End If
    If Len(pendingKey) > 0 Then
        ClearPendingAddresses pendingKey
        ClearPendingMarriageHistory pendingKey
    End If
    If Len(pendingMarriageKey) > 0 And pendingMarriageKey <> pendingKey Then ClearPendingMarriageHistory pendingMarriageKey

    ws.Range(CELL_PERSON_ID & ":" & CELL_DEATH_PLACE).ClearContents
    ws.Range(CELL_MARRIAGE_COUNTERPART & ":" & CELL_MARRIAGE_HIST_NOTE).ClearContents

    ws.Range(CELL_PENDING_ADDR_KEY).ClearContents
    ws.Range(CELL_PENDING_MARRIAGE_KEY).ClearContents
    ws.Range(CELL_ADDR_EDIT_ID).ClearContents

    ws.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents
    ws.Range(CELL_ADDR_KEY).ClearContents
    ws.Range(CELL_ADDR_SOURCE).ClearContents
    ws.Range(CELL_ADDR_COPY_SOURCE_ID).ClearContents
    ws.Range(CELL_ADDR_EDIT_ID).ClearContents
    ws.Range(CELL_ADDR_TYPE).Value = "���Z�n"

    ws.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"

    ws.Range(CELL_SHOW_DIAGRAM).Value = SHOW_YES
    RefreshPendingMarriageHistoryPanel

CleanExit:

    EnsurePersonInputValidationOnly ws

    ApplyInputUsability

    Exit Sub

EH:

    Resume CleanExit

End Sub

Private Function SuggestSurname(ByVal modeName As String, ByVal baseId As String) As String

    Dim decId As String, s As String

    If modeName = MODE_OTHER Then

        SuggestSurname = ""

        Exit Function

    End If

    If modeName = MODE_DECEDENT Then

        SuggestSurname = ""

        Exit Function

    End If

    If Len(baseId) > 0 Then s = GetPersonValue(baseId, P_SURNAME)

    decId = GetDecedentId()

    Select Case modeName

        Case MODE_FATHER, MODE_MOTHER, MODE_SIBLING

            If Len(decId) > 0 Then SuggestSurname = GetPersonValue(decId, P_SURNAME) Else SuggestSurname = s

        Case Else

            SuggestSurname = s

    End Select

End Function

Public Sub LoadBaseFromSelection()

    Dim ws As Worksheet, sel As String, pid As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    sel = CleanText(ws.Range(CELL_BASE_SELECT).Value)

    pid = ParseIdFromCandidate(sel)

    If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then

        QuietWarn "��l����₩��l����I��ł��������B", False, "��l���I��"

        Exit Sub

    End If

    SetBasePerson pid

End Sub

Public Sub SetDecedentAsBase()

    Dim pid As String

    pid = GetDecedentId()

    If Len(pid) = 0 Then

        QuietWarn "�푊���l���܂��o�^����Ă��܂���B", False, "��l���I��"

        Exit Sub

    End If

    SetBasePerson pid

End Sub

Public Sub SetBasePerson(ByVal personId As String)

    Dim ws As Worksheet, r As Long, addr As String, relationText As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    r = FindPersonRow(personId)

    If r = 0 Then Exit Sub

    ws.Range(CELL_BASE_ID).Value = personId

    ws.Range(CELL_BASE_NAME).Value = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, P_DISPLAY).Value

    relationText = RelationshipCanonicalStoredLabel(DiagramGraphDisplayRelationForPerson(personId))
    If Len(relationText) > 0 Then
        ws.Range(CELL_BASE_REL).Value = relationText
    Else
        ws.Range(CELL_BASE_REL).Value = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, P_REL_DEC).Value
    End If

    addr = GetCurrentAddressText(personId)

    ws.Range(CELL_BASE_ADDRESS).Value = addr

    ws.Range(CELL_BASE_SELECT).Value = personId & " " & ws.Range(CELL_BASE_NAME).Value

    If Len(CleanText(ws.Range(CELL_MODE).Value)) > 0 Then UpdateInputGuide CleanText(ws.Range(CELL_MODE).Value)

End Sub

Public Function FindPersonRow(ByVal personId As String) As Long

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, P_ID).Value) = personId And CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            FindPersonRow = r

            Exit Function

        End If

    Next r

End Function

Public Function GetPersonValue(ByVal personId As String, ByVal colNum As Long) As String

    Dim r As Long

    r = FindPersonRow(personId)

    If r > 0 Then GetPersonValue = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, colNum).Value)

End Function

Public Function GetDecedentId() As String

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, P_TYPE).Value) = MODE_DECEDENT And CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            GetDecedentId = CStr(ws.Cells(r, P_ID).Value)

            Exit Function

        End If

    Next r

End Function

Public Function GetInheritanceDate() As Variant

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_CONFIG)

    If HasInputDate(ws.Range(CELL_CONFIG_INHERIT_DATE).Value) Then

        GetInheritanceDate = SameDateOrBlank(ws.Range(CELL_CONFIG_INHERIT_DATE).Value)

    Else

        GetInheritanceDate = ""

    End If

End Function

Public Sub RegisterInputPerson()

    On Error GoTo EH

    AppBegin

    Dim wsIn As Worksheet, wsP As Worksheet, modeName As String, pid As String, r As Long
    Dim prevBaseId As String

    Dim surname As String, givenName As String, former As String, autoSurname As String

    Dim displayName As String, personType As String, relationText As String, baseId As String

    Dim gender As String, birthDate As Variant, deathDate As Variant, occupation As String, note As String

    Dim deathPlace As String, pendingKey As String, pendingMarriageKey As String, relationBaseId As String

    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)

    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)

    modeName = CleanText(wsIn.Range(CELL_MODE).Value)

    If Len(modeName) = 0 Then modeName = MODE_DECEDENT

    baseId = CleanText(wsIn.Range(CELL_BASE_ID).Value)
    prevBaseId = baseId

    If modeName <> MODE_DECEDENT And Len(baseId) = 0 Then Err.Raise 5, , "��l�������ݒ�ł��B"

    surname = CleanText(wsIn.Range(CELL_SURNAME).Value)

    givenName = CleanText(wsIn.Range(CELL_GIVEN_NAME).Value)

    former = CleanText(wsIn.Range(CELL_FORMER_SURNAME).Value)

    autoSurname = CleanText(wsIn.Range(CELL_AUTO_SURNAME).Value)

    If Len(surname) = 0 And Len(autoSurname) > 0 Then surname = autoSurname

    If Len(givenName) = 0 Then Err.Raise 5, , "������͂��Ă��������B"

    If Len(surname) = 0 Then Err.Raise 5, , "������͂��Ă��������B"

    '�������͌���m�F�ƂȂ���������邽�߁A�l���o�^���͎̂~�߂Ȃ��B
    '�����͂�C_�`�F�b�N/���n�񖢔��f�ň����A���͓������d�����Ȃ��B

    gender = CleanText(wsIn.Range(CELL_GENDER).Value)

    relationText = CleanText(wsIn.Range(CELL_REL_TO_DECEDENT).Value)

    birthDate = SameDateOrBlank(wsIn.Range(CELL_BIRTH).Value)

    deathDate = SameDateOrBlank(wsIn.Range(CELL_DEATH).Value)

    relationText = ResolveRelationTextForRegistration(modeName, baseId, relationText, gender, birthDate)
    relationText = NormalizedRelationLabel(relationText)
    wsIn.Range(CELL_REL_TO_DECEDENT).Value = relationText

    If Len(autoSurname) > 0 And surname <> autoSurname And Len(former) = 0 _
            And ShouldAutoFormerSurname(modeName, relationText) Then

        former = autoSurname

        wsIn.Range(CELL_FORMER_SURNAME).Value = former

    End If

    displayName = ComposeDisplayName(surname, givenName, former)
    If modeName = MODE_SPOUSE And HasInputDate(wsIn.Range(CELL_DIVORCE).Value) Then relationText = "�O�z���"

    If modeName = MODE_DECEDENT Then
        personType = MODE_DECEDENT
    ElseIf modeName = MODE_OTHER Then
        personType = "�֌W��"
    Else
        personType = "�e��"
    End If

    If modeName = MODE_CHILD Or modeName = MODE_GRANDCHILD Then
        If InStr(relationText, "�z��҂̎q") > 0 Then
            personType = "�e��"
        Else
            personType = "�����l"
        End If
    End If

    If modeName = MODE_SPOUSE And baseId = GetDecedentId() Then personType = "�����l"

    occupation = CleanText(wsIn.Range(CELL_OCCUPATION).Value)

    note = CleanText(wsIn.Range(CELL_NOTE).Value)

    deathPlace = CleanText(wsIn.Range(CELL_DEATH_PLACE).Value)
    If modeName <> MODE_DECEDENT Then deathPlace = ""
    pendingKey = CleanText(wsIn.Range(CELL_PENDING_ADDR_KEY).Value)
    pendingMarriageKey = CleanText(wsIn.Range(CELL_PENDING_MARRIAGE_KEY).Value)
    pid = CleanText(wsIn.Range(CELL_PERSON_ID).Value)
    If Len(pid) = 0 Then
        r = FindLikelyExistingPersonRow(displayName, birthDate, deathDate, modeName)
        If r > 0 Then
            pid = CStr(wsP.Cells(r, P_ID).Value)
        Else
            pid = NextId("�l��")
            r = NextBlankRow(wsP, 1)
            wsP.Cells(r, P_CREATED).Value = Now
        End If
    Else
        r = FindPersonRow(pid)
        If r = 0 Then r = NextBlankRow(wsP, 1)
    End If
    wsP.Cells(r, P_ID).Value = pid

    If Len(wsP.Cells(r, P_ORDER).Value) = 0 Then wsP.Cells(r, P_ORDER).Value = r - 1

    wsP.Cells(r, P_TYPE).Value = personType

    wsP.Cells(r, P_SURNAME).Value = surname

    wsP.Cells(r, P_GIVEN).Value = givenName

    wsP.Cells(r, P_FORMER).Value = former

    wsP.Cells(r, P_DISPLAY).Value = displayName

    If Len(autoSurname) > 0 And surname = autoSurname Then
        wsP.Cells(r, P_SUR_MODE).Value = "����"
    Else
        wsP.Cells(r, P_SUR_MODE).Value = "�����"
    End If

    'P_SUR_SRC�͋����u���⊮�̊�l���v�����A�����֌W�}�̐e�q�������ɂ��g���B
    '�q�E���ȉ��͌�i�Ŏ��ۂ̐eID�ɏ㏑�����A�����ŋ����⊮������Ȃ��P�[�X�ł��e�q��������Ȃ��B
    If modeName <> MODE_DECEDENT And Len(baseId) > 0 Then
        'P_SUR_SRC �͋����̂܂܂����A�}�̐e�q�~�ςł��g�����ߊ�l��ID��ێ�����B
        '���⊮�������l���ł��A���E�]���ȉ����ォ�琳�����e�̉��֖߂���悤�ɂ���B
        wsP.Cells(r, P_SUR_SRC).Value = baseId
    Else
        wsP.Cells(r, P_SUR_SRC).Value = ""
    End If

    wsP.Cells(r, P_REL_DEC).Value = relationText

    wsP.Cells(r, P_REL_DISP).Value = relationText

    wsP.Cells(r, P_GENDER).Value = gender

    wsP.Cells(r, P_BIRTH).Value = birthDate

    wsP.Cells(r, P_DEATH).Value = deathDate

    wsP.Cells(r, P_OCC).Value = occupation

    If Len(CleanText(wsIn.Range(CELL_SHOW_DIAGRAM).Value)) = 0 Then
        wsP.Cells(r, P_SHOW).Value = SHOW_YES
    Else
        wsP.Cells(r, P_SHOW).Value = wsIn.Range(CELL_SHOW_DIAGRAM).Value
    End If

    wsP.Cells(r, P_NOTE).Value = note

    wsP.Cells(r, P_DEATH_PLACE).Value = deathPlace

    SavePersonMarriageFactFields wsP, r, wsIn.Range(CELL_MARRIAGE).Value, wsIn.Range(CELL_DIVORCE).Value

    wsP.Cells(r, P_STATUS).Value = STATUS_ACTIVE

    wsP.Cells(r, P_UPDATED).Value = Now

    wsIn.Range(CELL_PERSON_ID).Value = pid

    If modeName = MODE_DECEDENT Then

        ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_INHERIT_DATE).Value = deathDate
        '�푊���l�̖{�l�������肵���ڍs��ID���������A�ĕҏW���ɓ��������s���X�V����B
        UpsertMarriageHistory pid, "", "", wsIn.Range(CELL_MARRIAGE).Value, wsIn.Range(CELL_DIVORCE).Value, "�l������", "P|" & pid, ""

    Else

        relationBaseId = RelationBaseForRegistration(modeName, baseId, birthDate)
        If modeName = MODE_CHILD Or modeName = MODE_GRANDCHILD Then
            '���������ŋ����⊮���s�v�ȏꍇ���A�}��̒���e�𕜌��ł���悤���ۂ̐eID��ێ�����B
            wsP.Cells(r, P_SUR_SRC).Value = relationBaseId
        End If
        AddRelationIfNeeded relationBaseId, pid, modeName, relationText, wsIn.Range(CELL_MARRIAGE).Value, wsIn.Range(CELL_DIVORCE).Value
        ConfirmRelationshipFactsAfterRegister pid, modeName, baseId, relationBaseId, relationText, birthDate, wsIn.Range(CELL_MARRIAGE).Value, wsIn.Range(CELL_DIVORCE).Value
        If modeName = MODE_SPOUSE Then
            '�������Ԃ͕v�w�o���ɋ��ʂ���1�����Ƃ���1�s�����ۑ�����B
            '�J�[�h�E���n��E�݊���͐l��ID/����l��ID�̑o�����瓯���s��ǂށB
            UpsertMarriageHistory baseId, pid, displayName, wsIn.Range(CELL_MARRIAGE).Value, wsIn.Range(CELL_DIVORCE).Value, "�z��ғo�^", "S|" & baseId & "|" & pid, ""
        Else
            UpsertMarriageHistory pid, "", "", wsIn.Range(CELL_MARRIAGE).Value, wsIn.Range(CELL_DIVORCE).Value, "�l������", "P|" & pid, ""
        End If

    End If

    RegisterAddressFromInput pid
    If Len(pendingKey) > 0 Then
        FlushPendingAddressesToPerson pendingKey, pid
        FlushPendingMarriageHistoryToPerson pendingKey, pid
        wsIn.Range(CELL_PENDING_ADDR_KEY).ClearContents
    End If
    If Len(pendingMarriageKey) > 0 Then
        FlushPendingMarriageHistoryToPerson pendingMarriageKey, pid
        wsIn.Range(CELL_PENDING_MARRIAGE_KEY).ClearContents
    End If

    '��ɓ��͂������������𐳎��l��ID�ֈڂ�����Ŕz��Ҋ֌W�Əƍ�����B
    '������O�ɓ�������ƁA�z��҂͓o�^�ς݂Ȃ̂ɗ��������u���薢�w��v�Ŏc��B
    ReconcileMarriageHistoryCounterpartsFromRelations
    '�l���\�Ɣz��Ҋ֌W�\�̌݊����t���A����̍����������Ԃ���Ō�ɍČv�Z����B
    '���͗����ɃN���A�����o�H�ł��AW_�֌W������̂܂܎c���Ȃ��B
    SyncLegacyMarriageFactsFromHistory
    RefreshPendingMarriageHistoryPanel

    RefreshCandidatesAfterPersonRegister pid

    Dim nextBaseId As String

    nextBaseId = pid
    wsIn.Range(CELL_PREV_BASE_ID).Value = prevBaseId
    wsIn.Range(CELL_LAST_REGISTERED_ID).Value = pid

    '�o�^�O�ɍ��ꂽ�\���p�O���t��j�����Ă����l����\������B
    '�t�����ƁA�o�^�ς݂Ȃ̂Ɋ�l��������������/�������̂܂܎c��B
    DiagramGraphReset

    SetBasePerson nextBaseId

    wsIn.Range(CELL_BASE_SELECT).Value = nextBaseId & " " & GetPersonValue(nextBaseId, P_DISPLAY)

    ApplyInputUsability False

    WriteGuideAfterRegister modeName, displayName, nextBaseId

    SetPersonInputStatus "�o�^����: " & displayName & "�B" & NextActionMessage(modeName, nextBaseId)

CleanExit:

    AppEnd

    Exit Sub

EH:

    Dim errNum As Long, errDesc As String, errSrc As String

    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source

    On Error Resume Next

    If Not wsIn Is Nothing Then

        EnsurePersonInputValidationOnly wsIn

        ApplyInputUsability

    End If

    AppEnd

    On Error GoTo 0

    RuntimeShowErrorValues "RegisterInputPerson", "�l���o�^", _
        "�K�{���ځA��l���A���V�[�g�A�V�[�g�ی��Ԃ��m�F���Ă��������B", _
        "", errNum, errDesc, errSrc

End Sub

Public Sub ReturnToPreviousBasePerson()
    On Error GoTo EH
    Dim ws As Worksheet, pid As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    pid = CleanText(ws.Range(CELL_PREV_BASE_ID).Value)
    If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then
        QuietWarn "�߂�錳��l��������܂���B��l���I������I�ђ����Ă��������B", False, "��l��"
        Exit Sub
    End If
    SetBasePerson pid
    ws.Range(CELL_BASE_SELECT).Value = pid & " " & GetPersonValue(pid, P_DISPLAY)
    RefreshInputContextGuidance
    SetPersonInputStatus "��l�������̐l���֖߂��܂���: " & GetPersonValue(pid, P_DISPLAY)
    Exit Sub
EH:
    RuntimeShowError "ReturnToPreviousBasePerson", "����֖߂�", "�l��ID�Ɠ��̓V�[�g�̏�Ԃ��m�F���Ă��������B"
End Sub

Public Sub ReturnToDecedentBasePerson()
    On Error GoTo EH
    Dim ws As Worksheet, pid As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    pid = GetDecedentId()
    If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then
        QuietWarn "�푊���l�����o�^�ł��B", False, "��l��"
        Exit Sub
    End If
    SetBasePerson pid
    ws.Range(CELL_BASE_SELECT).Value = pid & " " & GetPersonValue(pid, P_DISPLAY)
    RefreshInputContextGuidance
    SetPersonInputStatus "��l����푊���l�֖߂��܂����B"
    Exit Sub
EH:
    RuntimeShowError "ReturnToDecedentBasePerson", "�푊���l�֖߂�", "�푊���l�o�^�Ɠ��̓V�[�g�̏�Ԃ��m�F���Ă��������B"
End Sub

Private Function FindLikelyExistingPersonRow(ByVal displayName As String, _
        ByVal birthDate As Variant, _
        ByVal deathDate As Variant, _
        ByVal modeName As String) As Long
    '�l��ID����̂܂ܓ����l�����ēo�^�������ɁA���ʂȏd���l�������Ȃ��B
    '���������ł͓����������득�������邽�߁A���t��񂪂���ꍇ�A�܂��͔푊���l������1������ꍇ���������X�V����B
    Dim ws As Worksheet, r As Long, lastR As Long
    If Len(displayName) = 0 Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            If CStr(ws.Cells(r, P_DISPLAY).Value) = displayName Then
                If modeName = MODE_DECEDENT And CStr(ws.Cells(r, P_TYPE).Value) = MODE_DECEDENT Then
                    FindLikelyExistingPersonRow = r
                    Exit Function
                End If
                If HasAnyDateForDuplicate(birthDate, deathDate) Then
                    If SameDateValueOrBlank(ws.Cells(r, P_BIRTH).Value, birthDate) Then
                        If SameDateValueOrBlank(ws.Cells(r, P_DEATH).Value, deathDate) Then
                            FindLikelyExistingPersonRow = r
                            Exit Function
                        End If
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function HasAnyDateForDuplicate(ByVal birthDate As Variant, ByVal deathDate As Variant) As Boolean
    HasAnyDateForDuplicate = (HasInputDate(birthDate) Or HasInputDate(deathDate))
End Function

Private Function RecommendedNextBase(ByVal modeName As String, ByVal baseId As String, ByVal newPersonId As String) As String

    '�o�^�����l�������̂܂܎��̊�l���ɂ���B

    '�u�����͂��Ă���l���̊֌W�҂𑱂��ēo�^����v������D�悷��B

    RecommendedNextBase = newPersonId

End Function

Private Function NextActionMessage(ByVal modeName As String, ByVal nextBaseId As String) As String

    Dim baseName As String

    baseName = GetPersonValue(nextBaseId, P_DISPLAY)

    NextActionMessage = "���݂̊�l�����u" & baseName & "�v�ɂ��܂����B" & _
        "���́A���̐l���̔z��ҁE���E��E�q�E�Z��o���Ȃǂ��֌W�{�^������ǉ����Ă��������B" & _
        "�ʂ̐l���̊֌W�҂֖߂�ꍇ�́A��l�����őI�Ԃ��u�푊���l�ɖ߂�v�������܂��B"

End Function

Private Sub WriteGuideAfterRegister(ByVal modeName As String, ByVal displayName As String, ByVal nextBaseId As String)

    Dim ws As Worksheet, guide As String, baseName As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    baseName = GetPersonValue(nextBaseId, P_DISPLAY)
    guide = "�o�^�����F" & displayName & "�@���̊�l���F" & baseName & "�@" & NextActionMessage(modeName, nextBaseId)
    ws.Range("B3").Value = Left$(guide, 120)
    Application.StatusBar = guide

End Sub

Private Sub SetPersonInputStatus(ByVal messageText As String)

    On Error Resume Next

    Application.StatusBar = messageText

    ThisWorkbook.Worksheets(SH_INPUT).Range("B3").Value = Left$(CleanText(messageText), 120)

    On Error GoTo 0

End Sub

Private Sub UpdateInputGuide(ByVal modeName As String)

    Dim ws As Worksheet, guide As String, baseId As String, baseName As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)

    baseName = GetPersonValue(baseId, P_DISPLAY)

    Select Case modeName

        Case MODE_DECEDENT

            guide = "�菇1�F�푊���l��o�^���܂��B���E���E���S���E�Z������͂��Ă��������B���S���������J�n���ɂȂ�܂��B�o�^��A�z��ҁA���A��A�q�̏��Ɋ֌W�҂�ǉ����܂��B"

        Case MODE_SPOUSE

            guide = "�z��Ғǉ��F�����������m�F�ł��l���o�^�ł��܂��B���t��������ꍇ�����������E�����������A���m�F��C_�`�F�b�N�Ōォ��ׂ��܂��B�����͕K�v�Ȑl�������͂��܂��B"

        Case MODE_FATHER

            guide = "���ǉ��F���S�ς݂Ȃ玀�S�������A�Ō�̏Z����o�^���Ă��������B���S�����Z���I���Ŏ��S���Z�������܂��B���̔z��҂�o�^����ƕ�Ƃ��Ĉ����܂��B"

        Case MODE_MOTHER

            guide = "��ǉ��F���S�ς݂Ȃ玀�S���ƍŌ�̏Z�������܂��B�����͕�����ꍇ�������͂��܂��B��̔z��҂�o�^����ƕ��Ƃ��Ĉ����܂��B"

        Case MODE_CHILD

            guide = "�q�ǉ��F��l���̎q��o�^���܂��B��l�����z��҂Ȃ�A�������E�������E�q�̐��N��������v�w�̎q�����肵�܂��B�����J�n�O���S�̎q�͑�P�Ҋm�F���K�v�ł��B"

        Case MODE_SIBLING

            guide = "�Z��o���ǉ��F���͔푊���l���̐��������\�����܂��B���ʂƐ��N����������ΌZ�E��E�o�E�����������肵�܂��B"

        Case MODE_GRANDCHILD

            guide = "���E���ʐ���ǉ��F�q�E���E�]���̒��������o�^���܂��B�z��҂���Ɏq������ꍇ�́A�v�w���ԓ��o���Ȃ猌�����v�w�̎q�Ƃ��Đ������낵�܂��B"

        Case Else

            guide = "���̑��֌W�ҁF���ҁE���ҁE�㗝�l�Ȃǂ͐e�q���ɍ����܂���B�e���Ƃ��Č��Ԑl���́A���̑��ł͂Ȃ����E��E�q�E�z��҂Ȃǂ̊֌W�{�^���œo�^���Ă��������B"

    End Select

    If Len(baseName) > 0 Then guide = "��l���F" & baseName & "�@" & guide

    If Len(baseName) > 0 Then
        ws.Range("B3").Value = "���͒��F" & modeName & "�@��l���F" & baseName
    Else
        ws.Range("B3").Value = "���͒��F" & modeName
    End If
    Application.StatusBar = guide

End Sub

Private Function AutoRelationText(ByVal modeName As String, _
        ByVal baseId As String, _
        ByVal gender As String, _
        ByVal birthDate As Variant) As String

    Dim decId As String, baseRel As String

    decId = GetDecedentId()

    baseRel = GetPersonValue(baseId, P_REL_DEC)

    If Len(baseRel) = 0 Then baseRel = "��l��"

    Select Case modeName

        Case MODE_DECEDENT

            AutoRelationText = "�푊���l"

        Case MODE_SPOUSE

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = "�z���"

            ElseIf NormalizedRelationLabel(baseRel) = "��" Then

                AutoRelationText = "��"

            ElseIf NormalizedRelationLabel(baseRel) = "��" Then

                AutoRelationText = "��"

            Else

                AutoRelationText = RelationViaBase(baseRel, "�z���", "�z���")

            End If

        Case MODE_FATHER

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = "��"

            Else

                AutoRelationText = RelationViaBase(baseRel, "��", "��")

            End If

        Case MODE_MOTHER

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = "��"

            Else

                AutoRelationText = RelationViaBase(baseRel, "��", "��")

            End If

        Case MODE_CHILD

            If Len(baseId) > 0 And baseId <> decId Then

                If BaseIsDirectChildRelation(baseRel) Then

                    AutoRelationText = "��"

                ElseIf BaseIsGrandchildRelation(baseRel) Then

                    AutoRelationText = "�]��"

                Else

                    AutoRelationText = RelationViaBase(baseRel, "�q", "�q")

                End If

            Else

                AutoRelationText = ChildRelationText(gender)

            End If

        Case MODE_SIBLING

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = SiblingRelationText(gender, birthDate)

            Else

                AutoRelationText = RelationViaBase(baseRel, "�Z��o��", "�Z��o��")

            End If

        Case MODE_GRANDCHILD

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = "��"

            ElseIf BaseIsDirectChildRelation(baseRel) Then

                AutoRelationText = "��"

            ElseIf BaseIsGrandchildRelation(baseRel) Then

                AutoRelationText = "�]��"

            ElseIf BaseIsGreatGrandchildRelation(baseRel) Then

                AutoRelationText = "����"

            Else

                AutoRelationText = RelationViaBase(baseRel, "�q", "��")

            End If

        Case Else

            If Len(baseId) > 0 And baseId <> decId Then

                AutoRelationText = RelationViaBase(baseRel, "�֌W��", "�֌W��")

            Else

                AutoRelationText = "�֌W��"

            End If

    End Select

End Function

Private Function ResolveRelationTextForRegistration(ByVal modeName As String, _
        ByVal baseId As String, _
        ByVal currentText As String, _
        ByVal gender As String, _
        ByVal birthDate As Variant) As String

    Dim suggested As String
    Dim bloodlineId As String, baseRel As String, bloodRel As String
    Dim marriageDate As Variant, divorceDate As Variant
    Dim level As Long, nextRel As String

    suggested = currentText
    If ShouldRecalculateAutoRelation(modeName, suggested) Then
        suggested = AutoRelationText(modeName, baseId, gender, birthDate)
    End If

    If modeName = MODE_CHILD Or modeName = MODE_GRANDCHILD Then
        baseRel = GetPersonValue(baseId, P_REL_DEC)
        If IsBaseSpouseOfDescendant(baseId, bloodlineId, marriageDate, divorceDate, birthDate) Then
            bloodRel = GetPersonValue(bloodlineId, P_REL_DEC)
            level = DescendantLevelFromRelation(bloodRel)
            nextRel = NextDescendantRelation(level)
            If Len(nextRel) = 0 Then nextRel = "�q"
            ResolveRelationTextForRegistration = nextRel
            Exit Function
        ElseIf FindBaseDescendantSpouseCandidate(baseId, bloodlineId, marriageDate, divorceDate) Then
            If Not HasInputDate(birthDate) Then
                ResolveRelationTextForRegistration = SpouseSideChildRelationLabel(baseId, "�o���N�����v�m�F")
            ElseIf Not HasInputDate(marriageDate) Then
                ResolveRelationTextForRegistration = SpouseSideChildRelationLabel(baseId, "�������v�m�F")
            ElseIf DateWithinMarriagePeriod(birthDate, marriageDate, divorceDate) Then
                bloodRel = GetPersonValue(bloodlineId, P_REL_DEC)
                level = DescendantLevelFromRelation(bloodRel)
                nextRel = NextDescendantRelation(level)
                If Len(nextRel) = 0 Then nextRel = "�q"
                ResolveRelationTextForRegistration = nextRel
            Else
                ResolveRelationTextForRegistration = SpouseSideChildRelationLabel(baseId, "�������ԊO")
            End If
            Exit Function
        End If

        level = DescendantLevelFromRelation(baseRel)
        If level >= 1 Then
            nextRel = NextDescendantRelation(level)
            If HasSpousePeriodForPerson(baseId, marriageDate, divorceDate, birthDate) Then
                If Not HasInputDate(birthDate) Then
                    ResolveRelationTextForRegistration = nextRel & "�i�������ԗv�m�F�j"
                    Exit Function
                ElseIf Not HasInputDate(marriageDate) Then
                    ResolveRelationTextForRegistration = nextRel & "�i�������ԗv�m�F�j"
                    Exit Function
                ElseIf Not DateWithinMarriagePeriod(birthDate, marriageDate, divorceDate) Then
                    ResolveRelationTextForRegistration = nextRel & "�i�O�z��҂Ƃ̎q�j"
                    Exit Function
                End If
            End If
            ResolveRelationTextForRegistration = nextRel
            Exit Function
        End If
    End If

    ResolveRelationTextForRegistration = suggested

End Function

Private Function RelationBaseForRegistration(ByVal modeName As String, ByVal baseId As String, ByVal birthDate As Variant) As String

    Dim bloodlineId As String, marriageDate As Variant, divorceDate As Variant
    RelationBaseForRegistration = baseId
    If modeName = MODE_CHILD Or modeName = MODE_GRANDCHILD Then
        If IsBaseSpouseOfDescendant(baseId, bloodlineId, marriageDate, divorceDate, birthDate) Then
            If HasInputDate(birthDate) Then
                If DateWithinMarriagePeriod(birthDate, marriageDate, divorceDate) Then RelationBaseForRegistration = bloodlineId
            End If
        End If
    End If

End Function

Private Function DescendantLevelFromRelation(ByVal relText As String) As Long

    DescendantLevelFromRelation = RelationshipDescendantLevel(relText)

End Function

Private Function IsGreatGrandchildLabelText(ByVal relText As String) As Boolean

    relText = CleanText(relText)
    If relText = "�]��" Or Left$(relText, 2) = "�]��" Then
        IsGreatGrandchildLabelText = True
    ElseIf relText = "�\��" Or Left$(relText, 2) = "�\��" Then
        IsGreatGrandchildLabelText = True
    ElseIf relText = "�Б�" Or Left$(relText, 3) = "�Б�" Then
        IsGreatGrandchildLabelText = True
    End If

End Function

Private Function RelationTextContainsGreatGrandchildLabel(ByVal relText As String) As Boolean

    relText = CleanText(relText)
    If InStr(relText, "�]��") > 0 Then
        RelationTextContainsGreatGrandchildLabel = True
    ElseIf InStr(relText, "�\��") > 0 Then
        RelationTextContainsGreatGrandchildLabel = True
    ElseIf InStr(relText, "�Б�") > 0 Then
        RelationTextContainsGreatGrandchildLabel = True
    End If

End Function

Private Function NextDescendantRelation(ByVal parentLevel As Long) As String

    NextDescendantRelation = RelationshipDescendantLabel(parentLevel + 1)
    If Len(NextDescendantRelation) = 0 Then NextDescendantRelation = "�q"

End Function

Private Function SpouseSideChildRelationLabel(ByVal baseId As String, ByVal reasonText As String) As String
    Dim baseRel As String
    baseRel = CleanText(GetPersonValue(baseId, P_REL_DEC))
    If Len(baseRel) = 0 Then baseRel = CleanText(GetPersonValue(baseId, P_REL_DISP))
    If Len(baseRel) = 0 Then baseRel = "�z���"
    reasonText = CleanText(reasonText)
    If Len(reasonText) > 0 Then
        SpouseSideChildRelationLabel = baseRel & "�̎q�i" & reasonText & "�j"
    Else
        SpouseSideChildRelationLabel = baseRel & "�̎q"
    End If
End Function

Private Function IsBaseSpouseOfDescendant(ByVal baseId As String, _
        ByRef bloodlineId As String, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant, _
        Optional ByVal targetDate As Variant) As Boolean

    Dim wr As Worksheet, r As Long, otherId As String, otherRel As String
    Dim firstBloodId As String, firstMarriage As Variant, firstDivorce As Variant
    Dim baseRow As Long, storedBaseId As String, storedRel As String, baseRelText As String
    Dim m As Variant, d As Variant
    baseId = CleanText(baseId)
    If Len(baseId) = 0 Then Exit Function

    '��l�����u���̔z��ҁv�Ȃǂ̏ꍇ�A�o�^���ID���猌�����̖{�l���ɋ~�ς���B
    '�������o���N�������v�w���ԊO�Ȃ�A�v�w�̎q�Ƃ��Ă͈���Ȃ��B
    baseRow = FindPersonRow(baseId)
    If baseRow > 0 Then
        baseRelText = CleanText(GetPersonValue(baseId, P_REL_DEC)) & " " & CleanText(GetPersonValue(baseId, P_REL_DISP))
        If InStr(1, baseRelText, "�z���", vbTextCompare) > 0 Then
            storedBaseId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(baseRow, P_SUR_SRC).Value)
            storedRel = CleanText(GetPersonValue(storedBaseId, P_REL_DEC))
            If DescendantLevelFromRelation(storedRel) >= 1 Then
                EffectiveRegistrationSpouseDatesForPair baseId, storedBaseId, Empty, Empty, m, d, targetDate
                If DateWithinMarriagePeriod(targetDate, m, d) Then
                    bloodlineId = storedBaseId
                    marriageDate = m
                    divorceDate = d
                    IsBaseSpouseOfDescendant = True
                    Exit Function
                ElseIf Len(firstBloodId) = 0 Then
                    firstBloodId = storedBaseId
                    firstMarriage = m
                    firstDivorce = d
                End If
            End If
        End If
    End If

    If Not SheetExists(SH_W_REL, ThisWorkbook) Then GoTo FallbackOnly
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And DiagramGraphIsSpouseRelationType(CStr(wr.Cells(r, R_TYPE).Value)) Then
            otherId = ""
            If CleanText(wr.Cells(r, R_BASE_ID).Value) = baseId Then
                otherId = CleanText(wr.Cells(r, R_OTHER_ID).Value)
            ElseIf CleanText(wr.Cells(r, R_OTHER_ID).Value) = baseId Then
                otherId = CleanText(wr.Cells(r, R_BASE_ID).Value)
            End If
            If Len(otherId) > 0 Then
                otherRel = GetPersonValue(otherId, P_REL_DEC)
                If DescendantLevelFromRelation(otherRel) >= 1 Then
                    EffectiveRegistrationSpouseDatesForPair baseId, otherId, wr.Cells(r, R_MARRIAGE).Value, wr.Cells(r, R_DIVORCE).Value, m, d, targetDate
                    If Len(firstBloodId) = 0 Then
                        firstBloodId = otherId
                        firstMarriage = m
                        firstDivorce = d
                    End If
                    If DateWithinMarriagePeriod(targetDate, m, d) Then
                        bloodlineId = otherId
                        marriageDate = m
                        divorceDate = d
                        IsBaseSpouseOfDescendant = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r

FallbackOnly:
    '�v�w�̎q�Ƃ��Č������֊񂹂�̂́A�������Əo���N����������ԓ��o���Ɗm��ł���ꍇ�����B
    '�����͓��͕⏕���ŕʓr�g�����߁A�����ł͖��m��� True �ɂ��Ȃ��B

End Function

Private Function FindBaseDescendantSpouseCandidate(ByVal baseId As String, _
        ByRef bloodlineId As String, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant) As Boolean
    Dim wr As Worksheet, r As Long, otherId As String, otherRel As String
    Dim baseRow As Long, storedBaseId As String, storedRel As String, baseRelText As String
    Dim m As Variant, d As Variant
    baseId = CleanText(baseId)
    If Len(baseId) = 0 Then Exit Function

    baseRow = FindPersonRow(baseId)
    If baseRow > 0 Then
        baseRelText = CleanText(GetPersonValue(baseId, P_REL_DEC)) & " " & CleanText(GetPersonValue(baseId, P_REL_DISP))
        If InStr(1, baseRelText, "�z���", vbTextCompare) > 0 Then
            storedBaseId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(baseRow, P_SUR_SRC).Value)
            storedRel = CleanText(GetPersonValue(storedBaseId, P_REL_DEC))
            If DescendantLevelFromRelation(storedRel) >= 1 Then
                EffectiveRegistrationSpouseDatesForPair baseId, storedBaseId, Empty, Empty, m, d
                bloodlineId = storedBaseId
                marriageDate = m
                divorceDate = d
                FindBaseDescendantSpouseCandidate = True
                Exit Function
            End If
        End If
    End If

    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And DiagramGraphIsSpouseRelationType(CStr(wr.Cells(r, R_TYPE).Value)) Then
            otherId = ""
            If CleanText(wr.Cells(r, R_BASE_ID).Value) = baseId Then
                otherId = CleanText(wr.Cells(r, R_OTHER_ID).Value)
            ElseIf CleanText(wr.Cells(r, R_OTHER_ID).Value) = baseId Then
                otherId = CleanText(wr.Cells(r, R_BASE_ID).Value)
            End If
            If Len(otherId) > 0 Then
                otherRel = GetPersonValue(otherId, P_REL_DEC)
                If DescendantLevelFromRelation(otherRel) >= 1 Then
                    EffectiveRegistrationSpouseDatesForPair baseId, otherId, wr.Cells(r, R_MARRIAGE).Value, wr.Cells(r, R_DIVORCE).Value, m, d
                    bloodlineId = otherId
                    marriageDate = m
                    divorceDate = d
                    FindBaseDescendantSpouseCandidate = True
                    Exit Function
                End If
            End If
        End If
    Next r
End Function

Private Function SpouseRelationDatesForPair(ByVal leftId As String, ByVal rightId As String, ByRef marriageDate As Variant, ByRef divorceDate As Variant) As Boolean

    Dim wr As Worksheet, r As Long, b As String, o As String
    Dim hasRelation As Boolean
    leftId = CleanText(leftId)
    rightId = CleanText(rightId)
    If Len(leftId) = 0 Or Len(rightId) = 0 Then Exit Function

    If SheetExists(SH_W_REL, ThisWorkbook) Then
        Set wr = ThisWorkbook.Worksheets(SH_W_REL)
        For r = 2 To LastRow(wr, 1)
            If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And DiagramGraphIsSpouseRelationType(CStr(wr.Cells(r, R_TYPE).Value)) Then
                b = CleanText(wr.Cells(r, R_BASE_ID).Value)
                o = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                If (b = leftId And o = rightId) Or (b = rightId And o = leftId) Then
                    EffectiveRegistrationSpouseDatesForPair leftId, rightId, wr.Cells(r, R_MARRIAGE).Value, wr.Cells(r, R_DIVORCE).Value, marriageDate, divorceDate
                    SpouseRelationDatesForPair = True
                    Exit Function
                End If
            End If
        Next r
    End If

    '�z��ҍs�̍������E����������A�܂��͔z��ҍs���̂����쐬�ł��A�l���{�l�̍������E�����������Ԕ���Ɏg���B
    EffectiveRegistrationSpouseDatesForPair leftId, rightId, Empty, Empty, marriageDate, divorceDate
    If HasInputDate(marriageDate) Or HasInputDate(divorceDate) Then SpouseRelationDatesForPair = True

End Function

Private Function IsBaseSpouseOfDirectChild(ByVal baseId As String, _
        ByRef directChildId As String, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant) As Boolean

    Dim wr As Worksheet, r As Long, otherId As String
    If Len(baseId) = 0 Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And DiagramGraphIsSpouseRelationType(CStr(wr.Cells(r, R_TYPE).Value)) Then
            otherId = ""
            If CStr(wr.Cells(r, R_BASE_ID).Value) = baseId Then
                otherId = CStr(wr.Cells(r, R_OTHER_ID).Value)
            ElseIf CStr(wr.Cells(r, R_OTHER_ID).Value) = baseId Then
                otherId = CStr(wr.Cells(r, R_BASE_ID).Value)
            End If
            If Len(otherId) > 0 Then
                If BaseIsDirectChildRelation(GetPersonValue(otherId, P_REL_DEC)) Then
                    directChildId = otherId
                    marriageDate = wr.Cells(r, R_MARRIAGE).Value
                    divorceDate = wr.Cells(r, R_DIVORCE).Value
                    IsBaseSpouseOfDirectChild = True
                    Exit Function
                End If
            End If
        End If
    Next r

End Function

Private Function IsBaseSpouseOfGrandchild(ByVal baseId As String, _
        ByRef grandChildId As String, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant) As Boolean

    Dim wr As Worksheet, r As Long, otherId As String
    If Len(baseId) = 0 Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And DiagramGraphIsSpouseRelationType(CStr(wr.Cells(r, R_TYPE).Value)) Then
            otherId = ""
            If CStr(wr.Cells(r, R_BASE_ID).Value) = baseId Then
                otherId = CStr(wr.Cells(r, R_OTHER_ID).Value)
            ElseIf CStr(wr.Cells(r, R_OTHER_ID).Value) = baseId Then
                otherId = CStr(wr.Cells(r, R_BASE_ID).Value)
            End If
            If Len(otherId) > 0 Then
                If BaseIsGrandchildRelation(GetPersonValue(otherId, P_REL_DEC)) Then
                    grandChildId = otherId
                    marriageDate = wr.Cells(r, R_MARRIAGE).Value
                    divorceDate = wr.Cells(r, R_DIVORCE).Value
                    IsBaseSpouseOfGrandchild = True
                    Exit Function
                End If
            End If
        End If
    Next r

End Function

Private Function HasSpousePeriodForPerson(ByVal personId As String, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant, _
        Optional ByVal targetDate As Variant) As Boolean

    Dim wr As Worksheet, wp As Worksheet, r As Long, personRow As Long
    Dim firstM As Variant, firstD As Variant, hasAny As Boolean
    Dim otherId As String, m As Variant, d As Variant
    personId = CleanText(personId)
    If Len(personId) = 0 Then Exit Function

    If SheetExists(SH_W_REL, ThisWorkbook) Then
        Set wr = ThisWorkbook.Worksheets(SH_W_REL)
        For r = 2 To LastRow(wr, 1)
            If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And DiagramGraphIsSpouseRelationType(CStr(wr.Cells(r, R_TYPE).Value)) Then
                otherId = ""
                If CleanText(wr.Cells(r, R_BASE_ID).Value) = personId Then
                    otherId = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                ElseIf CleanText(wr.Cells(r, R_OTHER_ID).Value) = personId Then
                    otherId = CleanText(wr.Cells(r, R_BASE_ID).Value)
                End If
                If Len(otherId) > 0 Then
                    EffectiveRegistrationSpouseDatesForPair personId, otherId, wr.Cells(r, R_MARRIAGE).Value, wr.Cells(r, R_DIVORCE).Value, m, d, targetDate
                    If HasInputDate(m) Or HasInputDate(d) Then
                        If Not hasAny Then
                            firstM = m
                            firstD = d
                            hasAny = True
                        End If
                        If Not HasInputDate(targetDate) Or DateWithinMarriagePeriod(targetDate, m, d) Then
                            marriageDate = m
                            divorceDate = d
                            HasSpousePeriodForPerson = True
                            Exit Function
                        End If
                    End If
                End If
            End If
        Next r
    End If

    '�z��҂�l���o�^���Ă��Ȃ����������A��������̍������ԂƂ��Ďg���B
    If ManualMarriagePeriodForPerson(personId, targetDate, marriageDate, divorceDate) Then
        If Not hasAny Then
            firstM = marriageDate
            firstD = divorceDate
            hasAny = True
        End If
        If Not HasInputDate(targetDate) Or DateWithinMarriagePeriod(targetDate, marriageDate, divorceDate) Then
            HasSpousePeriodForPerson = True
            Exit Function
        End If
    End If

    personRow = FindPersonRow(personId)
    If personRow > 0 Then
        Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
        If HasInputDate(wp.Cells(personRow, P_MARRIAGE).Value) Or HasInputDate(wp.Cells(personRow, P_DIVORCE).Value) Then
            If Not hasAny Then
                firstM = wp.Cells(personRow, P_MARRIAGE).Value
                firstD = wp.Cells(personRow, P_DIVORCE).Value
                hasAny = True
            End If
            If Not HasInputDate(targetDate) Or DateWithinMarriagePeriod(targetDate, wp.Cells(personRow, P_MARRIAGE).Value, wp.Cells(personRow, P_DIVORCE).Value) Then
                marriageDate = wp.Cells(personRow, P_MARRIAGE).Value
                divorceDate = wp.Cells(personRow, P_DIVORCE).Value
                HasSpousePeriodForPerson = True
                Exit Function
            End If
        End If
    End If

    If hasAny Then
        marriageDate = firstM
        divorceDate = firstD
        HasSpousePeriodForPerson = True
    End If

End Function

Private Function ManualMarriagePeriodForPerson(ByVal personId As String, _
        ByVal targetDate As Variant, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant) As Boolean

    Dim we As Worksheet, r As Long, d As Date, t As Date
    Dim firstM As Variant, firstD As Variant, bestM As Variant, bestD As Variant
    Dim hasAny As Boolean, m As Variant, dAfterM As Variant
    If Len(personId) = 0 Then Exit Function
    If Not SheetExists(SH_W_EVENT, ThisWorkbook) Then Exit Function
    Set we = ThisWorkbook.Worksheets(SH_W_EVENT)

    For r = 2 To LastRow(we, 1)
        If CStr(we.Cells(r, E_PERSON_ID).Value) = personId _
                And CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL _
                And HasInputDate(we.Cells(r, E_DATE).Value) Then
            If CStr(we.Cells(r, E_TYPE).Value) = "����" Or CStr(we.Cells(r, E_TYPE).Value) = "����" Then
                If Not hasAny Then
                    If CStr(we.Cells(r, E_TYPE).Value) = "����" Then firstM = we.Cells(r, E_DATE).Value Else firstD = we.Cells(r, E_DATE).Value
                    hasAny = True
                End If
                If CStr(we.Cells(r, E_TYPE).Value) = "����" Then
                    If Not HasInputDate(firstM) Then
                        firstM = we.Cells(r, E_DATE).Value
                    ElseIf CDate(SameDateOrBlank(we.Cells(r, E_DATE).Value)) < CDate(SameDateOrBlank(firstM)) Then
                        firstM = we.Cells(r, E_DATE).Value
                    End If
                ElseIf CStr(we.Cells(r, E_TYPE).Value) = "����" Then
                    If Not HasInputDate(firstD) Then
                        firstD = we.Cells(r, E_DATE).Value
                    ElseIf CDate(SameDateOrBlank(we.Cells(r, E_DATE).Value)) < CDate(SameDateOrBlank(firstD)) Then
                        firstD = we.Cells(r, E_DATE).Value
                    End If
                End If
            End If
        End If
    Next r
    If Not hasAny Then Exit Function

    If HasInputDate(targetDate) Then
        t = CDate(SameDateOrBlank(targetDate))
        'target���ȑO�̍ŐV������T���B
        For r = 2 To LastRow(we, 1)
            If CStr(we.Cells(r, E_PERSON_ID).Value) = personId _
                    And CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL _
                    And CStr(we.Cells(r, E_TYPE).Value) = "����" _
                    And HasInputDate(we.Cells(r, E_DATE).Value) Then
                d = CDate(SameDateOrBlank(we.Cells(r, E_DATE).Value))
                If d <= t Then
                    If Not HasInputDate(bestM) Then
                        bestM = d
                    ElseIf d > CDate(SameDateOrBlank(bestM)) Then
                        bestM = d
                    End If
                End If
            End If
        Next r
        If HasInputDate(bestM) Then
            '���̍�����̍ŏ��̗�����T���B
            For r = 2 To LastRow(we, 1)
                If CStr(we.Cells(r, E_PERSON_ID).Value) = personId _
                        And CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL _
                        And CStr(we.Cells(r, E_TYPE).Value) = "����" _
                        And HasInputDate(we.Cells(r, E_DATE).Value) Then
                    d = CDate(SameDateOrBlank(we.Cells(r, E_DATE).Value))
                    If d >= CDate(SameDateOrBlank(bestM)) Then
                        If Not HasInputDate(dAfterM) Then
                            dAfterM = d
                        ElseIf d < CDate(SameDateOrBlank(dAfterM)) Then
                            dAfterM = d
                        End If
                    End If
                End If
            Next r
            marriageDate = bestM
            divorceDate = dAfterM
            ManualMarriagePeriodForPerson = True
            Exit Function
        End If
    End If

    marriageDate = firstM
    divorceDate = firstD
    ManualMarriagePeriodForPerson = True

End Function


Private Sub EffectiveRegistrationSpouseDatesForPair(ByVal leftId As String, _
        ByVal rightId As String, _
        ByVal relationMarriageDate As Variant, _
        ByVal relationDivorceDate As Variant, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant, _
        Optional ByVal targetDate As Variant)
    marriageDate = Empty
    divorceDate = Empty

    '���������m�F�ŏC�����ꂽ���t���ŗD�悷��B
    '�l���\�E�֌W�\�������ɓǂނƁA�m�F��ʂŒ��������������v�w�q����֓͂��Ȃ��B
    If MarriageHistoryTryGetPairPeriod(leftId, rightId, targetDate, marriageDate, divorceDate) Then Exit Sub
    '�����s�����݂���̂ɓ��t����A�܂��͎���ς݂Ȃ�A����̎c�[�֖߂�Ȃ��B
    'W_���������𐳖{�Ƃ���ȏ�A�u�L�^����E���ԕs���v�����m�ȏ�ԂƂ��Ĉ����B
    If MarriageHistoryPairHasRecord(leftId, rightId, True) Then Exit Sub

    If HasInputDate(relationMarriageDate) Then marriageDate = SameDateOrBlank(relationMarriageDate)
    If HasInputDate(relationDivorceDate) Then divorceDate = SameDateOrBlank(relationDivorceDate)
    If Not HasInputDate(marriageDate) Then marriageDate = PersonMarriageFactDateForRegistration(leftId, True)
    If Not HasInputDate(marriageDate) Then marriageDate = PersonMarriageFactDateForRegistration(rightId, True)
    If Not HasInputDate(divorceDate) Then divorceDate = PersonMarriageFactDateForRegistration(leftId, False)
    If Not HasInputDate(divorceDate) Then divorceDate = PersonMarriageFactDateForRegistration(rightId, False)
End Sub

Private Function PersonMarriageFactDateForRegistration(ByVal personId As String, ByVal wantMarriage As Boolean) As Variant
    Dim rowNo As Long, v As Variant
    personId = CleanText(personId)
    If Len(personId) = 0 Then Exit Function
    rowNo = FindPersonRow(personId)
    If rowNo <= 0 Then Exit Function
    If wantMarriage Then
        v = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(rowNo, P_MARRIAGE).Value
    Else
        v = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(rowNo, P_DIVORCE).Value
    End If
    If HasInputDate(v) Then PersonMarriageFactDateForRegistration = SameDateOrBlank(v)
End Function

Private Function DateWithinMarriagePeriod(ByVal targetDate As Variant, ByVal marriageDate As Variant, ByVal divorceDate As Variant) As Boolean

    Dim t As Variant, m As Variant, d As Variant
    t = SameDateOrBlank(targetDate)
    m = SameDateOrBlank(marriageDate)
    d = SameDateOrBlank(divorceDate)
    If Not HasInputDate(t) Then Exit Function
    '�v�w�̎q����́A�����J�n�����m�F�ł���ꍇ�����m�舵���ɂ���B
    If Not HasInputDate(m) Then Exit Function
    If CDate(t) < CDate(m) Then Exit Function
    If HasInputDate(d) Then
        If CDate(t) > CDate(d) Then Exit Function
    End If
    DateWithinMarriagePeriod = True

End Function

Private Function RelationViaBase(ByVal baseRel As String, ByVal suffixText As String, ByVal fallbackText As String) As String

    baseRel = CleanText(baseRel)

    If Len(baseRel) = 0 Or baseRel = "�푊���l" Then

        RelationViaBase = fallbackText

    ElseIf InStr(baseRel, "��") > 0 Then

        RelationViaBase = baseRel & "�E" & suffixText

    Else

        RelationViaBase = baseRel & "��" & suffixText

    End If

End Function

Private Function BaseIsDirectChildRelation(ByVal baseRel As String) As Boolean

    baseRel = CleanText(baseRel)
    If InStr(baseRel, "�i") > 0 Then baseRel = Left$(baseRel, InStr(baseRel, "�i") - 1)
    If baseRel = "�q" Or baseRel = "�{�q" Then
        BaseIsDirectChildRelation = True
    ElseIf ChildOrdinalIndex(baseRel, "�j") > 0 Or ChildOrdinalIndex(baseRel, "��") > 0 Then
        BaseIsDirectChildRelation = True
    End If

End Function

Private Function BaseIsGrandchildRelation(ByVal baseRel As String) As Boolean

    baseRel = CleanText(baseRel)
    If InStr(baseRel, "�z���") > 0 Then Exit Function
    BaseIsGrandchildRelation = (baseRel = "��" Or Left$(baseRel, 2) = "���i")

End Function

Private Function BaseIsGreatGrandchildRelation(ByVal baseRel As String) As Boolean

    baseRel = CleanText(baseRel)
    If InStr(baseRel, "�z���") > 0 Then Exit Function
    BaseIsGreatGrandchildRelation = IsGreatGrandchildLabelText(baseRel)

End Function


Private Function IsDirectDescendantRelationText(ByVal relText As String) As Boolean

    IsDirectDescendantRelationText = (RelationshipDescendantLevel(relText) > 0)

End Function

Private Function SuggestedGender(ByVal modeName As String, ByVal baseId As String) As String

    Dim baseGender As String

    Select Case modeName

        Case MODE_FATHER

            SuggestedGender = "�j"

        Case MODE_MOTHER

            SuggestedGender = "��"

        Case MODE_SPOUSE

            baseGender = GetPersonValue(baseId, P_GENDER)

            If baseGender = "�j" Then

                SuggestedGender = "��"

            ElseIf baseGender = "��" Then

                SuggestedGender = "�j"

            End If

    End Select

End Function


Private Function NormalizedRelationLabel(ByVal relText As String) As String

    NormalizedRelationLabel = RelationshipCanonicalStoredLabel(relText)

End Function

Public Function RepairStoredRelationshipLabelsFromGraph() As Long
    '�����f�[�^�͊m��eID�𐳂Ƃ��Đ����1�񂾂��v�Z���A�ۑ��ςݑ����𒼂��B
    '�����񂾂��Ō������]���Ɩ߂��Ɩ{���̌����܂ŉ󂷂��߁A�e���m�肵���l��������Ώۂɂ���B
    On Error GoTo EH
    Dim wp As Worksheet, r As Long, pid As String, rawRel As String, canonicalRel As String
    Dim graphRel As String, parentId As String, fixedRel As String, noteSuffix As String
    Dim currentLevel As Long, expectedLevel As Long, changed As Long
    Dim decId As String

    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Function
    decId = GetDecedentId()
    If Len(decId) = 0 Then Exit Function
    If Not DiagramGraphRebuildFresh(decId, False) Then Exit Function

    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, P_ID)
        If CleanText(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            pid = CleanText(wp.Cells(r, P_ID).Value)
            If Len(pid) > 0 And pid <> decId And Not DiagramGraphIsPureSpouseId(pid) Then
                parentId = DiagramGraphParentIdForChildId(pid)
                If Len(parentId) > 0 And parentId <> pid Then
                    rawRel = CleanText(wp.Cells(r, P_REL_DEC).Value)
                    canonicalRel = RelationshipCanonicalStoredLabel(rawRel)
                    graphRel = DiagramGraphDisplayRelation(pid, canonicalRel)
                    currentLevel = RelationshipDescendantLevel(canonicalRel)
                    expectedLevel = RelationshipDescendantLevel(graphRel)
                    If expectedLevel >= 1 Then
                        noteSuffix = RelationshipNoteSuffix(rawRel)
                        If currentLevel <> expectedLevel Then
                            If expectedLevel = 1 And RelationshipDescendantLevel(graphRel) = 1 Then
                                fixedRel = RelationshipStructuralText(graphRel) & noteSuffix
                            Else
                                fixedRel = RelationshipDescendantLabel(expectedLevel) & noteSuffix
                            End If
                        Else
                            fixedRel = canonicalRel
                        End If

                        If Len(fixedRel) > 0 Then
                            If CleanText(wp.Cells(r, P_REL_DEC).Value) <> fixedRel _
                                    Or CleanText(wp.Cells(r, P_REL_DISP).Value) <> fixedRel _
                                    Or CleanText(wp.Cells(r, P_SUR_SRC).Value) <> parentId Then
                                wp.Cells(r, P_REL_DEC).Value = fixedRel
                                wp.Cells(r, P_REL_DISP).Value = fixedRel
                                wp.Cells(r, P_SUR_SRC).Value = parentId
                                wp.Cells(r, P_UPDATED).Value = Now
                                RepairStoredParentRelationRow parentId, pid, fixedRel
                                changed = changed + 1
                            End If
                        End If
                    End If
                End If
            End If
        End If
    Next r

    RepairStoredRelationshipLabelsFromGraph = changed
    DiagramGraphReset
    Exit Function
EH:
    RuntimeAppendLog "WARN", "RepairStoredRelationshipLabelsFromGraph", "�����ۑ��l�C��", _
        "�m��ł����l���܂ŏC�����A�c��͕ύX���Ă��܂���B", Err.Number, Err.Description, Err.Source
    RepairStoredRelationshipLabelsFromGraph = changed
    DiagramGraphReset
End Function

Private Sub RepairStoredParentRelationRow(ByVal parentId As String, ByVal childId As String, ByVal relationText As String)
    Dim wr As Worksheet, r As Long, a As String, b As String
    If Len(parentId) = 0 Or Len(childId) = 0 Then Exit Sub
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, R_ID)
        If CleanText(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL _
                And DiagramGraphIsParentChildRelationRow(wr, r) Then
            a = CleanText(wr.Cells(r, R_BASE_ID).Value)
            b = CleanText(wr.Cells(r, R_OTHER_ID).Value)
            If (a = parentId And b = childId) Or (a = childId And b = parentId) Then
                wr.Cells(r, R_BASE_ID).Value = parentId
                wr.Cells(r, R_OTHER_ID).Value = childId
                wr.Cells(r, R_DISPLAY).Value = relationText
                wr.Cells(r, R_UPDATED).Value = Now
                Exit Sub
            End If
        End If
    Next r
End Sub

Private Function RelationLabelWithNotes(ByVal baseLabel As String, ByVal rawText As String) As String

    Dim s As String
    s = baseLabel
    rawText = CleanText(rawText)
    If InStr(rawText, "�O�z���") > 0 Then
        If InStr(s, "�O�z���") = 0 Then s = s & "�i�O�z��҂Ƃ̎q�j"
    ElseIf InStr(rawText, "�������ԗv�m�F") > 0 Then
        If InStr(s, "�������ԗv�m�F") = 0 Then s = s & "�i�������ԗv�m�F�j"
    End If
    RelationLabelWithNotes = s

End Function

Public Sub RefreshCurrentRelationText()

    Dim ws As Worksheet, modeName As String, baseId As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    modeName = CleanText(ws.Range(CELL_MODE).Value)

    If Len(modeName) = 0 Then Exit Sub

    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)

    ws.Range(CELL_REL_TO_DECEDENT).Value = ResolveRelationTextForRegistration(modeName, baseId, _
        CleanText(ws.Range(CELL_REL_TO_DECEDENT).Value), CleanText(ws.Range(CELL_GENDER).Value), ws.Range(CELL_BIRTH).Value)

End Sub

Private Function ChildRelationText(ByVal gender As String) As String

    If gender = "�j" Then
        ChildRelationText = ChildOrdinalLabel("�j", NextChildOrdinal("�j"))
    ElseIf gender = "��" Then
        ChildRelationText = ChildOrdinalLabel("��", NextChildOrdinal("��"))
    Else
        ChildRelationText = "�q"
    End If

End Function

Private Function CountRelationStartsWith(ByVal a As String, ByVal b As String, ByVal c As String, ByVal g As String) As Long

    Dim ws As Worksheet, r As Long, lastR As Long, v As String

    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        v = CStr(ws.Cells(r, P_REL_DEC).Value)

        If v = a Or v = b Or v = c Or InStr(v, g) > 0 Then CountRelationStartsWith = CountRelationStartsWith + 1

    Next r

End Function

Private Function ShouldRecalculateAutoRelation(ByVal modeName As String, ByVal relText As String) As Boolean

    relText = CleanText(relText)
    If Len(relText) = 0 Then
        ShouldRecalculateAutoRelation = True
        Exit Function
    End If
    If relText = "�q" Or relText = "�Z��o��" Or relText = "��l���̎q" Then
        ShouldRecalculateAutoRelation = True
        Exit Function
    End If
    Select Case modeName
        Case MODE_CHILD
            ShouldRecalculateAutoRelation = IsDirectChildAutoRelation(relText) _
                Or InStr(1, relText, "�������ԗv�m�F", vbTextCompare) > 0 _
                Or InStr(1, relText, "�O�z��҂Ƃ̎q", vbTextCompare) > 0
        Case MODE_SIBLING
            ShouldRecalculateAutoRelation = (relText = "�Z" Or relText = "��" Or relText = "�o" Or relText = "��" _
                Or relText = "�Z��" Or relText = "�o��" Or relText = "�Z��o��")
        Case MODE_GRANDCHILD
            ShouldRecalculateAutoRelation = (relText = "��" Or relText = "�]��" Or relText = "�Б�" Or relText = "�\��" Or relText = "����" _
                Or InStr(1, relText, "�������ԗv�m�F", vbTextCompare) > 0 _
                Or InStr(1, relText, "�O�z��҂Ƃ̎q", vbTextCompare) > 0)
        Case MODE_FATHER, MODE_MOTHER, MODE_SPOUSE
            ShouldRecalculateAutoRelation = (relText = modeName Or InStr(1, relText, "��" & modeName, vbTextCompare) > 0)
    End Select

End Function

Private Function IsDirectChildAutoRelation(ByVal relText As String) As Boolean

    relText = CleanText(relText)
    If InStr(relText, "�i") > 0 Then relText = Left$(relText, InStr(relText, "�i") - 1)
    If relText = "�q" Then
        IsDirectChildAutoRelation = True
    ElseIf ChildOrdinalIndex(relText, "�j") > 0 Or ChildOrdinalIndex(relText, "��") > 0 Then
        IsDirectChildAutoRelation = True
    End If

End Function

Private Function NextChildOrdinal(ByVal gender As String) As Long

    Dim ws As Worksheet, r As Long, lastR As Long, relText As String, idx As Long, maxIdx As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            relText = CleanText(ws.Cells(r, P_REL_DEC).Value)
            idx = ChildOrdinalIndex(relText, gender)
            If idx > maxIdx Then maxIdx = idx
        End If
    Next r
    NextChildOrdinal = maxIdx + 1
    If NextChildOrdinal < 1 Then NextChildOrdinal = 1

End Function

Private Function ChildOrdinalIndex(ByVal relText As String, ByVal gender As String) As Long

    relText = CleanText(relText)
    If InStr(relText, "�i") > 0 Then relText = Left$(relText, InStr(relText, "�i") - 1)
    If gender = "�j" Then
        Select Case relText
            Case "���j": ChildOrdinalIndex = 1
            Case "��j": ChildOrdinalIndex = 2
            Case "�O�j": ChildOrdinalIndex = 3
            Case "�l�j": ChildOrdinalIndex = 4
            Case "�ܒj": ChildOrdinalIndex = 5
            Case "�Z�j": ChildOrdinalIndex = 6
            Case "���j": ChildOrdinalIndex = 7
            Case "���j": ChildOrdinalIndex = 8
            Case "��j": ChildOrdinalIndex = 9
            Case "�\�j": ChildOrdinalIndex = 10
        End Select
    ElseIf gender = "��" Then
        Select Case relText
            Case "����": ChildOrdinalIndex = 1
            Case "��": ChildOrdinalIndex = 2
            Case "�O��": ChildOrdinalIndex = 3
            Case "�l��": ChildOrdinalIndex = 4
            Case "�܏�": ChildOrdinalIndex = 5
            Case "�Z��": ChildOrdinalIndex = 6
            Case "����": ChildOrdinalIndex = 7
            Case "����": ChildOrdinalIndex = 8
            Case "�㏗": ChildOrdinalIndex = 9
            Case "�\��": ChildOrdinalIndex = 10
        End Select
    End If

End Function

Private Function ChildOrdinalLabel(ByVal gender As String, ByVal idx As Long) As String

    Dim suffixText As String
    If gender = "��" Then
        suffixText = "��"
    Else
        suffixText = "�j"
    End If
    Select Case idx
        Case 1
            If gender = "��" Then
                ChildOrdinalLabel = "����"
            Else
                ChildOrdinalLabel = "���j"
            End If
        Case 2
            ChildOrdinalLabel = "��" & suffixText
        Case 3
            ChildOrdinalLabel = "�O" & suffixText
        Case 4
            ChildOrdinalLabel = "�l" & suffixText
        Case 5
            ChildOrdinalLabel = "��" & suffixText
        Case 6
            ChildOrdinalLabel = "�Z" & suffixText
        Case 7
            ChildOrdinalLabel = "��" & suffixText
        Case 8
            ChildOrdinalLabel = "��" & suffixText
        Case 9
            ChildOrdinalLabel = "��" & suffixText
        Case 10
            ChildOrdinalLabel = "�\" & suffixText
        Case Else
            ChildOrdinalLabel = "�q"
    End Select

End Function

Private Function SiblingRelationText(ByVal gender As String, ByVal birthDate As Variant) As String

    Dim decId As String, decBirth As Variant, older As Boolean

    decId = GetDecedentId()

    decBirth = GetPersonValue(decId, P_BIRTH)

    If Not HasInputDate(birthDate) Or Not HasInputDate(decBirth) Then
        If gender = "�j" Then
            SiblingRelationText = "�Z��"
        ElseIf gender = "��" Then
            SiblingRelationText = "�o��"
        Else
            SiblingRelationText = "�Z��o��"
        End If
        Exit Function
    End If

    older = CDate(SameDateOrBlank(birthDate)) < CDate(SameDateOrBlank(decBirth))

    If gender = "�j" Then
        If older Then
            SiblingRelationText = "�Z"
        Else
            SiblingRelationText = "��"
        End If
    ElseIf gender = "��" Then
        If older Then
            SiblingRelationText = "�o"
        Else
            SiblingRelationText = "��"
        End If
    Else
        SiblingRelationText = "�Z��o��"
    End If

End Function


Private Sub ConfirmRelationshipFactsAfterRegister(ByVal personId As String, _
        ByVal modeName As String, _
        ByVal inputBaseId As String, _
        ByVal relationBaseId As String, _
        ByVal relationText As String, _
        ByVal birthDate As Variant, _
        ByVal marriageDate As Variant, _
        ByVal divorceDate As Variant)
    Dim wsP As Worksheet, personRow As Long, decId As String
    Dim inputBaseRel As String, bloodlineId As String, m As Variant, d As Variant
    Dim level As Long, fixedRel As String
    If Len(personId) = 0 Then Exit Sub
    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)
    personRow = FindPersonRow(personId)
    If personRow <= 0 Then Exit Sub

    inputBaseId = CleanText(inputBaseId)
    relationBaseId = CleanText(relationBaseId)
    decId = GetDecedentId()

    If modeName = MODE_SPOUSE Then
        inputBaseRel = NormalizedRelationLabel(GetPersonValue(inputBaseId, P_REL_DEC))
        If inputBaseRel = "��" Then
            wsP.Cells(personRow, P_REL_DEC).Value = "��"
            wsP.Cells(personRow, P_REL_DISP).Value = "��"
            wsP.Cells(personRow, P_SUR_SRC).Value = inputBaseId
            AddRelationIfNeeded decId, personId, MODE_MOTHER, "��", Empty, Empty
        ElseIf inputBaseRel = "��" Then
            wsP.Cells(personRow, P_REL_DEC).Value = "��"
            wsP.Cells(personRow, P_REL_DISP).Value = "��"
            wsP.Cells(personRow, P_SUR_SRC).Value = inputBaseId
            AddRelationIfNeeded decId, personId, MODE_FATHER, "��", Empty, Empty
        End If
    End If

    If modeName = MODE_CHILD Or modeName = MODE_GRANDCHILD Then
        If inputBaseId <> relationBaseId And Len(relationBaseId) > 0 Then
            If IsBaseSpouseOfDescendant(inputBaseId, bloodlineId, m, d, birthDate) Then
                If bloodlineId = relationBaseId Then
                    level = DescendantLevelFromRelation(GetPersonValue(relationBaseId, P_REL_DEC))
                    fixedRel = NextDescendantRelation(level)
                    If Len(fixedRel) > 0 Then
                        If DateWithinMarriagePeriod(birthDate, m, d) Then
                            wsP.Cells(personRow, P_REL_DEC).Value = fixedRel
                            wsP.Cells(personRow, P_REL_DISP).Value = fixedRel
                            wsP.Cells(personRow, P_SUR_SRC).Value = relationBaseId
                            AddRelationIfNeeded inputBaseId, personId, modeName, fixedRel, Empty, Empty
                        End If
                    End If
                End If
            End If
        End If
    End If
End Sub

Private Sub AddRelationIfNeeded(ByVal baseId As String, _
        ByVal otherId As String, _
        ByVal modeName As String, _
        ByVal relationText As String, _
        ByVal marriageDate As Variant, _
        ByVal divorceDate As Variant)
    If Len(baseId) = 0 Or Len(otherId) = 0 Then Exit Sub
    If baseId = otherId Then Exit Sub

    Dim ws As Worksheet, r As Long, relationType As String
    Dim writeBaseId As String, writeOtherId As String

    Set ws = ThisWorkbook.Worksheets(SH_W_REL)
    relationType = "���̑�"
    writeBaseId = baseId
    writeOtherId = otherId

    If modeName = MODE_SPOUSE Then relationType = "�z���"
    If modeName = MODE_CHILD Or modeName = MODE_FATHER Or modeName = MODE_MOTHER Or modeName = MODE_GRANDCHILD Then relationType = "�e�q"
    If modeName = MODE_SIBLING Then relationType = "�Z��o��"

    '�e�q�֌W�͕K�� R_BASE_ID=�e�AR_OTHER_ID=�q �ɐ��K�����ĕۑ�����B
    '����o�^���� base=�q / other=�e �ɂȂ�₷���A�}�E���n��E���͂ŋt�������̂ɂȂ邽�ߓ����Œׂ��B
    If relationType = "�e�q" Then
        If modeName = MODE_FATHER Or modeName = MODE_MOTHER Then
            writeBaseId = otherId
            writeOtherId = baseId
        Else
            writeBaseId = baseId
            writeOtherId = otherId
        End If
    End If

    r = FindExistingRelationRow(writeBaseId, writeOtherId, relationType)
    If r = 0 And (relationType = "�z���" Or relationType = "�Z��o��" Or relationType = "�e�q") Then
        r = FindExistingRelationRow(writeOtherId, writeBaseId, relationType)
    End If
    If r = 0 Then
        r = NextBlankRow(ws, 1)
        ws.Cells(r, R_ID).Value = NextId("�֌W")
        ws.Cells(r, R_CREATED).Value = Now
    End If
    ws.Cells(r, R_BASE_ID).Value = writeBaseId
    ws.Cells(r, R_OTHER_ID).Value = writeOtherId
    ws.Cells(r, R_TYPE).Value = relationType
    ws.Cells(r, R_DISPLAY).Value = relationText
    If relationType = "�z���" Then
        ws.Cells(r, R_MARRIAGE).Value = SameDateOrBlank(marriageDate)
        ws.Cells(r, R_DIVORCE).Value = SameDateOrBlank(divorceDate)
    Else
        ws.Cells(r, R_MARRIAGE).ClearContents
        ws.Cells(r, R_DIVORCE).ClearContents
    End If
    ws.Cells(r, R_AUTO).Value = "����"
    ws.Cells(r, R_STATUS).Value = STATUS_ACTIVE
    ws.Cells(r, R_UPDATED).Value = Now
End Sub

Private Function FindExistingRelationRow(ByVal baseId As String, ByVal otherId As String, ByVal relationType As String) As Long
    Dim ws As Worksheet, r As Long, lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_REL)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If CStr(ws.Cells(r, R_BASE_ID).Value) = baseId _
                    And CStr(ws.Cells(r, R_OTHER_ID).Value) = otherId _
                    And CStr(ws.Cells(r, R_TYPE).Value) = relationType Then
                FindExistingRelationRow = r
                Exit Function
            End If
        End If
    Next r
End Function

Private Sub RegisterAddressFromInput(ByVal personId As String, Optional ByVal explicitCopySourcePersonId As String = "", Optional ByVal explicitCopySourceAddressId As String = "")

    Dim wsIn As Worksheet, addressText As String, addressKey As String, candId As String

    Dim addrId As String, r As Long, wsA As Worksheet, personRow As Long

    Dim addrType As String, startValue As Variant, endValue As Variant, startKind As String
    Dim copySourcePersonId As String, copySourceAddressId As String

    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    copySourcePersonId = AddressCopySourceIdFromInput(wsIn, explicitCopySourcePersonId)
    copySourceAddressId = AddressCopySourceAddressIdFromInput(wsIn, explicitCopySourceAddressId)

    addressText = CleanText(wsIn.Range(CELL_ADDR_TEXT).Value)

    If Len(addressText) = 0 Or Len(personId) = 0 Then Exit Sub

    addressKey = CleanText(wsIn.Range(CELL_ADDR_KEY).Value)

    If Len(addressKey) = 0 Then addressKey = NormalizeAddress(addressText)

    wsIn.Range(CELL_ADDR_KEY).Value = addressKey

    addrType = CleanText(wsIn.Range(CELL_ADDR_TYPE).Value)

    If Len(addrType) = 0 Then addrType = "���Z�n"

    startValue = SameDateOrBlank(wsIn.Range(CELL_ADDR_START).Value)

    endValue = SameDateOrBlank(wsIn.Range(CELL_ADDR_END).Value)

    startKind = AddressStartKindFromInput(personId)

    candId = GetOrCreateAddressCandidate(addressText, addressKey, personId)

    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    r = FindMatchingAddressHistoryRow(personId, addressKey, addrType, startValue, endValue)

    If r > 0 Then

        addrId = CStr(wsA.Cells(r, A_ID).Value)

        wsA.Cells(r, A_CAND_ID).Value = candId

        wsA.Cells(r, A_TEXT).Value = addressText

        wsA.Cells(r, A_KEY).Value = addressKey

        wsA.Cells(r, A_SOURCE).Value = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)

        wsA.Cells(r, A_COPY_PERSON_ID).Value = copySourcePersonId
        wsA.Cells(r, A_COPY_ADDR_ID).Value = copySourceAddressId

        wsA.Cells(r, A_NOTE).Value = CleanText(wsIn.Range(CELL_ADDR_NOTE).Value)

        wsA.Cells(r, A_STATUS).Value = STATUS_ACTIVE

        wsA.Cells(r, A_UPDATED).Value = Now

        wsA.Cells(r, A_START_KIND).Value = startKind

    Else

        r = NextBlankRow(wsA, 1)

        addrId = NextId("�Z������")

        wsA.Cells(r, A_ID).Value = addrId

        wsA.Cells(r, A_PERSON_ID).Value = personId

        wsA.Cells(r, A_CAND_ID).Value = candId

        wsA.Cells(r, A_TYPE).Value = addrType

        wsA.Cells(r, A_START).Value = startValue

        wsA.Cells(r, A_END).Value = endValue

        wsA.Cells(r, A_TEXT).Value = addressText

        wsA.Cells(r, A_KEY).Value = addressKey

        wsA.Cells(r, A_SOURCE).Value = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)

        wsA.Cells(r, A_COPY_PERSON_ID).Value = copySourcePersonId
        wsA.Cells(r, A_COPY_ADDR_ID).Value = copySourceAddressId

        wsA.Cells(r, A_NOTE).Value = CleanText(wsIn.Range(CELL_ADDR_NOTE).Value)

        wsA.Cells(r, A_STATUS).Value = STATUS_ACTIVE

        wsA.Cells(r, A_CREATED).Value = Now

        wsA.Cells(r, A_UPDATED).Value = Now

        wsA.Cells(r, A_START_KIND).Value = startKind

    End If

    UpdateRepresentativeAddressId personId
    DiagramGraphReset

End Sub

Private Function AddressCopySourceIdFromInput(ByVal wsIn As Worksheet, Optional ByVal explicitCopySourcePersonId As String = "") As String
    Dim srcText As String, baseId As String
    explicitCopySourcePersonId = CleanText(explicitCopySourcePersonId)
    If Len(explicitCopySourcePersonId) > 0 Then
        AddressCopySourceIdFromInput = explicitCopySourcePersonId
        Exit Function
    End If
    If wsIn Is Nothing Then Exit Function
    srcText = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)
    If InStr(1, srcText, "�R�s�[", vbTextCompare) > 0 And InStr(1, srcText, "�", vbTextCompare) > 0 Then
        baseId = CleanText(wsIn.Range(CELL_BASE_ID).Value)
        If Len(baseId) > 0 Then AddressCopySourceIdFromInput = baseId
    End If
End Function

Private Function AddressCopySourceAddressIdFromInput(ByVal wsIn As Worksheet, Optional ByVal explicitCopySourceAddressId As String = "") As String
    Dim srcText As String, v As String
    explicitCopySourceAddressId = CleanText(explicitCopySourceAddressId)
    If Len(explicitCopySourceAddressId) > 0 Then
        AddressCopySourceAddressIdFromInput = explicitCopySourceAddressId
        Exit Function
    End If
    If wsIn Is Nothing Then Exit Function
    srcText = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)
    If InStr(1, srcText, "�R�s�[", vbTextCompare) > 0 And InStr(1, srcText, "�", vbTextCompare) > 0 Then
        v = CleanText(wsIn.Range(CELL_ADDR_COPY_SOURCE_ID).Value)
        If Len(v) > 0 Then AddressCopySourceAddressIdFromInput = v
    End If
End Function

Private Function AddressStartKindFromInput(ByVal personId As String) As String

    Dim v As String
    v = CleanText(ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_START_KIND).Value)
    If v = "�c����" Or v = "���Z�J�n" Then
        AddressStartKindFromInput = v
    Else
        AddressStartKindFromInput = "���Z�J�n"
    End If

End Function

Public Sub MarkAddressStartConfirmed()

    On Error Resume Next
    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"
    SetPersonInputStatus "�Z���J�n���̈������w���Z�J�n�x�ɂ��܂����B"
    On Error GoTo 0

End Sub

Public Sub MarkAddressStartObserved()

    On Error Resume Next
    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_START_KIND).Value = "�c����"
    SetPersonInputStatus "�Z���J�n���̈������w�c�����x�ɂ��܂����B�ŏ��̏Z���ȂǁA���ۂ̈ړ]�����s���ȏꍇ�Ɏg���܂��B"
    On Error GoTo 0

End Sub

Private Function FindMatchingAddressHistoryRow(ByVal personId As String, _
        ByVal addressKey As String, _
        ByVal addrType As String, _
        ByVal startValue As Variant, _
        ByVal endValue As Variant) As Long

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, A_PERSON_ID).Value) = personId Then
            If CStr(ws.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
                If CStr(ws.Cells(r, A_KEY).Value) = addressKey Then
                    If CleanText(ws.Cells(r, A_TYPE).Value) = addrType Then
                        If SameDateValueOrBlank(ws.Cells(r, A_START).Value, startValue) Then
                            If SameDateValueOrBlank(ws.Cells(r, A_END).Value, endValue) Then

                                FindMatchingAddressHistoryRow = r

                                Exit Function

                            End If
                        End If
                    End If
                End If
            End If
        End If

    Next r

End Function

Private Function SameDateValueOrBlank(ByVal a As Variant, ByVal b As Variant) As Boolean

    SameDateValueOrBlank = SameInputDateOrBothBlank(a, b)

End Function

Private Function GetOrCreateAddressCandidate(ByVal addressText As String, ByVal addressKey As String, ByVal personId As String) As String

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, AC_KEY).Value) = addressKey Then

            ws.Cells(r, AC_LAST_PERSON).Value = personId

            ws.Cells(r, AC_USE_COUNT).Value = Val(ws.Cells(r, AC_USE_COUNT).Value) + 1

            ws.Cells(r, AC_LAST_USED).Value = Now

            GetOrCreateAddressCandidate = CStr(ws.Cells(r, AC_ID).Value)

            Exit Function

        End If

    Next r

    r = NextBlankRow(ws, 1)

    GetOrCreateAddressCandidate = NextId("�Z�����")

    ws.Cells(r, AC_ID).Value = GetOrCreateAddressCandidate

    ws.Cells(r, AC_TEXT).Value = addressText

    ws.Cells(r, AC_KEY).Value = addressKey

    ws.Cells(r, AC_FIRST_PERSON).Value = personId

    ws.Cells(r, AC_LAST_PERSON).Value = personId

    ws.Cells(r, AC_USE_COUNT).Value = 1

    ws.Cells(r, AC_LAST_USED).Value = Now

End Function

Public Sub AddAddressAndStartNext()
    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, pid As String, addedEnd As Variant

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)

    If Len(CleanText(ws.Range(CELL_ADDR_TEXT).Value)) = 0 Then Err.Raise 5, , "�ǉ�����Z������͂��Ă��������B"

    If Len(CleanText(ws.Range(CELL_ADDR_EDIT_ID).Value)) > 0 Then
        UpdateAddressHistoryFromInputById CleanText(ws.Range(CELL_ADDR_EDIT_ID).Value), pid
        addedEnd = ws.Range(CELL_ADDR_END).Value
        RefreshAddressCandidateListOnly
        RefreshDateCandidateListOnly
        BeginNextAddressForCurrentPerson addedEnd
        SetPersonInputStatus "�Z��������������܂����B���̏Z���𑱂��ē��͂ł��܂��B"
        AppEnd
        Exit Sub
    End If

    addedEnd = ws.Range(CELL_ADDR_END).Value

    If Len(pid) = 0 Then
        StageAddressFromInput PendingAddressKeyForInput(True)
        RefreshDateCandidateListOnly
        BeginNextAddressForCurrentPerson addedEnd
        SetPersonInputStatus "�Z�������ǉ����܂����B�l����o�^����ƁA���̏Z���������܂Ƃ߂ēo�^����܂��B"
    Else
        RegisterAddressFromInput pid
        RefreshAddressCandidateListOnly
        RefreshDateCandidateListOnly
        BeginNextAddressForCurrentPerson addedEnd
        SetPersonInputStatus "�Z��������ǉ����܂����B���̏Z���𑱂��ē��͂ł��܂��B"
    End If
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "AddAddressAndStartNext", "�Z������ǉ�", "�l��ID�E�Z���E�J�n���E�I�����̓��͏�Ԃ��m�F���Ă��������B"

End Sub

Public Sub AddAddressForCurrentPerson()
    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, pid As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)

    If Len(CleanText(ws.Range(CELL_ADDR_TEXT).Value)) = 0 Then Err.Raise 5, , "�ǉ�����Z������͂��Ă��������B"

    If Len(pid) = 0 Then
        StageAddressFromInput PendingAddressKeyForInput(True)
        RefreshDateCandidateListOnly
        SetPersonInputStatus "�Z�������ǉ����܂����B�l����o�^����ƁA���̏Z���������܂Ƃ߂ēo�^����܂��B"
    Else
        RegisterAddressFromInput pid
        RefreshAddressCandidateListOnly
        RefreshDateCandidateListOnly
        SetPersonInputStatus "�Z��������ǉ����܂����B"
    End If

    ApplyInputUsability False
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "AddAddressForCurrentPerson", "�Z������ǉ�", "�l��ID�E�Z���E�J�n���E�I�����̓��͏�Ԃ��m�F���Ă��������B"

End Sub

Public Sub BeginNextAddressForCurrentPerson(Optional ByVal previousEndDate As Variant)

    On Error Resume Next

    Dim ws As Worksheet, nextStart As Variant

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If IsMissing(previousEndDate) Then previousEndDate = ws.Range(CELL_ADDR_END).Value

    If HasInputDate(previousEndDate) Then nextStart = DateAdd("d", 1, CDate(SameDateOrBlank(previousEndDate)))

    ws.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents
    ws.Range(CELL_ADDR_KEY).ClearContents
    ws.Range(CELL_ADDR_SOURCE).ClearContents
    ws.Range(CELL_ADDR_COPY_SOURCE_ID).ClearContents
    ws.Range(CELL_ADDR_EDIT_ID).ClearContents

    ws.Range(CELL_ADDR_TYPE).Value = "���Z�n"

    ws.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"

    If HasInputDate(nextStart) Then ws.Range(CELL_ADDR_START).Value = SameDateOrBlank(nextStart)

    ApplyInputUsability

    ws.Range(CELL_ADDR_TEXT).Select

    On Error GoTo 0

End Sub

Public Sub LoadBasePersonForEdit()
    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, sel As String, pid As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    sel = CleanText(ws.Range(CELL_BASE_SELECT).Value)
    pid = ParseIdFromCandidate(sel)
    If Len(pid) = 0 Then pid = CleanText(ws.Range(CELL_BASE_ID).Value)
    If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then Err.Raise 5, , "��������l������l����₩��I��ł��������B"
    LoadPersonIntoInputForEdit pid
    SetPersonInputStatus "�l����������p�ɓǂݍ��݂܂����B�����Ă���w�o�^�E�X�V�x�������Ă��������B"
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "LoadBasePersonForEdit", "�l�������Ǎ�", "��l�����E�l���ꗗ�E���̓V�[�g�̏�Ԃ��m�F���Ă��������B"
End Sub

Public Sub DeleteCurrentInputPerson()
    On Error GoTo EH
    Dim ws As Worksheet, pid As String, personName As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)
    If Len(pid) = 0 Then pid = CleanText(ws.Range(CELL_BASE_ID).Value)
    If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then Err.Raise 5, , "�폜����l����l�������Ǎ��œǂݍ��ނ��A��l����₩��I��ł��������B"
    personName = GetPersonValue(pid, P_DISPLAY)
    If MsgBox("�l���w" & personName & "�x���폜���܂��B" & vbCrLf & _
              "�֘A����Z�������E�֌W�E������������������ɂ��܂��B���ɖ߂��ꍇ�͍�ƃV�[�g�Ŏ����߂��K�v������܂��B", _
              vbExclamation + vbYesNo, "�l���폜�m�F") <> vbYes Then Exit Sub
    AppBegin
    CancelCurrentPersonRelatedRows pid
    ClearPersonInput True
    RefreshCandidates
    SetPersonInputStatus "�l�����폜���܂����B"
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "DeleteCurrentInputPerson", "�l���폜", "�l��ID�A�֌W�\�A�Z�������A���������̏�Ԃ��m�F���Ă��������B"
End Sub

Private Sub CancelCurrentPersonRelatedRows(ByVal personId As String)
    Dim wsP As Worksheet, wsA As Worksheet, wsR As Worksheet, wsM As Worksheet, r As Long
    If Len(personId) = 0 Then Exit Sub
    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)
    r = FindPersonRow(personId)
    If r > 0 Then
        wsP.Cells(r, P_STATUS).Value = STATUS_CANCEL
        wsP.Cells(r, P_UPDATED).Value = Now
        wsP.Cells(r, P_SHOW).Value = SHOW_NO
    End If
    If SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then
        Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
        For r = 2 To LastRow(wsA, A_ID)
            If CleanText(wsA.Cells(r, A_PERSON_ID).Value) = personId Then
                wsA.Cells(r, A_STATUS).Value = STATUS_CANCEL
                wsA.Cells(r, A_UPDATED).Value = Now
            End If
        Next r
    End If
    If SheetExists(SH_W_REL, ThisWorkbook) Then
        Set wsR = ThisWorkbook.Worksheets(SH_W_REL)
        For r = 2 To LastRow(wsR, R_ID)
            If CleanText(wsR.Cells(r, R_BASE_ID).Value) = personId Or CleanText(wsR.Cells(r, R_OTHER_ID).Value) = personId Then
                wsR.Cells(r, R_STATUS).Value = STATUS_CANCEL
                wsR.Cells(r, R_UPDATED).Value = Now
            End If
        Next r
    End If
    If SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then
        Set wsM = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
        For r = 2 To LastRow(wsM, MH_ID)
            If CleanText(wsM.Cells(r, MH_PERSON_ID).Value) = personId Or CleanText(wsM.Cells(r, MH_COUNTERPART_ID).Value) = personId Then
                wsM.Cells(r, MH_STATUS).Value = STATUS_CANCEL
                wsM.Cells(r, MH_SHOW).Value = SHOW_NO
                wsM.Cells(r, MH_UPDATED).Value = Now
            End If
        Next r
    End If
End Sub

Private Sub LoadPersonIntoInputForEdit(ByVal personId As String)
    Dim wsIn As Worksheet, wsP As Worksheet, r As Long, baseId As String, bestAddrRow As Long
    If Len(personId) = 0 Then Exit Sub
    r = FindPersonRow(personId)
    If r = 0 Then Exit Sub
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)
    wsIn.Unprotect Password:=TOOL_PASSWORD
    wsIn.Range(CELL_PERSON_ID).Value = personId
    wsIn.Range(CELL_PENDING_ADDR_KEY).ClearContents
    wsIn.Range(CELL_PENDING_MARRIAGE_KEY).ClearContents
    wsIn.Range(CELL_ADDR_EDIT_ID).ClearContents
    wsIn.Range(CELL_MODE).Value = PersonEditModeFromRow(r)
    baseId = CleanText(wsP.Cells(r, P_SUR_SRC).Value)
    If Len(baseId) = 0 And CleanText(wsP.Cells(r, P_TYPE).Value) <> MODE_DECEDENT Then baseId = GetDecedentId()
    If Len(baseId) > 0 And FindPersonRow(baseId) > 0 And baseId <> personId Then SetBasePerson baseId
    If Len(baseId) > 0 And FindPersonRow(baseId) > 0 Then
        wsIn.Range(CELL_AUTO_SURNAME).Value = GetPersonValue(baseId, P_SURNAME)
    Else
        wsIn.Range(CELL_AUTO_SURNAME).ClearContents
    End If
    wsIn.Range(CELL_SURNAME).Value = wsP.Cells(r, P_SURNAME).Value
    wsIn.Range(CELL_GIVEN_NAME).Value = wsP.Cells(r, P_GIVEN).Value
    wsIn.Range(CELL_FORMER_SURNAME).Value = wsP.Cells(r, P_FORMER).Value
    wsIn.Range(CELL_GENDER).Value = wsP.Cells(r, P_GENDER).Value
    wsIn.Range(CELL_REL_TO_DECEDENT).Value = wsP.Cells(r, P_REL_DEC).Value
    wsIn.Range(CELL_BIRTH).Value = wsP.Cells(r, P_BIRTH).Value
    wsIn.Range(CELL_DEATH).Value = wsP.Cells(r, P_DEATH).Value
    wsIn.Range(CELL_OCCUPATION).Value = wsP.Cells(r, P_OCC).Value
    wsIn.Range(CELL_MARRIAGE).Value = wsP.Cells(r, P_MARRIAGE).Value
    wsIn.Range(CELL_DIVORCE).Value = wsP.Cells(r, P_DIVORCE).Value
    wsIn.Range(CELL_NOTE).Value = wsP.Cells(r, P_NOTE).Value
    wsIn.Range(CELL_SHOW_DIAGRAM).Value = wsP.Cells(r, P_SHOW).Value
    If Len(CleanText(wsIn.Range(CELL_SHOW_DIAGRAM).Value)) = 0 Then wsIn.Range(CELL_SHOW_DIAGRAM).Value = SHOW_YES
    wsIn.Range(CELL_DEATH_PLACE).Value = wsP.Cells(r, P_DEATH_PLACE).Value
    bestAddrRow = BestAddressHistoryRowForPerson(personId)
    If bestAddrRow > 0 Then
        LoadAddressFieldsFromHistoryRow bestAddrRow
    Else
        wsIn.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents
        wsIn.Range(CELL_ADDR_KEY).ClearContents
        wsIn.Range(CELL_ADDR_SOURCE).ClearContents
        wsIn.Range(CELL_ADDR_COPY_SOURCE_ID).ClearContents
        wsIn.Range(CELL_ADDR_TYPE).Value = "���Z�n"
        wsIn.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"
        wsIn.Range(CELL_ADDR_EDIT_ID).ClearContents
    End If
    EnsurePersonInputValidationOnly wsIn
    EnsurePersonInputDateDisplay wsIn
    ApplyInputUsability False
    If Not ActiveSheet Is Nothing Then
        If ActiveSheet.Name = wsIn.Name Then wsIn.Range(CELL_GIVEN_NAME).Select
    End If
End Sub

Private Function PersonEditModeFromRow(ByVal personRow As Long) As String
    Dim relText As String, pType As String
    If personRow <= 0 Then PersonEditModeFromRow = MODE_OTHER: Exit Function
    With ThisWorkbook.Worksheets(SH_W_PERSON)
        pType = CleanText(.Cells(personRow, P_TYPE).Value)
        relText = NormalizedRelationLabel(CleanText(.Cells(personRow, P_REL_DEC).Value))
    End With
    If pType = MODE_DECEDENT Or relText = MODE_DECEDENT Then
        PersonEditModeFromRow = MODE_DECEDENT
    ElseIf RelationIsSpousePersonLabel(relText) Then
        PersonEditModeFromRow = MODE_SPOUSE
    ElseIf relText = "��" Then
        PersonEditModeFromRow = MODE_FATHER
    ElseIf relText = "��" Then
        PersonEditModeFromRow = MODE_MOTHER
    ElseIf BaseIsDirectChildRelation(relText) Then
        PersonEditModeFromRow = MODE_CHILD
    ElseIf RelationshipDescendantLevel(relText) >= 2 Then
        PersonEditModeFromRow = MODE_GRANDCHILD
    ElseIf InStr(1, relText, "�Z", vbTextCompare) > 0 Or InStr(1, relText, "��", vbTextCompare) > 0 _
            Or InStr(1, relText, "�o", vbTextCompare) > 0 Or InStr(1, relText, "��", vbTextCompare) > 0 Then
        PersonEditModeFromRow = MODE_SIBLING
    Else
        PersonEditModeFromRow = MODE_OTHER
    End If
End Function

Public Sub LoadSelectedAddressHistoryForEdit()
    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, activeObj As Object
    Dim rowNo As Long, addrId As String, histRow As Long, personId As String
    Set activeObj = ActiveSheet
    If Not TypeOf activeObj Is Worksheet Then Err.Raise 5, , "�Z�����𑁌��\�Œ�������s��I�����Ă��������B"
    Set ws = activeObj
    If ws.Name <> SH_ADDR_TABLE Then Err.Raise 5, , "�Z�����𑁌��\�Œ�������s��I�����Ă��������B"
    rowNo = ActiveCell.Row
    If rowNo < 9 Then Err.Raise 5, , "��������Z�������̖��׍s��I�����Ă��������B"
    addrId = CleanText(ws.Cells(rowNo, 10).Value)
    histRow = FindAddressHistoryRowById(addrId)
    If histRow = 0 Then Err.Raise 5, , "�Z������ID���m�F�ł��܂���B�Z�����𑁌��\����蒼���Ă��������B"
    personId = CleanText(ThisWorkbook.Worksheets(SH_W_ADDR_HIST).Cells(histRow, A_PERSON_ID).Value)
    ShowOnlyInputCore True
    LoadPersonIntoInputForEdit personId
    LoadAddressFieldsFromHistoryRow histRow
    SetPersonInputStatus "�Z������������p�ɓǂݍ��݂܂����B�����Ă���w�Z�������x�������Ă��������B"
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "LoadSelectedAddressHistoryForEdit", "�Z����������Ǎ�", "�Z�����𑁌��\�Ŗ��׍s��I��ł��������B"
End Sub

Public Sub DeleteSelectedAddressFromTable()
    On Error GoTo EH
    Dim ws As Worksheet, activeObj As Object
    Dim rowNo As Long, addrId As String, histRow As Long, labelText As String
    Set activeObj = ActiveSheet
    If Not TypeOf activeObj Is Worksheet Then Err.Raise 5, , "�Z�����𑁌��\�ō폜����s��I�����Ă��������B"
    Set ws = activeObj
    If ws.Name <> SH_ADDR_TABLE Then Err.Raise 5, , "�Z�����𑁌��\�ō폜����s��I�����Ă��������B"
    rowNo = ActiveCell.Row
    If rowNo < 9 Then Err.Raise 5, , "�폜����Z�������̖��׍s��I�����Ă��������B"
    addrId = CleanText(ws.Cells(rowNo, 10).Value)
    histRow = FindAddressHistoryRowById(addrId)
    If histRow = 0 Then Err.Raise 5, , "�Z������ID���m�F�ł��܂���B�Z�����𑁌��\����蒼���Ă��������B"
    labelText = CleanText(ws.Cells(rowNo, 2).Value) & " / " & CleanText(ws.Cells(rowNo, 8).Value)
    If MsgBox("�I�������Z���������폜���܂��B" & vbCrLf & labelText, vbExclamation + vbYesNo, "�Z���폜�m�F") <> vbYes Then Exit Sub
    AppBegin
    CancelAddressHistoryRow histRow
    BuildAddressHistoryTable
    ApplyOutputUsability
    ThisWorkbook.Worksheets(SH_ADDR_TABLE).Activate
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "DeleteSelectedAddressFromTable", "�Z�������폜", "�Z�����𑁌��\�Ŗ��׍s��I��ł��������B"
End Sub

Public Sub UpdateSelectedAddressFromInput()
    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, pid As String, addrId As String, histRow As Long
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)
    If Len(pid) = 0 Then Err.Raise 5, , "��ɐl����o�^���邩�A�l�������Ǎ��Ől����ǂݍ���ł��������B"
    If Len(CleanText(ws.Range(CELL_ADDR_TEXT).Value)) = 0 Then Err.Raise 5, , "������̏Z������͂��Ă��������B"
    addrId = CleanText(ws.Range(CELL_ADDR_EDIT_ID).Value)
    histRow = FindAddressHistoryRowById(addrId)
    If histRow = 0 Then histRow = FindAddressHistoryRowFromInput(pid)
    If histRow = 0 Then Err.Raise 5, , "�����Ώۂ̏Z��������������܂���B�Z���ꗗ����Ώۍs��ǂݍ���ł��������B"
    UpdateAddressHistoryFromInputByRow histRow, pid
    RefreshAddressCandidateListOnly
    RefreshDateCandidateListOnly
    UpdateRepresentativeAddressId pid
    SetPersonInputStatus "�Z��������������܂����B"
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "UpdateSelectedAddressFromInput", "�Z���������", "�����Ώۂ̏Z�������A�l��ID�A���t�A�Z�����͂��m�F���Ă��������B"
End Sub

Public Sub DeleteSelectedAddressFromInput()
    On Error GoTo EH
    Dim ws As Worksheet, pid As String, addrId As String, histRow As Long, pendingRow As Long, labelText As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)
    addrId = CleanText(ws.Range(CELL_ADDR_EDIT_ID).Value)
    histRow = FindAddressHistoryRowById(addrId)
    If histRow = 0 And Len(pid) > 0 Then histRow = FindAddressHistoryRowFromInput(pid)
    If histRow > 0 Then
        labelText = CleanText(ThisWorkbook.Worksheets(SH_W_ADDR_HIST).Cells(histRow, A_TEXT).Value)
        If MsgBox("���̏Z���������폜���܂��B" & vbCrLf & labelText, vbExclamation + vbYesNo, "�Z���폜�m�F") <> vbYes Then Exit Sub
        AppBegin
        CancelAddressHistoryRow histRow
        BeginNextAddressForCurrentPerson
        RefreshAddressCandidateListOnly
        RefreshDateCandidateListOnly
        If Len(pid) > 0 Then UpdateRepresentativeAddressId pid
        SetPersonInputStatus "�Z���������폜���܂����B"
        AppEnd
        Exit Sub
    End If

    pendingRow = FindLastPendingAddressRow(CleanText(ws.Range(CELL_PENDING_ADDR_KEY).Value))
    If pendingRow = 0 Then Err.Raise 5, , "�폜�Ώۂ̏Z��������������܂���B�Z���ꗗ����Ώۍs��ǂݍ���ł��������B"
    labelText = CleanText(ThisWorkbook.Worksheets(SH_W_ADDR_PENDING).Cells(pendingRow, AP_ADDR_TEXT).Value)
    If MsgBox("���ǉ������Z�����폜���܂��B" & vbCrLf & labelText, vbExclamation + vbYesNo, "�Z���폜�m�F") <> vbYes Then Exit Sub
    AppBegin
    ThisWorkbook.Worksheets(SH_W_ADDR_PENDING).Cells(pendingRow, AP_STATUS).Value = STATUS_CANCEL
    BeginNextAddressForCurrentPerson
    SetPersonInputStatus "���ǉ��Z�����폜���܂����B"
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "DeleteSelectedAddressFromInput", "�Z�������폜", "�폜�Ώۂ̏Z�������A�l��ID�A�Z�����͂��m�F���Ă��������B"
End Sub

Private Sub UpdateAddressHistoryFromInputById(ByVal addressHistoryId As String, ByVal personId As String)
    Dim histRow As Long
    histRow = FindAddressHistoryRowById(addressHistoryId)
    If histRow = 0 Then Err.Raise 5, , "�����Ώۂ̏Z��������������܂���B"
    If Len(personId) = 0 Then personId = CleanText(ThisWorkbook.Worksheets(SH_W_ADDR_HIST).Cells(histRow, A_PERSON_ID).Value)
    UpdateAddressHistoryFromInputByRow histRow, personId
End Sub

Private Sub UpdateAddressHistoryFromInputByRow(ByVal histRow As Long, ByVal personId As String)
    Dim wsIn As Worksheet, wsA As Worksheet, addressText As String, addressKey As String, addrType As String, candId As String
    If histRow <= 0 Then Exit Sub
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    addressText = CleanText(wsIn.Range(CELL_ADDR_TEXT).Value)
    If Len(addressText) = 0 Then Err.Raise 5, , "�Z������͂��Ă��������B"
    addressKey = CleanText(wsIn.Range(CELL_ADDR_KEY).Value)
    If Len(addressKey) = 0 Then addressKey = NormalizeAddress(addressText)
    addrType = CleanText(wsIn.Range(CELL_ADDR_TYPE).Value)
    If Len(addrType) = 0 Then addrType = "���Z�n"
    If Len(personId) = 0 Then personId = CleanText(wsA.Cells(histRow, A_PERSON_ID).Value)
    candId = GetOrCreateAddressCandidate(addressText, addressKey, personId)
    wsA.Cells(histRow, A_PERSON_ID).Value = personId
    wsA.Cells(histRow, A_CAND_ID).Value = candId
    wsA.Cells(histRow, A_TYPE).Value = addrType
    wsA.Cells(histRow, A_START).Value = SameDateOrBlank(wsIn.Range(CELL_ADDR_START).Value)
    wsA.Cells(histRow, A_END).Value = SameDateOrBlank(wsIn.Range(CELL_ADDR_END).Value)
    wsA.Cells(histRow, A_TEXT).Value = addressText
    wsA.Cells(histRow, A_KEY).Value = addressKey
    wsA.Cells(histRow, A_SOURCE).Value = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)
    wsA.Cells(histRow, A_COPY_PERSON_ID).Value = AddressCopySourceIdFromInput(wsIn)
    If Len(CleanText(wsA.Cells(histRow, A_COPY_PERSON_ID).Value)) = 0 Then wsA.Cells(histRow, A_COPY_ADDR_ID).ClearContents
    wsA.Cells(histRow, A_NOTE).Value = CleanText(wsIn.Range(CELL_ADDR_NOTE).Value)
    wsA.Cells(histRow, A_STATUS).Value = STATUS_ACTIVE
    wsA.Cells(histRow, A_UPDATED).Value = Now
    wsA.Cells(histRow, A_START_KIND).Value = AddressStartKindFromInput(personId)
    wsIn.Range(CELL_ADDR_KEY).Value = addressKey
    wsIn.Range(CELL_ADDR_EDIT_ID).Value = wsA.Cells(histRow, A_ID).Value
End Sub

Private Function FindAddressHistoryRowById(ByVal addressHistoryId As String) As Long
    Dim wsA As Worksheet, r As Long
    addressHistoryId = CleanText(addressHistoryId)
    If Len(addressHistoryId) = 0 Then Exit Function
    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Function
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    For r = 2 To LastRow(wsA, A_ID)
        If CleanText(wsA.Cells(r, A_ID).Value) = addressHistoryId And CleanText(wsA.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
            FindAddressHistoryRowById = r
            Exit Function
        End If
    Next r
End Function

Private Function FindAddressHistoryRowFromInput(ByVal personId As String) As Long
    Dim wsIn As Worksheet, addressKey As String, addrType As String
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    addressKey = CleanText(wsIn.Range(CELL_ADDR_KEY).Value)
    If Len(addressKey) = 0 Then addressKey = NormalizeAddress(wsIn.Range(CELL_ADDR_TEXT).Value)
    addrType = CleanText(wsIn.Range(CELL_ADDR_TYPE).Value)
    If Len(addrType) = 0 Then addrType = "���Z�n"
    FindAddressHistoryRowFromInput = FindMatchingAddressHistoryRow(personId, addressKey, addrType, _
        SameDateOrBlank(wsIn.Range(CELL_ADDR_START).Value), SameDateOrBlank(wsIn.Range(CELL_ADDR_END).Value))
End Function

Private Sub LoadAddressFieldsFromHistoryRow(ByVal histRow As Long)
    Dim wsIn As Worksheet, wsA As Worksheet
    If histRow <= 0 Then Exit Sub
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    wsIn.Range(CELL_ADDR_CAND).ClearContents
    wsIn.Range(CELL_ADDR_TEXT).Value = wsA.Cells(histRow, A_TEXT).Value
    wsIn.Range(CELL_ADDR_KEY).Value = wsA.Cells(histRow, A_KEY).Value
    wsIn.Range(CELL_ADDR_TYPE).Value = wsA.Cells(histRow, A_TYPE).Value
    wsIn.Range(CELL_ADDR_START).Value = wsA.Cells(histRow, A_START).Value
    wsIn.Range(CELL_ADDR_END).Value = wsA.Cells(histRow, A_END).Value
    wsIn.Range(CELL_ADDR_SOURCE).Value = wsA.Cells(histRow, A_SOURCE).Value
    wsIn.Range(CELL_ADDR_NOTE).Value = wsA.Cells(histRow, A_NOTE).Value
    If Len(CleanText(wsA.Cells(histRow, A_START_KIND).Value)) = 0 Then
        wsIn.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"
    Else
        wsIn.Range(CELL_ADDR_START_KIND).Value = CleanText(wsA.Cells(histRow, A_START_KIND).Value)
    End If
    wsIn.Range(CELL_ADDR_EDIT_ID).Value = wsA.Cells(histRow, A_ID).Value
    EnsurePersonInputDateDisplay wsIn
End Sub

Private Sub CancelAddressHistoryRow(ByVal histRow As Long)
    Dim wsA As Worksheet, personId As String
    If histRow <= 0 Then Exit Sub
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    personId = CleanText(wsA.Cells(histRow, A_PERSON_ID).Value)
    wsA.Cells(histRow, A_STATUS).Value = STATUS_CANCEL
    wsA.Cells(histRow, A_UPDATED).Value = Now
    If Len(personId) > 0 Then UpdateRepresentativeAddressId personId
End Sub

Private Function FindLastPendingAddressRow(ByVal pendingKey As String) As Long
    Dim wsP As Worksheet, r As Long
    pendingKey = CleanText(pendingKey)
    If Len(pendingKey) = 0 Then Exit Function
    If Not SheetExists(SH_W_ADDR_PENDING, ThisWorkbook) Then Exit Function
    Set wsP = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    For r = LastRow(wsP, AP_KEY) To 2 Step -1
        If CleanText(wsP.Cells(r, AP_KEY).Value) = pendingKey And CleanText(wsP.Cells(r, AP_STATUS).Value) = STATUS_ACTIVE Then
            FindLastPendingAddressRow = r
            Exit Function
        End If
    Next r
End Function

Private Function PendingAddressKeyForInput(Optional ByVal createIfMissing As Boolean = True) As String

    Dim ws As Worksheet, k As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    k = CleanText(ws.Range(CELL_PENDING_ADDR_KEY).Value)
    If Len(k) = 0 And createIfMissing Then
        k = "TMP" & Format(Now, "yyyymmddhhmmss") & Format(Int(Rnd() * 10000), "0000")
        ws.Range(CELL_PENDING_ADDR_KEY).Value = k
    End If
    PendingAddressKeyForInput = k

End Function

Private Sub StageAddressFromInput(ByVal pendingKey As String)

    Dim wsIn As Worksheet, wsP As Worksheet, r As Long, addressText As String, addressKey As String
    If Len(pendingKey) = 0 Then Exit Sub
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    Set wsP = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    addressText = CleanText(wsIn.Range(CELL_ADDR_TEXT).Value)
    If Len(addressText) = 0 Then Exit Sub
    addressKey = CleanText(wsIn.Range(CELL_ADDR_KEY).Value)
    If Len(addressKey) = 0 Then addressKey = NormalizeAddress(addressText)
    wsIn.Range(CELL_ADDR_KEY).Value = addressKey
    r = NextBlankRow(wsP, 1)
    wsP.Cells(r, AP_KEY).Value = pendingKey
    wsP.Cells(r, AP_SEQ).Value = PendingAddressCount(pendingKey) + 1
    wsP.Cells(r, AP_ADDR_TEXT).Value = addressText
    wsP.Cells(r, AP_ADDR_KEY).Value = addressKey
    If Len(CleanText(wsIn.Range(CELL_ADDR_TYPE).Value)) = 0 Then
        wsP.Cells(r, AP_ADDR_TYPE).Value = "���Z�n"
    Else
        wsP.Cells(r, AP_ADDR_TYPE).Value = CleanText(wsIn.Range(CELL_ADDR_TYPE).Value)
    End If
    wsP.Cells(r, AP_START).Value = SameDateOrBlank(wsIn.Range(CELL_ADDR_START).Value)
    wsP.Cells(r, AP_END).Value = SameDateOrBlank(wsIn.Range(CELL_ADDR_END).Value)
    wsP.Cells(r, AP_SOURCE).Value = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)
    wsP.Cells(r, AP_NOTE).Value = CleanText(wsIn.Range(CELL_ADDR_NOTE).Value)
    wsP.Cells(r, AP_COPY_PERSON_ID).Value = AddressCopySourceIdFromInput(wsIn)
    wsP.Cells(r, AP_COPY_ADDR_ID).Value = AddressCopySourceAddressIdFromInput(wsIn)
    wsP.Cells(r, AP_CREATED).Value = Now
    wsP.Cells(r, AP_START_KIND).Value = AddressStartKindFromInput("")
    wsP.Cells(r, AP_STATUS).Value = STATUS_ACTIVE

End Sub

Private Function PendingAddressCount(ByVal pendingKey As String) As Long

    Dim ws As Worksheet, r As Long
    If Len(pendingKey) = 0 Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, AP_KEY).Value) = pendingKey And CStr(ws.Cells(r, AP_STATUS).Value) = STATUS_ACTIVE Then PendingAddressCount = PendingAddressCount + 1
    Next r

End Function

Private Sub FlushPendingAddressesToPerson(ByVal pendingKey As String, ByVal personId As String)

    Dim wsIn As Worksheet, wsP As Worksheet, r As Long
    If Len(pendingKey) = 0 Or Len(personId) = 0 Then Exit Sub
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    Set wsP = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    For r = 2 To LastRow(wsP, 1)
        If CStr(wsP.Cells(r, AP_KEY).Value) = pendingKey And CStr(wsP.Cells(r, AP_STATUS).Value) = STATUS_ACTIVE Then
            wsIn.Range(CELL_ADDR_TEXT).Value = wsP.Cells(r, AP_ADDR_TEXT).Value
            wsIn.Range(CELL_ADDR_KEY).Value = wsP.Cells(r, AP_ADDR_KEY).Value
            wsIn.Range(CELL_ADDR_TYPE).Value = wsP.Cells(r, AP_ADDR_TYPE).Value
            wsIn.Range(CELL_ADDR_START).Value = wsP.Cells(r, AP_START).Value
            wsIn.Range(CELL_ADDR_END).Value = wsP.Cells(r, AP_END).Value
            wsIn.Range(CELL_ADDR_SOURCE).Value = wsP.Cells(r, AP_SOURCE).Value
            wsIn.Range(CELL_ADDR_NOTE).Value = wsP.Cells(r, AP_NOTE).Value
            If Len(CleanText(wsP.Cells(r, AP_START_KIND).Value)) = 0 Then
                wsIn.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"
            Else
                wsIn.Range(CELL_ADDR_START_KIND).Value = CleanText(wsP.Cells(r, AP_START_KIND).Value)
            End If
            RegisterAddressFromInput personId, CleanText(wsP.Cells(r, AP_COPY_PERSON_ID).Value), CleanText(wsP.Cells(r, AP_COPY_ADDR_ID).Value)
            wsP.Cells(r, AP_STATUS).Value = "�o�^��"
        End If
    Next r
    RefreshAddressCandidateListOnly

End Sub

Private Sub ClearPendingAddresses(ByVal pendingKey As String)

    Dim ws As Worksheet, r As Long
    If Len(pendingKey) = 0 Then Exit Sub
    If Not SheetExists(SH_W_ADDR_PENDING, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, AP_KEY).Value) = pendingKey Then ws.Cells(r, AP_STATUS).Value = STATUS_CANCEL
    Next r

End Sub

Private Sub SavePersonMarriageFactFields(ByVal wsP As Worksheet, _
        ByVal personRow As Long, _
        ByVal marriageDate As Variant, _
        ByVal divorceDate As Variant)

    If wsP Is Nothing Then Exit Sub
    If personRow <= 0 Then Exit Sub
    If HasInputDate(marriageDate) Then
        wsP.Cells(personRow, P_MARRIAGE).Value = SameDateOrBlank(marriageDate)
    Else
        wsP.Cells(personRow, P_MARRIAGE).ClearContents
    End If
    If HasInputDate(divorceDate) Then
        wsP.Cells(personRow, P_DIVORCE).Value = SameDateOrBlank(divorceDate)
    Else
        wsP.Cells(personRow, P_DIVORCE).ClearContents
    End If

End Sub

Private Sub UpdatePersonMarriageFactFields(ByVal personId As String, _
        ByVal marriageDate As Variant, _
        ByVal divorceDate As Variant)

    Dim wsP As Worksheet, r As Long
    If Len(personId) = 0 Then Exit Sub
    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)
    r = FindPersonRow(personId)
    If r = 0 Then Exit Sub
    If HasInputDate(marriageDate) Then wsP.Cells(r, P_MARRIAGE).Value = SameDateOrBlank(marriageDate)
    If HasInputDate(divorceDate) Then wsP.Cells(r, P_DIVORCE).Value = SameDateOrBlank(divorceDate)

End Sub

Private Function GuardTransientInputBeforeNewMode(ByVal ws As Worksheet, ByVal nextMode As String) As Boolean
    Dim addrKey As String, mhKey As String, lastText As String
    Dim addrCount As Long, mhCount As Long, msg As String, resp As VbMsgBoxResult
    Dim hasPersonData As Boolean
    GuardTransientInputBeforeNewMode = True
    If ws Is Nothing Then Exit Function
    addrKey = CleanText(ws.Range(CELL_PENDING_ADDR_KEY).Value)
    mhKey = CleanText(ws.Range(CELL_PENDING_MARRIAGE_KEY).Value)
    addrCount = PendingAddressCount(addrKey)
    mhCount = PendingMarriageHistoryCount(PendingMarriagePersonId(mhKey), lastText)
    hasPersonData = CurrentInputHasUnsavedPerson(ws)
    If addrCount = 0 And mhCount = 0 And Not hasPersonData Then Exit Function

    msg = "���o�^�̓��͓��e������܂��B" & vbCrLf & _
          "�l������: " & YesNoText(hasPersonData) & vbCrLf & _
          "�Z������: " & CStr(addrCount) & "��" & vbCrLf & _
          "��������: " & CStr(mhCount) & "��" & vbCrLf & vbCrLf & _
          "�ʂ̐l�����͂ֈڂ�ƁA�����͌��݂̐l���ɔ��f����܂���B" & vbCrLf & _
          "�l���o�^���邩�A���̓N���A�Ŕj�����Ă���i��ł��������B" & vbCrLf & vbCrLf & _
          "�����Ŕj�����ĐV�������͂��J�n���܂����H"
    resp = MsgBox(msg, vbExclamation + vbYesNo, "���o�^���͂̊m�F")
    If resp <> vbYes Then
        GuardTransientInputBeforeNewMode = False
        SetPersonInputStatus "���o�^���͂����邽�߁A�ʐl�����͂𒆎~���܂����B�o�^�܂��͓��̓N���A���s���Ă��������B"
        Exit Function
    End If
    If addrCount > 0 Then ClearPendingAddresses addrKey
    If mhCount > 0 Then ClearPendingMarriageHistory mhKey
    ws.Range(CELL_PENDING_ADDR_KEY).ClearContents
    ws.Range(CELL_PENDING_MARRIAGE_KEY).ClearContents
    RefreshPendingMarriageHistoryPanel
End Function

Private Function CurrentInputHasUnsavedPerson(ByVal ws As Worksheet) As Boolean

    Dim modeName As String, personId As String, relText As String
    If ws Is Nothing Then Exit Function
    personId = CleanText(ws.Range(CELL_PERSON_ID).Value)
    If Len(personId) > 0 Then Exit Function
    modeName = CleanText(ws.Range(CELL_MODE).Value)
    relText = CleanText(ws.Range(CELL_REL_TO_DECEDENT).Value)
    If Len(modeName) = 0 And Len(relText) = 0 Then Exit Function

    '���o�^�l���ւ̗���ǉ��́A�����E���t�E�������̎����͂�����ꍇ�����F�߂�B
    '�֌W�{�^���������������̏�Ԃ��u���͒��l���v�Ƃ݂Ȃ��ƁA��l���̍������������l���֌�R�t�������B
    If Len(CleanText(ws.Range(CELL_GIVEN_NAME).Value)) > 0 Then CurrentInputHasUnsavedPerson = True: Exit Function
    If Len(CleanText(ws.Range(CELL_SURNAME).Value)) > 0 Then
        If StrComp(CleanText(ws.Range(CELL_SURNAME).Value), CleanText(ws.Range(CELL_AUTO_SURNAME).Value), vbTextCompare) <> 0 Then
            CurrentInputHasUnsavedPerson = True
            Exit Function
        End If
    End If
    If Len(CleanText(ws.Range(CELL_NOTE).Value)) > 0 Then CurrentInputHasUnsavedPerson = True: Exit Function
    If Len(CleanText(ws.Range(CELL_OCCUPATION).Value)) > 0 Then CurrentInputHasUnsavedPerson = True: Exit Function
    If Len(CleanText(ws.Range(CELL_MARRIAGE_COUNTERPART).Value)) > 0 Then CurrentInputHasUnsavedPerson = True: Exit Function
    If Len(CleanText(ws.Range(CELL_MARRIAGE_HIST_NOTE).Value)) > 0 Then CurrentInputHasUnsavedPerson = True: Exit Function
    If HasInputDate(ws.Range(CELL_BIRTH).Value) Then CurrentInputHasUnsavedPerson = True: Exit Function
    If HasInputDate(ws.Range(CELL_DEATH).Value) Then CurrentInputHasUnsavedPerson = True: Exit Function
    If HasInputDate(ws.Range(CELL_MARRIAGE).Value) Or HasInputDate(ws.Range(CELL_DIVORCE).Value) Then
        '�����������œ��͒��l���Ɋ񂹂�̂́A�z��ғ��͂ȂǑ���֌W�����m�ȏꍇ�Ɍ���B
        If modeName = MODE_SPOUSE Then CurrentInputHasUnsavedPerson = True
    End If

End Function

Public Sub RefreshPendingMarriageHistoryPanel()
    On Error GoTo EH
    Dim ws As Worksheet, bodyText As String, pendingKey As String, pendingId As String
    Dim countValue As Long, lastText As String, targetText As String, decisionText As String
    If Not SheetExists(SH_INPUT, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    pendingKey = CleanText(ws.Range(CELL_PENDING_MARRIAGE_KEY).Value)
    pendingId = PendingMarriagePersonId(pendingKey)
    countValue = PendingMarriageHistoryCount(pendingId, lastText)
    targetText = MarriageHistoryTargetText(ws)
    decisionText = CoupleChildDecisionTextForInput(ws)

    ws.Range(CELL_PENDING_MARRIAGE_PANEL_TITLE).Value = "���͒����������E�֌W����"
    If countValue > 0 Then
        bodyText = "�ǉ���: " & targetText & vbLf & _
                   "���ǉ� " & CStr(countValue) & "��" & vbLf & lastText & vbLf & _
                   "�l���o�^���ɖ{�lID�֎������f���܂��B"
    Else
        bodyText = "�ǉ���: " & targetText & vbLf & _
                   "������ǉ��ŁA�o�^�O�ł����͒��l���ɗ�����ς߂܂��B"
    End If
    If Len(decisionText) > 0 Then bodyText = bodyText & vbLf & decisionText
    ws.Range(CELL_PENDING_MARRIAGE_PANEL_BODY).Value = bodyText
    ws.Range(RANGE_PENDING_MARRIAGE_PANEL).WrapText = True
    Exit Sub
EH:
    Err.Clear
End Sub

Public Sub RefreshInputContextGuidance()
    On Error GoTo EH
    Dim ws As Worksheet, modeName As String, baseName As String, personText As String
    Dim msg As String, dmsg As String, cmsg As String, targetText As String
    If Not SheetExists(SH_INPUT, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    modeName = CleanText(ws.Range(CELL_MODE).Value)
    baseName = GetPersonValue(CleanText(ws.Range(CELL_BASE_ID).Value), P_DISPLAY)
    personText = PendingInputPersonDisplayText(ws)
    targetText = MarriageHistoryTargetText(ws)
    dmsg = DeathGuidanceTextForInput(ws)
    cmsg = CoupleChildDecisionTextForInput(ws)

    If Len(personText) > 0 Then
        msg = "���͒�: " & personText
    ElseIf Len(modeName) > 0 Then
        msg = "���͒�: " & modeName
    End If
    If Len(baseName) > 0 Then msg = JoinBriefPart(msg, "�: " & baseName)
    If Len(targetText) > 0 Then msg = JoinBriefPart(msg, "��������ǉ���: " & targetText)
    If Len(cmsg) > 0 Then msg = JoinBriefPart(msg, cmsg)
    If Len(dmsg) > 0 Then msg = JoinBriefPart(msg, dmsg)
    If Len(msg) > 0 Then SetPersonInputStatus msg
    RefreshPendingMarriageHistoryPanel
    Exit Sub
EH:
    Err.Clear
End Sub

Private Function PendingInputPersonDisplayText(ByVal ws As Worksheet) As String
    Dim pid As String, surname As String, givenName As String, relText As String, modeName As String, baseName As String
    If ws Is Nothing Then Exit Function
    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)
    If Len(pid) > 0 Then
        PendingInputPersonDisplayText = GetPersonValue(pid, P_DISPLAY)
        If Len(PendingInputPersonDisplayText) = 0 Then PendingInputPersonDisplayText = pid
        Exit Function
    End If
    surname = CleanText(ws.Range(CELL_SURNAME).Value)
    givenName = CleanText(ws.Range(CELL_GIVEN_NAME).Value)
    relText = CleanText(ws.Range(CELL_REL_TO_DECEDENT).Value)
    modeName = CleanText(ws.Range(CELL_MODE).Value)
    If Len(surname & givenName) > 0 Then
        PendingInputPersonDisplayText = Trim$(surname & " " & givenName)
        If Len(relText) > 0 Then PendingInputPersonDisplayText = PendingInputPersonDisplayText & "�i" & relText & "�j"
    ElseIf Len(modeName) > 0 Then
        baseName = GetPersonValue(CleanText(ws.Range(CELL_BASE_ID).Value), P_DISPLAY)
        If Len(baseName) > 0 And Len(relText) > 0 Then
            PendingInputPersonDisplayText = baseName & " �� " & relText
        ElseIf Len(relText) > 0 Then
            PendingInputPersonDisplayText = relText
        Else
            PendingInputPersonDisplayText = modeName
        End If
    End If
End Function

Private Function MarriageHistoryTargetText(ByVal ws As Worksheet) As String
    Dim pid As String, pendingText As String, baseId As String
    If ws Is Nothing Then Exit Function
    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)
    If Len(pid) > 0 Then
        MarriageHistoryTargetText = "�o�^�ϐl���u" & GetPersonValue(pid, P_DISPLAY) & "�v"
        Exit Function
    End If
    If CurrentInputHasUnsavedPerson(ws) Then
        pendingText = PendingInputPersonDisplayText(ws)
        If Len(pendingText) = 0 Then pendingText = "���͒��l��"
        MarriageHistoryTargetText = "���͒��l���u" & pendingText & "�v"
        Exit Function
    End If
    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)
    If Len(baseId) > 0 Then
        MarriageHistoryTargetText = "��l���u" & GetPersonValue(baseId, P_DISPLAY) & "�v"
    Else
        MarriageHistoryTargetText = "���m��"
    End If
End Function

Private Function CoupleChildDecisionTextForInput(ByVal ws As Worksheet) As String
    Dim modeName As String, baseId As String, bloodId As String, m As Variant, d As Variant, b As Variant
    Dim bloodRel As String, nextRel As String, bloodName As String, baseName As String
    If ws Is Nothing Then Exit Function
    modeName = CleanText(ws.Range(CELL_MODE).Value)
    If modeName <> MODE_CHILD And modeName <> MODE_GRANDCHILD Then Exit Function
    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)
    If Len(baseId) = 0 Then Exit Function
    b = ws.Range(CELL_BIRTH).Value
    If FindBaseDescendantSpouseCandidate(baseId, bloodId, m, d) Then
        bloodRel = GetPersonValue(bloodId, P_REL_DEC)
        nextRel = NextDescendantRelation(DescendantLevelFromRelation(bloodRel))
        bloodName = GetPersonValue(bloodId, P_DISPLAY)
        baseName = GetPersonValue(baseId, P_DISPLAY)
        If Len(nextRel) = 0 Then nextRel = "�q"
        If Not HasInputDate(b) Then
            CoupleChildDecisionTextForInput = "�v�w�q����: ���N�������Ȃ����ߕv�w�̎q�Ƃ��Ċm��ł��܂���B�o�^��� " & baseName & " ���̎q���Ƃ��Ĉ����A�v�w�������ɂ͂��܂���B"
        ElseIf Not HasInputDate(m) Then
            CoupleChildDecisionTextForInput = "�v�w�q����: ���������Ȃ����ߕv�w�̎q�Ƃ��Ċm��ł��܂���B����������ǉ����Ă��������B"
        ElseIf DateWithinMarriagePeriod(b, m, d) Then
            CoupleChildDecisionTextForInput = "�v�w�q����: �������ԓ��o���B�}��� " & nextRel & "�A���͕v�w�����B"
        Else
            CoupleChildDecisionTextForInput = "�v�w�q����: �������ԊO�o���B" & baseName & " ���̎q�Ƃ��Ĉ����A�v�w��������͉��낵�܂���B"
        End If
        Exit Function
    End If
End Function

Private Function DeathGuidanceTextForInput(ByVal ws As Worksheet) As String
    Dim deathValue As Variant, inh As Variant, modeName As String, relText As String, baseRel As String
    If ws Is Nothing Then Exit Function
    deathValue = ws.Range(CELL_DEATH).Value
    If Not HasInputDate(deathValue) Then Exit Function
    modeName = CleanText(ws.Range(CELL_MODE).Value)
    relText = CleanText(ws.Range(CELL_REL_TO_DECEDENT).Value)
    inh = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_INHERIT_DATE).Value
    If modeName = MODE_DECEDENT Or relText = "�푊���l" Then
        DeathGuidanceTextForInput = "���S������: �푊���l�͖v�N��̂ݕ\���B���S�ꏊ�ƍŌ�̏Z�����m�F�B"
        Exit Function
    End If
    baseRel = NormalizedRelationLabel(relText)
    If RelationIsSpousePersonLabel(baseRel) Then
        DeathGuidanceTextForInput = "���S������: �z��Ҏ��S�B���������A�Ō�̏Z���A�����J�n���z��҂����m�F�B"
    ElseIf baseRel = "��" Or baseRel = "��" Or InStr(1, baseRel, "�c", vbTextCompare) > 0 Then
        DeathGuidanceTextForInput = "���S������: �㐢�㎀�S�B�Ō�̏Z����o�^���A�Z���I�����͎��S�������ɂ��܂��B"
    ElseIf IsBloodDescendantRelationLabel(baseRel) Then
        If HasInputDate(inh) Then
            If CDate(SameDateOrBlank(deathValue)) < CDate(SameDateOrBlank(inh)) Then
                DeathGuidanceTextForInput = "���S������: �����J�n�O���S�̎q���B��P�ҁE�đ�P�҂̗L�����m�F���A���̐l���̎q�̓o�^�֐i��ł��������B"
            Else
                DeathGuidanceTextForInput = "���S������: �����J�n�㎀�S�̎q���B�����J�n���N��Ǝ��S��Z���I�����m�F�B"
            End If
        Else
            DeathGuidanceTextForInput = "���S������: �q�����S�B�����J�n����ݒ肷��Ƒ�P�m�F�̗v�ۂ𔻒�ł��܂��B"
        End If
    Else
        DeathGuidanceTextForInput = "���S������: �Ō�̏Z���ƏZ���I�������m�F�B"
    End If
End Function

Private Function RelationIsSpousePersonLabel(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    If Len(relText) = 0 Then Exit Function
    If InStr(1, relText, "�z��҂̎q", vbTextCompare) > 0 Then Exit Function
    If InStr(1, relText, "�z��҂Ƃ̎q", vbTextCompare) > 0 Then Exit Function
    If InStr(1, relText, "�O�z��҂Ƃ̎q", vbTextCompare) > 0 Then Exit Function
    If InStr(1, relText, "�A��q", vbTextCompare) > 0 Then Exit Function
    RelationIsSpousePersonLabel = (relText = "�z���" Or relText = "�O�z���" Or InStr(1, relText, "�̔z���", vbTextCompare) > 0)
End Function

Private Function IsBloodDescendantRelationLabel(ByVal relText As String) As Boolean
    relText = CleanText(relText)
    If RelationIsSpousePersonLabel(relText) Then Exit Function
    If InStr(1, relText, "�z���", vbTextCompare) > 0 Then Exit Function
    IsBloodDescendantRelationLabel = (BaseIsDirectChildRelation(relText) Or DescendantLevelFromRelation(relText) > 0)
End Function

Private Function PendingMarriageHistoryCount(ByVal pendingPersonId As String, ByRef lastText As String) As Long
    Dim ws As Worksheet, r As Long, n As Long, lineText As String
    pendingPersonId = CleanText(pendingPersonId)
    lastText = vbNullString
    If Len(pendingPersonId) = 0 Then Exit Function
    If Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(ws, MH_ID)
        If CleanText(ws.Cells(r, MH_PERSON_ID).Value) = pendingPersonId Then
            If CleanText(ws.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
                If CleanText(ws.Cells(r, MH_SHOW).Value) <> SHOW_NO Then
                    n = n + 1
                    lineText = MarriageHistoryBriefLine(ws, r)
                    If Len(lineText) > 0 Then lastText = "����: " & lineText
                End If
            End If
        End If
    Next r
    PendingMarriageHistoryCount = n
End Function

Private Function MarriageHistoryBriefLine(ByVal ws As Worksheet, ByVal rowNo As Long) As String
    Dim s As String, cp As String, m As Variant, d As Variant
    If ws Is Nothing Or rowNo <= 0 Then Exit Function
    cp = CleanText(ws.Cells(rowNo, MH_COUNTERPART_NAME).Value)
    m = ws.Cells(rowNo, MH_MARRIAGE).Value
    d = ws.Cells(rowNo, MH_DIVORCE).Value
    If Len(cp) > 0 Then s = cp
    If HasInputDate(m) Then s = JoinBriefPart(s, "���� " & Format(SameDateOrBlank(m), "yyyy/m/d"))
    If HasInputDate(d) Then s = JoinBriefPart(s, "���� " & Format(SameDateOrBlank(d), "yyyy/m/d"))
    If Len(s) = 0 Then s = "���t�E���薼������"
    MarriageHistoryBriefLine = s
End Function

Private Function JoinBriefPart(ByVal leftText As String, ByVal rightText As String) As String
    leftText = CleanText(leftText)
    rightText = CleanText(rightText)
    If Len(leftText) = 0 Then
        JoinBriefPart = rightText
    ElseIf Len(rightText) = 0 Then
        JoinBriefPart = leftText
    Else
        JoinBriefPart = leftText & " / " & rightText
    End If
End Function

Private Function YesNoText(ByVal flagValue As Boolean) As String
    If flagValue Then
        YesNoText = "����"
    Else
        YesNoText = "�Ȃ�"
    End If
End Function

Private Function PendingMarriagePersonId(ByVal pendingKey As String) As String

    pendingKey = CleanText(pendingKey)
    If Len(pendingKey) > 0 Then PendingMarriagePersonId = "__PENDING_MH__" & pendingKey

End Function

Private Function PendingMarriageKeyForInput(Optional ByVal createIfMissing As Boolean = True) As String

    Dim ws As Worksheet, k As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    k = CleanText(ws.Range(CELL_PENDING_MARRIAGE_KEY).Value)
    If Len(k) = 0 And createIfMissing Then
        k = "TMH" & Format(Now, "yyyymmddhhmmss") & Format(Int(Rnd() * 10000), "0000")
        ws.Range(CELL_PENDING_MARRIAGE_KEY).Value = k
    End If
    PendingMarriageKeyForInput = k

End Function

Private Sub FlushPendingMarriageHistoryToPerson(ByVal pendingKey As String, ByVal personId As String)

    Dim ws As Worksheet, wsIn As Worksheet, r As Long, pendingId As String
    Dim baseId As String, baseName As String, cpId As String, cpName As String
    pendingKey = CleanText(pendingKey)
    personId = CleanText(personId)
    If Len(pendingKey) = 0 Or Len(personId) = 0 Then Exit Sub
    pendingId = PendingMarriagePersonId(pendingKey)
    If Len(pendingId) = 0 Then Exit Sub
    EnsureMarriageHistoryWorkSheet
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    If SheetExists(SH_INPUT, ThisWorkbook) Then
        Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
        baseId = CleanText(wsIn.Range(CELL_BASE_ID).Value)
        If Len(baseId) > 0 And baseId <> personId Then baseName = GetPersonValue(baseId, P_DISPLAY)
    End If
    For r = 2 To LastRow(ws, MH_ID)
        If CleanText(ws.Cells(r, MH_PERSON_ID).Value) = pendingId Then
            If CleanText(ws.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
                cpId = CleanText(ws.Cells(r, MH_COUNTERPART_ID).Value)
                cpName = CleanText(ws.Cells(r, MH_COUNTERPART_NAME).Value)
                If Len(cpId) = 0 And Len(baseId) > 0 Then
                    If Len(cpName) = 0 Or StrComp(cpName, baseName, vbTextCompare) = 0 Then
                        ws.Cells(r, MH_COUNTERPART_ID).Value = baseId
                        If Len(baseName) > 0 Then ws.Cells(r, MH_COUNTERPART_NAME).Value = baseName
                    End If
                End If
                ws.Cells(r, MH_PERSON_ID).Value = personId
                ws.Cells(r, MH_UPDATED).Value = Now
            End If
        End If
    Next r
    UpdatePersonMarriageFactFieldsFromHistory personId
    DiagramGraphReset

End Sub

Private Sub ClearPendingMarriageHistory(ByVal pendingKey As String)

    Dim ws As Worksheet, r As Long, pendingId As String
    pendingKey = CleanText(pendingKey)
    If Len(pendingKey) = 0 Then Exit Sub
    pendingId = PendingMarriagePersonId(pendingKey)
    If Len(pendingId) = 0 Then Exit Sub
    If Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    For r = 2 To LastRow(ws, MH_ID)
        If CleanText(ws.Cells(r, MH_PERSON_ID).Value) = pendingId Then ws.Cells(r, MH_STATUS).Value = STATUS_CANCEL
    Next r
    RefreshPendingMarriageHistoryPanel

End Sub

Public Sub RegisterMarriageFactForBasePerson()

    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, pid As String, mDate As Variant, dDate As Variant, counterpart As String, noteText As String
    Dim counterpartId As String
    Dim pendingKey As String, isPendingPerson As Boolean
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    '�Z�������Ɠ������A�l���o�^�O�ł��u���͒��̐l���v�֍���������ς߂�悤�ɂ���B
    '��l���֓������ƁA���E��E���E���̔z��҂̍����������ʐl�ɕt�����ߋ֎~�B
    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)
    If Len(pid) = 0 Then
        If CurrentInputHasUnsavedPerson(ws) Then
            pendingKey = PendingMarriageKeyForInput(True)
            pid = PendingMarriagePersonId(pendingKey)
            isPendingPerson = True
        Else
            pid = CleanText(ws.Range(CELL_BASE_ID).Value)
        End If
    End If

    mDate = ws.Range(CELL_MARRIAGE).Value
    dDate = ws.Range(CELL_DIVORCE).Value
    If Not HasInputDate(mDate) And Not HasInputDate(dDate) Then Err.Raise 5, , "�������܂��͗���������͂��Ă��������B"

    counterpart = CleanText(ws.Range(CELL_MARRIAGE_COUNTERPART).Value)
    noteText = CleanText(ws.Range(CELL_MARRIAGE_HIST_NOTE).Value)
    counterpartId = MarriageCounterpartIdFromCurrentBase(ws, pid)
    If Len(counterpart) = 0 Then counterpart = MarriageCounterpartNameFromCurrentBase(ws, pid)
    If Len(counterpart) = 0 And Len(counterpartId) > 0 Then counterpart = GetPersonValue(counterpartId, P_DISPLAY)

    If Len(pid) = 0 Then Err.Raise 5, , "����������R�Â���l����������܂���B"

    UpsertMarriageHistory pid, counterpartId, counterpart, mDate, dDate, "�����������", "M|" & pid & "|" & counterpartId, noteText
    If Not isPendingPerson Then
        ReconcileMarriageHistoryCounterpartsFromRelations
        SyncLegacyMarriageFactsFromHistory
        RefreshCandidatesAfterPersonRegister pid
    End If
    RefreshMarriageDateCandidatesOnly mDate, dDate

    '�Z���ǉ������Z���Ɠ������A����ǉ���͗���p�̓��͗�������ɂ��ĘA�����͂��₷������B
    ws.Range(CELL_MARRIAGE).ClearContents
    ws.Range(CELL_DIVORCE).ClearContents
    ws.Range(CELL_MARRIAGE_COUNTERPART & ":" & CELL_MARRIAGE_HIST_NOTE).ClearContents

    RefreshPendingMarriageHistoryPanel
    RefreshInputContextGuidance
    DiagramGraphReset
    If isPendingPerson Then
        SetPersonInputStatus "���͒��̐l���ɍ����E�����̗��������ǉ����܂����B�����č���������ǉ��ł��܂��B�l���o�^���ɖ{�l�֕R�Â��܂��B"
    Else
        SetPersonInputStatus "�����E�����̗�����ǉ����܂����B�����č���������ǉ��ł��܂��B"
    End If
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "RegisterMarriageFactForBasePerson", "��������ǉ�", "���͒��̐l���A�������E�������A�������薼�A�����������m�F���Ă��������B"

End Sub

Private Function MarriageCounterpartIdFromCurrentBase(ByVal ws As Worksheet, ByVal personId As String) As String
    Dim baseId As String
    If ws Is Nothing Then Exit Function
    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)
    personId = CleanText(personId)
    If Len(baseId) = 0 Then Exit Function
    If Len(personId) > 0 Then
        If personId = baseId Then Exit Function
    End If
    If CleanText(ws.Range(CELL_MODE).Value) = MODE_SPOUSE Then MarriageCounterpartIdFromCurrentBase = baseId
End Function

Private Function MarriageCounterpartNameFromCurrentBase(ByVal ws As Worksheet, ByVal personId As String) As String
    Dim baseId As String, baseName As String
    If ws Is Nothing Then Exit Function
    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)
    If Len(baseId) > 0 Then
        If CleanText(ws.Range(CELL_MODE).Value) = MODE_SPOUSE Then
            baseName = GetPersonValue(baseId, P_DISPLAY)
            If Len(baseName) > 0 Then MarriageCounterpartNameFromCurrentBase = baseName
            Exit Function
        End If
    End If
    MarriageCounterpartNameFromCurrentBase = vbNullString
End Function

Private Sub UpdatePersonMarriageFactFieldsFromHistory(ByVal personId As String)
    Dim r As Long, m As Variant, d As Variant
    personId = CleanText(personId)
    If Len(personId) = 0 Then Exit Sub
    If Not SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then Exit Sub
    m = Empty: d = Empty
    '�����������ꍇ�́A�o�^���O�ɕۑ������l���\�̓��t�������Ȃ��B
    '���������������������A���̓�����Ԃ��݊���֓�������B
    If Not MarriageHistoryTryGetPrimaryPeriod(personId, m, d) Then Exit Sub
    r = FindPersonRow(personId)
    If r = 0 Then Exit Sub
    If HasInputDate(m) Then
        ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, P_MARRIAGE).Value = SameDateOrBlank(m)
    Else
        ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, P_MARRIAGE).ClearContents
    End If
    If HasInputDate(d) Then
        ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, P_DIVORCE).Value = SameDateOrBlank(d)
    Else
        ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, P_DIVORCE).ClearContents
    End If
End Sub

Public Sub SyncMarriageHistoryFromLegacyTables()
    '���`���̐l���P�ƍ�����/��������W_�֌W�̔z��ғ��t���A�Ɨ�����W_���������֔�j��Ŏ�荞�ށB
    '�ڍs�����̎��̂� modMarriageHistory ���ɏW�񂵁A�o�͏����Ŋ֌W�\�����������Ȃ��B
    On Error GoTo EH
    EnsureMarriageHistoryWorkSheet
    BackfillMarriageHistoryFromLegacyFacts
    DiagramGraphReset
    Exit Sub
EH:
    On Error Resume Next
    RuntimeAppendLog "WARN", "SyncMarriageHistoryFromLegacyTables", "���������ڍs", "", Err.Number, Err.Description, Err.Source
    On Error GoTo 0
End Sub


Private Sub UpsertManualTimelineEvent(ByVal personId As String, _
        ByVal eventDate As Variant, _
        ByVal eventType As String, _
        ByVal content As String, _
        ByVal srcType As String, _
        ByVal srcId As String)

    Dim ws As Worksheet, r As Long
    If Len(personId) = 0 Or Not HasInputDate(eventDate) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_EVENT)
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, E_PERSON_ID).Value) = personId Then
            If HasInputDate(ws.Cells(r, E_DATE).Value) And HasInputDate(eventDate) Then
                If CLng(CDate(SameDateOrBlank(ws.Cells(r, E_DATE).Value))) = CLng(CDate(SameDateOrBlank(eventDate))) Then
                    If CStr(ws.Cells(r, E_TYPE).Value) = eventType _
                            And CStr(ws.Cells(r, E_SOURCE_TYPE).Value) = srcType _
                            And CStr(ws.Cells(r, E_SOURCE_ID).Value) = srcId Then
                        ws.Cells(r, E_CONTENT).Value = content
                        ws.Cells(r, E_AUTO).Value = "�����"
                        ws.Cells(r, E_SHOW).Value = SHOW_YES
                        ws.Cells(r, E_STATUS).Value = STATUS_ACTIVE
                        Exit Sub
                    End If
                End If
            End If
        End If
    Next r
    r = NextBlankRow(ws, 1)
    ws.Cells(r, E_ID).Value = NextId("�C�x���g")
    ws.Cells(r, E_PERSON_ID).Value = personId
    ws.Cells(r, E_DATE).Value = SameDateOrBlank(eventDate)
    ws.Cells(r, E_YEAR).Value = Year(CDate(SameDateOrBlank(eventDate)))
    ws.Cells(r, E_TYPE).Value = eventType
    ws.Cells(r, E_CONTENT).Value = content
    ws.Cells(r, E_AUTO).Value = "�����"
    ws.Cells(r, E_SOURCE_TYPE).Value = srcType
    ws.Cells(r, E_SOURCE_ID).Value = srcId
    ws.Cells(r, E_SHOW).Value = SHOW_YES
    ws.Cells(r, E_STATUS).Value = STATUS_ACTIVE

End Sub


Public Sub FillFormerSurnameFromAuto(Optional ByVal showMessage As Boolean = True)

    Dim ws As Worksheet, modeName As String, autoSurname As String, currentSurname As String, relText As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    modeName = CleanText(ws.Range(CELL_MODE).Value)
    autoSurname = CleanText(ws.Range(CELL_AUTO_SURNAME).Value)
    currentSurname = CleanText(ws.Range(CELL_SURNAME).Value)
    If Len(autoSurname) = 0 Or Len(currentSurname) = 0 Then Exit Sub
    If StrComp(autoSurname, currentSurname, vbTextCompare) = 0 Then Exit Sub
    If Len(CleanText(ws.Range(CELL_FORMER_SURNAME).Value)) > 0 Then Exit Sub

    relText = ResolveRelationTextForRegistration(modeName, CleanText(ws.Range(CELL_BASE_ID).Value), _
        CleanText(ws.Range(CELL_REL_TO_DECEDENT).Value), CleanText(ws.Range(CELL_GENDER).Value), ws.Range(CELL_BIRTH).Value)

    If ShouldAutoFormerSurname(modeName, relText) Then
        ws.Range(CELL_FORMER_SURNAME).Value = autoSurname
        If showMessage Then SetPersonInputStatus "�����Ɂw" & autoSurname & "�x��⊮���܂����B�s�v�ȏꍇ���������Ă��������B"
    ElseIf showMessage Then
        SetPersonInputStatus "���̊֌W�ł͋����������⊮���܂���B�K�v�ȏꍇ�����������֓��͂��Ă��������B"
    End If

End Sub

Private Function ShouldAutoFormerSurname(ByVal modeName As String, ByVal relText As String) As Boolean

    relText = CleanText(relText)

    '�����⊮�͐��ʂŌ��߂Ȃ��B
    '�u��l���R���̐����v�ƌ��ݐ����Ⴄ�ꍇ�ɁA�q�E���E�]���E�����Ȃǂ̎q���n�����⊮����B
    '�������A�z��Җ{�l��u�z��҂̎q�v�Ɩ������ꂽ�l���ɂ́A��l�����̋���������ɓ���Ȃ��B
    If InStr(1, relText, "�z���", vbTextCompare) > 0 Then Exit Function

    If IsDirectDescendantRelationText(relText) Then
        ShouldAutoFormerSurname = True
    ElseIf Len(relText) = 0 Then
        ShouldAutoFormerSurname = (modeName = MODE_CHILD Or modeName = MODE_GRANDCHILD)
    End If

End Function

Public Sub MakeAddressKeyFromInput()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    ws.Range(CELL_ADDR_KEY).Value = NormalizeAddress(ws.Range(CELL_ADDR_TEXT).Value)

End Sub

Public Sub ApplySelectedAddressCandidate()

    Dim ws As Worksheet, sel As String, id As String, r As Long

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    sel = CleanText(ws.Range(CELL_ADDR_CAND).Value)

    If Len(sel) = 0 Then Exit Sub

    If InStr(sel, "��l���Ɠ��l") > 0 Then
        CopyBaseCurrentAddress False
        Exit Sub
    End If

    id = ParseIdFromCandidate(sel)

    r = FindAddressCandidateRow(id)

    If r = 0 Then Exit Sub

    ws.Range(CELL_ADDR_TEXT).Value = ThisWorkbook.Worksheets(SH_W_ADDR_CAND).Cells(r, AC_TEXT).Value

    ws.Range(CELL_ADDR_KEY).Value = ThisWorkbook.Worksheets(SH_W_ADDR_CAND).Cells(r, AC_KEY).Value
    ws.Range(CELL_ADDR_SOURCE).Value = "�Z�����I��"
    ws.Range(CELL_ADDR_COPY_SOURCE_ID).ClearContents

End Sub

Public Sub CopyBaseCurrentAddress(Optional ByVal showMessage As Boolean = True)

    Dim ws As Worksheet, baseId As String, addrText As String, addrKey As String, sourceAddrId As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)

    If Len(baseId) = 0 Then Exit Sub

    GetCurrentAddressParts baseId, addrText, addrKey
    sourceAddrId = CurrentAddressHistoryId(baseId)

    If Len(addrText) > 0 Then

        ws.Range(CELL_ADDR_TEXT).Value = addrText

        ws.Range(CELL_ADDR_KEY).Value = addrKey
        ws.Range(CELL_ADDR_SOURCE).Value = "��l���Z���R�s�["
        ws.Range(CELL_ADDR_COPY_SOURCE_ID).Value = sourceAddrId

        If showMessage Then NotifyInfo "��l���̏Z�����R�s�[���܂����B"

    End If

End Sub


Public Sub CopyBaseAddressHistoryToCurrentOrPending()

    On Error GoTo EH
    AppBegin
    Dim wsIn As Worksheet, baseId As String, pid As String, pendingKey As String
    Dim wsA As Worksheet, r As Long, copied As Long
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    baseId = CleanText(wsIn.Range(CELL_BASE_ID).Value)
    pid = CleanText(wsIn.Range(CELL_PERSON_ID).Value)
    If Len(baseId) = 0 Then Err.Raise 5, , "��l�������ݒ�ł��B"
    If Len(pid) = 0 Then pendingKey = PendingAddressKeyForInput(True)
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    For r = 2 To LastRow(wsA, 1)
        If CStr(wsA.Cells(r, A_PERSON_ID).Value) = baseId _
                And CStr(wsA.Cells(r, A_STATUS).Value) <> STATUS_CANCEL _
                And Len(CleanText(wsA.Cells(r, A_TEXT).Value)) > 0 Then
            If Len(pid) > 0 Then
                CopyAddressHistoryRowToPerson r, pid, baseId
            Else
                StageAddressHistoryRowToPending r, pendingKey, baseId
            End If
            copied = copied + 1
        End If
    Next r
    If copied = 0 Then Err.Raise 5, , "��l���̏Z������������܂���B"
    If Len(pid) > 0 Then
        RefreshAddressCandidateListOnly
        UpdateRepresentativeAddressId pid
        SetPersonInputStatus "��l���̏Z��������" & copied & "���R�s�[���܂����B"
    Else
        SetPersonInputStatus "��l���̏Z�����������ǉ����܂����B�l���o�^����" & copied & "���܂Ƃ߂ēo�^���܂��B"
    End If
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "CopyBaseAddressHistoryToCurrentOrPending", "�Z�������R�s�[", "��l���ƏZ�������̏�Ԃ��m�F���Ă��������B"

End Sub

Private Sub CopyAddressHistoryRowToPerson(ByVal srcRow As Long, ByVal personId As String, ByVal copySourcePersonId As String)

    Dim wsA As Worksheet, r As Long, candId As String
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    candId = GetOrCreateAddressCandidate(CStr(wsA.Cells(srcRow, A_TEXT).Value), CStr(wsA.Cells(srcRow, A_KEY).Value), personId)
    r = FindMatchingAddressHistoryRow(personId, CStr(wsA.Cells(srcRow, A_KEY).Value), CStr(wsA.Cells(srcRow, A_TYPE).Value), wsA.Cells(srcRow, A_START).Value, wsA.Cells(srcRow, A_END).Value)
    If r = 0 Then
        r = NextBlankRow(wsA, 1)
        wsA.Cells(r, A_ID).Value = NextId("�Z������")
        wsA.Cells(r, A_CREATED).Value = Now
    End If
    wsA.Cells(r, A_PERSON_ID).Value = personId
    wsA.Cells(r, A_CAND_ID).Value = candId
    wsA.Cells(r, A_TYPE).Value = wsA.Cells(srcRow, A_TYPE).Value
    wsA.Cells(r, A_START).Value = wsA.Cells(srcRow, A_START).Value
    wsA.Cells(r, A_END).Value = wsA.Cells(srcRow, A_END).Value
    wsA.Cells(r, A_TEXT).Value = wsA.Cells(srcRow, A_TEXT).Value
    wsA.Cells(r, A_KEY).Value = wsA.Cells(srcRow, A_KEY).Value
    wsA.Cells(r, A_SOURCE).Value = "��l���Z�������R�s�["
    wsA.Cells(r, A_COPY_PERSON_ID).Value = copySourcePersonId
    wsA.Cells(r, A_COPY_ADDR_ID).Value = wsA.Cells(srcRow, A_ID).Value
    wsA.Cells(r, A_NOTE).Value = wsA.Cells(srcRow, A_NOTE).Value
    wsA.Cells(r, A_STATUS).Value = STATUS_ACTIVE
    wsA.Cells(r, A_UPDATED).Value = Now
    If Len(CleanText(wsA.Cells(srcRow, A_START_KIND).Value)) = 0 Then
        wsA.Cells(r, A_START_KIND).Value = "���Z�J�n"
    Else
        wsA.Cells(r, A_START_KIND).Value = CleanText(wsA.Cells(srcRow, A_START_KIND).Value)
    End If

End Sub

Private Sub StageAddressHistoryRowToPending(ByVal srcRow As Long, ByVal pendingKey As String, ByVal copySourcePersonId As String)

    Dim wsA As Worksheet, wsP As Worksheet, r As Long
    If Len(pendingKey) = 0 Then Exit Sub
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    Set wsP = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    r = NextBlankRow(wsP, 1)
    wsP.Cells(r, AP_KEY).Value = pendingKey
    wsP.Cells(r, AP_SEQ).Value = PendingAddressCount(pendingKey) + 1
    wsP.Cells(r, AP_ADDR_TEXT).Value = wsA.Cells(srcRow, A_TEXT).Value
    wsP.Cells(r, AP_ADDR_KEY).Value = wsA.Cells(srcRow, A_KEY).Value
    wsP.Cells(r, AP_ADDR_TYPE).Value = wsA.Cells(srcRow, A_TYPE).Value
    wsP.Cells(r, AP_START).Value = wsA.Cells(srcRow, A_START).Value
    wsP.Cells(r, AP_END).Value = wsA.Cells(srcRow, A_END).Value
    wsP.Cells(r, AP_SOURCE).Value = "��l���Z�������R�s�["
    wsP.Cells(r, AP_NOTE).Value = wsA.Cells(srcRow, A_NOTE).Value
    wsP.Cells(r, AP_COPY_PERSON_ID).Value = copySourcePersonId
    wsP.Cells(r, AP_COPY_ADDR_ID).Value = wsA.Cells(srcRow, A_ID).Value
    wsP.Cells(r, AP_CREATED).Value = Now
    wsP.Cells(r, AP_STATUS).Value = STATUS_ACTIVE
    If Len(CleanText(wsA.Cells(srcRow, A_START_KIND).Value)) = 0 Then
        wsP.Cells(r, AP_START_KIND).Value = "���Z�J�n"
    Else
        wsP.Cells(r, AP_START_KIND).Value = CleanText(wsA.Cells(srcRow, A_START_KIND).Value)
    End If

End Sub

Public Sub CopyLastAddress()

    Dim ws As Worksheet, r As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    r = LastRow(ws, AC_LAST_USED)

    If r < 2 Then Exit Sub

    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_TEXT).Value = ws.Cells(r, AC_TEXT).Value

    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_KEY).Value = ws.Cells(r, AC_KEY).Value

End Sub

Public Sub UseMarriageDateAsAddressStart()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If HasInputDate(ws.Range(CELL_MARRIAGE).Value) Then
        ws.Range(CELL_ADDR_START).Value = SameDateOrBlank(ws.Range(CELL_MARRIAGE).Value)
        ws.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"
        EnsurePersonInputDateDisplay ws
        SetPersonInputStatus "���������Z���J�n���ɔ��f���܂����B"
    Else
        SetPersonInputStatus "�������������͂܂��͓��t�Ƃ��ēǂ߂Ȃ����߁A�Z���J�n���ɔ��f���Ă��܂���B"
    End If

End Sub

Public Sub UseBirthDateAsAddressStart()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If HasInputDate(ws.Range(CELL_BIRTH).Value) Then
        ws.Range(CELL_ADDR_START).Value = SameDateOrBlank(ws.Range(CELL_BIRTH).Value)
        ws.Range(CELL_ADDR_START_KIND).Value = "���Z�J�n"
        EnsurePersonInputDateDisplay ws
        SetPersonInputStatus "�o�������Z���J�n���ɔ��f���܂����B"
    Else
        SetPersonInputStatus "�o�����������͂܂��͓��t�Ƃ��ēǂ߂Ȃ����߁A�Z���J�n���ɔ��f���Ă��܂���B"
    End If

End Sub

Public Sub UseDeathDateAsAddressEnd()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If HasInputDate(ws.Range(CELL_DEATH).Value) Then
        ws.Range(CELL_ADDR_END).Value = SameDateOrBlank(ws.Range(CELL_DEATH).Value)
        EnsurePersonInputDateDisplay ws
        SetPersonInputStatus "���S�����Z���I�����ɔ��f���܂����B"
    Else
        SetPersonInputStatus "���S���������͂܂��͓��t�Ƃ��ēǂ߂Ȃ����߁A�Z���I�����ɔ��f���Ă��܂���B"
    End If

End Sub

Public Sub UseDivorceDateAsAddressEnd()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If HasInputDate(ws.Range(CELL_DIVORCE).Value) Then
        ws.Range(CELL_ADDR_END).Value = SameDateOrBlank(ws.Range(CELL_DIVORCE).Value)
        EnsurePersonInputDateDisplay ws
        SetPersonInputStatus "���������Z���I�����ɔ��f���܂����B"
    Else
        SetPersonInputStatus "�������������͂܂��͓��t�Ƃ��ēǂ߂Ȃ����߁A�Z���I�����ɔ��f���Ă��܂���B"
    End If

End Sub

Public Function FindAddressCandidateRow(ByVal candId As String) As Long

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, AC_ID).Value) = candId Then FindAddressCandidateRow = r: Exit Function

    Next r

End Function

Public Sub GetCurrentAddressParts(ByVal personId As String, ByRef addressText As String, ByRef addressKey As String)

    Dim ws As Worksheet, bestR As Long

    If Len(CleanText(personId)) = 0 Then Exit Sub

    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Sub

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    bestR = BestAddressHistoryRowForPerson(personId)

    If bestR > 0 Then

        addressText = CStr(ws.Cells(bestR, A_TEXT).Value)

        addressKey = CStr(ws.Cells(bestR, A_KEY).Value)

    End If

End Sub

Public Function CurrentAddressHistoryId(ByVal personId As String) As String
    Dim ws As Worksheet, bestR As Long
    If Len(CleanText(personId)) = 0 Then Exit Function
    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    bestR = BestAddressHistoryRowForPerson(personId)
    If bestR > 0 Then CurrentAddressHistoryId = CleanText(ws.Cells(bestR, A_ID).Value)
End Function

Public Function GetCurrentAddressText(ByVal personId As String) As String

    Dim t As String, k As String

    GetCurrentAddressParts personId, t, k

    GetCurrentAddressText = t

End Function

Public Sub RefreshRepresentativeAddresses()

    On Error Resume Next

    Dim wsP As Worksheet, r As Long, pid As String

    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub

    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)

    For r = 2 To LastRow(wsP, 1)

        pid = CleanText(wsP.Cells(r, P_ID).Value)

        If Len(pid) > 0 And CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            UpdateRepresentativeAddressId pid

        End If

    Next r

    On Error GoTo 0

End Sub

Public Sub UpdateRepresentativeAddressId(ByVal personId As String)

    Dim personRow As Long, bestR As Long

    If Len(CleanText(personId)) = 0 Then Exit Sub

    personRow = FindPersonRow(personId)

    If personRow = 0 Then Exit Sub

    bestR = BestAddressHistoryRowForPerson(personId)

    If bestR > 0 Then
        ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_REP_ADDR_ID).Value = _
            ThisWorkbook.Worksheets(SH_W_ADDR_HIST).Cells(bestR, A_ID).Value
    Else
        '�Z����S���������ɌÂ���\�Z��ID���c���ƁA�J�[�h�E���ʏo�͂�
        '���݂��Ȃ��Z�����Q�Ƃ������邽�߁A��\ID�����K��Ԃ֖߂��B
        ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_REP_ADDR_ID).ClearContents
    End If

End Sub

Private Function BestAddressHistoryRowForPerson(ByVal personId As String) As Long

    Dim ws As Worksheet, r As Long, lastR As Long

    Dim bestScore As Double, score As Double

    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Function

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    lastR = LastRow(ws, 1)

    bestScore = -1E+20

    For r = 2 To lastR

        If CStr(ws.Cells(r, A_PERSON_ID).Value) = personId _
                And CStr(ws.Cells(r, A_STATUS).Value) <> STATUS_CANCEL _
                And Len(CStr(ws.Cells(r, A_ID).Value)) > 0 Then

            score = AddressRepresentativeScore(ws, r)

            If score > bestScore Then

                bestScore = score

                BestAddressHistoryRowForPerson = r

            End If

        End If

    Next r

End Function

Private Function AddressRepresentativeScore(ByVal ws As Worksheet, ByVal rowNo As Long) As Double

    Dim baseDate As Variant, st As Variant, en As Variant, score As Double

    baseDate = PreferredAddressBaseDate()

    st = ws.Cells(rowNo, A_START).Value

    en = ws.Cells(rowNo, A_END).Value

    score = rowNo

    If CleanText(ws.Cells(rowNo, A_TYPE).Value) = "���Z�n" Then score = score + 100000

    If HasInputDate(st) Then score = score + CDbl(CDate(SameDateOrBlank(st))) / 100

    If HasInputDate(baseDate) Then

        If HasInputDate(st) Then

            If CDate(SameDateOrBlank(st)) <= CDate(SameDateOrBlank(baseDate)) Then score = score + 200000 Else score = score - 50000

        End If

        If HasInputDate(en) Then

            If CDate(SameDateOrBlank(en)) >= CDate(SameDateOrBlank(baseDate)) Then score = score + 200000 Else score = score - 20000

        Else

            score = score + 150000

        End If

    ElseIf Not HasInputDate(en) Then

        score = score + 50000

    End If

    AddressRepresentativeScore = score

End Function

Private Function PreferredAddressBaseDate() As Variant

    On Error Resume Next

    PreferredAddressBaseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_INHERIT_DATE).Value

    If Not HasInputDate(PreferredAddressBaseDate) Then _
        PreferredAddressBaseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value

    If Not HasInputDate(PreferredAddressBaseDate) Then PreferredAddressBaseDate = Date

    On Error GoTo 0

End Function

Private Sub EnsureCandidatesWarmForInputMode()

    '���̓��[�h�ؑւ̃z�b�g�p�X�ł͌��S�Đ����𑖂点�Ȃ��B
    '���V�[�g�����\�z�E��̏ꍇ�����A�C���Ƃ��Ĉ�x�����č\�z����B
    On Error GoTo EH
    Dim wsC As Worksheet
    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    If LastRow(wsC, 4) < 2 Then
        If LastRow(ThisWorkbook.Worksheets(SH_W_PERSON), 1) >= 2 Then
            RefreshCandidates
        End If
    End If
    Exit Sub
EH:
    RuntimeAppendLog "WARN", "EnsureCandidatesWarmForInputMode", "��≷��", "���͐ؑ�", Err.Number, Err.Description, Err.Source
    Err.Clear

End Sub

Public Sub RefreshCandidates()

    Dim wsC As Worksheet, wsP As Worksheet, wsA As Worksheet, r As Long, outR As Long, dict As Object, key As Variant

    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)

    wsC.Range("A2:O" & Application.Max(500, LastRow(wsC, 1), LastRow(wsC, 2), LastRow(wsC, 4), LastRow(wsC, 12), LastRow(wsC, 15))).ClearContents

    Set dict = CreateObject("Scripting.Dictionary")

    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)

    For r = 2 To LastRow(wsP, 1)

        If CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            If Len(CStr(wsP.Cells(r, P_SURNAME).Value)) > 0 Then dict(CStr(wsP.Cells(r, P_SURNAME).Value)) = 1

            If Len(CStr(wsP.Cells(r, P_FORMER).Value)) > 0 Then dict(CStr(wsP.Cells(r, P_FORMER).Value)) = 1

        End If

    Next r

    outR = 2

    For Each key In dict.Keys

        wsC.Cells(outR, 1).Value = key

        outR = outR + 1

    Next key

    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    outR = 2
    wsC.Cells(outR, 2).Value = "��l���Ɠ��l"
    wsC.Cells(outR, 3).Value = "__BASE__"
    outR = outR + 1
    For r = 2 To LastRow(wsA, 1)

        If Len(CStr(wsA.Cells(r, AC_ID).Value)) > 0 Then

            wsC.Cells(outR, 2).Value = wsA.Cells(r, AC_ID).Value & " " & wsA.Cells(r, AC_TEXT).Value
            wsC.Cells(outR, 3).Value = wsA.Cells(r, AC_ID).Value
            wsC.Cells(outR, 15).Value = wsA.Cells(r, AC_TEXT).Value

            outR = outR + 1

        End If

    Next r

    outR = 2
    For r = 2 To LastRow(wsP, 1)

        If Len(CStr(wsP.Cells(r, P_ID).Value)) > 0 And CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            wsC.Cells(outR, 4).Value = wsP.Cells(r, P_ID).Value & " " & wsP.Cells(r, P_DISPLAY).Value & "�i" & wsP.Cells(r, P_REL_DEC).Value & "�j"

            wsC.Cells(outR, 5).Value = wsP.Cells(r, P_ID).Value

            outR = outR + 1

        End If

    Next r

    FillStaticCandidates wsC

    FillDateCandidates wsC

    CompactCandidateColumn wsC, 1
    CompactCandidatePairColumns wsC, 2, 3
    CompactCandidateColumn wsC, 15
    CompactCandidatePairColumns wsC, 4, 5
    CompactCandidateColumn wsC, 12
    CompactCandidateColumn wsC, 13
    CompactCandidateColumn wsC, 14
    CompactCandidateColumn wsC, 15

End Sub

Private Sub RefreshAddressCandidateListOnly()

    '�Z���ǉ���̃z�b�g�p�X�ł́A�l��������t���܂ō�蒼���Ȃ��B
    '�Z�����񂾂����X�V���A�o�^����̌y���Ɠ��͌��̈ێ��𗼗�����B
    Dim wsC As Worksheet, wsA As Worksheet, r As Long, clearLast As Long, outR As Long

    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    clearLast = Application.Max(500, LastRow(wsC, 2), LastRow(wsC, 3), LastRow(wsC, 15), LastRow(wsA, 1))
    wsC.Range("B2:C" & clearLast).ClearContents
    wsC.Range("O2:O" & clearLast).ClearContents

    outR = 2
    wsC.Cells(outR, 2).Value = "��l���Ɠ��l"
    wsC.Cells(outR, 3).Value = "__BASE__"
    outR = outR + 1
    For r = 2 To LastRow(wsA, 1)

        If Len(CStr(wsA.Cells(r, AC_ID).Value)) > 0 Then

            wsC.Cells(outR, 2).Value = wsA.Cells(r, AC_ID).Value & " " & wsA.Cells(r, AC_TEXT).Value
            wsC.Cells(outR, 3).Value = wsA.Cells(r, AC_ID).Value
            wsC.Cells(outR, 15).Value = wsA.Cells(r, AC_TEXT).Value
            outR = outR + 1

        End If

    Next r

    CompactCandidatePairColumns wsC, 2, 3

End Sub

Private Sub RefreshCandidatesAfterPersonRegister(ByVal personId As String)

    '�l���o�^����̃z�b�g�p�X�ł� W_��� �S�̂������č�蒼���Ȃ��B
    '���E�l�����E�Z�����E������͂������t�������������f����B
    On Error GoTo EH

    Dim wsC As Worksheet, wsP As Worksheet, wsIn As Worksheet
    Dim pr As Long, candidateText As String

    If Len(personId) = 0 Then Exit Sub

    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)

    pr = FindPersonRow(personId)
    If pr > 0 Then
        AddCandidateTextUnique wsC, 1, CStr(wsP.Cells(pr, P_SURNAME).Value), 0
        AddCandidateTextUnique wsC, 1, CStr(wsP.Cells(pr, P_FORMER).Value), 0
        candidateText = CStr(wsP.Cells(pr, P_ID).Value) & " " & _
            CStr(wsP.Cells(pr, P_DISPLAY).Value) & "�i" & CStr(wsP.Cells(pr, P_REL_DEC).Value) & "�j"
        UpsertPersonCandidate wsC, CStr(wsP.Cells(pr, P_ID).Value), candidateText
    End If

    RefreshAddressCandidateListOnly
    AddDateCandidateToColumnUnique wsC, 12, wsIn.Range(CELL_MARRIAGE).Value, 0
    AddDateCandidateToColumnUnique wsC, 13, wsIn.Range(CELL_DIVORCE).Value, 0
    AddDateCandidateToColumnUnique wsC, 14, wsIn.Range(CELL_BIRTH).Value, 0
    AddDateCandidateToColumnUnique wsC, 14, wsIn.Range(CELL_DEATH).Value, 0
    AddDateCandidateToColumnUnique wsC, 14, wsIn.Range(CELL_ADDR_START).Value, 0
    AddDateCandidateToColumnUnique wsC, 14, wsIn.Range(CELL_ADDR_END).Value, 0
    Exit Sub

EH:
    RuntimeAppendLog "WARN", "RefreshCandidatesAfterPersonRegister", "��⍷���X�V", personId, Err.Number, Err.Description, Err.Source
    Err.Clear

End Sub

Private Sub UpsertPersonCandidate(ByVal wsC As Worksheet, ByVal personId As String, ByVal candidateText As String)

    Dim r As Long, firstBlank As Long
    personId = CleanText(personId)
    candidateText = CleanText(candidateText)
    If Len(personId) = 0 Or Len(candidateText) = 0 Then Exit Sub

    Dim maxRow As Long
    maxRow = Application.Max(LastRow(wsC, 4) + 50, LastRow(wsC, 5) + 50, 500)
    For r = 2 To maxRow
        If CleanText(wsC.Cells(r, 5).Value) = personId Then
            wsC.Cells(r, 4).Value = candidateText
            wsC.Cells(r, 5).Value = personId
            Exit Sub
        End If
        If firstBlank = 0 Then
            If Len(CleanText(wsC.Cells(r, 4).Value)) = 0 And Len(CleanText(wsC.Cells(r, 5).Value)) = 0 Then firstBlank = r
        End If
    Next r

    If firstBlank > 0 Then
        wsC.Cells(firstBlank, 4).Value = candidateText
        wsC.Cells(firstBlank, 5).Value = personId
    End If

End Sub

Private Sub AddCandidateTextUnique(ByVal wsC As Worksheet, ByVal colNum As Long, ByVal textValue As String, ByVal maxRow As Long)

    Dim r As Long, firstBlank As Long, v As String
    v = CleanText(textValue)
    If Len(v) = 0 Then Exit Sub
    If maxRow < 2 Then maxRow = Application.Max(LastRow(wsC, colNum) + 50, 500)

    For r = 2 To maxRow
        If StrComp(CleanText(wsC.Cells(r, colNum).Value), v, vbTextCompare) = 0 Then Exit Sub
        If firstBlank = 0 And Len(CleanText(wsC.Cells(r, colNum).Value)) = 0 Then firstBlank = r
    Next r

    If firstBlank > 0 Then wsC.Cells(firstBlank, colNum).Value = v

End Sub

Private Sub AddDateCandidateToColumnUnique(ByVal wsC As Worksheet, ByVal colNum As Long, ByVal candidateDate As Variant, ByVal maxRow As Long)

    Dim r As Long, firstBlank As Long, serialValue As Long
    If Not HasInputDate(candidateDate) Then Exit Sub
    If maxRow < 2 Then maxRow = Application.Max(LastRow(wsC, colNum) + 50, 500)
    serialValue = CLng(CDate(SameDateOrBlank(candidateDate)))

    For r = 2 To maxRow
        If HasInputDate(wsC.Cells(r, colNum).Value) Then
            If CLng(CDate(SameDateOrBlank(wsC.Cells(r, colNum).Value))) = serialValue Then Exit Sub
        End If
        If firstBlank = 0 And Len(CleanText(wsC.Cells(r, colNum).Value)) = 0 Then firstBlank = r
    Next r

    If firstBlank > 0 Then
        wsC.Cells(firstBlank, colNum).Value = SameDateOrBlank(candidateDate)
        wsC.Cells(firstBlank, colNum).NumberFormatLocal = "yyyy/m/d"
    End If

End Sub

Private Sub CompactCandidateColumn(ByVal wsC As Worksheet, ByVal colNum As Long)

    Dim lastR As Long, r As Long, outR As Long, values As Collection, v As Variant
    If wsC Is Nothing Then Exit Sub
    lastR = LastRow(wsC, colNum)
    If lastR < 2 Then Exit Sub

    Set values = New Collection
    For r = 2 To lastR
        If Len(CleanText(wsC.Cells(r, colNum).Value)) > 0 Then values.Add wsC.Cells(r, colNum).Value
    Next r

    wsC.Range(wsC.Cells(2, colNum), wsC.Cells(lastR, colNum)).ClearContents
    outR = 2
    For Each v In values
        wsC.Cells(outR, colNum).Value = v
        outR = outR + 1
    Next v

End Sub

Private Sub CompactCandidatePairColumns(ByVal wsC As Worksheet, ByVal displayCol As Long, ByVal idCol As Long)

    Dim lastR As Long, r As Long, outR As Long
    Dim displayValues As Collection, idValues As Collection

    If wsC Is Nothing Then Exit Sub
    lastR = Application.Max(LastRow(wsC, displayCol), LastRow(wsC, idCol))
    If lastR < 2 Then Exit Sub

    Set displayValues = New Collection
    Set idValues = New Collection
    For r = 2 To lastR
        If Len(CleanText(wsC.Cells(r, displayCol).Value)) > 0 Or Len(CleanText(wsC.Cells(r, idCol).Value)) > 0 Then
            displayValues.Add wsC.Cells(r, displayCol).Value
            idValues.Add wsC.Cells(r, idCol).Value
        End If
    Next r

    wsC.Range(wsC.Cells(2, displayCol), wsC.Cells(lastR, idCol)).ClearContents
    outR = 2
    For r = 1 To displayValues.Count
        wsC.Cells(outR, displayCol).Value = displayValues(r)
        wsC.Cells(outR, idCol).Value = idValues(r)
        outR = outR + 1
    Next r

End Sub

Private Sub FillDateCandidates(ByVal wsC As Worksheet)

    Dim dictM As Object, dictD As Object, dictA As Object

    Dim wsR As Worksheet, wsP As Worksheet, wsA As Worksheet, r As Long, key As Variant, outR As Long

    Set dictM = CreateObject("Scripting.Dictionary")

    Set dictD = CreateObject("Scripting.Dictionary")

    Set dictA = CreateObject("Scripting.Dictionary")

    Set wsR = ThisWorkbook.Worksheets(SH_W_REL)

    For r = 2 To LastRow(wsR, 1)

        If CStr(wsR.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then

            AddDateCandidate dictM, wsR.Cells(r, R_MARRIAGE).Value

            AddDateCandidate dictA, wsR.Cells(r, R_MARRIAGE).Value

            AddDateCandidate dictD, wsR.Cells(r, R_DIVORCE).Value

            AddDateCandidate dictA, wsR.Cells(r, R_DIVORCE).Value

        End If

    Next r

    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)

    For r = 2 To LastRow(wsP, 1)

        If CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            AddDateCandidate dictA, wsP.Cells(r, P_BIRTH).Value

            AddDateCandidate dictA, wsP.Cells(r, P_DEATH).Value

        End If

    Next r

    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    For r = 2 To LastRow(wsA, 1)

        If CStr(wsA.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then

            AddDateCandidate dictA, wsA.Cells(r, A_START).Value

            AddDateCandidate dictA, wsA.Cells(r, A_END).Value

        End If

    Next r

    AddRelationAndEventDatesToCandidateDictionaries dictM, dictD, dictA

    outR = 2

    For Each key In dictM.Keys

        wsC.Cells(outR, 12).Value = CDate(dictM(key))

        outR = outR + 1

    Next key

    outR = 2

    For Each key In dictD.Keys

        wsC.Cells(outR, 13).Value = CDate(dictD(key))

        outR = outR + 1

    Next key

    outR = 2

    For Each key In dictA.Keys

        wsC.Cells(outR, 14).Value = CDate(dictA(key))

        outR = outR + 1

    Next key

    wsC.Range("L2:N500").NumberFormatLocal = "yyyy/m/d"

End Sub

Private Sub AddRelationAndEventDatesToCandidateDictionaries(ByVal dictM As Object, ByVal dictD As Object, ByVal dictA As Object)

    Dim wr As Worksheet, we As Worksheet, r As Long
    If SheetExists(SH_W_REL, ThisWorkbook) Then
        Set wr = ThisWorkbook.Worksheets(SH_W_REL)
        For r = 2 To LastRow(wr, 1)
            If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
                AddDateCandidate dictM, wr.Cells(r, R_MARRIAGE).Value
                AddDateCandidate dictD, wr.Cells(r, R_DIVORCE).Value
                AddDateCandidate dictA, wr.Cells(r, R_MARRIAGE).Value
                AddDateCandidate dictA, wr.Cells(r, R_DIVORCE).Value
            End If
        Next r
    End If
    If SheetExists(SH_W_MARRIAGE_HIST, ThisWorkbook) Then
        Set wr = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
        For r = 2 To LastRow(wr, 1)
            If CStr(wr.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
                AddDateCandidate dictM, wr.Cells(r, MH_MARRIAGE).Value
                AddDateCandidate dictD, wr.Cells(r, MH_DIVORCE).Value
                AddDateCandidate dictA, wr.Cells(r, MH_MARRIAGE).Value
                AddDateCandidate dictA, wr.Cells(r, MH_DIVORCE).Value
            End If
        Next r
    End If
    If SheetExists(SH_W_EVENT, ThisWorkbook) Then
        Set we = ThisWorkbook.Worksheets(SH_W_EVENT)
        For r = 2 To LastRow(we, 1)
            If CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL Then
                AddDateCandidate dictA, we.Cells(r, E_DATE).Value
                If CStr(we.Cells(r, E_TYPE).Value) = "����" Then AddDateCandidate dictM, we.Cells(r, E_DATE).Value
                If CStr(we.Cells(r, E_TYPE).Value) = "����" Then AddDateCandidate dictD, we.Cells(r, E_DATE).Value
            End If
        Next r
    End If

End Sub

Private Sub RefreshDateCandidateListOnly()

    Dim wsC As Worksheet, lastClear As Long
    If Not SheetExists(SH_W_CAND, ThisWorkbook) Then Exit Sub
    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    lastClear = Application.Max(500, LastRow(wsC, 12), LastRow(wsC, 13), LastRow(wsC, 14))
    wsC.Range("L2:N" & lastClear).ClearContents
    FillDateCandidates wsC
    CompactCandidateColumn wsC, 12
    CompactCandidateColumn wsC, 13
    CompactCandidateColumn wsC, 14

End Sub

Private Sub RefreshMarriageDateCandidatesOnly(ByVal marriageDate As Variant, ByVal divorceDate As Variant)

    Dim wsC As Worksheet
    If Not SheetExists(SH_W_CAND, ThisWorkbook) Then Exit Sub
    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    AddDateCandidateToColumnUnique wsC, 12, marriageDate, 0
    AddDateCandidateToColumnUnique wsC, 13, divorceDate, 0
    AddDateCandidateToColumnUnique wsC, 14, marriageDate, 0
    AddDateCandidateToColumnUnique wsC, 14, divorceDate, 0

End Sub

Private Sub AddDateCandidate(ByVal dict As Object, ByVal v As Variant)

    If HasInputDate(v) Then dict(Format(SameDateOrBlank(v), "yyyy/mm/dd")) = SameDateOrBlank(v)

End Sub

Private Sub FillStaticCandidates(ByVal wsC As Worksheet)

    Dim arr, i As Long

    arr = Array("�ː�", "�ːЕ��[", "�Z���[", "�Z���[���[", "�\�q", "����", "�Œ莑�Y����", "���Z����", "�a������", "�،�����", "�ی�����", "�o�L����", "�{�ݎ���", "�a�@����", "��쎑��", "�e���\�q", "�X�֕�", "��������", "���L�^", "�{�݌_��", "���̑�")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 6).Value = arr(i)
    Next i

    arr = Array("���E", "��Ј�", "��Ж���", "���c��", "������", "����", "��t", "�Ō�t", "�m��", "�ŗ��m", "�ٌ�m", "�_��", "����", "�s���Y����", "��w�E��v", "�w��", "�N����", "�{�ݓ���", "���@��", "�v���", "�ސE", "�Ǝ��]��", "�s��", "���̑�")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 7).Value = arr(i)
    Next i

    arr = Array("�푊���l", "�z���", "�O�z���", "��", "��", "�{��", "�{��", "�c��", "�c��", "���j", "��j", "�O�j", "�l�j", "�ܒj", "�Z�j", "����", "��", "�O��", "�l��", "�܏�", "�Z��", "�q", "�{�q", "��", "�]��", "����", "�Z", "��", "�o", "��", "�Z��", "�o��", "�Z��o��", "�ٕ��Z��", "�ٕ�Z��", "�����Z��", "��", "��", "��P�����l", "����", "�����", "�������", "�⌾���s��", "���N�㌩�l", "�֌W��", "���̑��̊֌W�l")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 8).Value = arr(i)
    Next i

    arr = Array("���Z�n", "�Z���[�Z��", "������", "�{��", "�V�l�z�[��", "�T�[�r�X�t������Ҍ����Z��", "�a�@", "���{��", "�{��", "���S�ꏊ", "�ꎞ�؍ݐ�", "�]����", "�C�O�Z��", "�s��", "���̑�")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 9).Value = arr(i)
    Next i

    arr = Array("�j", "��", "�s��")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 10).Value = arr(i)
    Next i

    arr = Array(SHOW_YES, SHOW_NO)
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 11).Value = arr(i)
    Next i

End Sub

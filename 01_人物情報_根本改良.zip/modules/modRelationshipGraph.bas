Attribute VB_Name = "modRelationshipGraph"
Option Explicit

'���[���̌݊������B
'�Ƒ������̍\�z�� modFamilyModel �Ɉ�{�����A���̃��W���[���ł͍Đ��肵�Ȃ��B

Public Sub DiagramGraphReset()
    FamilyModelInvalidate
End Sub

Public Function DiagramGraphIsBuilt() As Boolean
    DiagramGraphIsBuilt = FamilyModelIsBuilt()
End Function

Public Function DiagramGraphEnsureBuilt(ByVal decedentId As String) As Boolean
    DiagramGraphEnsureBuilt = FamilyModelEnsureBuilt(decedentId)
End Function

Public Function DiagramGraphRebuildFresh(ByVal decedentId As String, Optional ByVal raiseOnError As Boolean = False) As Boolean
    On Error GoTo EH
    '�uFresh�v�̖��O�ǂ���A�ۑ��ςݐl���E�֌W�E���������𖈉�ǂݒ����B
    '�`�F�b�N�ō\�z�����L���b�V����`��֎g���񂷂ƁA�r���X�V��ɔ���Ɛ}������邽�ߋ֎~����B
    DiagramGraphRebuildFresh = FamilyModelRebuild(decedentId, raiseOnError)
    Exit Function
EH:
    If raiseOnError Then Err.Raise Err.Number, Err.Source, Err.Description
End Function

Public Sub BuildDiagramGraphForRelationshipDiagram(ByVal decedentId As String)
    If Not FamilyModelRebuild(decedentId, True) Then _
        Err.Raise vbObjectError + 9201, "BuildDiagramGraphForRelationshipDiagram", "�Ƒ��������f�����\�z�ł��܂���ł����B"
End Sub

Public Function DiagramGraphIsSpouseRelationType(ByVal relationType As String) As Boolean
    DiagramGraphIsSpouseRelationType = FamilyModelIsSpouseRelationType(relationType)
End Function

Public Function DiagramGraphIsParentChildRelationRow(ByVal wr As Worksheet, ByVal rowNo As Long) As Boolean
    DiagramGraphIsParentChildRelationRow = FamilyModelIsParentChildRow(wr, rowNo)
End Function

Public Function DiagramGraphChildRows(ByVal parentId As String) As Collection
    Dim result As New Collection, childIds As Collection, spouseIds As Collection
    Dim spouseChildren As Collection, i As Long, j As Long
    Dim childId As String, spouseId As String, kindText As String
    parentId = CleanText(parentId)
    If Len(parentId) = 0 Or Not FamilyModelIsBuilt() Then
        Set DiagramGraphChildRows = result
        Exit Function
    End If

    Set childIds = FamilyModelChildIds(parentId)
    For i = 1 To childIds.Count
        DiagramAppendPersonRow result, CleanText(CStr(childIds(i)))
    Next i

    '�v�w�J�[�h�̂����A�z��҂����e�Ƃ���A��q�E�v�m�F�q���\���ΏۂɊ܂߂�B
    '���̋N�_�� outputs �����m��eID�����Ĕz��҃J�[�h�֐؂�ւ���B
    Set spouseIds = FamilyModelSpouseIds(parentId)
    For i = 1 To spouseIds.Count
        spouseId = CleanText(CStr(spouseIds(i)))
        Set spouseChildren = FamilyModelChildIds(spouseId)
        For j = 1 To spouseChildren.Count
            childId = CleanText(CStr(spouseChildren(j)))
            kindText = FamilyModelChildKind(childId)
            If FamilyModelChildUsesCouple(childId, parentId, spouseId) _
                    Or kindText = CHILD_KIND_STEP _
                    Or FamilyModelChildNeedsReview(childId) Then
                DiagramAppendPersonRow result, childId
            End If
        Next j
    Next i
    Set DiagramGraphChildRows = result
End Function

Private Sub DiagramAppendPersonRow(ByVal rows As Collection, ByVal personId As String)
    Dim rowNo As Long, i As Long, existingId As String
    personId = CleanText(personId)
    If rows Is Nothing Or Len(personId) = 0 Then Exit Sub
    rowNo = FamilyModelPersonRow(personId)
    If rowNo <= 0 Then Exit Sub
    If Not DiagramModelPersonRowIsVisible(rowNo) Then Exit Sub
    For i = 1 To rows.Count
        existingId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(CLng(rows(i)), P_ID).Value)
        If existingId = personId Then Exit Sub
    Next i
    rows.Add rowNo
End Sub

Public Function DiagramGraphParentIdForChildId(ByVal childId As String) As String
    DiagramGraphParentIdForChildId = FamilyModelParentId(childId)
End Function

Public Function DiagramGraphParentIdForChildRow(ByVal childRow As Long) As String
    Dim childId As String
    If childRow <= 0 Then Exit Function
    childId = CleanText(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    DiagramGraphParentIdForChildRow = FamilyModelParentId(childId)
End Function

Public Function DiagramGraphSpouseId(ByVal personId As String) As String
    DiagramGraphSpouseId = DiagramGraphVisibleSpouseId(personId)
End Function

Public Function DiagramGraphSpouseRow(ByVal personId As String) As Long
    Dim rowNo As Long
    rowNo = FamilyModelPersonRow(DiagramGraphVisibleSpouseId(personId))
    If DiagramModelPersonRowIsVisible(rowNo) Then DiagramGraphSpouseRow = rowNo
End Function

Public Function DiagramGraphFatherRow(ByVal decedentId As String) As Long
    Dim rowNo As Long
    rowNo = FamilyModelFatherRow(decedentId)
    If DiagramModelPersonRowIsVisible(rowNo) Then DiagramGraphFatherRow = rowNo
End Function

Public Function DiagramGraphMotherRow(ByVal decedentId As String) As Long
    Dim rowNo As Long
    rowNo = FamilyModelMotherRow(decedentId)
    If DiagramModelPersonRowIsVisible(rowNo) Then DiagramGraphMotherRow = rowNo
End Function

Private Function DiagramModelPersonRowIsVisible(ByVal rowNo As Long) As Boolean
    Dim ws As Worksheet
    If rowNo <= 0 Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    If CleanText(ws.Cells(rowNo, P_STATUS).Value) = STATUS_CANCEL Then Exit Function
    If CleanText(ws.Cells(rowNo, P_SHOW).Value) = SHOW_NO Then Exit Function
    DiagramModelPersonRowIsVisible = (Len(CleanText(ws.Cells(rowNo, P_ID).Value)) > 0)
End Function

Private Function DiagramGraphVisibleSpouseId(ByVal personId As String) As String
    Dim preferredId As String, spouses As Collection, i As Long, spouseId As String, rowNo As Long
    preferredId = FamilyModelPreferredSpouseId(personId)
    rowNo = FamilyModelPersonRow(preferredId)
    If DiagramModelPersonRowIsVisible(rowNo) Then
        DiagramGraphVisibleSpouseId = preferredId
        Exit Function
    End If
    Set spouses = FamilyModelSpouseIds(personId)
    For i = 1 To spouses.Count
        spouseId = CleanText(CStr(spouses(i)))
        rowNo = FamilyModelPersonRow(spouseId)
        If DiagramModelPersonRowIsVisible(rowNo) Then
            DiagramGraphVisibleSpouseId = spouseId
            Exit Function
        End If
    Next i
End Function

Public Function DiagramGraphDisplayRelation(ByVal personId As String, ByVal fallbackText As String) As String
    DiagramGraphDisplayRelation = FamilyModelDisplayRelation(personId, fallbackText)
End Function

Public Function DiagramGraphDisplayRelationForPerson(ByVal personId As String) As String
    On Error GoTo Fallback
    personId = CleanText(personId)
    If Len(personId) = 0 Then Exit Function
    If FamilyModelEnsureBuilt(GetDecedentId()) Then
        DiagramGraphDisplayRelationForPerson = FamilyModelDisplayRelation(personId, GetPersonValue(personId, P_REL_DEC))
        If Len(DiagramGraphDisplayRelationForPerson) > 0 Then Exit Function
    End If
Fallback:
    Err.Clear
    DiagramGraphDisplayRelationForPerson = RelationshipCanonicalStoredLabel(GetPersonValue(personId, P_REL_DEC))
End Function

Public Function DiagramGraphIsPureSpouseId(ByVal personId As String) As Boolean
    DiagramGraphIsPureSpouseId = FamilyModelIsPureSpouse(personId)
End Function

Public Function DiagramGraphIsUnresolvedKinId(ByVal personId As String) As Boolean
    DiagramGraphIsUnresolvedKinId = FamilyModelIsUnresolved(personId)
End Function

Public Function DiagramGraphChildUsesCoupleOrigin(ByVal childId As String, ByVal parentId As String, ByVal spouseId As String) As Boolean
    DiagramGraphChildUsesCoupleOrigin = FamilyModelChildUsesCouple(childId, parentId, spouseId)
End Function

Public Function DiagramGraphChildIsSpouseSideUnconfirmed(ByVal childId As String) As Boolean
    DiagramGraphChildIsSpouseSideUnconfirmed = FamilyModelChildNeedsReview(childId)
End Function

Public Function DiagramGraphUnconfirmedReason(ByVal childId As String) As String
    DiagramGraphUnconfirmedReason = FamilyModelChildReviewReason(childId)
End Function

Public Function DiagramGraphSpouseCount(ByVal personId As String) As Long
    DiagramGraphSpouseCount = FamilyModelSpouseCount(personId)
End Function

Public Sub DiagramGraphWriteDiagnostics(ByVal decedentId As String)
    On Error GoTo EH
    Dim ws As Worksheet, wp As Worksheet, outR As Long, r As Long, lastR As Long
    Dim pid As String, parentId As String, spouseId As String, relationText As String
    Dim warningItems As Object, warningKey As Variant
    If Not FamilyModelEnsureBuilt(decedentId) Then Exit Sub
    If Not SheetExists(SH_CHECK, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_CHECK)
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    DiagramClearPriorFamilyDiagnostics ws
    outR = LastRow(ws, 1) + 2
    If outR < 4 Then outR = 4
    ws.Cells(outR, 1).Value = "�Ƒ��������f���f�f�iV2�j"
    ws.Cells(outR, 2).Value = Now
    outR = outR + 1
    SetRowValues ws.Cells(outR, 1), Array("�l��ID", "����", "�ۑ�����", "�}�㑱��", "�m��eID", "�m��e��", "��\�z���ID", "��\�z��Җ�", "�q�̋敪", "�m�x", "���荪��", "�Ƒ��L�[", "���N����", "���N�_", "�m�F����")
    outR = outR + 1
    lastR = LastRow(wp, P_ID)
    For r = 2 To lastR
        If CleanText(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CleanText(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            pid = CleanText(wp.Cells(r, P_ID).Value)
            If Len(pid) > 0 Then
                parentId = FamilyModelParentId(pid)
                spouseId = FamilyModelPreferredSpouseId(pid)
                relationText = FamilyModelDisplayRelation(pid, CleanText(wp.Cells(r, P_REL_DEC).Value))
                ws.Cells(outR, 1).Value = pid
                ws.Cells(outR, 2).Value = CleanText(wp.Cells(r, P_DISPLAY).Value)
                ws.Cells(outR, 3).Value = CleanText(wp.Cells(r, P_REL_DEC).Value)
                ws.Cells(outR, 4).Value = relationText
                ws.Cells(outR, 5).Value = parentId
                ws.Cells(outR, 6).Value = GetPersonValue(parentId, P_DISPLAY)
                ws.Cells(outR, 7).Value = spouseId
                ws.Cells(outR, 8).Value = GetPersonValue(spouseId, P_DISPLAY)
                ws.Cells(outR, 9).Value = FamilyModelChildKind(pid)
                ws.Cells(outR, 10).Value = FamilyModelChildConfidence(pid)
                ws.Cells(outR, 11).Value = FamilyModelChildEvidence(pid)
                ws.Cells(outR, 12).Value = FamilyModelChildFamilyKey(pid)
                ws.Cells(outR, 13).Value = wp.Cells(r, P_BIRTH).Value
                If Len(FamilyModelChildFamilyKey(pid)) > 0 Then
                    ws.Cells(outR, 14).Value = "�v�w����"
                ElseIf Len(parentId) > 0 Then
                    ws.Cells(outR, 14).Value = "�e�J�[�h"
                ElseIf FamilyModelIsUnresolved(pid) Then
                    ws.Cells(outR, 14).Value = "�֌W������"
                End If
                If FamilyModelChildNeedsReview(pid) Then ws.Cells(outR, 15).Value = FamilyModelChildReviewReason(pid)
                outR = outR + 1
            End If
        End If
    Next r

    Set warningItems = FamilyModelWarningItems()
    If Not warningItems Is Nothing Then
        If warningItems.Count > 0 Then
            outR = outR + 1
            ws.Cells(outR, 1).Value = "���f���x��"
            ws.Cells(outR, 2).Value = "���e"
            outR = outR + 1
            For Each warningKey In warningItems.Keys
                ws.Cells(outR, 1).Value = CStr(warningKey)
                ws.Cells(outR, 2).Value = CStr(warningItems(warningKey))
                outR = outR + 1
            Next warningKey
        End If
    End If
    ws.Columns("A:O").AutoFit
    Exit Sub
EH:
    RuntimeAppendLog "WARN", "DiagramGraphWriteDiagnostics", "�Ƒ��������f���f�f", "", Err.Number, Err.Description, Err.Source
End Sub

Private Sub DiagramClearPriorFamilyDiagnostics(ByVal ws As Worksheet)
    Dim r As Long, lastR As Long, valueText As String
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, 1)
    For r = 4 To lastR
        valueText = CleanText(ws.Cells(r, 1).Value)
        If valueText = "�Ƒ��������f���f�f�iV2�j" Or valueText = "�����֌W�}���f���f�f" Then
            ws.Range(ws.Cells(r, 1), ws.Cells(lastR, 18)).ClearContents
            Exit Sub
        End If
    Next r
End Sub

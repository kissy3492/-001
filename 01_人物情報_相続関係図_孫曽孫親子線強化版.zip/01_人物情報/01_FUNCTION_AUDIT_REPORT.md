# 01 人物情報 関数監査レポート

今回の重点は、相続関係図の親子線解決ロジック。

主な修正関数は以下。

- `GetRootChildRows`
- `GetChildRowsForParent`
- `InferredDiagramParentIdForChildRow`
- `DiagramBestExplicitParentIdForChildRow`
- `DiagramStoredBaseParentIdForDrawing`
- `DiagramPrimaryParentIdForDrawing`
- `ChildRowCanAppearUnderParent`
- `DiagramAuditResolveParentChild`
- `DiagramAuditParentLevel`

静的チェックでは、CP932デコード、プロシージャ開始終了、Public重複、OnAction/AddButton/OnKey未定義候補、TextFrame2残存、IIf残存、成功通知MsgBox候補、IMPORT_ORDER整合を確認済み。

実機VBEコンパイルではない。

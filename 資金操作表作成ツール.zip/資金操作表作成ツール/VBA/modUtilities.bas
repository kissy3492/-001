Attribute VB_Name = "modUtilities"
Option Explicit

Public Function SheetExists(ByVal sheetName As String) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    SheetExists = Not ws Is Nothing
    On Error GoTo 0
End Function

Public Function GetSheet(ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
    If ws Is Nothing Then
        Err.Raise vbObjectError + 1001, "GetSheet", "�V�[�g�u" & sheetName & "�v��������܂���BSetupWorkbook�����s���Ă��������B"
    End If
    Set GetSheet = ws
End Function

Public Function GetOrCreateSheet(ByVal sheetName As String, Optional ByVal resetSheet As Boolean = False) As Worksheet
    Dim ws As Worksheet
    On Error GoTo EH
    If SheetExists(sheetName) Then
        Set ws = ThisWorkbook.Worksheets(sheetName)
    Else
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        ws.Name = sheetName
    End If
    If ws Is Nothing Then Err.Raise vbObjectError + 1002, "GetOrCreateSheet", "�V�[�g�擾�Ɏ��s���܂���: " & sheetName
    On Error Resume Next
    ws.Visible = xlSheetVisible
    On Error GoTo EH
    If resetSheet Then ResetWorksheet ws
    Set GetOrCreateSheet = ws
    Exit Function
EH:
    Err.Raise Err.Number, "GetOrCreateSheet(" & sheetName & ")", Err.Description
End Function

Public Sub ResetWorksheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    DeleteToolShapes ws, True
    ws.Cells.UnMerge
    ws.Cells.Clear
    ws.Cells.ClearFormats
    ws.Cells.Validation.Delete
    ws.Cells.Locked = False
    On Error GoTo 0
End Sub

Public Sub DeleteToolShapes(ByVal ws As Worksheet, Optional ByVal deleteAll As Boolean = False)
    '�c�[�����쐬�����}�`�������폜����B
    '�}�`�ی��L���ɂ��Ă��邽�߁A�Đ����O�ɂ͕K���ی�������Ă���폜����B
    Dim i As Long
    Dim nm As String
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    For i = ws.Shapes.Count To 1 Step -1
        nm = ws.Shapes(i).Name
        If deleteAll Or Left$(nm, Len(UI_PREFIX)) = UI_PREFIX Then ws.Shapes(i).Delete
    Next i
    On Error GoTo 0
End Sub

Public Sub LockToolShapes(ByVal ws As Worksheet)
    '�}�`�{�^����J�[�h�w�i������Ĉړ��E�T�C�Y�ύX���Ȃ��悤�ɂ���B
    '���w�i�{�������̂悤�ȓǂ݂ɂ����}�`�����F�������ŕ␳����B
    Dim shp As Shape
    Dim fillColor As Long
    Dim fontColor As Long

    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    For Each shp In ws.Shapes
        If Left$(shp.Name, Len(UI_PREFIX)) = UI_PREFIX Then
            shp.Locked = True
            shp.Placement = xlMoveAndSize
            fillColor = shp.Fill.ForeColor.RGB
            fontColor = shp.TextFrame.Characters.Font.Color
            If IsLightExcelColor(fillColor) And IsLightExcelColor(fontColor) Then
                shp.TextFrame.Characters.Font.Color = RGB(15, 23, 42)
            End If
        End If
    Next shp
    On Error GoTo 0
End Sub

Public Sub ResetName(ByVal nm As String, ByVal rng As Range)
    Dim refText As String
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Names(nm).Delete
    Err.Clear
    refText = "='" & Replace(rng.Worksheet.Name, "'", "''") & "'!" & rng.Address(True, True, xlA1, False)
    ThisWorkbook.Names.Add Name:=nm, RefersTo:=refText
    On Error GoTo 0
End Sub

Public Function MacroRef(ByVal macroName As String) As String
    '�}�`�{�^�����ʃu�b�N�̓����}�N�����E��Ȃ��悤�A���̃u�b�N�֖����I�ɕR�Â���B
    MacroRef = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & macroName
End Function

Public Sub SetRowValues(ByVal firstCell As Range, ByVal values As Variant)
    '1����Array��Range�֒��ڑ���������������A�������Ɋm���ɏ������ށB
    Dim i As Long
    If firstCell Is Nothing Then Exit Sub
    For i = LBound(values) To UBound(values)
        firstCell.Offset(0, i - LBound(values)).Value = values(i)
    Next i
End Sub



Public Function BalanceInputLabelDisplay(ByVal labelText As String) As String
    Dim s As String
    s = Replace(Replace(CellText(labelText), vbCr, ""), vbLf, "")
    If InStr(s, "�N���E����") > 0 Then
        BalanceInputLabelDisplay = "�N���E����" & vbLf & "�c��"
    ElseIf InStr(s, "�����J�n") > 0 Then
        BalanceInputLabelDisplay = "�����J�n��" & vbLf & "�c��"
    Else
        s = Replace(s, "�N���c��", "�N��" & vbLf & "�c��")
        s = Replace(s, "���_�c��", vbLf & "�c��")
        BalanceInputLabelDisplay = s
    End If
End Function

Public Function BalanceTekiyoLabel(ByVal labelText As String) As String
    '��������\�̓E�v���p�B���t���Ɋ�������邽�߁A�E�v���ɂ͋�̓��t���o���Ȃ��B
    Dim s As String
    Dim p As Long
    s = CellText(labelText)
    s = Replace(s, vbCrLf, "")
    s = Replace(s, vbCr, "")
    s = Replace(s, vbLf, "")
    p = InStr(1, s, "�i", vbTextCompare)
    If p > 0 And InStr(1, s, "�c��", vbTextCompare) > 0 Then s = Left$(s, p - 1)
    BalanceTekiyoLabel = s
End Function


Public Sub ApplyReadablePrintSettings(ByVal ws As Worksheet, Optional ByVal titleRows As String = "")
    '������͉�1�y�[�W�Œ�B
    '��ʏ�̃t�H���g�T�C�Y��14�ȏ���ێ����A������͉����Ɏ��߂�B
    'Zoom=False �ɂ��Ȃ��� FitToPagesWide ���L���ɂȂ�Ȃ��B
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    With ws.PageSetup
        .PaperSize = xlPaperA4
        .Orientation = xlLandscape
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .CenterHorizontally = False
        .LeftMargin = Application.InchesToPoints(0.25)
        .RightMargin = Application.InchesToPoints(0.25)
        .TopMargin = Application.InchesToPoints(0.35)
        .BottomMargin = Application.InchesToPoints(0.35)
        If Len(titleRows) > 0 Then
            .PrintTitleRows = titleRows
        Else
            .PrintTitleRows = ""
        End If
        .CenterFooter = "&P / &N"
    End With
    On Error GoTo 0
End Sub

Public Sub FormatCashOperationOutputLayout(ByVal ws As Worksheet)
    Dim lastR As Long, widths As Variant, c As Long
    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then lastR = 1
    With ws.Range("A1:M" & lastR)
        .Font.Name = "Yu Gothic UI": .Font.Size = 11
        .Font.Color = RGB(30, 41, 59): .Interior.Color = vbWhite
        .VerticalAlignment = xlCenter: .WrapText = True
        .Borders.LineStyle = xlContinuous: .Borders.Color = RGB(220, 226, 233)
    End With
    widths = Array(12, 12, 10, 7, 11, 12, 6, 12, 12, 12, 7, 18, 12)
    For c = 1 To 13: ws.Columns(c).ColumnWidth = widths(c - 1): Next c
    ws.Columns("F:F").NumberFormat = "yyyy/m/d": ws.Columns("G:G").NumberFormat = "hh:mm"
    ws.Columns("H:I").NumberFormat = "#,##0": ws.Columns("M:M").NumberFormat = "General"
    ws.Columns("A:G").HorizontalAlignment = xlCenter
    ws.Columns("H:I").HorizontalAlignment = xlRight
    ws.Columns("J:M").HorizontalAlignment = xlLeft
    If lastR >= 2 Then
        ws.Rows("2:" & lastR).AutoFit
        Dim r As Long
        For r = 2 To lastR
            If ws.Rows(r).RowHeight < 25 Then ws.Rows(r).RowHeight = 25
        Next r
    End If
    FormatOutputHeader ws.Range("A1:M1")
    ws.Range("A1:M1").Font.Size = 11: ws.Rows(1).RowHeight = 29
    ApplyReadablePrintSettings ws, "$1:$1"
End Sub

Public Sub FormatBalanceTransitionOutputLayout(ByVal ws As Worksheet)
    Dim r As Long, lastR As Long, widths As Variant, c As Long
    lastR = LastRow(ws)
    ApplyBalanceOutputColumns ws
    With ws.Range("A1:L" & lastR)
        .Font.Name = "Yu Gothic UI": .Font.Size = 11
        .VerticalAlignment = xlCenter: .WrapText = True
    End With
    ws.Range("A1").Font.Size = 17: ws.Range("A1").Font.Bold = True
    ws.Range("A2:L2").Merge: ws.Range("A2").Font.Size = 10
    ws.Columns("G:K").HorizontalAlignment = xlRight
    For r = 1 To lastR
        If CellText(ws.Cells(r, 1).Value2) = "��s��" Then
            ws.Rows(r).RowHeight = 38
            ws.Range("A" & r & ":L" & r).HorizontalAlignment = xlCenter
        ElseIf ws.Rows(r).RowHeight < 25 Then
            ws.Rows(r).RowHeight = 25
        End If
    Next r
    ws.Rows(1).RowHeight = 30: ws.Rows(2).RowHeight = 25
    ApplyReadablePrintSettings ws, "$1:$2"
    ws.PageSetup.PrintArea = ws.Range("A1:L" & lastR).Address
End Sub











Public Function LastRow(ByVal ws As Worksheet, Optional ByVal colNo As Long = 1) As Long
    Dim r As Long
    If ws Is Nothing Then Exit Function
    r = ws.Cells(ws.Rows.Count, colNo).End(xlUp).Row
    If r = 1 And Len(Trim$(CStr(ws.Cells(1, colNo).Value))) = 0 Then r = 0
    LastRow = r
End Function

Public Function CellText(ByVal v As Variant) As String
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        CellText = ""
    Else
        CellText = Trim$(CStr(v))
    End If
End Function

Public Function HasText(ByVal v As Variant) As Boolean
    HasText = Len(CellText(v)) > 0
End Function

Public Function ToAmountOrBlank(ByVal v As Variant) As Variant
    Dim s As String
    s = Replace(CellText(v), ",", "")
    If Len(s) = 0 Then
        ToAmountOrBlank = ""
    ElseIf IsNumeric(s) Then
        ToAmountOrBlank = CDbl(s)
    Else
        ToAmountOrBlank = v
    End If
End Function

Public Function GetCfgCell(ByVal rowNo As Long) As Range
    Dim ws As Worksheet
    Set ws = GetSheet(SH_CONFIG)
    Set GetCfgCell = ws.Cells(rowNo, COL_CFG_VALUE)
End Function

Public Function GetCfgLong(ByVal rowNo As Long, ByVal defaultValue As Long) As Long
    On Error GoTo EH
    If IsNumeric(GetCfgCell(rowNo).Value) Then
        GetCfgLong = CLng(GetCfgCell(rowNo).Value)
    Else
        GetCfgLong = defaultValue
    End If
    Exit Function
EH:
    GetCfgLong = defaultValue
End Function

Public Function GetCfgDateValue(ByVal rowNo As Long) As Variant
    On Error GoTo EH
    If IsDate(GetCfgCell(rowNo).Value) Then
        GetCfgDateValue = CDate(GetCfgCell(rowNo).Value)
    Else
        GetCfgDateValue = ""
    End If
    Exit Function
EH:
    GetCfgDateValue = ""
End Function

Public Function GetInputMode() As String
    On Error GoTo EH
    GetInputMode = CellText(GetCfgCell(ROW_CFG_INPUT_MODE).Value)
    If Len(GetInputMode) = 0 Then GetInputMode = MODE_NORMAL
    Exit Function
EH:
    GetInputMode = MODE_NORMAL
End Function

Public Function GetYearInputMode() As String
    On Error GoTo EH
    If SheetExists(SH_INPUT) Then
        GetYearInputMode = CellText(GetSheet(SH_INPUT).Range(CELL_YEAR_SNAPSHOT).Value2)
        If Len(GetYearInputMode) > 0 Then Exit Function
    End If
    GetYearInputMode = CellText(GetCfgCell(ROW_CFG_YEAR_MODE).Value)
    If Len(GetYearInputMode) = 0 Then GetYearInputMode = YEAR_MODE_WAREKI
    Exit Function
EH:
    GetYearInputMode = YEAR_MODE_WAREKI
End Function








Public Function GetDisplayOption(ByVal rowNo As Long, Optional ByVal defaultShow As Boolean = True) As Boolean
    '�ݒ�V�[�g�́u�\������ / �\�����Ȃ��v�����S�ɓǂݎ��B
    '�󗓂�z��O�̒l�́A�Ɩ��ō���ɂ����悤 defaultShow ��Ԃ��B
    Dim v As String
    On Error GoTo EH
    v = CellText(GetCfgCell(rowNo).Value)
    If v = DISPLAY_ON Then
        GetDisplayOption = True
    ElseIf v = DISPLAY_OFF Then
        GetDisplayOption = False
    Else
        GetDisplayOption = defaultShow
    End If
    Exit Function
EH:
    GetDisplayOption = defaultShow
End Function

Public Function UseRelationshipDisplay() As Boolean
    UseRelationshipDisplay = GetDisplayOption(ROW_CFG_RELATIONSHIP, True)
End Function

Public Function ShowInheritanceStartRow() As Boolean
    ShowInheritanceStartRow = GetDisplayOption(ROW_CFG_SHOW_INHERITANCE_ROW, True)
End Function

Public Function ShowOpenDateRow() As Boolean
    ShowOpenDateRow = GetDisplayOption(ROW_CFG_SHOW_OPEN_DATE_ROW, True)
End Function

Public Function ShowCloseDateRow() As Boolean
    ShowCloseDateRow = GetDisplayOption(ROW_CFG_SHOW_CLOSE_DATE_ROW, True)
End Function

Public Function ShowBalanceRowsInCashOperation() As Boolean
    ShowBalanceRowsInCashOperation = GetDisplayOption(ROW_CFG_SHOW_BALANCE_ROWS, True)
End Function

Public Function DisplayPersonWithRelationship(ByVal personName As String, ByVal relationshipText As String) As String
    '�o�͂ł͗�𑝂₳���A�������̒��Łu�����i�����j�v�Ƃ��ĕ\������B
    '�ݒ�ő������\���ɂ����ꍇ�͎����݂̂�Ԃ��B
    Dim p As String, rel As String
    p = CellText(personName)
    rel = CellText(relationshipText)
    If UseRelationshipDisplay() And Len(rel) > 0 Then
        DisplayPersonWithRelationship = p & "�i" & rel & "�j"
    Else
        DisplayPersonWithRelationship = p
    End If
End Function

Public Function IsLightExcelColor(ByVal colorValue As Long) As Boolean
    '���w�i�ɔ���������鎖�̂�h�����߂̖��x����B
    Dim r As Long, g As Long, b As Long
    Dim brightness As Double
    r = colorValue Mod 256
    g = (colorValue \ 256) Mod 256
    b = (colorValue \ 65536) Mod 256
    brightness = 0.299 * r + 0.587 * g + 0.114 * b
    IsLightExcelColor = (brightness >= 210)
End Function

Public Sub FixUnreadableWhiteTextOnSheet(ByVal ws As Worksheet)
    '�W�F�w�i�{�W�F�����ɂȂ����Z�����A�ǂ݂₷���Z�F�֖߂����ʕ␳�B
    'UsedRange���ߋ��̏�������ŉߑ�ɂȂ��Ă���Əd���Ȃ邽�߁A
    '���ۂɒl�E�����������Ă���͈͂�����Ώۂɂ���B
    Dim rng As Range, c As Range
    Dim lastR As Long, lastC As Long
    If ws Is Nothing Then Exit Sub

    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then Exit Sub
    lastC = LastUsedColumnInSheet(ws, lastR)
    If lastC < 1 Then Exit Sub

    On Error Resume Next
    Set rng = ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC))
    If rng Is Nothing Then Exit Sub
    For Each c In rng.Cells
        If IsLightExcelColor(c.Interior.Color) And IsLightExcelColor(c.Font.Color) Then
            c.Font.Color = RGB(15, 23, 42)
        End If
    Next c
    On Error GoTo 0
End Sub

Public Function LastUsedRowInSheet(ByVal ws As Worksheet) As Long
    '���t���E�E�v�������̑����J�n���s���E����悤�A�����ł͂Ȃ��V�[�g�S�̂ōŏI�s��T���B
    Dim f As Range
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    If Not f Is Nothing Then LastUsedRowInSheet = f.Row
    On Error GoTo 0
End Function

Public Function IsTransactionRowBlank(ByVal ws As Worksheet, ByVal r As Long) As Boolean
    Dim c As Long
    If ws Is Nothing Then
        IsTransactionRowBlank = True
        Exit Function
    End If
    For c = COL_TX_YEAR To COL_TX_OTHER
        If HasText(ws.Cells(r, c).Value) Then
            IsTransactionRowBlank = False
            Exit Function
        End If
    Next c
    IsTransactionRowBlank = True
End Function

Public Function NormalizeYearInput(ByVal v As Variant, ByVal yearAdd As Long, ByRef ok As Boolean) As Long
    Dim s As String
    Dim y As Long
    Dim modeText As String
    ok = False
    s = NormalizeNumberText(CellText(v))
    If Len(s) = 0 Then Exit Function

    '4���ȏ�́A�ǂ̓��͕����ł�����Ƃ��Ĉ����B
    If IsNumeric(s) Then
        If CDbl(s) <> Fix(CDbl(s)) Then Exit Function
        y = CLng(s)
        If y >= 100 Then
            If y < 1900 Or y > 9999 Then Exit Function
            NormalizeYearInput = y
            ok = True
            Exit Function
        End If
    End If

    modeText = GetYearInputMode()
    If modeText = YEAR_MODE_WESTERN2 Then
        If Not IsNumeric(s) Then Exit Function
        y = CLng(s)
        If y < 0 Or y > 99 Then Exit Function
        y = yearAdd + y
    Else
        y = ResolveWarekiYearSmart(s)
    End If

    If y < 1900 Or y > 9999 Then Exit Function
    NormalizeYearInput = y
    ok = True
End Function

Private Function NormalizeNumberText(ByVal s As String) As String
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    s = Replace(s, "�N", "")
    NormalizeNumberText = Trim$(s)
End Function

Private Function ResolveWarekiYearSmart(ByVal s As String) As Long
    Dim y As Long
    Dim n As Long

    If ResolveExplicitEraYear(s, y) Then
        ResolveWarekiYearSmart = y
        Exit Function
    End If

    If s = "��" Then s = "1"
    If Not IsNumeric(s) Then Exit Function
    n = CLng(s)
    If n <= 0 Or n > 99 Then Exit Function

    ResolveWarekiYearSmart = BestJapaneseEraCandidate(n)
End Function

Private Function ResolveExplicitEraYear(ByVal s As String, ByRef westernYear As Long) As Boolean
    Dim era As String
    Dim n As Long
    s = UCase$(s)
    s = Replace(s, ".", "")
    s = Replace(s, "-", "")
    s = Replace(s, "�ߘa", "R")
    s = Replace(s, "����", "H")
    s = Replace(s, "���a", "S")
    If Len(s) < 2 Then Exit Function
    era = Left$(s, 1)
    If era <> "R" And era <> "H" And era <> "S" Then Exit Function
    s = Mid$(s, 2)
    If s = "��" Then s = "1"
    If Not IsNumeric(s) Then Exit Function
    n = CLng(s)
    If n <= 0 Then Exit Function

    Select Case era
        Case "R"
            If n > 99 Then Exit Function
            westernYear = 2018 + n
        Case "H"
            If n > 31 Then Exit Function
            westernYear = 1988 + n
        Case "S"
            If n > 64 Then Exit Function
            westernYear = 1925 + n
    End Select
    ResolveExplicitEraYear = (westernYear >= 1900 And westernYear <= 9999)
End Function

Private Function BestJapaneseEraCandidate(ByVal eraYear As Long) As Long
    Dim candidates(1 To 3) As Long
    Dim count As Long
    Dim i As Long
    Dim refYear As Long
    Dim bestYear As Long
    Dim bestScore As Long
    Dim score As Long

    If eraYear >= 1 And eraYear <= 99 Then
        count = count + 1
        candidates(count) = 2018 + eraYear  '�ߘa
    End If
    If eraYear >= 1 And eraYear <= 31 Then
        count = count + 1
        candidates(count) = 1988 + eraYear  '����
    End If
    If eraYear >= 1 And eraYear <= 64 Then
        count = count + 1
        candidates(count) = 1925 + eraYear  '���a
    End If

    refYear = GetYearResolutionReferenceYear()
    bestScore = 999999
    For i = 1 To count
        If candidates(i) >= 1900 And candidates(i) <= 2100 Then
            score = Abs(candidates(i) - refYear) + JapaneseEraWindowPenalty(candidates(i))
            If score < bestScore Or (score = bestScore And candidates(i) > bestYear) Then
                bestScore = score
                bestYear = candidates(i)
            End If
        End If
    Next i
    BestJapaneseEraCandidate = bestYear
End Function

Private Function GetYearResolutionReferenceYear() As Long
    Dim inheritDate As Variant
    Dim startYear As Long
    Dim endYear As Long
    If SheetExists(SH_INPUT) Then
        If HasText(GetSheet(SH_INPUT).Range("X10").Value2) Then
            GetYearResolutionReferenceYear = CLng(GetSheet(SH_INPUT).Range("X10").Value2)
            Exit Function
        End If
    End If
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    If IsDate(inheritDate) Then
        GetYearResolutionReferenceYear = Year(CDate(inheritDate))
        Exit Function
    End If
    startYear = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
    endYear = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
    If startYear > 0 And endYear >= startYear Then
        GetYearResolutionReferenceYear = CLng((startYear + endYear) / 2)
    Else
        GetYearResolutionReferenceYear = Year(Date)
    End If
End Function

Private Function JapaneseEraWindowPenalty(ByVal westernYear As Long) As Long
    Dim startYear As Long
    Dim endYear As Long
    startYear = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
    endYear = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
    If SheetExists(SH_INPUT) Then
        If HasText(GetSheet(SH_INPUT).Range("X8").Value2) Then startYear = CLng(GetSheet(SH_INPUT).Range("X8").Value2)
        If HasText(GetSheet(SH_INPUT).Range("X9").Value2) Then endYear = CLng(GetSheet(SH_INPUT).Range("X9").Value2)
    End If
    If westernYear < startYear - 5 Or westernYear > endYear + 5 Then
        JapaneseEraWindowPenalty = 1000
    Else
        JapaneseEraWindowPenalty = 0
    End If
End Function

Public Function ParseMonthDay(ByVal v As Variant, ByRef m As Long, ByRef d As Long) As Boolean
    Dim s As String
    s = CellText(v)
    ParseMonthDay = False
    If Len(s) < 3 Or Len(s) > 4 Then Exit Function
    If Not IsNumeric(s) Then Exit Function
    Dim pos As Long
    For pos = 1 To Len(s)
        If Mid$(s, pos, 1) < "0" Or Mid$(s, pos, 1) > "9" Then Exit Function
    Next pos
    If Len(s) = 3 Then
        m = CLng(Left$(s, 1))
        d = CLng(Right$(s, 2))
    Else
        m = CLng(Left$(s, 2))
        d = CLng(Right$(s, 2))
    End If
    If m < 1 Or m > 12 Then Exit Function
    If d < 1 Or d > 31 Then Exit Function
    ParseMonthDay = True
End Function

Public Function ResolveInputDate(ByVal yearVal As Variant, ByVal monthVal As Variant, ByVal dayVal As Variant, _
    ByRef currentYear As Long, ByRef currentMonth As Long, ByRef currentDay As Long, _
    ByVal yearAdd As Long, ByRef ok As Boolean) As Variant

    Dim tmpYear As Long
    Dim tmpMonth As Long
    Dim tmpDay As Long
    Dim yearOK As Boolean
    Dim d As Date

    ok = False
    On Error GoTo InvalidDate
    If IsError(yearVal) Or IsError(monthVal) Or IsError(dayVal) Then Exit Function
    If HasText(yearVal) Then
        tmpYear = NormalizeYearInput(yearVal, yearAdd, yearOK)
        If Not yearOK Then Exit Function
        currentYear = tmpYear
    End If
    If HasText(monthVal) Then
        If Not IsNumeric(CellText(monthVal)) Then Exit Function
        If CDbl(monthVal) <> Fix(CDbl(monthVal)) Then Exit Function
        currentMonth = CLng(CellText(monthVal))
    End If
    If HasText(dayVal) Then
        If ParseMonthDay(dayVal, tmpMonth, tmpDay) Then
            currentMonth = tmpMonth
            currentDay = tmpDay
        Else
            If Not IsNumeric(CellText(dayVal)) Then Exit Function
            If CDbl(dayVal) <> Fix(CDbl(dayVal)) Then Exit Function
            currentDay = CLng(CellText(dayVal))
        End If
    End If
    If currentYear = 0 Or currentMonth = 0 Or currentDay = 0 Then Exit Function
    If currentMonth < 1 Or currentMonth > 12 Or currentDay < 1 Or currentDay > 31 Then Exit Function
    On Error GoTo InvalidDate
    d = DateSerial(currentYear, currentMonth, currentDay)
    If Year(d) <> currentYear Or Month(d) <> currentMonth Or Day(d) <> currentDay Then GoTo InvalidDate
    ResolveInputDate = d
    ok = True
    Exit Function
InvalidDate:
    ResolveInputDate = ""
End Function

Public Function NormalizeTimeInput(ByVal v As Variant, ByRef ok As Boolean) As Variant
    Dim s As String, h As Long, m As Long, p As Variant, i As Long
    ok = False
    If IsError(v) Then Exit Function
    s = CellText(v)
    If s = "" Or s = "--:--" Then ok = True: Exit Function
    On Error GoTo InvalidTime
    s = StrConv(s, vbNarrow)
    If VarType(v) = vbDate Then
        NormalizeTimeInput = TimeSerial(Hour(CDate(v)), Minute(CDate(v)), 0): ok = True: Exit Function
    End If
    If IsNumeric(v) And VarType(v) <> vbString Then
        If CDbl(v) > 0 And CDbl(v) < 1 Then
            NormalizeTimeInput = CDate(CDbl(v)): ok = True: Exit Function
        End If
    End If
    If InStr(s, ":") > 0 Then
        p = Split(s, ":")
        If UBound(p) <> 1 Then Exit Function
        If Len(p(0)) < 1 Or Len(p(0)) > 2 Or Len(p(1)) <> 2 Then Exit Function
        s = CStr(p(0)) & CStr(p(1))
    End If
    If Len(s) > 4 Then Exit Function
    For i = 1 To Len(s)
        If Mid$(s, i, 1) < "0" Or Mid$(s, i, 1) > "9" Then Exit Function
    Next i
    s = Right$("0000" & s, 4): h = CLng(Left$(s, 2)): m = CLng(Right$(s, 2))
    If h > 23 Or m > 59 Then Exit Function
    NormalizeTimeInput = TimeSerial(h, m, 0): ok = True
InvalidTime:
End Function



Public Function ResolveAccountDateInput(ByVal v As Variant, ByRef ok As Boolean) As Variant
    '�����J�ݓ��E�����̓��͕⏕�p�B
    '������ׂ̔N���͂Ƃ͕ʂɁA���a�E�����E�ߘa�𖾎��ł���u�����R�[�h.�N.��.���v��D�悵�ĉ��߂���B
    '��F1.53.5.6=���a53�N5��6���A2.31.4.30=����31�N4��30���A3.1.5.1=�ߘa���N5��1���B
    '�����R�[�h�͐ݒ�V�[�g�̌����}�X�^�ŊǗ����邽�߁A�V�����̓}�X�^��1�s�ǉ�����ΑΉ��ł���B
    Dim s As String
    Dim cleaned As String
    Dim parts As Variant
    Dim y As Long, m As Long, d As Long
    Dim yearOK As Boolean
    Dim yAdd As Long

    ok = False
    If IsError(v) Then Exit Function
    If VarType(v) = vbDate Then ResolveAccountDateInput = CDate(v): ok = True: Exit Function
    s = CellText(v)
    If Len(s) = 0 Then
        ResolveAccountDateInput = ""
        ok = True
        Exit Function
    End If

    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = UCase$(s)
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    s = Replace(s, "�D", ".")
    s = Replace(s, "�B", ".")
    s = Replace(s, "�E", ".")
    s = Replace(s, "-", "/")
    s = Replace(s, ".", "/")
    s = Replace(s, "�N", "/")
    s = Replace(s, "��", "/")
    s = Replace(s, "��", "")
    yAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)

    If InStr(1, s, "/", vbTextCompare) > 0 Then
        parts = Split(s, "/")

        '�����R�[�h�t�����́B��F1/53/5/6�A2/31/4/30�A3/1/5/1�B
        If UBound(parts) = 3 Then
            ResolveAccountDateInput = ResolveEraCodeDateInput(parts(0), parts(1), parts(2), parts(3), ok)
            Exit Function
        End If

        '�]���݊��B��F31/4/30�AR1/5/1�A2019/5/1�B
        If UBound(parts) < 2 Then Exit Function
        y = NormalizeYearInput(parts(0), yAdd, yearOK)
        If Not yearOK Then Exit Function
        If Not IsNumeric(parts(1)) Or Not IsNumeric(parts(2)) Then Exit Function
        m = CLng(parts(1))
        d = CLng(parts(2))
        ResolveAccountDateInput = MakeCheckedDate(y, m, d, ok)
        Exit Function
    End If

    cleaned = Replace(s, "/", "")
    If IsNumeric(cleaned) Then
        Select Case Len(cleaned)
            Case 8
                y = CLng(Left$(cleaned, 4))
                m = CLng(Mid$(cleaned, 5, 2))
                d = CLng(Right$(cleaned, 2))
            Case 6
                y = NormalizeYearInput(Left$(cleaned, 2), yAdd, yearOK)
                If Not yearOK Then Exit Function
                m = CLng(Mid$(cleaned, 3, 2))
                d = CLng(Right$(cleaned, 2))
            Case 5
                'R1�N5��1���� 10501 �ƑłP�[�X�p�B���a�ȂǌÂ��J�ݓ��͌����R�[�h�t�����͂𐄏��B
                y = NormalizeYearInput(Left$(cleaned, 1), yAdd, yearOK)
                If Not yearOK Then Exit Function
                m = CLng(Mid$(cleaned, 2, 2))
                d = CLng(Right$(cleaned, 2))
            Case Else
                If IsDate(s) Then
                    ResolveAccountDateInput = CDate(s)
                    ok = True
                End If
                Exit Function
        End Select
        ResolveAccountDateInput = MakeCheckedDate(y, m, d, ok)
        Exit Function
    End If

    If IsDate(s) Then
        ResolveAccountDateInput = CDate(s)
        ok = True
    End If
End Function

Private Function ResolveEraCodeDateInput( _
    ByVal eraKey As String, _
    ByVal eraYearText As String, _
    ByVal monthText As String, _
    ByVal dayText As String, _
    ByRef ok As Boolean _
) As Variant
    '�����R�[�h�t�����t�𐼗���t�ɕϊ�����B
    '�N�́u���v��1�N�Ƃ��Ĉ����B�����̊J�n���E�I��������O���ꍇ�͖����ɂ���B
    Dim eraName As String
    Dim eraAbbr As String
    Dim startDate As Date
    Dim endDate As Date
    Dim hasEndDate As Boolean
    Dim eraYear As Long
    Dim m As Long
    Dim d As Long
    Dim westernYear As Long
    Dim dt As Variant

    ok = False
    eraYearText = NormalizeNumberText(eraYearText)
    If eraYearText = "��" Then eraYearText = "1"
    If Not IsNumeric(eraYearText) Then Exit Function
    If Not IsNumeric(monthText) Or Not IsNumeric(dayText) Then Exit Function

    eraYear = CLng(eraYearText)
    m = CLng(monthText)
    d = CLng(dayText)
    If eraYear <= 0 Then Exit Function

    If Not TryGetEraInfoByKey(eraKey, eraName, eraAbbr, startDate, endDate, hasEndDate) Then Exit Function

    westernYear = Year(startDate) + eraYear - 1
    dt = MakeCheckedDate(westernYear, m, d, ok)
    If Not ok Or Not IsDate(dt) Then Exit Function

    If CDate(dt) < startDate Then
        ok = False
        ResolveEraCodeDateInput = ""
        Exit Function
    End If
    If hasEndDate Then
        If CDate(dt) > endDate Then
            ok = False
            ResolveEraCodeDateInput = ""
            Exit Function
        End If
    End If

    ResolveEraCodeDateInput = CDate(dt)
    ok = True
End Function

Public Function TryGetEraInfoByKey( _
    ByVal eraKey As String, _
    ByRef eraName As String, _
    ByRef eraAbbr As String, _
    ByRef startDate As Date, _
    ByRef endDate As Date, _
    ByRef hasEndDate As Boolean _
) As Boolean
    '�ݒ�V�[�g�̌����}�X�^���猳�������擾����B
    '��v�����́u�����R�[�h�v�u�������v�u���́v�B�ݒ�V�[�g���������̏ꍇ�͏��a�E�����E�ߘa�̊���l�փt�H�[���o�b�N����B
    Dim ws As Worksheet
    Dim r As Long
    Dim key As String
    Dim codeText As String
    Dim nameText As String
    Dim abbrText As String
    Dim enabledText As String

    key = NormalizeEraKey(eraKey)
    If Len(key) = 0 Then Exit Function

    On Error Resume Next
    Set ws = GetSheet(SH_CONFIG)
    On Error GoTo 0

    If Not ws Is Nothing Then
        For r = ERA_MASTER_FIRST_ROW To ERA_MASTER_MAX_ROW
            codeText = NormalizeEraKey(CellText(ws.Cells(r, ERA_COL_CODE).Value))
            nameText = NormalizeEraKey(CellText(ws.Cells(r, ERA_COL_NAME).Value))
            abbrText = NormalizeEraKey(CellText(ws.Cells(r, ERA_COL_ABBR).Value))
            If Len(codeText) = 0 And Len(nameText) = 0 And Len(abbrText) = 0 Then
                '��s�͏��������̒ǉ����͗��Ȃ̂œǂݔ�΂��B
            ElseIf key = codeText Or key = nameText Or key = abbrText Then
                enabledText = UCase$(CellText(ws.Cells(r, ERA_COL_ENABLED).Value))
                If enabledText = "FALSE" Or enabledText = "0" Or enabledText = "����" Then Exit Function
                If Not IsDate(ws.Cells(r, ERA_COL_START).Value) Then Exit Function

                eraName = CellText(ws.Cells(r, ERA_COL_NAME).Value)
                eraAbbr = CellText(ws.Cells(r, ERA_COL_ABBR).Value)
                startDate = CDate(ws.Cells(r, ERA_COL_START).Value)
                If IsDate(ws.Cells(r, ERA_COL_END).Value) Then
                    endDate = CDate(ws.Cells(r, ERA_COL_END).Value)
                    hasEndDate = True
                Else
                    endDate = 0
                    hasEndDate = False
                End If
                TryGetEraInfoByKey = True
                Exit Function
            End If
        Next r
    End If

    '�t�H�[���o�b�N�B�ݒ�V�[�g���󂵂��ꍇ�ł��A����3�����͍Œ���g����悤�ɂ���B
    Select Case key
        Case "1", "S", "���a"
            eraName = "���a": eraAbbr = "S": startDate = DateSerial(1926, 12, 25): endDate = DateSerial(1989, 1, 7): hasEndDate = True
        Case "2", "H", "����"
            eraName = "����": eraAbbr = "H": startDate = DateSerial(1989, 1, 8): endDate = DateSerial(2019, 4, 30): hasEndDate = True
        Case "3", "R", "�ߘa"
            eraName = "�ߘa": eraAbbr = "R": startDate = DateSerial(2019, 5, 1): endDate = 0: hasEndDate = False
        Case Else
            Exit Function
    End Select
    TryGetEraInfoByKey = True
End Function

Private Function NormalizeEraKey(ByVal s As String) As String
    On Error Resume Next
    s = StrConv(s, vbNarrow)
    On Error GoTo 0
    s = UCase$(Trim$(s))
    s = Replace(s, " ", "")
    s = Replace(s, "�@", "")
    NormalizeEraKey = s
End Function

Private Function MakeCheckedDate(ByVal y As Long, ByVal m As Long, ByVal d As Long, ByRef ok As Boolean) As Variant
    Dim dt As Date
    ok = False
    If y < 1900 Or y > 9999 Or m < 1 Or m > 12 Or d < 1 Or d > 31 Then Exit Function
    On Error GoTo InvalidDate
    dt = DateSerial(y, m, d)
    If Year(dt) <> y Or Month(dt) <> m Or Day(dt) <> d Then GoTo InvalidDate
    MakeCheckedDate = dt
    ok = True
    Exit Function
InvalidDate:
    MakeCheckedDate = ""
End Function

Public Function NormalizedAccountDateForUse(ByVal v As Variant) As Variant
    '�]�L�����E�c��������p�B���͓r���̕�����ł����t�Ƃ��ēǂ߂���͎̂����t�Ɋ񂹂�B
    Dim ok As Boolean
    Dim d As Variant
    d = ResolveAccountDateInput(v, ok)
    If ok And IsDate(d) Then
        NormalizedAccountDateForUse = CDate(d)
    Else
        NormalizedAccountDateForUse = ""
    End If
End Function

Public Sub NormalizeAccountDateEntry(ByVal targetCell As Range)
    '�J�ݓ��E�����Z���̓��͒���ɁA�a������͂����₷�� yyyy/m/d �\���֐�����B
    '���t�͕�����ł͂Ȃ�Excel�̓��t�l�Ƃ��ĕێ����A�㑱�̎c������E�o�͂ł����肵�Ĉ����B
    Dim ok As Boolean
    Dim d As Variant
    If targetCell Is Nothing Then Exit Sub
    d = ResolveAccountDateInput(targetCell.Value, ok)
    If ok And IsDate(d) Then
        targetCell.NumberFormatLocal = "yyyy/m/d"
        targetCell.Value = CDate(d)
    End If
End Sub

Public Function AccountExistsAtDate(ByVal targetDate As Variant, ByVal openDate As Variant, ByVal closeDate As Variant) As Boolean
    If Not HasText(targetDate) Then Exit Function
    If HasText(openDate) Then
        If CDate(targetDate) < CDate(openDate) Then Exit Function
    End If
    If HasText(closeDate) Then
        If CDate(targetDate) > CDate(closeDate) Then Exit Function
    End If
    AccountExistsAtDate = True
End Function

Public Sub ApplyBalanceAvailability(ByVal ws As Worksheet)
    '�J�ݓ��E�����ɉ����Ďc�����͗��𐧌䂷��B
    '���݂��Ȃ����Ԃ̎c�����́A���͕s�E�I��s�E���F�\���ɂ��āATab�ړ��ł���΂��B
    Dim memoCol As Long
    Dim c As Long
    Dim openDate As Variant
    Dim closeDate As Variant
    Dim balDate As Variant
    Dim enabled As Boolean

    If ws Is Nothing Then Exit Sub
    If ws.Name <> SH_INPUT Then Exit Sub

    memoCol = BalanceMemoCol(ws)
    openDate = NormalizedAccountDateForUse(ws.Range(CELL_OPEN_DATE).Value)
    closeDate = NormalizedAccountDateForUse(ws.Range(CELL_CLOSE_DATE).Value)

    For c = BAL_FIRST_COL To memoCol - 1
        balDate = ws.Cells(BAL_DATE_ROW, c).Value
        enabled = AccountExistsAtDate(balDate, openDate, closeDate)
        ApplySingleBalanceInputState ws, c, enabled
    Next c
End Sub

Private Sub ApplySingleBalanceInputState(ByVal ws As Worksheet, ByVal c As Long, ByVal enabled As Boolean)
    Dim valueCell As Range
    Set valueCell = ws.Cells(BAL_VALUE_ROW, c)
    '���ԊO�ɕς���Ă����͍ς݂̐��l�������Ȃ��B�]�L�O�ɓ��t�Ƃ̐������m�F����B
    If enabled Then
        If CellText(valueCell.Value2) = "-" Then valueCell.ClearContents
        valueCell.Locked = False: valueCell.NumberFormat = "#,##0"
        valueCell.Interior.Color = vbWhite: valueCell.Font.Color = RGB(15, 23, 42)
    ElseIf HasText(valueCell.Value2) And CellText(valueCell.Value2) <> "-" Then
        valueCell.Locked = False: valueCell.Interior.Color = RGB(255, 237, 213)
        valueCell.Font.Color = RGB(124, 45, 18)
    Else
        valueCell.Value2 = "-": valueCell.Locked = True
        valueCell.Interior.Color = RGB(241, 245, 249): valueCell.Font.Color = RGB(100, 116, 139)
    End If
End Sub

Public Function FirstAvailableBalanceInputCell(ByVal ws As Worksheet) As Range
    Dim memoCol As Long
    Dim c As Long
    If ws Is Nothing Then Exit Function
    memoCol = BalanceMemoCol(ws)
    For c = BAL_FIRST_COL To memoCol - 1
        If Not ws.Cells(BAL_VALUE_ROW, c).Locked Then
            Set FirstAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, c)
            Exit Function
        End If
    Next c
    Set FirstAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, memoCol)
End Function

Public Function NextAvailableBalanceInputCell(ByVal ws As Worksheet, ByVal currentCol As Long, ByVal backwards As Boolean) As Range
    Dim memoCol As Long
    Dim c As Long
    If ws Is Nothing Then Exit Function
    memoCol = BalanceMemoCol(ws)

    If backwards Then
        For c = currentCol - 1 To BAL_FIRST_COL Step -1
            If Not ws.Cells(BAL_VALUE_ROW, c).Locked Then
                Set NextAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, c)
                Exit Function
            End If
        Next c
        Set NextAvailableBalanceInputCell = ws.Range(CELL_CLOSE_DATE)
    Else
        For c = currentCol + 1 To memoCol - 1
            If Not ws.Cells(BAL_VALUE_ROW, c).Locked Then
                Set NextAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, c)
                Exit Function
            End If
        Next c
        If currentCol < memoCol Then
            Set NextAvailableBalanceInputCell = ws.Cells(BAL_VALUE_ROW, memoCol)
        Else
            Set NextAvailableBalanceInputCell = ws.Cells(TX_FIRST_ROW, COL_TX_YEAR)
        End If
    End If
End Function

Public Function NormalizeAccountHyphen(ByVal accountNo As String) As String
    Dim s As String
    s = Trim$(accountNo)
    s = Replace(s, "�|", "-")
    s = Replace(s, "�\", "-")
    s = Replace(s, "�[", "-")
    s = Replace(s, "�", "-")
    s = Replace(s, "�|", "-")
    NormalizeAccountHyphen = s
End Function

Public Sub BuildBalanceCollections(ByRef labels As Collection, ByRef dates As Collection)
    Dim startYear As Long
    Dim endYear As Long
    Dim inheritDate As Variant
    Dim y As Long
    Dim dYearEnd As Date
    Dim eventAdded As Boolean
    Dim labelText As String
    Set labels = New Collection
    Set dates = New Collection
    startYear = ReadBalanceYear(ROW_CFG_BAL_START_YEAR)
    endYear = ReadBalanceYear(ROW_CFG_BAL_END_YEAR)
    If startYear < 1900 Or endYear > 9998 Or endYear < startYear Then Err.Raise vbObjectError + 2204, , "�c���\���N���m�F���Ă��������B"
    If endYear - startYear + 1 > BAL_TOTAL_LIMIT Then Err.Raise vbObjectError + 2205, , "�c���\���N��20�N�ȓ��ɂ��Ă��������B"
    If HasText(GetCfgCell(ROW_CFG_INHERITANCE_DATE).Value2) And Not IsDate(GetCfgCell(ROW_CFG_INHERITANCE_DATE).Value) Then Err.Raise vbObjectError + 2207, , "�����J�n���͗L���ȓ��t�œ��͂��邩�A�󗓂ɂ��Ă��������B"
    inheritDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    For y = startYear To endYear
        dYearEnd = DateSerial(y, 12, 31)
        If IsDate(inheritDate) Then
            If Not eventAdded And CDate(inheritDate) < dYearEnd Then
                labels.Add "�����J�n�����_" & vbLf & "�c���i" & Format$(CDate(inheritDate), "yyyy/m/d") & "�j"
                dates.Add CDate(inheritDate)
                eventAdded = True
            End If
            If CDate(inheritDate) = dYearEnd Then
                labelText = CStr(y) & "�N���E�����J�n�����_" & vbLf & "�c���i" & Format$(CDate(inheritDate), "yyyy/m/d") & "�j"
                eventAdded = True
            Else
                labelText = CStr(y) & "�N���c��"
            End If
        Else
            labelText = CStr(y) & "�N���c��"
        End If
        labels.Add labelText
        dates.Add dYearEnd
    Next y
    If IsDate(inheritDate) And Not eventAdded Then
        labels.Add "�����J�n�����_" & vbLf & "�c���i" & Format$(CDate(inheritDate), "yyyy/m/d") & "�j"
        dates.Add CDate(inheritDate)
    End If
    If dates.Count > BAL_TOTAL_LIMIT Then Err.Raise vbObjectError + 2208, , "�����J�n�����܂߂��c���\����20���_�܂łł��B�\���N�����߂Ă��������B"
End Sub

Private Function ReadBalanceYear(ByVal rowNo As Long) As Long
    Dim value As Variant, number As Double
    value = GetCfgCell(rowNo).Value2
    If IsError(value) Or Not IsNumeric(value) Or Not HasText(value) Then Err.Raise vbObjectError + 2209, , "�c���\���N��4���̐���œ��͂��Ă��������B"
    number = CDbl(value)
    If number < 1900 Or number > 9998 Or number <> Fix(number) Then Err.Raise vbObjectError + 2209, , "�c���\���N��1900����9998�܂ł̐����œ��͂��Ă��������B"
    ReadBalanceYear = CLng(number)
End Function

Public Function BalanceMemoCol(ByVal ws As Worksheet) As Long
    Dim c As Long
    If ws Is Nothing Then
        BalanceMemoCol = BAL_MAX_COL
        Exit Function
    End If
    For c = BAL_FIRST_COL To BAL_MAX_COL
        If CellText(ws.Cells(BAL_LABEL_ROW, c).Value) = "���̑�" Then
            BalanceMemoCol = c
            Exit Function
        End If
    Next c
    BalanceMemoCol = BAL_MAX_COL
End Function

Public Function EffectiveRange(ByVal rng As Range) As Range
    If rng Is Nothing Then Exit Function
    On Error Resume Next
    If rng.MergeCells Then
        Set EffectiveRange = rng.MergeArea
    Else
        Set EffectiveRange = rng
    End If
    On Error GoTo 0
End Function

Public Sub ApplyValidationInputOnly(ByVal rng As Range, ByVal imeMode As Long)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    target.Validation.Delete
    target.Validation.Add Type:=xlValidateInputOnly
    target.Validation.IgnoreBlank = True
    On Error Resume Next
    target.Validation.IMEMode = imeMode
    On Error GoTo 0
End Sub

Public Sub ApplyValidationList(ByVal rng As Range, ByVal listName As String, ByVal imeMode As Long, Optional ByVal allowFreeText As Boolean = True)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    target.Validation.Delete
    target.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="=" & listName
    target.Validation.IgnoreBlank = True
    target.Validation.InCellDropdown = True
    target.Validation.ShowError = Not allowFreeText
    On Error Resume Next
    target.Validation.IMEMode = imeMode
    On Error GoTo 0
End Sub

Public Sub UnlockRange(ByVal rng As Range)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.Locked = False
    On Error GoTo 0
End Sub

Public Sub MergeAndFormat(ByVal rng As Range, ByVal valueText As String, Optional ByVal mergeCells As Boolean = True)
    If rng Is Nothing Then Exit Sub
    On Error Resume Next
    rng.UnMerge
    If mergeCells Then rng.Merge
    rng.Value = valueText
    rng.WrapText = True
    rng.VerticalAlignment = xlCenter
    On Error GoTo 0
End Sub


Public Sub ClearEffectiveContents(ByVal rng As Range)
    Dim target As Range
    If rng Is Nothing Then Exit Sub
    Set target = EffectiveRange(rng)
    If target Is Nothing Then Set target = rng
    On Error Resume Next
    target.ClearContents
    On Error GoTo 0
End Sub

Public Sub AutoFitSheetSmart(ByVal ws As Worksheet, Optional ByVal columnsAddress As String = "", Optional ByVal minWidth As Double = 6, Optional ByVal maxWidth As Double = 34)
    '�񕝁E�s���̎��������BUsedRange����債�Ă���u�b�N�ł��d���Ȃ�Ȃ��悤�A
    '�l�E�����������Ă�����͈͂���ɂ���B
    Dim rngCols As Range
    Dim rngRows As Range
    Dim c As Range
    Dim r As Range
    Dim lastR As Long
    Dim lastC As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    lastR = LastUsedRowInSheet(ws)
    If lastR < 1 Then lastR = 1
    lastC = LastUsedColumnInSheet(ws, lastR)
    If lastC < 1 Then lastC = 1

    If Len(columnsAddress) > 0 Then
        Set rngCols = ws.Columns(columnsAddress)
    Else
        Set rngCols = ws.Range(ws.Cells(1, 1), ws.Cells(1, lastC)).EntireColumn
    End If
    If Not rngCols Is Nothing Then
        rngCols.AutoFit
        For Each c In rngCols.Columns
            If c.ColumnWidth < minWidth Then c.ColumnWidth = minWidth
            If c.ColumnWidth > maxWidth Then c.ColumnWidth = maxWidth
        Next c
    End If

    Set rngRows = ws.Range(ws.Rows(1), ws.Rows(lastR))
    rngRows.AutoFit
    For Each r In rngRows.Rows
        If r.RowHeight < 18 Then r.RowHeight = 18
        If r.RowHeight > 72 Then r.RowHeight = 72
    Next r
    On Error GoTo 0
End Sub

Public Sub PolishInputLayout(Optional ByVal ws As Worksheet = Nothing)
    If ws Is Nothing Then
        If Not SheetExists(SH_INPUT) Then Exit Sub
        Set ws = GetSheet(SH_INPUT)
    End If
    ApplyInputColumnWidths ws
End Sub
Private Sub ApplyInputColumnWidths(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Columns("A:A").ColumnWidth = 2
    ws.Columns("B:D").ColumnWidth = 11.5
    ws.Columns("E:E").ColumnWidth = 10.5
    ws.Columns("F:I").ColumnWidth = 14
    ws.Columns("J:J").ColumnWidth = 16
    ws.Columns("K:K").ColumnWidth = 18
    ws.Columns("L:L").ColumnWidth = 2
    ws.Columns("M:W").ColumnWidth = 2
    ws.Columns("X:X").Hidden = True
    ws.Rows("1:1").RowHeight = 4
    ws.Rows("2:14").RowHeight = 21
    ws.Rows(2).RowHeight = 24: ws.Rows(3).RowHeight = 34
    ws.Rows(4).RowHeight = 22: ws.Rows("5:6").RowHeight = 28
    ws.Rows(7).RowHeight = 20: ws.Rows(8).RowHeight = 22
    ws.Rows(BAL_LABEL_ROW).RowHeight = 30
    ws.Rows(BAL_VALUE_ROW).RowHeight = 26
    ws.Rows(BAL_DATE_ROW).RowHeight = 17
    ws.Rows(12).RowHeight = 24: ws.Rows(13).RowHeight = 6: ws.Rows(TX_HEADER_ROW).RowHeight = 26
    ws.Rows(TX_FIRST_ROW & ":" & TX_LAST_ROW).RowHeight = 23
    ws.Range("B2:K12").WrapText = True
    ws.Range("B15:K" & TX_LAST_ROW).WrapText = False
    ws.Range("B9:K9").Font.Size = 10: ws.Range("B9:K9").ShrinkToFit = False
    ws.Range("B11:K11").Font.Size = 9
    ws.Range("B14:K14").Font.Size = 11
    ws.ScrollArea = "A1:K" & TX_LAST_ROW
    If ActiveSheet.Name = ws.Name Then ActiveWindow.Zoom = 95
End Sub

Public Sub AutoFitInputSheetSmart(ByVal ws As Worksheet)
    Dim c As Long
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    '���o���Ɩ��ׂ���xAutoFit���A���̌�Ŏ�����K�v�ȍŒᕝ��ۏ؂���B
    ws.Range("B14:K" & TX_LAST_ROW).Columns.AutoFit
    For c = 2 To 11
        If ws.Columns(c).ColumnWidth < 13.2 Then ws.Columns(c).ColumnWidth = 13.2
        If c = COL_TX_TEKIYO And ws.Columns(c).ColumnWidth < 17 Then ws.Columns(c).ColumnWidth = 17
        If c = COL_TX_OTHER And ws.Columns(c).ColumnWidth < 28 Then ws.Columns(c).ColumnWidth = 28
        If ws.Columns(c).ColumnWidth > 32 Then ws.Columns(c).ColumnWidth = 32
    Next c
    ws.Rows("1:" & TX_LAST_ROW).AutoFit
    ApplyInputColumnWidths ws
    BuildOperationPanel ws
    BuildInputHelpCards ws
    On Error GoTo 0
End Sub


Public Sub RestoreAllTransactionRowStyles(Optional ByVal ws As Worksheet = Nothing)
    Dim r As Long
    If ws Is Nothing Then
        If Not SheetExists(SH_INPUT) Then Exit Sub
        Set ws = GetSheet(SH_INPUT)
    End If
    On Error Resume Next
    For r = TX_FIRST_ROW To TX_LAST_ROW
        With ws.Range(ws.Cells(r, COL_TX_YEAR), ws.Cells(r, COL_TX_OTHER))
            If (r - TX_FIRST_ROW) Mod 2 = 0 Then
                .Interior.Color = RGB(255, 255, 255)
            Else
                .Interior.Color = RGB(248, 250, 252)
            End If
            .Font.Color = RGB(15, 23, 42)
            .Borders.LineStyle = xlContinuous
            .Borders.Color = RGB(226, 232, 240)
        End With
    Next r
    On Error GoTo 0
End Sub


Public Sub SafeSelectCell(ByVal ws As Worksheet, ByVal addressText As String)
    On Error Resume Next
    If ws Is Nothing Then Exit Sub
    ThisWorkbook.Activate
    ws.Activate
    If ws.Name = SH_INPUT Then PrepareInputSelection ws.Range(addressText)
    ws.Range(addressText).Select
    On Error GoTo 0
End Sub

Public Sub SafeFreezeOutputHeader(ByVal ws As Worksheet)
    Dim prevSheet As Worksheet
    Dim win As Window
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set prevSheet = ActiveSheet
    If ws.Visible <> xlSheetVisible Then ws.Visible = xlSheetVisible
    ThisWorkbook.Activate
    ws.Activate
    Set win = Application.ActiveWindow
    If Not win Is Nothing Then
        win.FreezePanes = False
        win.SplitColumn = 0
        win.SplitRow = 0
        ws.Range("A2").Select
        win.FreezePanes = True
    End If
    If Not prevSheet Is Nothing Then prevSheet.Activate
    On Error GoTo 0
End Sub

Public Sub SafeFreezeInput()
    Dim win As Window, scrollRow As Long
    On Error Resume Next
    If ActiveWorkbook Is Nothing Then Exit Sub
    If Not ActiveWorkbook Is ThisWorkbook Then Exit Sub
    If ActiveSheet.Name <> SH_INPUT Then Exit Sub
    Set win = Application.ActiveWindow
    If win Is Nothing Then Exit Sub
    scrollRow = win.ScrollRow
    win.FreezePanes = False
    win.SplitColumn = 1: win.SplitRow = TX_HEADER_ROW
    win.FreezePanes = True
    If scrollRow >= TX_FIRST_ROW Then win.ScrollRow = scrollRow
End Sub

Public Function RequireToolReady() As Boolean
    RequireToolReady = False
    If Not SheetExists(SH_INPUT) Then
        MsgBox "���̓V�[�g������܂���BSetupWorkbook �����s���Ă��������B", vbExclamation
        Exit Function
    End If
    If Not SheetExists(SH_WORK_TX) Then
        MsgBox "��ƃV�[�g������܂���BSetupWorkbook �����s���Ă��������B", vbExclamation
        Exit Function
    End If
    If Not SheetExists(SH_CONFIG) Then
        MsgBox "�ݒ�V�[�g������܂���BSetupWorkbook �����s���Ă��������B", vbExclamation
        Exit Function
    End If
    RequireToolReady = True
End Function

Public Sub HideDailySheets(Optional ByVal hideOutputs As Boolean = False)
    '���i�G��Ȃ���ƁE���V�[�g���B���A���͉�ʂ���Ƃ̒��S�ɂ���B
    On Error Resume Next
    If SheetExists(SH_INPUT) Then ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    HideSheetIfExists SH_CONFIG
    HideSheetIfExists SH_TEKIYO
    HideSheetIfExists SH_ACCOUNT_TYPE
    HideSheetIfExists SH_INPUT_MODE
    HideSheetIfExists SH_YEAR_MODE
    HideSheetIfExists SH_DISPLAY_OPTION
    HideSheetIfExists SH_BANK_CAND
    HideSheetIfExists SH_BRANCH_CAND
    HideSheetIfExists SH_PERSON_CAND
    HideSheetIfExists SH_WORK_TX
    HideSheetIfExists SH_WORK_BAL
    HideSheetIfExists SH_ACCOUNTS
    HideSheetIfExists SH_BAL_DRAFT
    HideSheetIfExists SH_OUTPUT_TX_CONVERTED
    If hideOutputs Then
        HideSheetIfExists SH_OUTPUT_TX
        HideSheetIfExists SH_OUTPUT_BAL
        HideSheetIfExists SH_SHOP_TARGET
        HideSheetIfExists SH_OUTPUT_TX_CONVERTED
    End If
    On Error GoTo 0
End Sub

Public Sub HideSheetIfExists(ByVal sheetName As String)
    On Error Resume Next
    If SheetExists(sheetName) Then
        If ThisWorkbook.Worksheets(sheetName).Name <> ActiveSheet.Name Then ThisWorkbook.Worksheets(sheetName).Visible = xlSheetVeryHidden
    End If
    On Error GoTo 0
End Sub

Public Sub ShowCandidateSheets()
    If Not RequireToolReady() Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_ACCOUNT_TYPE).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_TEKIYO).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_BANK_CAND).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_BRANCH_CAND).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_PERSON_CAND).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_ACCOUNT_TYPE).Activate
    ThisWorkbook.Worksheets(SH_ACCOUNT_TYPE).Range("A2").Select
    On Error GoTo 0
End Sub

Public Sub ShowConfigSheet()
    If Not RequireToolReady() Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_CONFIG).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_CONFIG).Activate
    ThisWorkbook.Worksheets(SH_CONFIG).Range("C4").Select
    On Error GoTo 0
End Sub

Public Sub ShowInputSheet()
    '�戵�X�ϊ��Ώۂ�o�̓V�[�g����A���͍�Ƃ̒��S��ʂ֖߂邽�߂̓����B
    If Not SheetExists(SH_INPUT) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_INPUT).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_INPUT).Activate
    ProtectInputSheet
    EnableInputKeys
    UpdateInputStateLabel
    On Error GoTo 0
End Sub



Public Sub ShowShopConversionTargetSheet()
    If Not SheetExists(SH_SHOP_TARGET) Then Exit Sub
    On Error Resume Next
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Activate
    ThisWorkbook.Worksheets(SH_SHOP_TARGET).Range("A1").Select
    On Error GoTo 0
End Sub



Private Function LastUsedColumnInSheet(ByVal ws As Worksheet, ByVal lastR As Long) As Long
    Dim hit As Range
    Set hit = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, MatchCase:=False)
    If hit Is Nothing Then LastUsedColumnInSheet = 1 Else LastUsedColumnInSheet = hit.Column
End Function

Public Sub ApplyBalanceOutputColumns(ByVal ws As Worksheet)
    Dim widths As Variant, c As Long
    widths = Array(12, 12, 8, 12, 11, 11, 13, 13, 13, 13, 13, 17)
    For c = 1 To 12: ws.Columns(c).ColumnWidth = widths(c - 1): Next c
End Sub

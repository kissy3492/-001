Attribute VB_Name = "modUI"
Option Explicit

Private mButtonSeq As Long

Public Sub BuildOperationPanel(ByVal ws As Worksheet)
    Dim x As Double, y As Double, w As Double, gap As Double, bw As Double, i As Long
    Dim captions As Variant, actions As Variant, caption As String
    If ws Is Nothing Then Exit Sub
    ws.Unprotect Password:=TOOL_PASSWORD
    For i = ws.Shapes.Count To 1 Step -1
        If Left$(ws.Shapes(i).Name, Len(UI_PREFIX)) = UI_PREFIX And ws.Shapes(i).Name <> UI_PREFIX & "balance_page" Then ws.Shapes(i).Delete
    Next i
    PolishInputLayout ws
    mButtonSeq = 0
    x = ws.Range("B3").Left: y = ws.Range("B3").Top + 3
    gap = 6: w = ws.Range("B3:K3").Width: bw = (w - gap * 5) / 6
    caption = "�]�L���Ď���"
    If Len(CurrentEditAccountID()) > 0 Then caption = "�����𔽉f"
    captions = Array(caption, "�o�^����", "���[��\��", "Excel�o��", "���͂�����", "�ݒ�")
    actions = Array("TransferCurrentAccount", "ShowRegisteredAccounts", "BuildAllOutputSheets", "ExportFinalWorkbooks", "DiscardInput", "ShowConfigSheet")
    For i = 0 To 5
        AddUIButton ws, x + i * (bw + gap), y, bw, 29, CStr(captions(i)), CStr(actions(i)), IIf(i = 0, "primary", "tool")
    Next i
    ws.Range("B7:K7").UnMerge
    MergeAndFormat ws.Range("B7:K7"), ""
    ws.Range("B7:K7").Font.Color = RGB(30, 64, 175)
    LockToolShapes ws
    ApplyInputSections ws
    ws.Range("X14").Value2 = "1"
End Sub

Public Sub AddPanelBack(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double)
    Dim shp As Shape
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If Not shp Is Nothing Then
        With shp
            .Name = UI_PREFIX & "panel_back"
            .Fill.ForeColor.RGB = RGB(255, 255, 255)
            .Line.ForeColor.RGB = RGB(203, 213, 225)
            .Line.Weight = 1
            '�p�l���w�i�͌�h���b�O�œ����Ȃ��悤���b�N����B
            'xlMove�ɂ��āA�񕝒������ɃJ�[�h���s�p�ӂɐL�k���Ȃ��悤�ɂ���B
            .Placement = xlMoveAndSize
            .Locked = True
            .ZOrder msoSendToBack
            .Shadow.Visible = msoTrue
            .Shadow.Transparency = 0.88
            .Shadow.Blur = 7
            .Shadow.OffsetX = 0
            .Shadow.OffsetY = 2
        End With
    End If
    On Error GoTo 0
End Sub

Public Sub AddUIButton(ByVal ws As Worksheet, ByVal x As Double, ByVal y As Double, ByVal w As Double, ByVal h As Double, ByVal caption As String, ByVal macroName As String, ByVal styleName As String)
    Dim shp As Shape
    Dim btn As Object
    Dim fillColor As Long, lineColor As Long, fontColor As Long
    If ws Is Nothing Then Exit Sub
    GetButtonColors styleName, fillColor, lineColor, fontColor
    If IsLightExcelColor(fillColor) And IsLightExcelColor(fontColor) Then fontColor = RGB(15, 23, 42)
    On Error Resume Next
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, x, y, w, h)
    If Not shp Is Nothing Then
        mButtonSeq = mButtonSeq + 1
        With shp
            .Name = UI_PREFIX & "btn_" & CStr(mButtonSeq)
            .TextFrame.Characters.Text = caption
            .TextFrame.HorizontalAlignment = xlHAlignCenter
            .TextFrame.VerticalAlignment = xlVAlignCenter
            .TextFrame.MarginLeft = 2
            .TextFrame.MarginRight = 2
            .TextFrame.MarginTop = 0
            .TextFrame.MarginBottom = 0
            .TextFrame.Characters.Font.Name = "Yu Gothic UI"
            .TextFrame.Characters.Font.Size = IIf(h >= 30, 10.5, 9.5)
            .TextFrame.Characters.Font.Bold = True
            .TextFrame.Characters.Font.Color = fontColor
            .Fill.ForeColor.RGB = fillColor
            .Line.ForeColor.RGB = lineColor
            .Line.Weight = 0.8
            '�p�l���w�i�͌�h���b�O�œ����Ȃ��悤���b�N����B
            'xlMove�ɂ��āA�񕝒������ɃJ�[�h���s�p�ӂɐL�k���Ȃ��悤�ɂ���B
            .Placement = xlMoveAndSize
            .Locked = True
            .DrawingObject.PrintObject = False
            .OnAction = MacroRef(macroName)
            .AlternativeText = macroName
            .Shadow.Visible = msoFalse
        End With
        Exit Sub
    End If
    Err.Clear
    Set btn = ws.Buttons.Add(x, y, w, h)
    If Not btn Is Nothing Then
        btn.Caption = caption
        btn.OnAction = MacroRef(macroName)
        On Error Resume Next
        btn.Locked = True
        btn.Placement = xlMoveAndSize
        On Error GoTo 0
    End If
    On Error GoTo 0
End Sub

Private Sub GetButtonColors(ByVal styleName As String, ByRef fillColor As Long, ByRef lineColor As Long, ByRef fontColor As Long)
    fontColor = RGB(15, 23, 42)
    Select Case LCase$(styleName)
        Case "hero"
            fillColor = RGB(20, 184, 166)
            lineColor = RGB(13, 148, 136)
            fontColor = RGB(255, 255, 255)
        Case "primary"
            fillColor = RGB(37, 99, 235)
            lineColor = RGB(29, 78, 216)
            fontColor = RGB(255, 255, 255)
        Case "accent"
            fillColor = RGB(14, 165, 233)
            lineColor = RGB(2, 132, 199)
            fontColor = RGB(255, 255, 255)
        Case "export"
            fillColor = RGB(124, 58, 237)
            lineColor = RGB(109, 40, 217)
            fontColor = RGB(255, 255, 255)
        Case "danger"
            fillColor = RGB(239, 68, 68)
            lineColor = RGB(220, 38, 38)
            fontColor = RGB(255, 255, 255)
        Case "neutral"
            fillColor = RGB(241, 245, 249)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(15, 23, 42)
        Case "tool"
            fillColor = RGB(255, 255, 255)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(30, 64, 175)
        Case "soft"
            fillColor = RGB(248, 250, 252)
            lineColor = RGB(226, 232, 240)
            fontColor = RGB(51, 65, 85)
        Case Else
            fillColor = RGB(248, 250, 252)
            lineColor = RGB(203, 213, 225)
            fontColor = RGB(15, 23, 42)
    End Select
End Sub

Public Sub AddConfigButton(ByVal ws As Worksheet, ByVal cellAddress As String, ByVal caption As String, ByVal macroName As String)
    Dim a As Range
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    Set a = ws.Range(cellAddress)
    On Error GoTo 0
    If a Is Nothing Then Exit Sub
    AddUIButton ws, a.Left, a.Top, 150, 28, caption, macroName, "tool"
End Sub

Public Sub BuildInputHelpCards(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    ws.Range("M2:T14").ClearContents
End Sub

Public Sub RefreshButtonActions()
    'SaveAs��Ƀu�b�N�����ς���Ă��A�}�`�{�^���̎Q�Ɛ�����݂�ThisWorkbook�֒��蒼���B
    Dim ws As Worksheet
    Dim shp As Shape
    Dim macroName As String
    On Error Resume Next
    For Each ws In ThisWorkbook.Worksheets
        For Each shp In ws.Shapes
            If Left$(shp.Name, Len(UI_PREFIX)) = UI_PREFIX Then
                macroName = shp.AlternativeText
                If Len(macroName) > 0 Then
                    If shp.OnAction <> MacroRef(macroName) Then shp.OnAction = MacroRef(macroName)
                End If
            End If
        Next shp
    Next ws
    On Error GoTo 0
End Sub

Public Sub FormatHeader(ByVal rng As Range, Optional ByVal fillColor As Long = 0)
    If rng Is Nothing Then Exit Sub
    If fillColor = 0 Then fillColor = RGB(226, 232, 240)
    With rng
        .Font.Bold = True
        .Font.Color = RGB(15, 23, 42)
        .Interior.Color = fillColor
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(203, 213, 225)
        .VerticalAlignment = xlCenter
    End With
End Sub

Public Sub FormatOutputHeader(ByVal rng As Range)
    If rng Is Nothing Then Exit Sub
    With rng
        .Font.Bold = True
        .Font.Size = 14
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(30, 64, 175)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(147, 197, 253)
    End With
End Sub

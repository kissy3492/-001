Attribute VB_Name = "modShopConversion"
Option Explicit

Public Sub BuildShopConversionTargetSheet()
    OpenShopNames
End Sub

Public Sub BuildShopConversionTargetSheetCore(Optional ByVal activateAfter As Boolean = False, Optional ByVal sourceSheet As Worksheet = Nothing, Optional ByVal destination As Worksheet = Nothing)
    Dim wsOut As Worksheet, wsTarget As Worksheet
    Dim lastR As Long, r As Long, targetR As Long, nextNo As Long, oldLastR As Long
    Dim bankName As String, shopText As String, codeText As String
    Dim oldData As Variant, preservedResult As String, preservedStatus As String
    Dim oldMap As Object, targetRows As Object, key As Variant, entry As Variant

    If Not SheetExists(SH_OUTPUT_TX) Then Exit Sub
    If sourceSheet Is Nothing Then Set wsOut = GetSheet(SH_OUTPUT_TX) Else Set wsOut = sourceSheet
    If destination Is Nothing Then Set wsTarget = GetOrCreateSheet(SH_SHOP_TARGET, False) Else Set wsTarget = destination

    '�Đ������Ă��A���ɓ��͂����u�ϊ���戵�X�v�u�m�F�󋵁v�͋�s��+�R�[�h�P�ʂň����p���B
    oldLastR = LastRow(wsTarget, SHOP_TGT_COL_NO)
    If oldLastR >= 2 Then oldData = wsTarget.Range("A1:K" & oldLastR).Value

    Set oldMap = CreateObject("Scripting.Dictionary")
    Set targetRows = CreateObject("Scripting.Dictionary")
    If IsArray(oldData) Then
        For r = 2 To UBound(oldData, 1)
            bankName = CellText(oldData(r, SHOP_TGT_COL_BANK))
            codeText = NormalizeShopCodeText(CellText(oldData(r, SHOP_TGT_COL_CODE)))
            If Len(bankName) > 0 And Len(codeText) > 0 Then
                oldMap(bankName & Chr$(30) & codeText) = Array(bankName, codeText, oldData(r, SHOP_TGT_COL_RESULT), oldData(r, SHOP_TGT_COL_STATUS))
            End If
        Next r
    End If
    SetupShopConversionTargetSheet wsTarget
    lastR = LastRow(wsOut, OUT_COL_BANK)
    nextNo = 1

    For r = 2 To lastR
        If IsCashOperationTransactionRow(wsOut, r) Then
            shopText = CellText(wsOut.Cells(r, OUT_COL_SHOP).Value)
            If IsCodeLikeShop(shopText) Then
                bankName = CellText(wsOut.Cells(r, OUT_COL_BANK).Value)
                codeText = NormalizeShopCodeText(shopText)
                key = bankName & Chr$(30) & codeText
                targetR = 0
                If targetRows.Exists(key) Then targetR = CLng(targetRows(key))

                If targetR = 0 Then
                    targetR = LastRow(wsTarget, SHOP_TGT_COL_NO) + 1
                    If targetR < 2 Then targetR = 2
                    targetRows.Add key, targetR

                    wsTarget.Cells(targetR, SHOP_TGT_COL_NO).Value = nextNo
                    wsTarget.Cells(targetR, SHOP_TGT_COL_BANK).Value = bankName
                    wsTarget.Cells(targetR, SHOP_TGT_COL_CODE).Value = codeText
                    wsTarget.Cells(targetR, SHOP_TGT_COL_COUNT).Value = 1
                    wsTarget.Cells(targetR, SHOP_TGT_COL_ROWS).Value = CStr(r)

                    preservedResult = "": preservedStatus = ""
                    If oldMap.Exists(key) Then
                        entry = oldMap(key)
                        preservedResult = CellText(entry(2)): preservedStatus = CellText(entry(3))
                    End If
                    wsTarget.Cells(targetR, SHOP_TGT_COL_RESULT).Value = preservedResult
                    If Len(preservedStatus) > 0 Then
                        wsTarget.Cells(targetR, SHOP_TGT_COL_STATUS).Value = preservedStatus
                    ElseIf Len(preservedResult) > 0 Then
                        wsTarget.Cells(targetR, SHOP_TGT_COL_STATUS).Value = "���͍�"
                    Else
                        wsTarget.Cells(targetR, SHOP_TGT_COL_STATUS).Value = "������"
                    End If
                    wsTarget.Cells(targetR, SHOP_TGT_COL_CREATED).Value = Now
                    nextNo = nextNo + 1
                Else
                    wsTarget.Cells(targetR, SHOP_TGT_COL_COUNT).Value = CLng(Val(wsTarget.Cells(targetR, SHOP_TGT_COL_COUNT).Value)) + 1
                    wsTarget.Cells(targetR, SHOP_TGT_COL_ROWS).Value = AppendRowNumber(CellText(wsTarget.Cells(targetR, SHOP_TGT_COL_ROWS).Value), r)
                End If
            End If
        End If
    Next r

    '�����ŊY��������Ȃ��Ȃ��Ă��A���͂������̂Ɗm�F�󋵂������Ȃ��B
    For Each key In oldMap.Keys
        If Not targetRows.Exists(key) Then
            entry = oldMap(key)
            preservedResult = CellText(entry(2)): preservedStatus = CellText(entry(3))
            If Len(preservedResult) > 0 Or (Len(preservedStatus) > 0 And preservedStatus <> "������") Then
                targetR = LastRow(wsTarget, SHOP_TGT_COL_NO) + 1
                wsTarget.Cells(targetR, SHOP_TGT_COL_NO).Value2 = nextNo
                wsTarget.Cells(targetR, SHOP_TGT_COL_BANK).Value2 = entry(0)
                wsTarget.Cells(targetR, SHOP_TGT_COL_CODE).Value2 = entry(1)
                wsTarget.Cells(targetR, SHOP_TGT_COL_COUNT).Value2 = 0
                wsTarget.Cells(targetR, SHOP_TGT_COL_RESULT).Value2 = preservedResult
                wsTarget.Cells(targetR, SHOP_TGT_COL_STATUS).Value2 = preservedStatus
                wsTarget.Cells(targetR, SHOP_TGT_COL_CREATED).Value = Now
                nextNo = nextNo + 1
            End If
        End If
    Next key
    FormatShopConversionTargetSheet wsTarget
    wsTarget.Visible = xlSheetVisible
    If activateAfter Then
        wsTarget.Activate
        wsTarget.Range("A1").Select
    End If
End Sub

Public Sub ApplyShopConversionToCashOperation()
    BuildAllOutputSheets
End Sub



Public Function FillBlankShopWithBranch(ByVal ws As Worksheet) As Long
    Dim lastR As Long, r As Long, branchName As String
    If ws Is Nothing Then Exit Function
    lastR = LastRow(ws, OUT_COL_BANK)
    For r = 2 To lastR
        If IsCashOperationTransactionRow(ws, r) Then
            If Len(CellText(ws.Cells(r, OUT_COL_SHOP).Value)) = 0 Then
                branchName = CellText(ws.Cells(r, OUT_COL_BRANCH).Value)
                If Len(branchName) > 0 Then
                    ws.Cells(r, OUT_COL_SHOP).Value = branchName
                    FillBlankShopWithBranch = FillBlankShopWithBranch + 1
                End If
            End If
        End If
    Next r
End Function

Public Sub SetupShopConversionTargetSheet(ByVal ws As Worksheet)
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    DeleteToolShapes ws, False
    ws.Cells.UnMerge
    ws.Cells.Clear
    ws.Cells.ClearFormats
    ws.Cells.Validation.Delete
    ws.AutoFilterMode = False
    On Error GoTo 0

    ws.Cells.Font.Name = "Yu Gothic UI"
    ws.Cells.Font.Size = 10
    ws.Cells.Interior.Color = RGB(248, 250, 252)
    ws.Cells.Font.Color = RGB(15, 23, 42)

    SetRowValues ws.Range("A1"), Array("No", "��s��", "�戵�X�R�[�h", "�Y������", "�Y���s�ԍ�", "�ϊ���戵�X", "�m�F��", "�쐬����")
    FormatOutputHeader ws.Range("A1:H1")
    ws.Range("A1:H1").Interior.Color = RGB(37, 99, 235)
    ws.Range("A1:H1").Font.Color = RGB(255, 255, 255)
    ws.Range("A1:H1").Borders.Color = RGB(147, 197, 253)

    ws.Columns("A:A").ColumnWidth = 6
    ws.Columns("B:B").ColumnWidth = 24
    ws.Columns("C:C").ColumnWidth = 18
    ws.Columns("D:D").ColumnWidth = 10
    ws.Columns("E:E").ColumnWidth = 24
    ws.Columns("F:F").ColumnWidth = 34
    ws.Columns("G:G").ColumnWidth = 14
    ws.Columns("H:H").ColumnWidth = 18
    ws.Columns("J:N").ColumnWidth = 14

    ws.Columns("B:C").NumberFormatLocal = "@"
    ws.Columns("F:G").NumberFormatLocal = "@"
    ws.Columns("F:G").Interior.Color = RGB(255, 255, 255)
    ws.Columns("H:H").NumberFormatLocal = "yyyy/m/d h:mm"
    ws.Rows(1).RowHeight = 28
    ws.Rows(1).Font.Bold = True
    ws.Range("F:F").Font.Bold = True

    On Error Resume Next
    ws.Range("G2:G1000").Validation.Delete
    ws.Range("G2:G1000").Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="������,���͍�,�m�F�s�v,�ۗ�"
    ws.Range("G2:G1000").Validation.InCellDropdown = True
    ws.Range("G2:G1000").Validation.ShowError = False
    On Error GoTo 0
End Sub

Public Sub FormatShopConversionTargetSheet(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long
    If ws Is Nothing Then Exit Sub
    lastR = LastRow(ws, SHOP_TGT_COL_NO)
    On Error Resume Next
    ws.AutoFilterMode = False
    On Error GoTo 0

    If lastR < 2 Then
        ws.Range("A2:H2").UnMerge
        ws.Range("A2").Value = "�ϊ��Ώۂ̎戵�X�R�[�h�͂���܂���B"
        ws.Range("A2:H2").Merge
        ws.Range("A2:H2").Interior.Color = RGB(220, 252, 231)
        ws.Range("A2:H2").Font.Color = RGB(20, 83, 45)
        ws.Range("A2:H2").Font.Bold = True
        ws.Range("A2:H2").HorizontalAlignment = xlCenter
        ws.Rows(2).RowHeight = 28
    Else
        For r = 2 To lastR
            With ws.Range("A" & r & ":H" & r)
                .Borders.LineStyle = xlContinuous
                .Borders.Color = RGB(226, 232, 240)
                If (r Mod 2) = 0 Then
                    .Interior.Color = RGB(255, 255, 255)
                Else
                    .Interior.Color = RGB(248, 250, 252)
                End If
                .Font.Color = RGB(15, 23, 42)
            End With
            ws.Cells(r, SHOP_TGT_COL_CODE).Interior.Color = RGB(239, 246, 255)
            ws.Cells(r, SHOP_TGT_COL_RESULT).Interior.Color = RGB(236, 253, 245)
            ws.Cells(r, SHOP_TGT_COL_STATUS).Interior.Color = RGB(254, 249, 195)
        Next r
        ws.Range("A1:H" & lastR).AutoFilter
    End If

    ws.Range("A1:H" & Application.Max(2, lastR)).VerticalAlignment = xlCenter
    ws.Range("A:E").HorizontalAlignment = xlCenter
    ws.Range("F:F").HorizontalAlignment = xlLeft
    ws.Range("G:G").HorizontalAlignment = xlCenter
    ws.Range("H:H").HorizontalAlignment = xlCenter
    ws.Range("E:F").WrapText = True
    ws.Range("A1:H1").HorizontalAlignment = xlCenter
    ws.Range("A1:H1").VerticalAlignment = xlCenter
    ws.Rows(1).RowHeight = 32

    AutoFitSheetSmart ws, "A:H", 6, 45
    If ws.Columns("B:B").ColumnWidth < 22 Then ws.Columns("B:B").ColumnWidth = 22
    If ws.Columns("C:C").ColumnWidth < 16 Then ws.Columns("C:C").ColumnWidth = 16
    If ws.Columns("E:E").ColumnWidth < 22 Then ws.Columns("E:E").ColumnWidth = 22
    If ws.Columns("F:F").ColumnWidth < 32 Then ws.Columns("F:F").ColumnWidth = 32
    If ws.Columns("G:G").ColumnWidth < 13 Then ws.Columns("G:G").ColumnWidth = 13
    If ws.Columns("H:H").ColumnWidth < 18 Then ws.Columns("H:H").ColumnWidth = 18

    With ws.Range("G2:G" & Application.Max(1000, lastR))
        .Validation.Delete
        .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:="������,���͍�,�m�F�s�v,�ۗ�"
        .Validation.InCellDropdown = True
        .Validation.ShowError = True
    End With
    BuildShopConversionTargetPanel ws
    FixUnreadableWhiteTextOnSheet ws
    LockToolShapes ws
    SafeFreezeOutputHeader ws
    ProtectShopConversionTargetSheet ws
End Sub

Public Sub BuildShopConversionTargetPanel(ByVal ws As Worksheet)
    DeleteToolShapes ws, False
    ws.Columns("J:N").ColumnWidth = 2
    ws.Range("J2:N2").UnMerge: ws.Range("J2:N2").ClearContents
    AddConfigButton ws, "J2", "���[��\��", "BuildAllOutputSheets"
    AddConfigButton ws, "J4", "���֖͂߂�", "ShowInputSheet"
    LockToolShapes ws
End Sub

Public Sub ProtectShopConversionTargetSheet(Optional ByVal destination As Worksheet = Nothing)
    '�戵�X�ϊ��ΏۃV�[�g�́A�ϊ���戵�X�E�m�F�󋵂������͂ł���΂悢�B
    '�{�^����J�[�h�͕ی삵�āA����Ĉړ��E�T�C�Y�ύX����Ȃ��悤�ɂ���B
    Dim ws As Worksheet
    If Not SheetExists(SH_SHOP_TARGET) Then Exit Sub
    If destination Is Nothing Then Set ws = GetSheet(SH_SHOP_TARGET) Else Set ws = destination

    On Error Resume Next
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.Locked = True
    ws.Range("F2:G" & Application.Max(1000, LastRow(ws))).Locked = False
    LockToolShapes ws
    ws.Protect Password:=TOOL_PASSWORD, DrawingObjects:=True, Contents:=True, Scenarios:=False, _
               UserInterfaceOnly:=True, AllowFiltering:=True, AllowSorting:=True, _
               AllowFormattingCells:=False, AllowFormattingColumns:=False, AllowFormattingRows:=False
    ws.EnableSelection = xlNoRestrictions
    On Error GoTo 0
End Sub

Private Function IsCashOperationTransactionRow(ByVal ws As Worksheet, ByVal r As Long) As Boolean
    If ws Is Nothing Or r < 2 Then Exit Function
    If Not HasText(ws.Cells(r, OUT_COL_BANK).Value2) Then Exit Function
    '�ʏ����͎����s���ł� --:-- �����B�E�v�̌��ł͍s��ʂ����߂Ȃ��B
    IsCashOperationTransactionRow = HasText(ws.Cells(r, OUT_COL_TIME).Value2)
End Function



Private Function AppendRowNumber(ByVal existingText As String, ByVal rowNo As Long) As String
    If Len(existingText) = 0 Then
        AppendRowNumber = CStr(rowNo)
    ElseIf Right$(existingText, 3) = " �ق�" Then
        AppendRowNumber = existingText
    ElseIf Len(existingText) + Len(CStr(rowNo)) + 1 > 160 Then
        AppendRowNumber = existingText & " �ق�"
    Else
        AppendRowNumber = existingText & "," & CStr(rowNo)
    End If
End Function

Public Function IsCodeLikeShop(ByVal valueText As String) As Boolean
    Dim s As String
    s = NormalizeShopCodeText(valueText)
    If Len(s) = 0 Then Exit Function
    If ContainsJapaneseChar(s) Then Exit Function
    If Not ContainsDigit(s) Then Exit Function
    If InStr(s, "�x�X") > 0 Or InStr(s, "�{�X") > 0 Then Exit Function
    IsCodeLikeShop = True
End Function

Public Function NormalizeShopCodeText(ByVal valueText As String) As String
    Dim s As String, i As Long, ch As String, code As Long, outText As String
    s = Trim$(CStr(valueText))
    s = Replace(s, "�@", " ")
    s = Trim$(s)
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        code = AscW(ch)
        If code < 0 Then code = code + 65536
        Select Case code
            Case &HFF10& To &HFF19&
                outText = outText & ChrW$(code - &HFEE0&)
            Case &HFF21& To &HFF3A&
                outText = outText & ChrW$(code - &HFEE0&)
            Case &HFF41& To &HFF5A&
                outText = outText & UCase$(ChrW$(code - &HFEE0&))
            Case &H2010&, &H2011&, &H2012&, &H2013&, &H2014&, &H2212&, &HFF0D&
                outText = outText & "-"
            Case 32, 9
                '�󔒂͏��O
            Case Else
                outText = outText & UCase$(ch)
        End Select
    Next i
    NormalizeShopCodeText = outText
End Function

Private Function ContainsDigit(ByVal s As String) As Boolean
    Dim i As Long, code As Long
    For i = 1 To Len(s)
        code = AscW(Mid$(s, i, 1))
        If code >= 48 And code <= 57 Then ContainsDigit = True: Exit Function
    Next i
End Function

Private Function ContainsJapaneseChar(ByVal s As String) As Boolean
    Dim i As Long, code As Long
    For i = 1 To Len(s)
        code = AscW(Mid$(s, i, 1))
        If code < 0 Then code = code + 65536
        If (code >= &H3040& And code <= &H30FF&) Or _
           (code >= &H3400& And code <= &H9FFF&) Or _
           (code >= &HF900& And code <= &HFAFF&) Or _
           (code >= &HFF66& And code <= &HFF9D&) Then
            ContainsJapaneseChar = True
            Exit Function
        End If
    Next i
End Function

Public Sub UpdateShopMappingStatus(ByVal Target As Range)
    Dim ws As Worksheet, changed As Range, cell As Range, status As String
    Set ws = Target.Worksheet
    Set changed = Intersect(Target, ws.Range("F2:F" & Application.Max(2, LastRow(ws))))
    If changed Is Nothing Then Exit Sub
    For Each cell In changed.Cells
        'F:G���ꏏ�ɓ\��t�����ꍇ�́A����������Ԃ�D�悷��B
        If Intersect(Target, ws.Cells(cell.Row, SHOP_TGT_COL_STATUS)) Is Nothing Then
            status = CellText(ws.Cells(cell.Row, SHOP_TGT_COL_STATUS).Value2)
            If status <> "�ۗ�" And status <> "�m�F�s�v" Then
                ws.Cells(cell.Row, SHOP_TGT_COL_STATUS).Value2 = IIf(HasText(cell.Value2), "���͍�", "������")
            End If
        End If
    Next cell
End Sub

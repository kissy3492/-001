Attribute VB_Name = "modBuildOutputs"
Option Explicit

Public Sub BuildAllOutputSheets()
    If Not RequireToolReady() Then Exit Sub
    If Not RequirePostedInput() Then Exit Sub
    On Error GoTo EH
    AppBegin "���[���쐬���Ă��܂�..."
    EnsureCurrentOutputs
    GetSheet(SH_OUTPUT_TX).Activate
    AppEnd
    Exit Sub
EH:
    Dim originalErrorText As String
    originalErrorText = Err.Description
    AppEnd
    MsgBox "���[���쐬�ł��܂���ł����B" & vbCrLf & originalErrorText, vbExclamation
End Sub

Public Sub RefreshAllOutputs()
    Dim original(0 To 2) As Worksheet, staged(0 To 2) As Worksheet
    Dim names As Variant, stageNames(0 To 2) As String, i As Long
    Dim errorText As String, restoreText As String, swapped(0 To 2) As Boolean
    On Error GoTo EH
    EnsureAccountStore
    InvalidateOutputViews
    names = Array(SH_OUTPUT_TX, SH_SHOP_TARGET, SH_OUTPUT_BAL)
    '3���Ƃ��R�s�[��ō쐬����B���̓��͂��܂ތ��̃V�[�g�͊����܂ŕێ�����B
    For i = 0 To 2
        Set original(i) = GetSheet(CStr(names(i)))
        original(i).Copy After:=ThisWorkbook.Sheets(ThisWorkbook.Sheets.Count)
        Set staged(i) = ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count)
        stageNames(i) = staged(i).Name
    Next i
    BuildCashOperationSheetCore False, staged(0)
    BuildShopConversionTargetSheetCore False, staged(0), staged(1)
    ApplyShopNamesToOutput staged(0), staged(1)
    BuildBalanceTransitionSheetCore False, staged(2)
    For i = 0 To 2
        original(i).Name = AvailableOutputSheetName()
        swapped(i) = True
        staged(i).Name = CStr(names(i))
        staged(i).Move Before:=original(i)
    Next i
    GetSheet(SH_INPUT).Activate
    For i = 0 To 2: original(i).Visible = xlSheetVeryHidden: Next i
    GetSheet(SH_INPUT).Range("X7").Value2 = "0"
    '��������͊����ς݁B�ޔ��V�[�g�̍폜���s�Ŋ����i�������߂��Ȃ��B
    On Error Resume Next
    For i = 0 To 2: original(i).Delete: Next i
    HideDailySheets False
    On Error GoTo 0
    Exit Sub
EH:
    errorText = Err.Description
    On Error Resume Next
    GetSheet(SH_INPUT).Activate
    For i = 2 To 0 Step -1
        Err.Clear
        If swapped(i) Then
            staged(i).Name = stageNames(i)
            original(i).Name = CStr(names(i))
            If Err.Number <> 0 Then restoreText = restoreText & " " & CStr(names(i))
        End If
        Err.Clear
        If Not staged(i) Is Nothing Then
            staged(i).Visible = xlSheetVeryHidden
            staged(i).Delete
        End If
    Next i
    HideDailySheets True
    InvalidateOutputViews
    On Error GoTo 0
    If Len(restoreText) > 0 Then
        errorText = errorText & vbCrLf & "���[���̕����������F" & restoreText & "�B�㏑���ۑ������A�ۑ��ς݂̃u�b�N���J�������Ă��������B"
    Else
        errorText = errorText & vbCrLf & "�o�^�f�[�^�Ǝ戵�X���͕ێ����Ă��܂��B�����𒼂��Ă��璠�[���č쐬���Ă��������B"
    End If
    Err.Raise vbObjectError + 2402, "RefreshAllOutputs", errorText
End Sub

Private Function AvailableOutputSheetName() As String
    Dim n As Long, nameText As String
    n = 1
    Do
        nameText = "W_���[�ޔ�_" & n
        If Not SheetExists(nameText) Then Exit Do
        n = n + 1
    Loop
    AvailableOutputSheetName = nameText
End Function

Public Sub BuildCashOperationSheet()
    BuildAllOutputSheets
End Sub

Public Sub BuildBalanceTransitionSheet()
    BuildAllOutputSheets
    If SheetExists(SH_OUTPUT_BAL) Then GetSheet(SH_OUTPUT_BAL).Activate
End Sub

Public Sub BuildCashOperationSheetCore(ByVal activateAfter As Boolean, Optional ByVal destination As Worksheet = Nothing)
    Dim src As Variant, data As Variant, ws As Worksheet, r As Long, c As Long, n As Long
    Dim kind As String, included As Boolean, inheritanceDate As Variant, kinds As Variant
    src = ReadStore(GetSheet(SH_WORK_TX), 16)
    If destination Is Nothing Then Set ws = GetSheet(SH_OUTPUT_TX) Else Set ws = destination
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.UnMerge: ws.Cells.Clear
    ws.Visible = xlSheetVisible
    ws.Columns("A:E").NumberFormat = "@": ws.Columns("J:L").NumberFormat = "@"
    SetRowValues ws.Range("A1"), Array("��s��", "�x�X��", "����", "�Ȗ�", "�����ԍ�", "���t", "����", "�o��", "����", "�戵�X", "�@��", "�E�v", "���̑�")
    ReDim data(1 To UBound(src, 1) + 1, 1 To 17)
    inheritanceDate = GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)
    If ShowInheritanceStartRow() And IsDate(inheritanceDate) Then
        n = 1: data(n, 6) = CDbl(CDate(inheritanceDate)): data(n, 12) = "�����J�n��": data(n, 17) = "����"
    End If
    For r = 2 To UBound(src, 1)
        kind = CStr(src(r, TX_KIND_COL)): included = True
        Select Case kind
            Case "�J��": included = ShowOpenDateRow()
            Case "���": included = ShowCloseDateRow()
            Case "�c��": included = ShowBalanceRowsInCashOperation()
        End Select
        If included Then
            n = n + 1
            For c = 1 To 13: data(n, c) = src(r, c): Next c
            data(n, 3) = DisplayPersonWithRelationship(CStr(src(r, 3)), CStr(src(r, 14)))
            data(n, 17) = kind
            If kind = "���" Then
                If Not HasText(data(n, 10)) Then data(n, 10) = data(n, 2)
                If Not HasText(data(n, 7)) Then data(n, 7) = "--:--"
            End If
        End If
    Next r
    If n > 0 Then
        Dim fitted As Variant
        ReDim fitted(1 To n, 1 To 17)
        For r = 1 To n
            For c = 1 To 17: fitted(r, c) = data(r, c): Next c
        Next r
        ws.Range("A2").Resize(n, 17).Value2 = fitted
    End If
    SortCashOperation ws
    FormatCashOperationOutputLayout ws
    kinds = ws.Range("Q1:Q" & Application.Max(2, n + 1)).Value2
    For r = 2 To n + 1
        kind = CellText(kinds(r, 1))
        Select Case kind
            Case "�c��"
                ws.Range("A" & r & ":M" & r).Interior.Color = RGB(236, 247, 241)
                ws.Cells(r, 13).NumberFormat = "#,##0"
            Case "����"
                ws.Range("A" & r & ":M" & r).Interior.Color = RGB(255, 246, 219)
                ws.Range("A" & r & ":M" & r).Font.Bold = True
            Case "�J��", "���"
                ws.Range("A" & r & ":M" & r).Interior.Color = RGB(239, 246, 255)
        End Select
    Next r
    ws.Columns("N:Q").ClearContents
    ws.PageSetup.PrintArea = ws.Range("A1:M" & n + 1).Address
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range("A1:M" & n + 1).AutoFilter
    ProtectGeneratedOutput ws
    If activateAfter Then ws.Activate
End Sub

Public Sub SortCashOperation(ByVal ws As Worksheet)
    Dim lastR As Long, r As Long, v As Variant, times As Variant, keys As Variant
    lastR = LastUsedRowInSheet(ws)
    If lastR < 3 Then Exit Sub
    SetRowValues ws.Range("N1"), Array("���͏�", "�����L��", "�����L�[")
    times = ws.Range("G2:G" & lastR).Value2
    ReDim keys(1 To lastR - 1, 1 To 3)
    For r = 1 To UBound(times, 1)
        keys(r, 1) = r + 1
        v = times(r, 1)
        If IsNumeric(v) And HasText(v) Then
            keys(r, 2) = 0: keys(r, 3) = CDbl(v)
        Else
            keys(r, 2) = 1: keys(r, 3) = 0
        End If
    Next r
    ws.Range("N2").Resize(UBound(keys, 1), 3).Value2 = keys
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range("F2:F" & lastR), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("O2:O" & lastR), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("P2:P" & lastR), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("N2:N" & lastR), Order:=xlAscending
        .SetRange ws.Range("A1:Q" & lastR): .Header = xlYes: .Apply
    End With
    ws.Range("N1:P" & lastR).ClearContents
End Sub





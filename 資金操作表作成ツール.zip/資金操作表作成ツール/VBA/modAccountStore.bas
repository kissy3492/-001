Attribute VB_Name = "modAccountStore"
Option Explicit

Public Const SH_ACCOUNTS As String = "W_����"
Public Const SH_ACCOUNT_LIST As String = "�o�^����"
Public Const SH_BAL_DRAFT As String = "W_���͎c��"
Public Const CELL_EDIT_ID As String = "X1"
Public Const CELL_DIRTY As String = "X2"
Public Const CELL_BAL_PAGE As String = "X3"
Public Const CELL_BAL_MEMO As String = "X4"
Public Const CELL_YEAR_SNAPSHOT As String = "X5"
Public Const CELL_YEAR_ADD As String = "X6"
Public Const TX_ID_COL As Long = 15
Public Const TX_KIND_COL As Long = 16
Public Const BAL_ID_COL As Long = 13

Public Function CurrentEditAccountID() As String
    CurrentEditAccountID = CellText(GetSheet(SH_INPUT).Range(CELL_EDIT_ID).Value2)
End Function

Public Function InputIsDirty() As Boolean
    InputIsDirty = (CellText(GetSheet(SH_INPUT).Range(CELL_DIRTY).Value2) = "1")
End Function

Public Sub MarkInputDirty(ByVal Target As Range)
    Dim ws As Worksheet
    Set ws = Target.Worksheet
    If Intersect(Target, ws.Range("B5:K6,B10:K10,B15:K" & InputLastTransactionRow())) Is Nothing Then Exit Sub
    ws.Range(CELL_DIRTY).Value2 = "1"
    UpdateInputStateLabel
    If Len(CellText(ws.Range(CELL_YEAR_SNAPSHOT).Value2)) = 0 Then
        ws.Range(CELL_YEAR_SNAPSHOT).Value2 = GetCfgCell(ROW_CFG_YEAR_MODE).Value2
        ws.Range(CELL_YEAR_ADD).Value2 = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)
        ws.Range("X8").Value2 = GetCfgLong(ROW_CFG_BAL_START_YEAR, Year(Date) - 4)
        ws.Range("X9").Value2 = GetCfgLong(ROW_CFG_BAL_END_YEAR, Year(Date))
        If IsDate(GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)) Then
            ws.Range("X10").Value2 = Year(CDate(GetCfgDateValue(ROW_CFG_INHERITANCE_DATE)))
        Else
            ws.Range("X10").Value2 = CLng((CDbl(ws.Range("X8").Value2) + CDbl(ws.Range("X9").Value2)) / 2)
        End If
    End If
End Sub

Public Function InputYearAdd() As Long
    InputYearAdd = GetCfgLong(ROW_CFG_YEAR_ADD, 2000)
    If HasText(GetSheet(SH_INPUT).Range(CELL_YEAR_ADD).Value2) Then _
        InputYearAdd = CLng(GetSheet(SH_INPUT).Range(CELL_YEAR_ADD).Value2)
End Function

Public Sub EnsureAccountStore()
    Dim ws As Worksheet
    If SheetExists(SH_ACCOUNTS) Then Set ws = GetSheet(SH_ACCOUNTS) Else Set ws = GetOrCreateSheet(SH_ACCOUNTS, False)
    If Not HasText(ws.Cells(1, 1).Value2) Then
        SetRowValues ws.Cells(1, 1), Array("����ID", "��s��", "�x�X��", "����", "����", "�Ȗ�", "�����ԍ�", "�J�ݓ�", "����", "����")
        ws.Columns("A:G").NumberFormat = "@"
        ws.Columns("H:I").NumberFormat = "yyyy/m/d"
        ws.Columns("J:J").NumberFormat = "@"
    End If
    If ws.Visible <> xlSheetVeryHidden Then ws.Visible = xlSheetVeryHidden
    If SheetExists(SH_BAL_DRAFT) Then Set ws = GetSheet(SH_BAL_DRAFT) Else Set ws = GetOrCreateSheet(SH_BAL_DRAFT, False)
    If Not HasText(ws.Cells(1, 1).Value2) Then
        SetRowValues ws.Cells(1, 1), Array("���", "���o��", "���͒l")
        ws.Columns(1).NumberFormat = "yyyy/m/d"
    End If
    If ws.Visible <> xlSheetVeryHidden Then ws.Visible = xlSheetVeryHidden
End Sub

Public Function AccountRow(ByVal accountID As String) As Long
    Dim hit As Variant
    If Len(accountID) = 0 Then Exit Function
    hit = Application.Match(accountID, GetSheet(SH_ACCOUNTS).Columns(1), 0)
    If Not IsError(hit) Then AccountRow = CLng(hit)
End Function

Public Function NextAccountID() As String
    Dim ws As Worksheet, r As Long, n As Long, v As Long
    Set ws = GetSheet(SH_ACCOUNTS)
    For r = 2 To LastRow(ws)
        v = CLng(Val(Mid$(CellText(ws.Cells(r, 1).Value2), 2)))
        If v > n Then n = v
    Next r
    NextAccountID = "A" & Format$(n + 1, "000000")
End Function

Public Function AccountIdentityKey(ByVal bank As String, ByVal branch As String, ByVal subject As String, ByVal number As String) As String
    AccountIdentityKey = Trim$(bank) & Chr$(30) & Trim$(branch) & Chr$(30) & Trim$(subject) & Chr$(30) & NormalizeAccountHyphen(number)
End Function

Public Function DuplicateAccountID(ByVal bank As String, ByVal branch As String, ByVal subject As String, ByVal number As String, ByVal excludeID As String) As String
    Dim data As Variant, r As Long, key As String
    key = AccountIdentityKey(bank, branch, subject, number)
    data = ReadStore(GetSheet(SH_ACCOUNTS), 10)
    For r = 2 To UBound(data, 1)
        If CStr(data(r, 1)) <> excludeID Then
            If AccountIdentityKey(CStr(data(r, 2)), CStr(data(r, 3)), CStr(data(r, 6)), CStr(data(r, 7))) = key Then
                DuplicateAccountID = CStr(data(r, 1)): Exit Function
            End If
        End If
    Next r
End Function

Public Function ReadStore(ByVal ws As Worksheet, ByVal columnsCount As Long) As Variant
    Dim n As Long
    n = LastRow(ws, 1)
    If n < 1 Then n = 1
    ReadStore = ws.Cells(1, 1).Resize(n, columnsCount).Value2
End Function

Public Sub WriteStore(ByVal ws As Worksheet, ByVal data As Variant)
    Dim oldRows As Long, newRows As Long, nCols As Long
    oldRows = LastRow(ws, 1): newRows = UBound(data, 1): nCols = UBound(data, 2)
    ws.Cells(1, 1).Resize(newRows, nCols).Value2 = data
    If oldRows > newRows Then ws.Cells(newRows + 1, 1).Resize(oldRows - newRows, nCols).ClearContents
End Sub

Public Function ReplaceAccountRows(ByVal oldData As Variant, ByVal newData As Variant, ByVal newCount As Long, ByVal idColumn As Long, ByVal accountID As String) As Variant
    Dim result As Variant, r As Long, c As Long, n As Long, dest As Long, inserted As Boolean
    n = 1 + newCount
    For r = 2 To UBound(oldData, 1)
        If CStr(oldData(r, idColumn)) <> accountID Then n = n + 1
    Next r
    ReDim result(1 To n, 1 To UBound(oldData, 2))
    For c = 1 To UBound(oldData, 2): result(1, c) = oldData(1, c): Next c
    dest = 1
    For r = 2 To UBound(oldData, 1)
        If CStr(oldData(r, idColumn)) = accountID Then
            If Not inserted Then CopyReplacementRows result, dest, newData, newCount: inserted = True
        Else
            dest = dest + 1
            For c = 1 To UBound(oldData, 2): result(dest, c) = oldData(r, c): Next c
        End If
    Next r
    If Not inserted Then CopyReplacementRows result, dest, newData, newCount
    ReplaceAccountRows = result
End Function

Private Sub CopyReplacementRows(ByRef result As Variant, ByRef dest As Long, ByVal rows As Variant, ByVal count As Long)
    Dim r As Long, c As Long
    For r = 1 To count
        dest = dest + 1
        For c = 1 To UBound(result, 2): result(dest, c) = rows(r, c): Next c
    Next r
End Sub

Public Sub ShowRegisteredAccounts()
    Dim ws As Worksheet, data As Variant, r As Long, c As Long, out As Variant
    On Error GoTo EH
    EnsureAccountStore
    AppBegin "�o�^������\�����Ă��܂�..."
    Set ws = GetOrCreateSheet(SH_ACCOUNT_LIST, False)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Cells.Clear
    DeleteToolShapes ws, False
    data = ReadStore(GetSheet(SH_ACCOUNTS), 10)
    ws.Range("A1").Value2 = "�o�^����"
    ws.Range("A2").Value2 = "�s���_�u���N���b�N����ƁA���ׁE�c��������ł��܂��B"
    SetRowValues ws.Range("A4"), Array("��s��", "�x�X��", "����", "����", "�Ȗ�", "�����ԍ�", "�J�ݓ�", "����", "����", "����ID")
    ws.Columns("A:F").NumberFormat = "@": ws.Columns("I:J").NumberFormat = "@"
    ws.Columns("G:H").NumberFormat = "yyyy/m/d"
    If UBound(data, 1) >= 2 Then
        ReDim out(1 To UBound(data, 1) - 1, 1 To 10)
        For r = 2 To UBound(data, 1)
            For c = 2 To 10: out(r - 1, c - 1) = data(r, c): Next c
            out(r - 1, 10) = data(r, 1)
        Next r
        ws.Range("A5").Resize(UBound(out, 1), 10).Value2 = out
    End If
    ws.Cells.Font.Name = "Yu Gothic UI": ws.Cells.Font.Size = 11
    ws.Cells.Font.Color = RGB(30, 41, 59): ws.Cells.Interior.Color = vbWhite
    ws.Range("A1").Font.Size = 17: ws.Range("A1").Font.Bold = True
    ws.Rows(1).RowHeight = 32: ws.Rows(2).RowHeight = 24
    ws.Columns("A:C").ColumnWidth = 19: ws.Columns("D:E").ColumnWidth = 12
    ws.Columns("F:H").ColumnWidth = 17: ws.Columns("I:I").ColumnWidth = 24
    ws.Columns("J:J").Hidden = True
    ws.Rows("4:" & CStr(UBound(data, 1) + 3)).RowHeight = 26
    FormatOutputHeader ws.Range("A4:I4")
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    ws.Range("A4:I" & CStr(UBound(data, 1) + 3)).AutoFilter
    AddUIButton ws, ws.Range("D1").Left, ws.Range("D1").Top, 124, 26, "�I�����������", "LoadSelectedAccountForEdit", "tool"
    AddUIButton ws, ws.Range("D1").Left + 132, ws.Range("D1").Top, 124, 26, "���ׂ�ǉ�����", "LoadSelectedAccountForAppend", "tool"
    AddUIButton ws, ws.Range("D1").Left + 264, ws.Range("D1").Top, 124, 26, "�I���������폜", "DeleteSelectedAccount", "danger"
    AddUIButton ws, ws.Range("D1").Left + 396, ws.Range("D1").Top, 124, 26, "���֖͂߂�", "ShowInputSheet", "tool"
    ws.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True, DrawingObjects:=True, AllowFiltering:=True
    ws.EnableSelection = xlNoRestrictions
    ws.Visible = xlSheetVisible: ws.Activate
    ws.Range("A5").Select
    AppEnd
    Exit Sub
EH:
    Dim originalErrorText As String
    originalErrorText = Err.Description
    AppEnd
    MsgBox "�o�^������\���ł��܂���ł����B" & vbCrLf & originalErrorText, vbExclamation
End Sub

Public Sub LoadSelectedAccountForEdit()
    LoadSelectedAccount False
End Sub

Public Sub LoadSelectedAccountForAppend()
    LoadSelectedAccount True
End Sub

Private Sub LoadSelectedAccount(ByVal appendMode As Boolean)
    Dim accountID As String
    If ActiveSheet.Name <> SH_ACCOUNT_LIST Then Exit Sub
    If ActiveCell.Row < 5 Then Exit Sub
    accountID = CellText(ActiveSheet.Cells(ActiveCell.Row, 10).Value2)
    If Len(accountID) = 0 Then Exit Sub
    If InputIsDirty Then
        If MsgBox("���͒��̖����f�̓��e��j�����A�I�������������J���܂����H", vbYesNo + vbExclamation + vbDefaultButton2) <> vbYes Then Exit Sub
    End If
    LoadAccountForEdit accountID, appendMode
End Sub

Public Sub LoadAccountForEdit(ByVal accountID As String, Optional ByVal appendMode As Boolean = False)
    Dim data As Variant, balances As Variant, info As Variant, inputData() As Variant
    Dim r As Long, n As Long, c As Long, ar As Long, d As Date, ws As Worksheet
    Dim state As Collection, nextRow As Long, parsedTime As Variant, timeOK As Boolean
    Dim changing As Boolean, message As String, restoreFailed As Boolean
    On Error GoTo EH
    ar = AccountRow(accountID)
    If ar < 2 Then Err.Raise vbObjectError + 2101, , "�������������������܂���B"
    data = ReadStore(GetSheet(SH_WORK_TX), 16)
    balances = ReadStore(GetSheet(SH_WORK_BAL), 13)
    For r = 2 To UBound(data, 1)
        If CStr(data(r, TX_ID_COL)) = accountID And CStr(data(r, TX_KIND_COL)) = "���" Then n = n + 1
    Next r
    ReDim inputData(1 To Application.Max(1, n), 1 To 10)
    n = 0
    For r = 2 To UBound(data, 1)
        If CStr(data(r, TX_ID_COL)) = accountID And CStr(data(r, TX_KIND_COL)) = "���" Then
            n = n + 1: d = CDate(data(r, OUT_COL_DATE))
            inputData(n, 1) = Year(d): inputData(n, 2) = Month(d): inputData(n, 3) = Day(d)
            parsedTime = NormalizeTimeInput(data(r, OUT_COL_TIME), timeOK)
            If timeOK Then
                If HasText(parsedTime) Then inputData(n, 4) = Format$(CDate(parsedTime), "hh:mm")
            Else
                inputData(n, 4) = CellText(data(r, OUT_COL_TIME))
            End If
            For c = 8 To 13: inputData(n, c - 3) = data(r, c): Next c
        End If
    Next r
    info = GetSheet(SH_ACCOUNTS).Cells(ar, 1).Resize(1, 10).Value2
    '�ǂݍ��߂Ȃ����t������΁A���͗�������������O�ɒm�点��B
    ValidateAccountBalanceLoad balances, accountID
    AppBegin "������ǂݍ���ł��܂�..."
    Set ws = GetSheet(SH_INPUT)
    Set state = CaptureInputState()
    changing = True
    EnsureTransactionCapacity n + 1
    ws.Unprotect Password:=TOOL_PASSWORD
    InputTransactionRange().ClearContents
    FitEmptyTransactionCapacity n + 1
    ws.Range(CELL_BANK).Value2 = info(1, 2): ws.Range(CELL_BRANCH).Value2 = info(1, 3)
    ws.Range(CELL_PERSON).Value2 = info(1, 4): ws.Range(CELL_RELATIONSHIP).Value2 = info(1, 5)
    ws.Range(CELL_ACCOUNT_TYPE).Value2 = info(1, 6): ws.Range(CELL_ACCOUNT_NO).Value2 = info(1, 7)
    ws.Range(CELL_OPEN_DATE).Value2 = info(1, 8): ws.Range(CELL_CLOSE_DATE).Value2 = info(1, 9)
    ws.Cells(TX_FIRST_ROW, COL_TX_YEAR).Resize(UBound(inputData, 1), 10).Value2 = inputData
    ws.Range(CELL_EDIT_ID).Value2 = accountID
    ws.Range(CELL_DIRTY).Value2 = "0"
    ws.Range(CELL_YEAR_SNAPSHOT).ClearContents: ws.Range(CELL_YEAR_ADD).ClearContents
    ws.Range("X8:X10").ClearContents
    LoadBalanceDraft balances, accountID, CStr(info(1, 10))
    ApplyInputSettings False
    BuildOperationPanel ws
    ResetInputNavigation
    ShowInputSheet
    If appendMode Then
        nextRow = TX_FIRST_ROW + n
        If nextRow > InputLastTransactionRow() Then nextRow = InputLastTransactionRow()
        SetInputSections False, False
        ws.Cells(nextRow, IIf(n > 0, COL_TX_DAY, COL_TX_YEAR)).Select
        SetInputStatus "�����ɒǉ����͂ł��܂��B�N�E���͒��O�s����⊮���܂��B������Ɂu�����𔽉f�v�������Ă��������B"
    Else
        SetInputSections True, False
        SafeSelectCell ws, CELL_ACCOUNT_NO
        SetInputStatus "�������@���ׂ̒ǉ��E�폜�A�������E�c���̒������ł��܂��B"
    End If
    changing = False
    AppEnd
    Exit Sub
EH:
    message = Err.Description
    If changing Then
        On Error Resume Next
        Err.Clear
        RestoreInputState state
        If Err.Number <> 0 Then restoreFailed = True
        On Error GoTo 0
    End If
    AppEnd
    If restoreFailed Then message = message & vbCrLf & "���͉�ʂ̕������������ł��B�o�^�ς݃f�[�^�͕ύX���Ă��܂���B�o�^��������J�������Ă��������B"
    MsgBox "������ǂݍ��߂܂���ł����B" & vbCrLf & message, vbExclamation
End Sub

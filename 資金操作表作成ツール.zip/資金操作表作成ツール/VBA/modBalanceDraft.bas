Attribute VB_Name = "modBalanceDraft"
Option Explicit

Public Const BAL_TOTAL_LIMIT As Long = 20
Public Const CELL_BAL_RENDER As String = "X11"

Public Sub FlushBalancePage()
    Dim ws As Worksheet, draft As Worksheet, c As Long, r As Long, hit As Variant
    Set ws = GetSheet(SH_INPUT): Set draft = GetSheet(SH_BAL_DRAFT)
    '�ĕ\�������f�������͓ǂݖ߂��Ȃ��B�֑ؑO�ɕۑ������������𐳂Ƃ���B
    If CellText(ws.Range(CELL_BAL_RENDER).Value2) = "1" Then Exit Sub
    For c = BAL_FIRST_COL To BalanceMemoCol(ws) - 1
        If IsDate(ws.Cells(BAL_DATE_ROW, c).Value) Then
            hit = Application.Match(CDbl(CDate(ws.Cells(BAL_DATE_ROW, c).Value)), draft.Columns(1), 0)
            If Not IsError(hit) Then
                r = CLng(hit)
                If CellText(ws.Cells(BAL_VALUE_ROW, c).Value2) <> "-" Then draft.Cells(r, 3).Value2 = ws.Cells(BAL_VALUE_ROW, c).Value2
            End If
        End If
    Next c
    ws.Range(CELL_BAL_MEMO).Value2 = ws.Cells(BAL_VALUE_ROW, BalanceMemoCol(ws)).Value2
End Sub

Public Sub RebuildBalanceDraft()
    Dim labels As Collection, dates As Collection, old As Variant, map As Object
    Dim r As Long, key As Variant, arr() As Variant, keys As Variant, i As Long, j As Long, tmp As Variant
    EnsureAccountStore
    FlushBalancePage
    old = ReadStore(GetSheet(SH_BAL_DRAFT), 3)
    BuildBalanceCollections labels, dates
    Set map = CreateObject("Scripting.Dictionary")
    For i = 1 To dates.Count: map(CStr(CLng(CDate(dates(i))))) = Array(dates(i), labels(i), Empty): Next i
    For r = 2 To UBound(old, 1)
        key = CStr(CLng(old(r, 1)))
        If map.Exists(key) Then
            tmp = map(key): tmp(2) = old(r, 3): map(key) = tmp
        ElseIf HasText(old(r, 3)) Then
            map(key) = Array(old(r, 1), Format$(CDate(old(r, 1)), "yyyy/m/d") & "���_�c��", old(r, 3))
        End If
    Next r
    keys = map.Keys
    For i = 0 To map.Count - 2
        For j = i + 1 To map.Count - 1
            If CLng(keys(i)) > CLng(keys(j)) Then tmp = keys(i): keys(i) = keys(j): keys(j) = tmp
        Next j
    Next i
    ReDim arr(1 To map.Count + 1, 1 To 3)
    arr(1, 1) = "���": arr(1, 2) = "���o��": arr(1, 3) = "���͒l"
    For i = 0 To map.Count - 1
        tmp = map(keys(i))
        For j = 0 To 2: arr(i + 2, j + 1) = tmp(j): Next j
    Next i
    WriteStore GetSheet(SH_BAL_DRAFT), arr
    GetSheet(SH_INPUT).Range(CELL_BAL_PAGE).Value2 = 1
    RenderBalancePage
End Sub

Public Sub RenderBalancePage()
    Dim ws As Worksheet, draft As Worksheet, p As Long, count As Long, startRow As Long
    Dim i As Long, c As Long, memoCol As Long, pages As Long, shp As Shape
    Dim errorText As String
    On Error GoTo EH
    Set ws = GetSheet(SH_INPUT): Set draft = GetSheet(SH_BAL_DRAFT)
    count = LastRow(draft) - 1
    pages = (count + BAL_MAX_LABELS - 1) \ BAL_MAX_LABELS
    If pages < 1 Then pages = 1
    p = CLng(Val(CellText(ws.Range(CELL_BAL_PAGE).Value2)))
    If p < 1 Or p > pages Then p = 1
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(CELL_BAL_PAGE).Value2 = p
    ws.Range(CELL_BAL_RENDER).Value2 = "1"
    ResetBalanceInputArea ws
    startRow = 2 + (p - 1) * BAL_MAX_LABELS
    For i = 0 To BAL_MAX_LABELS - 1
        If startRow + i > LastRow(draft) Then Exit For
        c = BAL_FIRST_COL + i
        ws.Cells(BAL_LABEL_ROW, c).Value2 = BalanceInputLabelDisplay(CStr(draft.Cells(startRow + i, 2).Value2))
        ws.Cells(BAL_DATE_ROW, c).Value2 = draft.Cells(startRow + i, 1).Value2
        ws.Cells(BAL_VALUE_ROW, c).Value2 = draft.Cells(startRow + i, 3).Value2
    Next i
    memoCol = BAL_FIRST_COL + i
    If memoCol > BAL_MAX_COL Then memoCol = BAL_MAX_COL
    MergeAndFormat ws.Range(ws.Cells(BAL_LABEL_ROW, memoCol), ws.Cells(BAL_LABEL_ROW, BAL_MAX_COL)), "���̑�"
    MergeAndFormat ws.Range(ws.Cells(BAL_VALUE_ROW, memoCol), ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL)), CellText(ws.Range(CELL_BAL_MEMO).Value2)
    FormatBalanceInputArea ws, memoCol
    If memoCol > BAL_FIRST_COL Then ApplyValidationInputOnly ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, memoCol - 1)), xlIMEModeOff
    ApplyValidationInputOnly ws.Cells(BAL_VALUE_ROW, memoCol), xlIMEModeHiragana
    ws.Range(ws.Cells(BAL_VALUE_ROW, memoCol), ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL)).Locked = False
    ApplyBalanceAvailability ws
    On Error Resume Next
    ws.Shapes(UI_PREFIX & "balance_page").Delete
    On Error GoTo EH
    Set shp = ws.Shapes.AddShape(msoShapeRectangle, ws.Range("I8").Left, ws.Range("I8").Top, ws.Range("I8:K8").Width, ws.Rows(8).Height)
    With shp
        .Name = UI_PREFIX & "balance_page"
        .TextFrame.Characters.Text = p & " / " & pages & IIf(pages > 1, "�@����", "")
        .TextFrame.Characters.Font.Name = "Yu Gothic UI": .TextFrame.Characters.Font.Size = 10
        .TextFrame.Characters.Font.Color = RGB(30, 64, 175): .TextFrame.Characters.Font.Bold = True
        .TextFrame.VerticalAlignment = xlVAlignCenter
        .Fill.ForeColor.RGB = RGB(239, 246, 255): .Line.Visible = msoFalse
        .Locked = True: .Placement = xlMoveAndSize
        .OnAction = MacroRef("NextBalancePage"): .AlternativeText = "NextBalancePage"
        .DrawingObject.PrintObject = False
    End With
    ApplyInputSections ws
    ws.Range(CELL_BAL_RENDER).Value2 = "0"
    Exit Sub
EH:
    errorText = Err.Description
    On Error Resume Next
    ws.Range(ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL), ws.Cells(BAL_VALUE_ROW, BAL_MAX_COL)).Locked = True
    ProtectInputSheet
    On Error GoTo 0
    Err.Raise vbObjectError + 2206, "RenderBalancePage", errorText
End Sub

Public Sub NextBalancePage()
    Dim ws As Worksheet, oldPage As Variant, errorText As String, started As Boolean
    On Error GoTo EH
    Set ws = GetSheet(SH_INPUT)
    oldPage = ws.Range(CELL_BAL_PAGE).Value2
    AppBegin "�c�����͂�؂�ւ��Ă��܂�..."
    started = True
    If CellText(ws.Range(CELL_BAL_RENDER).Value2) <> "1" Then
        FlushBalancePage
        ws.Range(CELL_BAL_PAGE).Value2 = CLng(Val(CellText(oldPage))) + 1
    End If
    RenderBalancePage
    SetInputSections Not ws.Rows(5).Hidden, True
    AppEnd
    Exit Sub
EH:
    errorText = Err.Description
    On Error Resume Next
    If started Then
        Err.Clear
        ws.Range(CELL_BAL_PAGE).Value2 = oldPage
        RenderBalancePage
        If Err.Number <> 0 Then errorText = errorText & vbCrLf & "�c���͉������ɕێ����Ă��܂��B�ۑ����ĊJ�������ƍĕ\�����܂��B"
    End If
    AppEnd
    On Error GoTo 0
    MsgBox "�c���̐ؑւ������ł��܂���ł����B" & vbCrLf & errorText, vbExclamation
End Sub

Public Sub ValidateAccountBalanceLoad(ByVal data As Variant, ByVal accountID As String)
    Dim labels As Collection, dates As Collection, r As Long, d As Date
    BuildBalanceCollections labels, dates
    For r = 2 To UBound(data, 1)
        If CStr(data(r, BAL_ID_COL)) = accountID Then
            If Not IsNumeric(data(r, 8)) Then Err.Raise vbObjectError + 2202, , "�o�^�ςݎc���̊�����m�F���Ă��������B"
            d = CDate(data(r, 8))
        End If
    Next r
End Sub

Public Sub LoadBalanceDraft(ByVal data As Variant, ByVal accountID As String, ByVal memo As String)
    Dim ws As Worksheet, r As Long, n As Long, a() As Variant
    For r = 2 To UBound(data, 1)
        If CStr(data(r, BAL_ID_COL)) = accountID Then n = n + 1
    Next r
    ReDim a(1 To n + 1, 1 To 3)
    a(1, 1) = "���": a(1, 2) = "���o��": a(1, 3) = "���͒l": n = 1
    For r = 2 To UBound(data, 1)
        If CStr(data(r, BAL_ID_COL)) = accountID Then
            n = n + 1: a(n, 1) = data(r, 8): a(n, 2) = data(r, 9): a(n, 3) = data(r, 10)
        End If
    Next r
    Set ws = GetSheet(SH_INPUT)
    ResetBalanceInputArea ws
    ws.Range(CELL_BAL_MEMO).Value2 = memo
    WriteStore GetSheet(SH_BAL_DRAFT), a
    '���݃y�[�W�̓ǂݖ߂����������㏑�����Ȃ��悤�ɂ���B
    ws.Cells(BAL_LABEL_ROW, BAL_FIRST_COL).Value2 = "���̑�"
    ws.Cells(BAL_VALUE_ROW, BAL_FIRST_COL).Value2 = memo
    RebuildBalanceDraft
End Sub

Public Sub ClearBalanceDraft()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_BAL_DRAFT)
    If LastRow(ws) >= 2 Then ws.Range("C2:C" & LastRow(ws)).ClearContents
    GetSheet(SH_INPUT).Range(CELL_BAL_MEMO).ClearContents
    GetSheet(SH_INPUT).Range(CELL_BAL_PAGE).Value2 = 1
    RenderBalancePage
End Sub

Public Sub FocusBalanceDate(ByVal balanceDate As Variant)
    Dim ws As Worksheet, draft As Worksheet, hit As Variant, r As Long, col As Long
    On Error GoTo EH
    Set ws = GetSheet(SH_INPUT): Set draft = GetSheet(SH_BAL_DRAFT)
    hit = Application.Match(CDbl(CDate(balanceDate)), draft.Columns(1), 0)
    If IsError(hit) Then Exit Sub
    AppBegin
    FlushBalancePage
    r = CLng(hit)
    ws.Range(CELL_BAL_PAGE).Value2 = 1 + (r - 2) \ BAL_MAX_LABELS
    RenderBalancePage
    ws.Activate
    SetInputSections False, True
    col = BAL_FIRST_COL + (r - 2) Mod BAL_MAX_LABELS
    ws.Cells(BAL_VALUE_ROW, col).Select
    AppEnd
    Exit Sub
EH:
    Dim message As String
    message = Err.Description
    AppEnd
    Err.Raise vbObjectError + 2702, "FocusBalanceDate", message
End Sub

Attribute VB_Name = "modInputLayout"
Option Explicit

Private Const CELL_ACCOUNT_FOLDED As String = "X12"
Private Const CELL_BALANCE_FOLDED As String = "X13"

Public Sub SetInputSections(ByVal showAccount As Boolean, ByVal showBalances As Boolean)
    Dim ws As Worksheet, changed As Boolean
    On Error GoTo EH
    Set ws = GetSheet(SH_INPUT)
    changed = (ws.Rows(5).Hidden = showAccount Or ws.Rows(9).Hidden = showBalances)
    If Not changed Then Exit Sub
    AppBegin
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Range(CELL_ACCOUNT_FOLDED).Value2 = IIf(showAccount, "0", "1")
    ws.Range(CELL_BALANCE_FOLDED).Value2 = IIf(showBalances, "0", "1")
    ApplyInputSections ws
    AppEnd
    Exit Sub
EH:
    Dim message As String
    message = Err.Description
    AppEnd
    Err.Raise vbObjectError + 2701, "SetInputSections", message
End Sub

Public Sub ApplyInputSections(ByVal ws As Worksheet)
    ws.Unprotect Password:=TOOL_PASSWORD
    ws.Rows("5:6").Hidden = (CellText(ws.Range(CELL_ACCOUNT_FOLDED).Value2) = "1")
    ws.Rows("9:11").Hidden = (CellText(ws.Range(CELL_BALANCE_FOLDED).Value2) = "1")
    RefreshInputHeadings ws
    ProtectInputSheet
    SafeFreezeInput
End Sub

Public Sub ToggleAccountDetails()
    On Error GoTo EH
    AppBegin
    SetInputSections GetSheet(SH_INPUT).Rows(5).Hidden, Not GetSheet(SH_INPUT).Rows(9).Hidden
    AppEnd
    Exit Sub
EH:
    AppEnd
    MsgBox Err.Description, vbExclamation
End Sub

Public Sub ToggleBalanceDetails()
    On Error GoTo EH
    AppBegin
    SetInputSections Not GetSheet(SH_INPUT).Rows(5).Hidden, GetSheet(SH_INPUT).Rows(9).Hidden
    AppEnd
    Exit Sub
EH:
    AppEnd
    MsgBox Err.Description, vbExclamation
End Sub

Public Sub PrepareInputSelection(ByVal targetCell As Range)
    Dim r As Long, ws As Worksheet
    Set ws = targetCell.Worksheet
    If ws.Name <> SH_INPUT Then Exit Sub
    r = targetCell.Row
    If r >= TX_FIRST_ROW And r <= TX_LAST_ROW Then
        SetInputSections False, False
    ElseIf r = 5 Or r = 6 Then
        SetInputSections True, Not ws.Rows(9).Hidden
    ElseIf r >= BAL_LABEL_ROW And r <= BAL_DATE_ROW Then
        SetInputSections Not ws.Rows(5).Hidden, True
    End If
End Sub

Public Sub RefreshInputHeadings(ByVal ws As Worksheet)
    Dim caption As String, detail As String
    caption = "�������"
    If ws.Rows(5).Hidden Then
        detail = CellText(ws.Range(CELL_PERSON).Value2) & "�@" & CellText(ws.Range(CELL_BANK).Value2) & "�@" & CellText(ws.Range(CELL_ACCOUNT_NO).Value2)
        caption = caption & "�@" & Left$(Trim$(detail), 55) & "�@�{"
    Else
        caption = caption & "�@�|"
    End If
    SetInputHeading ws, "account_toggle", "B4:K4", caption, "ToggleAccountDetails"
    caption = "�c������" & IIf(ws.Rows(9).Hidden, "�@�{", "�@�|")
    SetInputHeading ws, "balance_toggle", "B8:H8", caption, "ToggleBalanceDetails"
    UpdateInputStateLabel
End Sub

Private Sub SetInputHeading(ByVal ws As Worksheet, ByVal key As String, ByVal addressText As String, ByVal caption As String, ByVal action As String)
    Dim shp As Shape, box As Range
    Set box = ws.Range(addressText)
    On Error Resume Next
    Set shp = ws.Shapes(UI_PREFIX & key)
    On Error GoTo 0
    If shp Is Nothing Then Set shp = ws.Shapes.AddShape(msoShapeRectangle, box.Left, box.Top, box.Width, box.Height)
    With shp
        .Name = UI_PREFIX & key
        .Left = box.Left: .Top = box.Top: .Width = box.Width: .Height = box.Height
        .TextFrame.Characters.Text = caption
        .TextFrame.Characters.Font.Name = "Yu Gothic UI": .TextFrame.Characters.Font.Size = 10
        .TextFrame.Characters.Font.Bold = True: .TextFrame.Characters.Font.Color = RGB(30, 64, 175)
        .TextFrame.VerticalAlignment = xlVAlignCenter
        .TextFrame.MarginTop = 0: .TextFrame.MarginBottom = 0
        .Fill.ForeColor.RGB = RGB(239, 246, 255): .Line.Visible = msoFalse
        .Locked = True: .Placement = xlMoveAndSize
        .OnAction = MacroRef(action): .AlternativeText = action
        .DrawingObject.PrintObject = False
    End With
End Sub

Public Sub UpdateInputStateLabel()
    Dim ws As Worksheet, caption As String
    Set ws = GetSheet(SH_INPUT)
    caption = IIf(Len(CurrentEditAccountID()) > 0, "������", "�V��������")
    If InputIsDirty Then
        caption = caption & "�@�E�@�����f"
    ElseIf Len(CurrentEditAccountID()) > 0 Then
        caption = caption & "�@�E�@���f�ς�"
    End If
    If CellText(ws.Range("B7").Value2) = caption Then Exit Sub
    ws.Range("B7").Value2 = caption
    With ws.Range("B7:K7")
        .Interior.Color = IIf(InputIsDirty, RGB(255, 247, 224), RGB(248, 250, 252))
        .Font.Color = IIf(InputIsDirty, RGB(120, 73, 0), RGB(51, 65, 85))
        .Font.Size = 10: .Font.Bold = True
    End With
End Sub

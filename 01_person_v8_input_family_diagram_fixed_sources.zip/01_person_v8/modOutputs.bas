Attribute VB_Name = "modOutputs"
Option Explicit

Public Sub BuildAllOutputs()
    On Error GoTo EH
    AppBegin
    RefreshRepresentativeAddresses
    GenerateEvents
    BuildConfirmList
    RunChecks
    BuildRelationshipDiagram
    BuildAddressHistoryTable
    BuildCohabitationTable
    BuildTimelineTable
    BuildPersonList
    ApplyOutputUsability
    ShowOutputSheetsCore True
CleanExit:
    AppEnd
    MsgBox "�l�����n�̒��[���ꊇ�쐬���܂����B�o�̓V�[�g��\�����܂����B���֖͂߂�ꍇ�͊e�V�[�g�̃{�^���������Ă��������B", vbInformation
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "BuildAllOutputs", "�ꊇ�쐬", "�l�����́E��ƃV�[�g�E�o�̓V�[�g�̏�Ԃ��m�F���Ă��������B"
End Sub

Public Sub BuildConfirmList()
    Dim ws As Worksheet, wp As Worksheet, r As Long, outR As Long, pid As String
    Set ws = ThisWorkbook.Worksheets(SH_CONFIRM)
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    ws.Range("A4:J1000").ClearContents
    outR = 4
    For r = 2 To LastRow(wp, 1)
        If Len(CStr(wp.Cells(r, P_ID).Value)) > 0 And CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            pid = CStr(wp.Cells(r, P_ID).Value)
            ws.Cells(outR, 1).Value = wp.Cells(r, P_ORDER).Value
            ws.Cells(outR, 2).Value = pid
            ws.Cells(outR, 3).Value = wp.Cells(r, P_TYPE).Value
            ws.Cells(outR, 4).Value = wp.Cells(r, P_REL_DEC).Value
            ws.Cells(outR, 5).Value = wp.Cells(r, P_DISPLAY).Value
            ws.Cells(outR, 6).Value = wp.Cells(r, P_FORMER).Value
            ws.Cells(outR, 7).Value = wp.Cells(r, P_BIRTH).Value
            ws.Cells(outR, 8).Value = wp.Cells(r, P_DEATH).Value
            ws.Cells(outR, 9).Value = GetCurrentAddressText(pid)
            ws.Cells(outR, 10).Value = wp.Cells(r, P_NOTE).Value
            outR = outR + 1
        End If
    Next r
    ws.Range("G4:H" & Application.Max(4, outR)).NumberFormatLocal = "yyyy/m/d"
    ThemeApplyCompleteBorders ws.Range("A3:J" & Application.Max(4, outR - 1)), "border"
    ws.Range("A4:J" & Application.Max(4, outR - 1)).WrapText = True
    ws.Columns("A:J").AutoFit
    CapColumnWidths ws, 1, 10, 38
End Sub

Public Sub RunChecks()
    Dim ws As Worksheet, wp As Worksheet, r As Long, outR As Long, decCount As Long
    Set ws = ThisWorkbook.Worksheets(SH_CHECK)
    ws.Range("A4:H1000").ClearContents
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    outR = 4
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wp.Cells(r, P_ID).Value)) > 0 Then
            If wp.Cells(r, P_TYPE).Value = MODE_DECEDENT Then decCount = decCount + 1
            If Len(CStr(wp.Cells(r, P_GIVEN).Value)) = 0 Then AddCheck ws, outR, "�G���[", "�����󗓂ł��B", wp.Cells(r, P_ID).Value, wp.Cells(r, P_DISPLAY).Value, "�l��", "�������"
            If Len(CStr(wp.Cells(r, P_REL_DEC).Value)) = 0 Then AddCheck ws, outR, "����", "�������󗓂ł��B", wp.Cells(r, P_ID).Value, wp.Cells(r, P_DISPLAY).Value, "�l��", "�������m�F"
            If Len(GetCurrentAddressText(CStr(wp.Cells(r, P_ID).Value))) = 0 Then AddCheck ws, outR, "����", "�Z�������������͂ł��B", wp.Cells(r, P_ID).Value, wp.Cells(r, P_DISPLAY).Value, "�Z��", "�Z����o�^"
        End If
    Next r
    CheckAddressHistoryIssues ws, outR
    If decCount = 0 Then AddCheck ws, outR, "�G���[", "�푊���l�����o�^�ł��B", "", "", "�푊���l", "�푊���l��o�^"
    If decCount > 1 Then AddCheck ws, outR, "�G���[", "�푊���l�������o�^����Ă��܂��B", "", "", "�푊���l", "1�l�ɐ���"
    ThemeApplyCompleteBorders ws.Range("A3:H" & Application.Max(4, outR - 1)), "border"
    ws.Columns("A:H").AutoFit
    CapColumnWidths ws, 1, 8, 42
End Sub

Private Sub CheckAddressHistoryIssues(ByVal ws As Worksheet, ByRef outR As Long)
    Dim wa As Worksheet, r As Long, pid As String
    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Sub
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    For r = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wa.Cells(r, A_ID).Value)) > 0 Then
            pid = CStr(wa.Cells(r, A_PERSON_ID).Value)
            If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then
                AddCheck ws, outR, "�G���[", "�Z�������̐l��ID���l���ꗗ�ɂ���܂���B", _
                    pid, "", "�Z��", "�l����I�ђ����ďZ����o�^"
            End If
            If IsDate(wa.Cells(r, A_START).Value) And IsDate(wa.Cells(r, A_END).Value) Then
                If CDate(wa.Cells(r, A_START).Value) > CDate(wa.Cells(r, A_END).Value) Then
                    AddCheck ws, outR, "�G���[", "�Z���̔c���J�n�����I��������ł��B", _
                        pid, GetPersonValue(pid, P_DISPLAY), "�Z������", "�c���J�n���E�I�������C��"
                End If
            End If
        End If
    Next r
End Sub

Private Sub AddCheck(ByVal ws As Worksheet, _
        ByRef outR As Long, _
        ByVal level As String, _
        ByVal msg As String, _
        ByVal pid As String, _
        ByVal nameText As String, _
        ByVal target As String, _
        ByVal actionText As String)
    ws.Cells(outR, 1).Value = level
    ws.Cells(outR, 2).Value = msg
    ws.Cells(outR, 3).Value = pid
    ws.Cells(outR, 4).Value = nameText
    ws.Cells(outR, 5).Value = target
    ws.Cells(outR, 6).Value = actionText
    ws.Cells(outR, 7).Value = Now
    outR = outR + 1
End Sub

Private Sub GenerateEvents()
    Dim we As Worksheet, wp As Worksheet, wr As Worksheet, wa As Worksheet, r As Long
    Dim decId As String, inhDate As Variant, pid As String, otherId As String
    Dim manualEvents As Collection
    Set we = ThisWorkbook.Worksheets(SH_W_EVENT)
    Set manualEvents = PreserveManualTimelineEvents(we)
    we.Range("A2:L" & CStr(Application.Max(2, LastRow(we, 1)))).ClearContents
    RestoreManualTimelineEvents we, manualEvents

    SanitizeRelationDatesForTimeline

    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wp.Cells(r, P_ID).Value)) > 0 Then
            pid = CStr(wp.Cells(r, P_ID).Value)
            If IsDate(wp.Cells(r, P_BIRTH).Value) Then AddEvent pid, wp.Cells(r, P_BIRTH).Value, "�o��", "�o��", "����", "�l��", pid
            If IsDate(wp.Cells(r, P_DEATH).Value) Then AddEvent pid, wp.Cells(r, P_DEATH).Value, "���S", "���S", "����", "�l��", pid
        End If
    Next r

    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" Then
            pid = CStr(wr.Cells(r, R_BASE_ID).Value)
            otherId = CStr(wr.Cells(r, R_OTHER_ID).Value)
            If Len(pid) > 0 And Len(otherId) > 0 And pid <> otherId _
                    And FindPersonRow(pid) > 0 And FindPersonRow(otherId) > 0 Then
                If IsDate(wr.Cells(r, R_MARRIAGE).Value) Then
                    AddEvent pid, wr.Cells(r, R_MARRIAGE).Value, "����", "����", "����", "�֌W", wr.Cells(r, R_ID).Value
                    AddEvent otherId, wr.Cells(r, R_MARRIAGE).Value, "����", "����", "����", "�֌W", wr.Cells(r, R_ID).Value
                End If
                If IsDate(wr.Cells(r, R_DIVORCE).Value) Then
                    AddEvent pid, wr.Cells(r, R_DIVORCE).Value, "����", "�����F" & GetPersonValue(otherId, P_DISPLAY), "����", "�֌W", wr.Cells(r, R_ID).Value
                    AddEvent otherId, wr.Cells(r, R_DIVORCE).Value, "����", "�����F" & GetPersonValue(pid, P_DISPLAY), "����", "�֌W", wr.Cells(r, R_ID).Value
                End If
            End If
        End If
    Next r

    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    For r = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
            pid = CStr(wa.Cells(r, A_PERSON_ID).Value)
            If Len(pid) > 0 And FindPersonRow(pid) > 0 Then
                If IsDate(wa.Cells(r, A_START).Value) Then
                    AddEvent pid, wa.Cells(r, A_START).Value, _
                        "�Z���c��", "�Z���c���F" & wa.Cells(r, A_TEXT).Value, "����", "�Z��", wa.Cells(r, A_ID).Value
                End If
                If IsDate(wa.Cells(r, A_END).Value) Then
                    If Not IsPersonDeathDate(pid, wa.Cells(r, A_END).Value) Then
                        AddEvent pid, wa.Cells(r, A_END).Value, _
                            "�Z���I��", "�Z���I���F" & wa.Cells(r, A_TEXT).Value, "����", "�Z��", wa.Cells(r, A_ID).Value
                    End If
                End If
            End If
        End If
    Next r
    decId = GetDecedentId()
    inhDate = GetInheritanceDate()
    If Len(decId) > 0 And IsDate(inhDate) Then AddEvent decId, inhDate, "�����J�n", "�����J�n", "����", "�ݒ�", "�����J�n��"
End Sub

Private Function PreserveManualTimelineEvents(ByVal ws As Worksheet) As Collection
    Dim col As New Collection, r As Long, c As Long
    Dim arr As Variant
    If ws Is Nothing Then
        Set PreserveManualTimelineEvents = col
        Exit Function
    End If
    For r = 2 To LastRow(ws, 1)
        If Len(CStr(ws.Cells(r, E_ID).Value)) > 0 _
                And CStr(ws.Cells(r, E_STATUS).Value) <> STATUS_CANCEL _
                And CStr(ws.Cells(r, E_AUTO).Value) <> "����" Then
            ReDim arr(1 To 12)
            For c = 1 To 12
                arr(c) = ws.Cells(r, c).Value
            Next c
            col.Add arr
        End If
    Next r
    Set PreserveManualTimelineEvents = col
End Function

Private Sub RestoreManualTimelineEvents(ByVal ws As Worksheet, ByVal events As Collection)
    Dim item As Variant, r As Long, c As Long
    If ws Is Nothing Then Exit Sub
    If events Is Nothing Then Exit Sub
    For Each item In events
        r = NextBlankRow(ws, 1)
        For c = 1 To 12
            ws.Cells(r, c).Value = item(c)
        Next c
    Next item
End Sub

Private Sub SanitizeRelationDatesForTimeline()
    Dim wr As Worksheet, r As Long
    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If CStr(wr.Cells(r, R_TYPE).Value) <> "�z���" Then
                wr.Cells(r, R_MARRIAGE).ClearContents
                wr.Cells(r, R_DIVORCE).ClearContents
            End If
        End If
    Next r
End Sub

Private Function IsPersonDeathDate(ByVal personId As String, ByVal v As Variant) As Boolean
    Dim d As Variant
    If Len(personId) = 0 Or Not IsDate(v) Then Exit Function
    d = GetPersonValue(personId, P_DEATH)
    If IsDate(d) Then IsPersonDeathDate = (CLng(CDate(d)) = CLng(CDate(v)))
End Function

Private Sub AddEvent(ByVal personId As String, _
        ByVal eventDate As Variant, _
        ByVal eventType As String, _
        ByVal content As String, _
        ByVal autoFlag As String, _
        ByVal srcType As String, _
        ByVal srcId As String)
    Dim ws As Worksheet, r As Long
    If Len(CStr(personId)) = 0 Or Not IsDate(eventDate) Then Exit Sub
    If FindPersonRow(CStr(personId)) = 0 Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_EVENT)
    If TimelineEventExists(ws, CStr(personId), eventDate, eventType, content, srcType, srcId) Then Exit Sub
    r = NextBlankRow(ws, 1)
    ws.Cells(r, E_ID).Value = NextId("�C�x���g")
    ws.Cells(r, E_PERSON_ID).Value = personId
    ws.Cells(r, E_DATE).Value = eventDate
    ws.Cells(r, E_YEAR).Value = Year(CDate(eventDate))
    ws.Cells(r, E_TYPE).Value = eventType
    ws.Cells(r, E_CONTENT).Value = content
    ws.Cells(r, E_AUTO).Value = autoFlag
    ws.Cells(r, E_SOURCE_TYPE).Value = srcType
    ws.Cells(r, E_SOURCE_ID).Value = srcId
    ws.Cells(r, E_SHOW).Value = SHOW_YES
    ws.Cells(r, E_STATUS).Value = STATUS_ACTIVE
End Sub

Private Function TimelineEventExists(ByVal ws As Worksheet, _
        ByVal personId As String, _
        ByVal eventDate As Variant, _
        ByVal eventType As String, _
        ByVal content As String, _
        ByVal srcType As String, _
        ByVal srcId As String) As Boolean
    Dim r As Long
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, E_PERSON_ID).Value) = personId _
                And IsDate(ws.Cells(r, E_DATE).Value) _
                And CLng(CDate(ws.Cells(r, E_DATE).Value)) = CLng(CDate(eventDate)) _
                And CStr(ws.Cells(r, E_TYPE).Value) = eventType _
                And CStr(ws.Cells(r, E_CONTENT).Value) = content _
                And CStr(ws.Cells(r, E_SOURCE_TYPE).Value) = srcType _
                And CStr(ws.Cells(r, E_SOURCE_ID).Value) = CStr(srcId) _
                And CStr(ws.Cells(r, E_STATUS).Value) <> STATUS_CANCEL Then
            TimelineEventExists = True
            Exit Function
        End If
    Next r
End Function

Public Sub ShowAddressHistoryOutput()
    On Error GoTo EH
    AppBegin
    RefreshRepresentativeAddresses
    BuildAddressHistoryTable
    ApplyOutputUsability
    ShowOnlyInputCore False
    ThisWorkbook.Worksheets(SH_ADDR_TABLE).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_ADDR_TABLE).Activate
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowAddressHistoryOutput", "�Z������\��", "�Z�������V�[�g�E�Z�������f�[�^�̏�Ԃ��m�F���Ă��������B"
End Sub

Public Sub ShowRelationshipDiagramOutput()
    On Error GoTo EH
    AppBegin "�����֌W�}���쐬��..."
    RefreshRepresentativeAddresses
    BuildRelationshipDiagram
    ApplyOutputUsability
    ShowOnlyInputCore False
    ThisWorkbook.Worksheets(SH_DIAGRAM).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_DIAGRAM).Activate
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowRelationshipDiagramOutput", "�����֌W�}�쐬", _
        "�푊���l�A�֌W�ҁA�}�\���ݒ�A�o�̓V�[�g�̏�Ԃ��m�F���Ă��������B"
End Sub

Public Sub ShowTimelineOutput()
    On Error GoTo EH
    AppBegin "���n��\���쐬��..."
    RefreshRepresentativeAddresses
    GenerateEvents
    BuildTimelineTable
    ApplyOutputUsability
    ShowOnlyInputCore False
    ThisWorkbook.Worksheets(SH_TIMELINE).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(SH_TIMELINE).Activate
CleanExit:
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "ShowTimelineOutput", "���n��\�쐬", _
        "�l���A���N�����E���S���A�������A�Z���c���J�n���E�I�����̏�Ԃ��m�F���Ă��������B"
End Sub

Private Sub BuildRelationshipDiagram()
    Dim ws As Worksheet
    Dim decId As String, decRow As Long, spouseRow As Long, fatherRow As Long, motherRow As Long
    Dim decShape As Shape, spouseShape As Shape, fatherShape As Shape, motherShape As Shape
    Dim children As Collection, drawn As Object
    Dim cardW As Double, cardH As Double, pageCenter As Double, pageLeft As Double, pageRight As Double
    Dim parentY As Double, decY As Double, childTop As Double, coupleGap As Double, blockGap As Double
    Dim decX As Double, spouseX As Double, parentOriginX As Double, parentOriginY As Double
    Dim coupleOriginX As Double, coupleOriginY As Double, childConnectorY As Double
    Dim firstIndex As Long, rowCount As Long, i As Long, col As Long
    Dim totalW As Double, startX As Double, x As Double, rowBottom As Double, maxBottom As Double
    Dim childRow As Long, blockW As Double, childCenterX As Double, childBottom As Double, branchY As Double

    Set ws = ThisWorkbook.Worksheets(SH_DIAGRAM)
    ClearSheetAll ws
    ApplySheetCanvas ws
    Set drawn = CreateObject("Scripting.Dictionary")

    With ws.PageSetup
        .PaperSize = xlPaperA4
        .Orientation = xlLandscape
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = 1
        .LeftMargin = Application.CentimetersToPoints(0.45)
        .RightMargin = Application.CentimetersToPoints(0.45)
        .TopMargin = Application.CentimetersToPoints(0.45)
        .BottomMargin = Application.CentimetersToPoints(0.45)
        .PrintArea = ""
    End With

    ws.Columns("A:M").ColumnWidth = 8.4
    ws.Rows("1:120").RowHeight = 15.5
    ws.Range("A1:M1").Merge
    TitleBannerStyle ws.Range("A1:M1"), "�����֌W�}"
    AddButton ws, "L1:M1", "���֖͂߂�", "ShowOnlyInput", 0, 22

    cardW = 158
    cardH = 128
    coupleGap = 14
    blockGap = 18
    pageLeft = 24
    pageRight = 790
    pageCenter = (pageLeft + pageRight) / 2
    parentY = 52
    decY = 192
    childTop = 340

    decId = GetDecedentId()
    decRow = FindPersonRow(decId)
    If decRow = 0 Then
        ws.Range("A4:M8").Merge
        ws.Range("A4").Value = "�푊���l�����o�^�ł��B"
        ws.Range("A4").Interior.Color = ThemeColor("danger-soft")
        ws.Range("A4").Font.Color = ThemeColor("red")
        ws.Range("A4").Font.Bold = True
        ThemeApplyMonochromePrint ws, "$A$1:$M$10", False, "", 1, 1
        Exit Sub
    End If

    spouseRow = GetSpouseRowOfPerson(decId)
    If spouseRow > 0 Then
        decX = pageCenter - cardW - coupleGap / 2
        spouseX = pageCenter + coupleGap / 2
    Else
        decX = pageCenter - cardW / 2
        spouseX = 0
    End If

    fatherRow = GetFirstVisiblePersonRowByRelation("��")
    motherRow = GetFirstVisiblePersonRowByRelation("��")
    If fatherRow > 0 And motherRow > 0 Then
        Set fatherShape = DrawTreeCard(ws, fatherRow, ShapeCenterTargetX(decX, cardW) - cardW - coupleGap / 2, parentY, cardW, cardH, drawn)
        Set motherShape = DrawTreeCard(ws, motherRow, ShapeCenterTargetX(decX, cardW) + coupleGap / 2, parentY, cardW, cardH, drawn)
        ConnectHorizontalCouple ws, fatherShape, motherShape, parentOriginX, parentOriginY
        DrawVLine ws, parentOriginX, parentOriginY, decY
    ElseIf fatherRow > 0 Then
        Set fatherShape = DrawTreeCard(ws, fatherRow, ShapeCenterTargetX(decX, cardW) - cardW / 2, parentY, cardW, cardH, drawn)
        DrawVLine ws, ShapeCenterX(fatherShape), fatherShape.Top + fatherShape.Height, decY
    ElseIf motherRow > 0 Then
        Set motherShape = DrawTreeCard(ws, motherRow, ShapeCenterTargetX(decX, cardW) - cardW / 2, parentY, cardW, cardH, drawn)
        DrawVLine ws, ShapeCenterX(motherShape), motherShape.Top + motherShape.Height, decY
    End If

    Set decShape = DrawTreeCard(ws, decRow, decX, decY, cardW, cardH, drawn)
    If spouseRow > 0 Then
        Set spouseShape = DrawTreeCard(ws, spouseRow, spouseX, decY, cardW, cardH, drawn)
        ConnectHorizontalCouple ws, decShape, spouseShape, coupleOriginX, coupleOriginY
    Else
        coupleOriginX = ShapeCenterX(decShape)
        coupleOriginY = decShape.Top + decShape.Height
    End If
    maxBottom = decY + cardH

    Set children = GetDirectChildRows(decId)
    If children.Count > 0 Then
        firstIndex = 1
        Do While firstIndex <= children.Count
            rowCount = Application.Min(2, children.Count - firstIndex + 1)
            totalW = 0
            For col = 0 To rowCount - 1
                totalW = totalW + FamilyBlockWidth(CLng(children(firstIndex + col)), cardW, coupleGap)
                If col > 0 Then totalW = totalW + blockGap
            Next col
            startX = pageCenter - totalW / 2
            branchY = childTop - 26
            DrawVLine ws, coupleOriginX, coupleOriginY, branchY
            rowBottom = childTop
            x = startX
            For col = 0 To rowCount - 1
                childRow = CLng(children(firstIndex + col))
                blockW = FamilyBlockWidth(childRow, cardW, coupleGap)
                childCenterX = x + cardW / 2
                DrawHLine ws, Application.Min(coupleOriginX, childCenterX), branchY, Application.Max(coupleOriginX, childCenterX)
                DrawVLine ws, childCenterX, branchY, childTop
                childBottom = DrawHorizontalChildFamilyBlock(ws, childRow, x, childTop, cardW, cardH, coupleGap, blockGap, drawn)
                If childBottom > rowBottom Then rowBottom = childBottom
                x = x + blockW + blockGap
            Next col
            If rowBottom > maxBottom Then maxBottom = rowBottom
            firstIndex = firstIndex + rowCount
            childTop = rowBottom + 52
            coupleOriginY = branchY
        Loop
    End If

    maxBottom = DrawRemainingVisiblePersons(ws, drawn, pageLeft, maxBottom + 38, cardW, cardH, coupleGap, pageRight)
    PolishRelationshipDiagramOutput ws
    ThemeLockShapeLayer ws
End Sub

Private Function ShapeCenterTargetX(ByVal leftPt As Double, ByVal widthPt As Double) As Double
    ShapeCenterTargetX = leftPt + widthPt / 2
End Function

Private Function DrawTreeCard(ByVal ws As Worksheet, _
        ByVal personRow As Long, _
        ByVal leftPt As Double, _
        ByVal topPt As Double, _
        ByVal widthPt As Double, _
        ByVal heightPt As Double, _
        ByVal drawn As Object) As Shape
    Dim pid As String
    Set DrawTreeCard = DrawPersonCardShape(ws, personRow, leftPt, topPt, widthPt, heightPt)
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    If Len(pid) > 0 Then
        If Not drawn.Exists(pid) Then drawn.Add pid, True
    End If
End Function

Private Function IsDrawnPerson(ByVal drawn As Object, ByVal personRow As Long) As Boolean
    Dim pid As String
    pid = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_ID).Value)
    If Len(pid) = 0 Then Exit Function
    IsDrawnPerson = drawn.Exists(pid)
End Function

Private Function FamilyBlockWidth(ByVal childRow As Long, ByVal cardW As Double, ByVal coupleGap As Double) As Double
    Dim childId As String, spouseRow As Long
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    spouseRow = GetSpouseRowOfPerson(childId)
    If spouseRow > 0 Then
        FamilyBlockWidth = cardW * 2 + coupleGap
    Else
        FamilyBlockWidth = cardW
    End If
End Function

Private Function DrawHorizontalChildFamilyBlock(ByVal ws As Worksheet, _
        ByVal childRow As Long, _
        ByVal blockLeft As Double, _
        ByVal blockTop As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal blockGap As Double, _
        ByVal drawn As Object) As Double
    Dim childShape As Shape, spouseShape As Shape
    Dim childId As String, spouseRow As Long, originX As Double, originY As Double
    Dim gcRows As Collection, rowCount As Long, firstIndex As Long, col As Long
    Dim gW As Double, startX As Double, gX As Double, gTop As Double, branchY As Double, bottomY As Double
    Dim gcBlockW As Double, gcCenterX As Double, gcBottom As Double
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    Set childShape = DrawTreeCard(ws, childRow, blockLeft, blockTop, cardW, cardH, drawn)
    originX = ShapeCenterX(childShape)
    originY = blockTop + cardH
    bottomY = blockTop + cardH

    spouseRow = GetSpouseRowOfPerson(childId)
    If spouseRow > 0 And Not IsDrawnPerson(drawn, spouseRow) Then
        Set spouseShape = DrawTreeCard(ws, spouseRow, blockLeft + cardW + coupleGap, blockTop, cardW, cardH, drawn)
        ConnectHorizontalCouple ws, childShape, spouseShape, originX, originY
        bottomY = blockTop + cardH
    End If

    Set gcRows = GetGrandchildRowsForParent(childId)
    If gcRows.Count > 0 Then
        gTop = bottomY + 54
        firstIndex = 1
        Do While firstIndex <= gcRows.Count
            rowCount = Application.Min(2, gcRows.Count - firstIndex + 1)
            gW = 0
            For col = 0 To rowCount - 1
                If col > 0 Then gW = gW + blockGap
                gW = gW + FamilyBlockWidth(CLng(gcRows(firstIndex + col)), cardW, coupleGap)
            Next col
            startX = blockLeft + (FamilyBlockWidth(childRow, cardW, coupleGap) - gW) / 2
            branchY = gTop - 24
            DrawVLine ws, originX, originY, branchY
            gX = startX
            For col = 0 To rowCount - 1
                gcBlockW = FamilyBlockWidth(CLng(gcRows(firstIndex + col)), cardW, coupleGap)
                gcCenterX = gX + gcBlockW / 2
                DrawHLine ws, Application.Min(originX, gcCenterX), branchY, Application.Max(originX, gcCenterX)
                DrawVLine ws, gcCenterX, branchY, gTop
                gcBottom = DrawGrandchildFamilyBlock(ws, CLng(gcRows(firstIndex + col)), gX, gTop, cardW, cardH, coupleGap, drawn)
                If gcBottom > bottomY Then bottomY = gcBottom
                gX = gX + gcBlockW + blockGap
            Next col
            originY = branchY
            firstIndex = firstIndex + rowCount
            gTop = bottomY + 34
        Loop
    End If
    DrawHorizontalChildFamilyBlock = bottomY
End Function

Private Function DrawGrandchildFamilyBlock(ByVal ws As Worksheet, _
        ByVal gcRow As Long, _
        ByVal blockLeft As Double, _
        ByVal blockTop As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal coupleGap As Double, _
        ByVal drawn As Object) As Double
    Dim gcShape As Shape, spouseShape As Shape
    Dim gcId As String, spouseRow As Long, originX As Double, originY As Double
    gcId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(gcRow, P_ID).Value)
    If IsDrawnPerson(drawn, gcRow) Then
        DrawGrandchildFamilyBlock = blockTop + cardH
        Exit Function
    End If
    Set gcShape = DrawTreeCard(ws, gcRow, blockLeft, blockTop, cardW, cardH, drawn)
    originX = ShapeCenterX(gcShape)
    originY = blockTop + cardH
    spouseRow = GetSpouseRowOfPerson(gcId)
    If spouseRow > 0 And Not IsDrawnPerson(drawn, spouseRow) Then
        Set spouseShape = DrawTreeCard(ws, spouseRow, blockLeft + cardW + coupleGap, blockTop, cardW, cardH, drawn)
        ConnectHorizontalCouple ws, gcShape, spouseShape, originX, originY
    End If
    DrawGrandchildFamilyBlock = blockTop + cardH
End Function

Private Function DrawRemainingVisiblePersons(ByVal ws As Worksheet, _
        ByVal drawn As Object, _
        ByVal leftPt As Double, _
        ByVal topPt As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal gapPt As Double, _
        ByVal rightLimit As Double) As Double
    Dim wp As Worksheet, r As Long, x As Double, y As Double, maxBottom As Double
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    x = leftPt
    y = topPt
    maxBottom = y
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            If Not IsDrawnPerson(drawn, r) Then
                If x + cardW > rightLimit Then
                    x = leftPt
                    y = y + cardH + 24
                End If
                DrawTreeCard ws, r, x, y, cardW, cardH, drawn
                If y + cardH > maxBottom Then maxBottom = y + cardH
                x = x + cardW + gapPt
            End If
        End If
    Next r
    DrawRemainingVisiblePersons = maxBottom
End Function

Private Sub ConnectHorizontalCouple(ByVal ws As Worksheet, ByVal leftShape As Shape, ByVal rightShape As Shape, ByRef originX As Double, ByRef originY As Double)
    originY = ShapeCenterY(leftShape)
    DrawHLine ws, leftShape.Left + leftShape.Width, originY, rightShape.Left
    originX = (leftShape.Left + leftShape.Width + rightShape.Left) / 2
End Sub

Private Function DrawPortraitChildFamilyBlock(ByVal ws As Worksheet, _
        ByVal childRow As Long, _
        ByVal childX As Double, _
        ByVal childTop As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal smallW As Double, _
        ByVal smallH As Double) As Double
    Dim childShape As Shape, spouseShape As Shape
    Dim spouseRow As Long, childId As String, gcRows As Collection
    Dim bottomY As Double, i As Long, gTop As Double, gX As Double
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    Set childShape = DrawPersonCardShape(ws, childRow, childX, childTop, cardW, cardH)
    bottomY = childTop + cardH

    spouseRow = GetSpouseRowOfPerson(childId)
    If spouseRow > 0 Then
        Set spouseShape = DrawPersonCardShape(ws, spouseRow, childX, bottomY + 10, cardW, cardH)
        DrawVLine ws, ShapeCenterX(childShape), bottomY, spouseShape.Top
        bottomY = spouseShape.Top + spouseShape.Height
    End If

    Set gcRows = GetGrandchildRowsForParent(childId)
    If gcRows.Count > 0 Then
        DrawVLine ws, childX + cardW / 2, bottomY, bottomY + 18
        For i = 1 To gcRows.Count
            gX = childX + (cardW - smallW) / 2
            gTop = bottomY + 20 + (i - 1) * (smallH + 8)
            DrawVLine ws, childX + cardW / 2, IIf(i = 1, bottomY + 18, gTop - 8), gTop
            DrawPersonCardShape ws, CLng(gcRows(i)), gX, gTop, smallW, smallH
        Next i
        bottomY = bottomY + 20 + gcRows.Count * smallH + (gcRows.Count - 1) * 8
    End If
    DrawPortraitChildFamilyBlock = bottomY
End Function

Private Function EstimateChildFamilyBlockHeight(ByVal childRow As Long, ByVal cardH As Double) As Double
    Dim childId As String, spouseRow As Long, gcRows As Collection, h As Double, gcH As Double
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    spouseRow = GetSpouseRowOfPerson(childId)
    h = cardH
    If spouseRow > 0 Then h = h + 16 + cardH
    Set gcRows = GetGrandchildRowsForParent(childId)
    If Not gcRows Is Nothing Then
        If gcRows.Count > 0 Then
            gcH = cardH + (gcRows.Count - 1) * 76
            If gcH > h Then h = gcH
        End If
    End If
    EstimateChildFamilyBlockHeight = Application.Max(cardH, h)
End Function

Private Sub WarnDiagramIfCardCollisions(ByVal ws As Worksheet)
    Dim i As Long, j As Long, a As Shape, b As Shape, msg As String, nr As Long
    If ws Is Nothing Then Exit Sub
    For i = 1 To ws.Shapes.Count
        Set a = ws.Shapes(i)
        If Left$(a.Name, 5) = "card_" Then
            For j = i + 1 To ws.Shapes.Count
                Set b = ws.Shapes(j)
                If Left$(b.Name, 5) = "card_" Then
                    If ShapesOverlap(a, b, 3) Then
                        msg = "�����֌W�}�̃J�[�h�d�Ȃ��₪����܂��B�l���������ꍇ�͏o�̓v���r���[�Ŋm�F���Ă�������: " & a.Name & " / " & b.Name
                        If SheetExists(SH_CHECK) Then
                            nr = LastRow(ThisWorkbook.Worksheets(SH_CHECK), 1) + 1
                            If nr < 2 Then nr = 2
                            ThisWorkbook.Worksheets(SH_CHECK).Cells(nr, 1).Value = "�x��"
                            ThisWorkbook.Worksheets(SH_CHECK).Cells(nr, 2).Value = "�����֌W�����}"
                            ThisWorkbook.Worksheets(SH_CHECK).Cells(nr, 3).Value = msg
                        End If
                        AddDiagramLayoutWarning ws, msg
                        Exit Sub
                    End If
                End If
            Next j
        End If
    Next i
End Sub

Private Function ShapesOverlap(ByVal a As Shape, ByVal b As Shape, Optional ByVal marginPt As Double = 0) As Boolean
    ShapesOverlap = Not (a.Left + a.Width + marginPt < b.Left Or b.Left + b.Width + marginPt < a.Left Or _
                         a.Top + a.Height + marginPt < b.Top Or b.Top + b.Height + marginPt < a.Top)
End Function

Private Sub WarnDiagramIfPrintBoundsRisk(ByVal ws As Worksheet)
    Dim shp As Shape
    Dim maxRight As Double, maxBottom As Double, printRight As Double, printBottom As Double
    If ws Is Nothing Then Exit Sub
    On Error Resume Next
    printRight = ws.Range("J1").Left + ws.Range("J1").Width
    printBottom = ws.Rows(66).Top + ws.Rows(66).Height
    For Each shp In ws.Shapes
        If Not ThemeIsButtonShape(shp) Then
            If shp.Left + shp.Width > maxRight Then maxRight = shp.Left + shp.Width
            If shp.Top + shp.Height > maxBottom Then maxBottom = shp.Top + shp.Height
        End If
    Next shp
    If maxRight > printRight + 8 Or maxBottom > printBottom + 8 Then
        AddDiagramLayoutWarning ws, "�����֌W�}��A4�c1�y�[�W�𒴂���\��������܂��B�l���������Č��ł͏c�����y�[�W�ŉǐ���D�悵�܂��B"
    End If
    On Error GoTo 0
End Sub

Private Sub AddDiagramLayoutWarning(ByVal ws As Worksheet, ByVal msg As String)
    RuntimeAppendLog "WARN", "�����֌W�}", "���C�A�E�g", msg, 0, "", ""
End Sub

Private Sub PolishRelationshipDiagramOutput(ByVal ws As Worksheet)
    Dim shp As Shape
    Dim maxBottom As Double
    Dim printRows As Long, decId As String
    If ws Is Nothing Then Exit Sub
    decId = GetDecedentId()
    maxBottom = 0
    On Error Resume Next
    For Each shp In ws.Shapes
        If shp.Top + shp.Height > maxBottom Then maxBottom = shp.Top + shp.Height
        If Len(shp.OnAction) > 0 Then
            shp.PrintObject = False
        Else
            shp.PrintObject = True
            If shp.Type = msoLine Then
                shp.Line.ForeColor.RGB = ThemeColor("text")
                shp.Line.Weight = 1.05
            ElseIf Left$(shp.Name, 5) = "card_" Or Left$(shp.Name, 9) = "cardname_" Then
                If shp.Name = "card_" & decId Then
                    shp.Line.ForeColor.RGB = ThemeColor("title")
                    shp.Line.Weight = 2.4
                Else
                    shp.Line.ForeColor.RGB = ThemeColor("text")
                    shp.Line.Weight = IIf(Left$(shp.Name, 9) = "cardname_", 0.8, 1.35)
                End If
                shp.Shadow.Visible = msoFalse
                shp.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = ThemeColor("text")
            End If
        End If
    Next shp
    printRows = Application.Max(24, CLng((maxBottom + 30) / 16.5) + 1)
    If printRows > 88 Then printRows = 88
    If printRows <= 66 Then
        ThemeApplyMonochromePrint ws, "$A$1:$M$" & CStr(printRows), False, "", 1, 1
    Else
        ThemeApplyMonochromePrint ws, "$A$1:$M$" & CStr(printRows), False, "", 1, 1
    End If
    ws.PageSetup.CenterHorizontally = True
    ThemeLockShapeLayer ws
    On Error GoTo 0
End Sub

Private Function DrawPersonCardShape(ByVal ws As Worksheet, _
        ByVal personRow As Long, _
        ByVal leftPt As Double, _
        ByVal topPt As Double, _
        ByVal widthPt As Double, _
        ByVal heightPt As Double) As Shape
    Dim wp As Worksheet, shp As Shape
    Dim displayName As String, cardText As String, pid As String, relText As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    pid = CStr(wp.Cells(personRow, P_ID).Value)
    displayName = CStr(wp.Cells(personRow, P_DISPLAY).Value)
    relText = CStr(wp.Cells(personRow, P_REL_DEC).Value)
    cardText = DiagramCardText(personRow)

    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt, topPt, widthPt, heightPt)
    With shp
        .Name = "card_" & pid
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.ForeColor.RGB = CardFillColor(relText)
        .Line.ForeColor.RGB = IIf(relText = "�푊���l", ThemeColor("title"), ThemeColor("text"))
        .Line.Weight = IIf(relText = "�푊���l", 2.4, 1.15)
        .Shadow.Visible = msoFalse
        .TextFrame2.TextRange.Text = cardText
        .TextFrame2.TextRange.Font.Name = "Yu Gothic"
        .TextFrame2.TextRange.Font.Size = CardFontSizeForText(cardText)
        .TextFrame2.TextRange.Font.Bold = msoFalse
        .TextFrame2.WordWrap = msoTrue
        .TextFrame2.AutoSize = msoAutoSizeNone
        .TextFrame2.TextRange.Font.Fill.ForeColor.RGB = ThemeColor("text")
        .TextFrame2.VerticalAnchor = msoAnchorMiddle
        .TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
        .TextFrame2.MarginLeft = 5
        .TextFrame2.MarginRight = 5
        .TextFrame2.MarginTop = 4
        .TextFrame2.MarginBottom = 4
        If Len(displayName) > 0 Then
            .TextFrame2.TextRange.Characters(1, Len(displayName)).Font.Bold = msoTrue
            .TextFrame2.TextRange.Characters(1, Len(displayName)).Font.Size = HeaderFontSizeForName(displayName, widthPt)
            .TextFrame2.TextRange.Characters(1, Len(displayName)).Font.Fill.ForeColor.RGB = ThemeColor("title")
        End If
        .ZOrder msoBringToFront
    End With
    Set DrawPersonCardShape = shp
End Function

Private Function DiagramCardText(ByVal personRow As Long) As String
    Dim wp As Worksheet, pid As String, relText As String, genderText As String, s As String
    Dim inh As Variant, birthValue As Variant, deathValue As Variant
    Dim addrAtInh As String, addrCurrent As String, lineText As String, deathPlace As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    pid = CStr(wp.Cells(personRow, P_ID).Value)
    relText = CStr(wp.Cells(personRow, P_REL_DEC).Value)
    genderText = CStr(wp.Cells(personRow, P_GENDER).Value)
    birthValue = wp.Cells(personRow, P_BIRTH).Value
    deathValue = wp.Cells(personRow, P_DEATH).Value
    inh = GetInheritanceDate()

    AppendCardLine s, CStr(wp.Cells(personRow, P_DISPLAY).Value)
    lineText = relText
    If Len(genderText) > 0 Then lineText = lineText & " / " & genderText
    AppendCardLine s, lineText
    If IsDate(birthValue) Then AppendCardLine s, "�� " & DateWithEraYear(birthValue)
    If IsDate(deathValue) Then
        If IsDate(birthValue) Then
            AppendCardLine s, "�v " & DateWithEraYear(deathValue) & "�@�v�N�� " & AgeOnDate(birthValue, deathValue)
        Else
            AppendCardLine s, "�v " & DateWithEraYear(deathValue)
        End If
    End If
    If relText = "�푊���l" Then
        deathPlace = CleanText(wp.Cells(personRow, P_DEATH_PLACE).Value)
        If Len(deathPlace) > 0 Then AppendCardLine s, "���S�ꏊ " & CompactCardText(deathPlace, 24)
    End If
    If IsDate(birthValue) And IsDate(inh) Then AppendCardLine s, "�����J�n�� " & AgeOnDate(birthValue, inh)
    If Len(CStr(wp.Cells(personRow, P_OCC).Value)) > 0 Then AppendCardLine s, CStr(wp.Cells(personRow, P_OCC).Value)
    If IsDate(inh) Then
        addrAtInh = GetAddressTextAtDate(pid, inh)
        AppendCardLine s, "�����J�n���Z�� " & CompactCardText(addrAtInh, 22)
    End If
    addrCurrent = GetCurrentAddressText(pid)
    AppendCardLine s, "���ݏZ�� " & CompactCardText(addrCurrent, 22)
    DiagramCardText = s
End Function

Private Sub AppendCardLine(ByRef s As String, ByVal lineText As String)
    lineText = CleanText(lineText)
    If Len(lineText) = 0 Then Exit Sub
    If Len(s) > 0 Then s = s & vbLf
    s = s & lineText
End Sub

Private Function CompactCardText(ByVal s As String, ByVal maxLen As Long) As String
    s = CleanText(s)
    If Len(s) = 0 Then
        CompactCardText = "���o�^"
    ElseIf Len(s) > maxLen Then
        CompactCardText = Left$(s, maxLen - 3) & "..."
    Else
        CompactCardText = s
    End If
End Function

Private Function GetAddressTextAtDate(ByVal personId As String, ByVal baseDate As Variant) As String
    Dim wa As Worksheet, r As Long, bestR As Long, bestScore As Double, score As Double
    Dim st As Variant, en As Variant
    If Len(personId) = 0 Or Not IsDate(baseDate) Then Exit Function
    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Function
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    bestScore = -1E+20
    For r = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r, A_PERSON_ID).Value) = personId And CStr(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then
            st = wa.Cells(r, A_START).Value
            en = wa.Cells(r, A_END).Value
            If AddressRowCoversDate(st, en, baseDate) Then
                score = r
                If CleanText(wa.Cells(r, A_TYPE).Value) = "���Z�n" Then score = score + 100000
                If IsDate(st) Then score = score + CDbl(CDate(st)) / 100
                If score > bestScore Then
                    bestScore = score
                    bestR = r
                End If
            End If
        End If
    Next r
    If bestR > 0 Then GetAddressTextAtDate = CStr(wa.Cells(bestR, A_TEXT).Value)
End Function

Private Function AddressRowCoversDate(ByVal startValue As Variant, ByVal endValue As Variant, ByVal baseDate As Variant) As Boolean
    If Not IsDate(baseDate) Then Exit Function
    If IsDate(startValue) Then
        If CDate(startValue) > CDate(baseDate) Then Exit Function
    End If
    If IsDate(endValue) Then
        If CDate(endValue) < CDate(baseDate) Then Exit Function
    End If
    AddressRowCoversDate = True
End Function

Private Function DateWithEraYear(ByVal v As Variant) As String
    If Not IsDate(v) Then Exit Function
    DateWithEraYear = Format(CDate(v), "yyyy/m/d") & "�i" & EraCodeForDate(v) & "�j"
End Function

Private Function EraCodeForDate(ByVal v As Variant) As String
    Dim d As Date, y As Long
    If Not IsDate(v) Then Exit Function
    d = CDate(v)
    If d >= DateSerial(2019, 5, 1) Then
        y = Year(d) - 2018
        EraCodeForDate = "R" & CStr(y)
    ElseIf d >= DateSerial(1989, 1, 8) Then
        y = Year(d) - 1988
        EraCodeForDate = "H" & CStr(y)
    ElseIf d >= DateSerial(1926, 12, 25) Then
        y = Year(d) - 1925
        EraCodeForDate = "S" & CStr(y)
    ElseIf d >= DateSerial(1912, 7, 30) Then
        y = Year(d) - 1911
        EraCodeForDate = "T" & CStr(y)
    ElseIf d >= DateSerial(1868, 1, 25) Then
        y = Year(d) - 1867
        EraCodeForDate = "M" & CStr(y)
    Else
        EraCodeForDate = CStr(Year(d))
    End If
End Function

Private Function HeaderFontSizeForName(ByVal displayName As String, ByVal widthPt As Double) As Double
    If Len(displayName) >= 16 Or widthPt < 142 Then
        HeaderFontSizeForName = 7.8
    ElseIf Len(displayName) >= 12 Then
        HeaderFontSizeForName = 8.4
    Else
        HeaderFontSizeForName = 9.2
    End If
End Function

Private Function CardFontSizeForText(ByVal text As String) As Double
    Dim n As Long
    n = Len(text)
    If n >= 95 Then
        CardFontSizeForText = 6.8
    ElseIf n >= 70 Then
        CardFontSizeForText = 7.3
    ElseIf n >= 48 Then
        CardFontSizeForText = 7.8
    Else
        CardFontSizeForText = 8.2
    End If
End Function


Private Function CardFillColor(ByVal relationText As String) As Long
    Select Case relationText
        Case "�푊���l"
            CardFillColor = ThemeColor("info-very-soft")
        Case "�z���"
            CardFillColor = ThemeColor("warning-soft")
        Case "��", "��"
            CardFillColor = ThemeColor("success-soft")
        Case "��"
            CardFillColor = ThemeColor("purple-soft")
        Case Else
            If IsDirectChildRelationText(relationText) Then
                CardFillColor = ThemeColor("info-very-soft")
            ElseIf InStr(relationText, "�z���") > 0 Then
                CardFillColor = ThemeColor("warning-soft")
            Else
                CardFillColor = ThemeColor("canvas")
            End If
    End Select
End Function

Private Sub ConnectVerticalCouple(ByVal ws As Worksheet, ByVal upperShape As Shape, ByVal lowerShape As Shape, ByRef originX As Double, ByRef originY As Double)
    originX = ShapeCenterX(upperShape)
    DrawVLine ws, originX, upperShape.Top + upperShape.Height, lowerShape.Top
    originY = (upperShape.Top + upperShape.Height + lowerShape.Top) / 2
End Sub

Private Sub DrawChildFamilyBlock(ByVal ws As Worksheet, _
        ByVal childRow As Long, _
        ByVal childX As Double, _
        ByVal childTop As Double, _
        ByVal gcX As Double, _
        ByVal cardW As Double, _
        ByVal cardH As Double, _
        ByVal childShapes As Object)
    Dim childShape As Shape, spouseRow As Long, spouseShape As Shape
    Dim childId As String, originX As Double, originY As Double, gcRows As Collection
    Dim i As Long, topG As Double, startG As Double, branchX As Double, gRow As Long
    childId = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(childRow, P_ID).Value)
    Set childShape = DrawPersonCardShape(ws, childRow, childX, childTop, cardW, cardH)
    If Not childShapes.Exists(childId) Then childShapes.Add childId, childShape.Name
    
    spouseRow = GetSpouseRowOfPerson(childId)
    If spouseRow > 0 Then
        Set spouseShape = DrawPersonCardShape(ws, spouseRow, childX, childTop + cardH + 16, cardW, cardH)
        ConnectVerticalCouple ws, childShape, spouseShape, originX, originY
    Else
        originX = childShape.Left + childShape.Width
        originY = ShapeCenterY(childShape)
    End If
    
    Set gcRows = GetGrandchildRowsForParent(childId)
    If gcRows.Count > 0 Then
        branchX = gcX - 28
        startG = originY - ((gcRows.Count - 1) * 76) / 2 - cardH / 2
        If startG < 78 Then startG = 78
        DrawHLine ws, originX, originY, branchX
        DrawVLine ws, branchX, Application.Min(originY, startG + cardH / 2), Application.Max(originY, startG + (gcRows.Count - 1) * 76 + cardH / 2)
        For i = 1 To gcRows.Count
            gRow = CLng(gcRows(i))
            topG = startG + (i - 1) * 76
            DrawPersonCardShape ws, gRow, gcX, topG, cardW, cardH
            DrawHLine ws, branchX, topG + cardH / 2, gcX
        Next i
    End If
End Sub

Private Sub DrawUnlinkedGrandchildren(ByVal ws As Worksheet, ByVal gcX As Double, ByVal topPt As Double, ByVal cardW As Double, ByVal cardH As Double)
    Dim rows As Collection, i As Long
    Set rows = GetUnlinkedGrandchildRows()
    If rows.Count = 0 Then Exit Sub
    For i = 1 To rows.Count
        DrawPersonCardShape ws, CLng(rows(i)), gcX, topPt + (i - 1) * 70, cardW, cardH
    Next i
End Sub

Private Function GetFirstVisiblePersonRowByRelation(ByVal relationText As String) As Long
    Dim wp As Worksheet, r As Long
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            If CStr(wp.Cells(r, P_REL_DEC).Value) = relationText Then
                GetFirstVisiblePersonRowByRelation = r
                Exit Function
            End If
        End If
    Next r
End Function

Private Function GetDirectChildRows(ByVal decId As String) As Collection
    Dim col As New Collection, wp As Worksheet, r As Long, relText As String, pid As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        pid = CStr(wp.Cells(r, P_ID).Value)
        relText = CStr(wp.Cells(r, P_REL_DEC).Value)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            If pid <> decId And IsDirectChildRelationText(relText) Then col.Add r
        End If
    Next r
    Set GetDirectChildRows = col
End Function

Private Function IsDirectChildRelationText(ByVal relText As String) As Boolean
    Select Case relText
        Case "���j", "��j", "�O�j", "�l�j", "�ܒj", "�Z�j", "����", "��", "�O��", "�l��", "�܏�", "�Z��", "�q", "�{�q"
            IsDirectChildRelationText = True
    End Select
End Function

Private Function IsGrandchildRelationText(ByVal relText As String) As Boolean
    IsGrandchildRelationText = (relText = "��" Or InStr(relText, "��") > 0)
End Function

Private Function GetSpouseRowOfPerson(ByVal personId As String) As Long
    Dim wr As Worksheet, r As Long, otherId As String
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" And Not IsDate(wr.Cells(r, R_DIVORCE).Value) Then
            If CStr(wr.Cells(r, R_BASE_ID).Value) = personId Then
                otherId = CStr(wr.Cells(r, R_OTHER_ID).Value)
                GetSpouseRowOfPerson = FindPersonRow(otherId)
                Exit Function
            ElseIf CStr(wr.Cells(r, R_OTHER_ID).Value) = personId Then
                otherId = CStr(wr.Cells(r, R_BASE_ID).Value)
                GetSpouseRowOfPerson = FindPersonRow(otherId)
                Exit Function
            End If
        End If
    Next r
End Function

Private Function GetGrandchildRowsForParent(ByVal parentId As String) As Collection
    Dim col As New Collection, wr As Worksheet, r As Long, gcId As String, gcRow As Long
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�e�q" Then
            If CStr(wr.Cells(r, R_BASE_ID).Value) = parentId Then
                gcId = CStr(wr.Cells(r, R_OTHER_ID).Value)
                gcRow = FindPersonRow(gcId)
                If gcRow > 0 Then
                    If IsGrandchildRelationText(CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(gcRow, P_REL_DEC).Value)) Then col.Add gcRow
                End If
            End If
        End If
    Next r
    Set GetGrandchildRowsForParent = col
End Function

Private Function GetUnlinkedGrandchildRows() As Collection
    Dim col As New Collection, wp As Worksheet, r As Long, pid As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        pid = CStr(wp.Cells(r, P_ID).Value)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            If IsGrandchildRelationText(CStr(wp.Cells(r, P_REL_DEC).Value)) And Not HasParentRelationFromDirectChild(pid) Then col.Add r
        End If
    Next r
    Set GetUnlinkedGrandchildRows = col
End Function

Private Function HasParentRelationFromDirectChild(ByVal personId As String) As Boolean
    Dim wr As Worksheet, r As Long, pRow As Long
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�e�q" Then
            If CStr(wr.Cells(r, R_OTHER_ID).Value) = personId Then
                pRow = FindPersonRow(CStr(wr.Cells(r, R_BASE_ID).Value))
                If pRow > 0 Then
                    If IsDirectChildRelationText(CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(pRow, P_REL_DEC).Value)) Then
                        HasParentRelationFromDirectChild = True
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Sub PlaceOtherListHorizontal(ByVal ws As Worksheet, ByVal leftPt As Double, ByVal topPt As Double)
    Dim wp As Worksheet, r As Long, relText As String, outText As String
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    For r = 2 To LastRow(wp, 1)
        relText = CStr(wp.Cells(r, P_REL_DEC).Value)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            If ShouldListAsOther(relText) Then
                If Len(outText) > 0 Then outText = outText & vbLf
                outText = outText & "�E" & wp.Cells(r, P_DISPLAY).Value & "�i" & relText & "�j"
            End If
        End If
    Next r
    If Len(outText) = 0 Then Exit Sub
    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt, topPt, 360, 88)
    With shp
        .Name = "box_other_relations"
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.ForeColor.RGB = ThemeColor("canvas")
        .Line.ForeColor.RGB = ThemeColor("line-muted")
        .Line.Weight = 1
        .TextFrame2.TextRange.Text = "���̑��֌W��" & vbLf & outText
        .TextFrame2.TextRange.Font.Name = "Yu Gothic"
        .TextFrame2.TextRange.Font.Size = 8.5
        .TextFrame2.TextRange.Font.Fill.ForeColor.RGB = ThemeColor("text")
        .TextFrame2.MarginLeft = 8
        .TextFrame2.MarginRight = 8
        .TextFrame2.VerticalAnchor = msoAnchorTop
    End With
End Sub

Private Function ShouldListAsOther(ByVal relText As String) As Boolean
    If relText = "�푊���l" Or relText = "�z���" Or relText = "��" Or relText = "��" Then Exit Function
    If IsDirectChildRelationText(relText) Then Exit Function
    If IsGrandchildRelationText(relText) Then Exit Function
    If InStr(relText, "�z���") > 0 Then Exit Function
    ShouldListAsOther = True
End Function

Private Sub AddDiagramLegend(ByVal ws As Worksheet, ByVal leftPt As Double, ByVal topPt As Double)
    '�o�͐}�ɂ͐��������ڂ��Ȃ��B
End Sub

Private Sub DrawGenerationLabel(ByVal ws As Worksheet, ByVal leftPt As Double, ByVal topPt As Double, ByVal caption As String)
    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPt, topPt, 118, 22)
    With shp
        .Name = "label_" & caption
        .Placement = xlFreeFloating
        .Locked = True
        .Fill.ForeColor.RGB = ThemeColor("locked")
        .Line.ForeColor.RGB = ThemeColor("border")
        .Line.Weight = 0.75
        .TextFrame2.TextRange.Text = caption
        .TextFrame2.TextRange.Font.Name = "Yu Gothic"
        .TextFrame2.TextRange.Font.Size = 8.5
        .TextFrame2.TextRange.Font.Bold = msoTrue
        .TextFrame2.TextRange.Font.Fill.ForeColor.RGB = ThemeColor("muted-strong")
        .TextFrame2.VerticalAnchor = msoAnchorMiddle
        .TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
    End With
End Sub

Private Sub DrawHLine(ByVal ws As Worksheet, ByVal x1 As Double, ByVal y As Double, ByVal x2 As Double)
    Dim shp As Shape
    Set shp = ws.Shapes.AddLine(x1, y, x2, y)
    shp.Placement = xlFreeFloating
    shp.Locked = True
    With shp.Line
        .ForeColor.RGB = ThemeColor("muted-strong")
        .Weight = 1.5
        .EndArrowheadStyle = msoArrowheadNone
        .BeginArrowheadStyle = msoArrowheadNone
    End With
    shp.ZOrder msoSendToBack
End Sub

Private Sub DrawVLine(ByVal ws As Worksheet, ByVal x As Double, ByVal y1 As Double, ByVal y2 As Double)
    Dim shp As Shape
    Set shp = ws.Shapes.AddLine(x, y1, x, y2)
    shp.Placement = xlFreeFloating
    shp.Locked = True
    With shp.Line
        .ForeColor.RGB = ThemeColor("muted-strong")
        .Weight = 1.5
        .EndArrowheadStyle = msoArrowheadNone
        .BeginArrowheadStyle = msoArrowheadNone
    End With
    shp.ZOrder msoSendToBack
End Sub

Private Function ShapeCenterX(ByVal shp As Shape) As Double
    ShapeCenterX = shp.Left + shp.Width / 2
End Function

Private Function ShapeCenterY(ByVal shp As Shape) As Double
    ShapeCenterY = shp.Top + shp.Height / 2
End Function


Private Sub BuildAddressHistoryTable()
    Dim ws As Worksheet, wa As Worksheet, outR As Long, r As Long, pid As String, endDate As Variant
    Set ws = ThisWorkbook.Worksheets(SH_ADDR_TABLE)
    ClearSheetAll ws
    ws.Range("A1:J1").Merge
    SectionStyle ws.Range("A1:J1"), "�Z�����𑁌��\"
    AddButton ws, "K1", "���֖͂߂�", "ShowOnlyInput", 90, 24
    SetRowValues ws.Range("A3"), Array("�l��ID", "����", "����", "�Z���敪", "�c���J�n��", "�I����", "����", "�Z��", "�Z���L�[", "����")
    HeaderStyle ws.Range("A3:J3")
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    outR = 4
    For r = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r, A_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wa.Cells(r, A_ID).Value)) > 0 Then
            pid = wa.Cells(r, A_PERSON_ID).Value
            endDate = EffectiveEndDate(r)
            ws.Cells(outR, 1).Value = pid
            ws.Cells(outR, 2).Value = GetPersonValue(pid, P_DISPLAY)
            ws.Cells(outR, 3).Value = GetPersonValue(pid, P_REL_DEC)
            ws.Cells(outR, 4).Value = wa.Cells(r, A_TYPE).Value
            ws.Cells(outR, 5).Value = wa.Cells(r, A_START).Value
            ws.Cells(outR, 6).Value = endDate
            ws.Cells(outR, 7).Value = PeriodText(wa.Cells(r, A_START).Value, endDate)
            ws.Cells(outR, 8).Value = wa.Cells(r, A_TEXT).Value
            ws.Cells(outR, 9).Value = wa.Cells(r, A_KEY).Value
            ws.Cells(outR, 10).Value = wa.Cells(r, A_SOURCE).Value
            outR = outR + 1
        End If
    Next r
    If outR > 4 Then SortAddressHistoryOutput ws, outR - 1
    ws.Range("E4:F" & Application.Max(4, outR)).NumberFormatLocal = "yyyy/m/d"
    ThemeApplyCompleteBorders ws.Range("A3:J" & Application.Max(4, outR - 1)), "border"
    ws.Columns("A:J").AutoFit
    ws.Columns("H:H").ColumnWidth = 42
    PolishSimplePersonOutput ws, Application.Max(4, outR - 1), 10, "$3:$3"
End Sub

Private Sub SortAddressHistoryOutput(ByVal ws As Worksheet, ByVal lastDataRow As Long)
    If ws Is Nothing Then Exit Sub
    If lastDataRow < 5 Then Exit Sub
    On Error Resume Next
    With ws.Sort
        .SortFields.Clear
        .SortFields.Add Key:=ws.Range("A4:A" & lastDataRow), Order:=xlAscending
        .SortFields.Add Key:=ws.Range("E4:E" & lastDataRow), Order:=xlAscending
        .SetRange ws.Range("A3:J" & lastDataRow)
        .Header = xlYes
        .Apply
    End With
    On Error GoTo 0
End Sub

Private Function EffectiveEndDate(ByVal addrRow As Long) As Variant
    Dim wa As Worksheet, pid As String, r As Long, bestNext As Variant, baseDate As Variant, death As Variant
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    If IsDate(wa.Cells(addrRow, A_END).Value) Then EffectiveEndDate = wa.Cells(addrRow, A_END).Value: Exit Function
    pid = wa.Cells(addrRow, A_PERSON_ID).Value
    For r = 2 To LastRow(wa, 1)
        If r <> addrRow And wa.Cells(r, A_PERSON_ID).Value = pid And IsDate(wa.Cells(r, A_START).Value) And IsDate(wa.Cells(addrRow, A_START).Value) Then
            If CDate(wa.Cells(r, A_START).Value) > CDate(wa.Cells(addrRow, A_START).Value) Then
                If Not IsDate(bestNext) Or CDate(wa.Cells(r, A_START).Value) < CDate(bestNext) Then bestNext = wa.Cells(r, A_START).Value
            End If
        End If
    Next r
    If IsDate(bestNext) Then EffectiveEndDate = DateAdd("d", -1, CDate(bestNext)): Exit Function
    death = GetPersonValue(pid, P_DEATH)
    If IsDate(death) Then EffectiveEndDate = death: Exit Function
    baseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value
    If IsDate(baseDate) Then EffectiveEndDate = baseDate Else EffectiveEndDate = ""
End Function

Private Sub BuildCohabitationTable()
    Dim ws As Worksheet, wa As Worksheet, r1 As Long, r2 As Long, outR As Long, coNo As Long, s1 As Variant, e1 As Variant, s2 As Variant, e2 As Variant, st As Variant, en As Variant
    Set ws = ThisWorkbook.Worksheets(SH_COHAB)
    ClearSheetAll ws
    ApplySheetCanvas ws
    ws.Range("A1:J1").Merge
    TitleBannerStyle ws.Range("A1:J1"), "��������\"
    AddButton ws, "K1", "���֖͂߂�", "ShowOnlyInput", 90, 24
    SetRowValues ws.Range("A3"), Array("��������ID", "�l��A", "����A", "�l��B", "����B", "�Z��", "��������J�n", "��������I��", "����", "����")
    HeaderStyle ws.Range("A3:J3")
    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    outR = 4
    coNo = 1
    For r1 = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r1, A_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wa.Cells(r1, A_KEY).Value)) > 0 Then
            For r2 = r1 + 1 To LastRow(wa, 1)
                If CStr(wa.Cells(r2, A_STATUS).Value) <> STATUS_CANCEL And wa.Cells(r1, A_KEY).Value = wa.Cells(r2, A_KEY).Value And wa.Cells(r1, A_PERSON_ID).Value <> wa.Cells(r2, A_PERSON_ID).Value Then
                    s1 = wa.Cells(r1, A_START).Value: e1 = EffectiveEndDate(r1)
                    s2 = wa.Cells(r2, A_START).Value: e2 = EffectiveEndDate(r2)
                    If IsDate(s1) And IsDate(e1) And IsDate(s2) And IsDate(e2) Then
                        st = IIf(CDate(s1) > CDate(s2), s1, s2)
                        en = IIf(CDate(e1) < CDate(e2), e1, e2)
                        If CDate(st) <= CDate(en) Then
                            WriteCohab ws, outR, "CO" & Format(coNo, "000000"), wa.Cells(r1, A_PERSON_ID).Value, wa.Cells(r2, A_PERSON_ID).Value, wa.Cells(r1, A_TEXT).Value, st, en, "��������"
                            coNo = coNo + 1
                            outR = outR + 1
                        End If
                    Else
                        WriteCohab ws, outR, "CO" & Format(coNo, "000000"), wa.Cells(r1, A_PERSON_ID).Value, wa.Cells(r2, A_PERSON_ID).Value, wa.Cells(r1, A_TEXT).Value, "", "", "��������E���ԗv�m�F"
                        coNo = coNo + 1
                        outR = outR + 1
                    End If
                End If
            Next r2
        End If
    Next r1
    ws.Range("G4:H" & Application.Max(4, outR)).NumberFormatLocal = "yyyy/m/d"
    ThemeApplyCompleteBorders ws.Range("A3:J" & Application.Max(4, outR - 1)), "border"
    ws.Columns("A:J").AutoFit
    CapColumnWidths ws, 1, 10, 38
    ws.Columns("F:F").ColumnWidth = 42
    PolishSimplePersonOutput ws, Application.Max(4, outR - 1), 10, "$3:$3"
End Sub

Private Sub WriteCohab(ByVal ws As Worksheet, _
        ByVal outR As Long, _
        ByVal cohabId As String, _
        ByVal p1 As String, _
        ByVal p2 As String, _
        ByVal addr As String, _
        ByVal st As Variant, _
        ByVal en As Variant, _
        ByVal judge As String)
    ws.Cells(outR, 1).Value = cohabId
    ws.Cells(outR, 2).Value = GetPersonValue(p1, P_DISPLAY)
    ws.Cells(outR, 3).Value = GetPersonValue(p1, P_REL_DEC)
    ws.Cells(outR, 4).Value = GetPersonValue(p2, P_DISPLAY)
    ws.Cells(outR, 5).Value = GetPersonValue(p2, P_REL_DEC)
    ws.Cells(outR, 6).Value = addr
    ws.Cells(outR, 7).Value = st
    ws.Cells(outR, 8).Value = en
    ws.Cells(outR, 9).Value = PeriodText(st, en)
    ws.Cells(outR, 10).Value = judge
End Sub

Private Sub BuildTimelineTable()
    Dim ws As Worksheet, wp As Worksheet, we As Worksheet
    Dim minY As Long, maxY As Long, r As Long, c As Long, y As Long
    Dim rowOut As Long, lastCol As Long, lastDataRow As Long, baseDate As Variant
    Set ws = ThisWorkbook.Worksheets(SH_TIMELINE)
    ClearSheetAll ws
    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    Set we = ThisWorkbook.Worksheets(SH_W_EVENT)

    baseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value
    If IsDate(baseDate) Then
        maxY = Year(CDate(baseDate))
    Else
        maxY = Year(Date)
    End If
    minY = maxY
    For r = 2 To LastRow(we, 1)
        If IsNumeric(we.Cells(r, E_YEAR).Value) And CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL Then
            If CLng(we.Cells(r, E_YEAR).Value) < minY Then minY = CLng(we.Cells(r, E_YEAR).Value)
            If CLng(we.Cells(r, E_YEAR).Value) > maxY Then maxY = CLng(we.Cells(r, E_YEAR).Value)
        End If
    Next r
    If minY > maxY Then minY = maxY

    ApplySheetCanvas ws

    c = 3
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then c = c + 2
    Next r
    lastCol = Application.Max(5, c - 1)

    ws.Range(ws.Cells(1, 1), ws.Cells(1, lastCol)).Merge
    TitleBannerStyle ws.Range(ws.Cells(1, 1), ws.Cells(1, lastCol)), "���n��\"
    AddButton ws, ws.Cells(1, lastCol).Address(False, False), "���֖͂߂�", "ShowOnlyInput", 90, 24

    ws.Cells(3, 1).Value = "����"
    ws.Range("A3:A5").Merge
    HeaderStyle ws.Range("A3:A5"), ThemeColor("blue")
    ws.Cells(3, 2).Value = "�a��"
    ws.Range("B3:B5").Merge
    HeaderStyle ws.Range("B3:B5"), ThemeColor("blue")

    c = 3
    For r = 2 To LastRow(wp, 1)
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
            ws.Range(ws.Cells(3, c), ws.Cells(3, c + 1)).Merge
            ws.Cells(3, c).Value = wp.Cells(r, P_DISPLAY).Value
            ws.Range(ws.Cells(4, c), ws.Cells(4, c + 1)).Merge
            ws.Cells(4, c).Value = wp.Cells(r, P_REL_DEC).Value
            ws.Cells(5, c).Value = "�N��"
            ws.Cells(5, c + 1).Value = "�o����"
            HeaderStyle ws.Range(ws.Cells(3, c), ws.Cells(5, c + 1)), ThemeColor("muted-strong")
            c = c + 2
        End If
    Next r

    rowOut = 6
    For y = minY To maxY
        ws.Cells(rowOut, 1).Value = y
        ws.Cells(rowOut, 2).Value = EraYearText(y)
        c = 3
        For r = 2 To LastRow(wp, 1)
            If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL And CStr(wp.Cells(r, P_SHOW).Value) <> SHOW_NO Then
                ws.Cells(rowOut, c).Value = AgeForYear(wp.Cells(r, P_BIRTH).Value, wp.Cells(r, P_DEATH).Value, y)
                ws.Cells(rowOut, c + 1).Value = EventsForPersonYear(wp.Cells(r, P_ID).Value, y)
                ws.Cells(rowOut, c).HorizontalAlignment = xlCenter
                ws.Cells(rowOut, c + 1).WrapText = True
                ws.Cells(rowOut, c + 1).VerticalAlignment = xlTop
                c = c + 2
            End If
        Next r
        If rowOut Mod 2 = 0 Then ws.Range(ws.Cells(rowOut, 1), ws.Cells(rowOut, lastCol)).Interior.Color = ThemeColor("canvas")
        rowOut = rowOut + 1
    Next y
    lastDataRow = Application.Max(6, rowOut - 1)
    With ws.Range(ws.Cells(3, 1), ws.Cells(lastDataRow, lastCol))
        .VerticalAlignment = xlTop
    End With
    ThemeApplyCompleteBorders ws.Range(ws.Cells(3, 1), ws.Cells(lastDataRow, lastCol)), "border"
    ws.Columns("A:A").ColumnWidth = 8
    ws.Columns("B:B").ColumnWidth = 16
    For c = 3 To lastCol
        If (c - 3) Mod 2 = 0 Then ws.Columns(c).ColumnWidth = 9 Else ws.Columns(c).ColumnWidth = 34
    Next c
    ws.Rows("1:5").RowHeight = 23
    ws.Rows("6:" & lastDataRow).RowHeight = 42
    PolishTimelineOutput ws, lastDataRow, lastCol
End Sub

Private Sub PolishTimelineOutput(ByVal ws As Worksheet, ByVal lastDataRow As Long, ByVal lastCol As Long)
    Dim fitWide As Long
    If ws Is Nothing Then Exit Sub
    ThemeMarkMacroButtonsNonPrintable ws
    fitWide = 1
    If lastCol > 14 Then fitWide = 2
    If lastCol > 22 Then fitWide = 3
    ThemeApplyPrintTable ws.Range(ws.Cells(3, 1), ws.Cells(lastDataRow, lastCol)), 3
    ThemeCapRowHeights ws.Range(ws.Cells(6, 1), ws.Cells(lastDataRow, lastCol)), 32, 84
    ThemeApplyMonochromePrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(lastDataRow, lastCol)).Address, True, "$1:$5", fitWide, 0
    On Error Resume Next
    ws.PageSetup.PrintTitleColumns = "$A:$B"
    On Error GoTo 0
End Sub

Private Function AgeForYear(ByVal birthDate As Variant, ByVal deathDate As Variant, ByVal y As Long) As String
    If Not IsDate(birthDate) Then AgeForYear = "": Exit Function
    If Year(CDate(birthDate)) > y Then AgeForYear = "�o���O": Exit Function
    If IsDate(deathDate) And Year(CDate(deathDate)) < y Then AgeForYear = "���S��": Exit Function
    Dim baseDate As Date
    If IsDate(deathDate) And Year(CDate(deathDate)) = y Then baseDate = CDate(deathDate) Else baseDate = DateSerial(y, 12, 31)
    AgeForYear = AgeOnDate(birthDate, baseDate)
End Function

Private Function EventsForPersonYear(ByVal personId As String, ByVal y As Long) As String
    Dim we As Worksheet, r As Long, s As String, lineText As String
    Dim seen As Object
    Set seen = CreateObject("Scripting.Dictionary")
    Set we = ThisWorkbook.Worksheets(SH_W_EVENT)
    For r = 2 To LastRow(we, 1)
        If CStr(we.Cells(r, E_PERSON_ID).Value) = personId And CLng(Val(we.Cells(r, E_YEAR).Value)) = y And CStr(we.Cells(r, E_STATUS).Value) <> STATUS_CANCEL Then
            lineText = ""
            If IsDate(we.Cells(r, E_DATE).Value) Then lineText = Format(we.Cells(r, E_DATE).Value, "m/d") & "�i" & EraCodeForDate(we.Cells(r, E_DATE).Value) & "�j "
            lineText = lineText & CStr(we.Cells(r, E_CONTENT).Value)
            If Not seen.Exists(lineText) Then
                seen.Add lineText, True
                If Len(s) > 0 Then s = s & vbLf
                s = s & lineText
            End If
        End If
    Next r
    EventsForPersonYear = s
End Function

Private Sub BuildPersonList()
    Dim ws As Worksheet, src As Worksheet
    Dim lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_PERSON_LIST)
    Set src = ThisWorkbook.Worksheets(SH_W_PERSON)
    ClearSheetAll ws
    ws.Range("A1:V1").Merge
    SectionStyle ws.Range("A1:V1"), "�l���ꗗ"
    AddButton ws, "W1", "���֖͂߂�", "ShowOnlyInput", 90, 24
    lastR = LastRow(src, 1)
    If lastR < 1 Then lastR = 1
    ws.Range("A3").Resize(lastR, 22).Value = src.Range("A1:V" & CStr(lastR)).Value
    HeaderStyle ws.Range("A3:V3")
    ws.Columns.AutoFit
    CapColumnWidths ws, 1, 22, 34
    PolishSimplePersonOutput ws, lastR + 2, 22, "$3:$3"
End Sub


Private Sub PolishSimplePersonOutput(ByVal ws As Worksheet, ByVal lastR As Long, ByVal lastC As Long, ByVal repeatRows As String)
    If ws Is Nothing Then Exit Sub
    ThemeMarkMacroButtonsNonPrintable ws
    If lastR < 1 Or lastC < 1 Then Exit Sub
    On Error Resume Next
    ThemeApplyPrintTable ws.Range(ws.Cells(3, 1), ws.Cells(lastR, lastC)), 1
    ThemeCapRowHeights ws.Range(ws.Cells(4, 1), ws.Cells(lastR, lastC)), 18, 72
    ThemeApplyMonochromePrint ws, ws.Range(ws.Cells(1, 1), ws.Cells(lastR, lastC)).Address, True, repeatRows, 1, 0
    On Error GoTo 0
End Sub

Public Sub SaveCommonData()

    On Error GoTo EH

    Dim folderPath As String, outPath As String, wb As Workbook, shNames As Variant, tNames As Variant, i As Long

    folderPath = ThisWorkbook.Path

    If Len(folderPath) = 0 Then

        MsgBox "��ɂ��̃u�b�N���Č��t�H���_�֕ۑ����Ă��������B", vbExclamation

        GoTo CleanExit

    End If

    AppBegin

    RefreshRepresentativeAddresses

    GenerateEvents

    BuildCohabitationTable

    ApplyOutputUsability

    outPath = folderPath & Application.PathSeparator & "00_���ʃf�[�^.xlsx"

    Set wb = Workbooks.Add(xlWBATWorksheet)

    shNames = Array(SH_CONFIG, SH_W_PERSON, SH_W_REL, SH_W_ADDR_CAND, SH_W_ADDR_HIST, SH_COHAB, SH_W_EVENT)

    tNames = Array("T_�ݒ�_���{", "T_�l��", "T_�֌W", "T_�Z�����", "T_�Z������", "T_��������", "T_�C�x���g")

    For i = LBound(shNames) To UBound(shNames)

        If i = 0 Then

            wb.Worksheets(1).Name = tNames(i)

        Else

            wb.Worksheets.Add After:=wb.Worksheets(wb.Worksheets.Count)

            wb.Worksheets(wb.Worksheets.Count).Name = tNames(i)

        End If

        If CStr(tNames(i)) = "T_��������" Then

            WriteCohabCommonTable wb.Worksheets(tNames(i))

        Else

            CopySheetValuesToCommonWorkbook ThisWorkbook.Worksheets(shNames(i)), wb.Worksheets(tNames(i))

            wb.Worksheets(tNames(i)).Columns.AutoFit
            CapUsedColumnWidths wb.Worksheets(tNames(i)), 42

        End If

    Next i

    AddCommonDataControlSheets wb

    Application.CutCopyMode = False

    RuntimeSafeSaveAsXlsxAndClose wb, outPath, "SaveCommonData", "00_���ʃf�[�^.xlsx�ۑ�"

    LogAction "���ʃf�[�^�ۑ�", outPath

CleanExit:

    AppEnd

    If Len(outPath) > 0 Then MsgBox "���ʃf�[�^��ۑ����܂����B�㑱�c�[���͂��̃t�@�C����T_�l���AT_�Z�������AT_��������AT_�A�g�ݒ��ǂݍ��݂܂��B" & vbCrLf & outPath, vbInformation

    Exit Sub

EH:

    Dim errNum As Long, errDesc As String, errSrc As String
    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppEnd
    On Error GoTo 0
    RuntimeShowErrorValues "SaveCommonData", "���ʃf�[�^�ۑ�", "�ۑ��悪�J���Ă��Ȃ����A�o�̓t�H���_�֏������߂邩�m�F���Ă��������B", outPath, errNum, errDesc, errSrc

End Sub




Private Sub CopySheetValuesToCommonWorkbook(ByVal src As Worksheet, ByVal dst As Worksheet)
    'UsedRange/Clipboard���g�킸�A���f�[�^�͈͂�����z��]�L����B
    Dim lastR As Long, lastC As Long
    If src Is Nothing Or dst Is Nothing Then Exit Sub
    lastR = LastNonEmptyRow(src)
    lastC = LastNonEmptyColumn(src)
    If lastR < 1 Or lastC < 1 Then Exit Sub
    With dst.Range("A1").Resize(lastR, lastC)
        .Value = src.Range(src.Cells(1, 1), src.Cells(lastR, lastC)).Value
        .NumberFormat = src.Range(src.Cells(1, 1), src.Cells(lastR, lastC)).NumberFormat
    End With
End Sub

Private Function LastNonEmptyRow(ByVal ws As Worksheet) As Long
    Dim f As Range
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If Not f Is Nothing Then LastNonEmptyRow = f.Row
End Function

Private Function LastNonEmptyColumn(ByVal ws As Worksheet) As Long
    Dim f As Range
    If ws Is Nothing Then Exit Function
    On Error Resume Next
    Set f = ws.Cells.Find(What:="*", LookIn:=xlFormulas, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious)
    On Error GoTo 0
    If Not f Is Nothing Then LastNonEmptyColumn = f.Column
End Function

Private Sub WriteCohabCommonTable(ByVal dst As Worksheet)
    '�㑱���̓c�[�����m���ɐl��ID�œ���������Q�Ƃł���悤�A
    '�\���p�̓�������\�ł͂Ȃ��AID�t���E1�s�ڃw�b�_�[�̘A�g��p�\�Ƃ��ĕۑ�����B
    Dim wa As Worksheet, r1 As Long, r2 As Long, outR As Long, coNo As Long
    Dim s1 As Variant, e1 As Variant, s2 As Variant, e2 As Variant, st As Variant, en As Variant
    Dim p1 As String, p2 As String, judge As String

    dst.Cells.Clear
    SetRowValues dst.Range("A1"), Array("��������ID", "�l��ID_A", "�l��A", "����A", "�l��ID_B", "�l��B", "����B", "�Z��", "�Z���L�[", "��������J�n", "��������I��", "����", "����")
    HeaderStyle dst.Range("A1:M1")

    Set wa = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)
    outR = 2
    coNo = 1
    For r1 = 2 To LastRow(wa, 1)
        If CStr(wa.Cells(r1, A_STATUS).Value) <> STATUS_CANCEL And Len(CStr(wa.Cells(r1, A_KEY).Value)) > 0 Then
            For r2 = r1 + 1 To LastRow(wa, 1)
                If CStr(wa.Cells(r2, A_STATUS).Value) <> STATUS_CANCEL And wa.Cells(r1, A_KEY).Value = wa.Cells(r2, A_KEY).Value And wa.Cells(r1, A_PERSON_ID).Value <> wa.Cells(r2, A_PERSON_ID).Value Then
                    p1 = CStr(wa.Cells(r1, A_PERSON_ID).Value)
                    p2 = CStr(wa.Cells(r2, A_PERSON_ID).Value)
                    s1 = wa.Cells(r1, A_START).Value: e1 = EffectiveEndDate(r1)
                    s2 = wa.Cells(r2, A_START).Value: e2 = EffectiveEndDate(r2)
                    judge = "��������E���ԗv�m�F"
                    st = "": en = ""
                    If IsDate(s1) And IsDate(e1) And IsDate(s2) And IsDate(e2) Then
                        st = IIf(CDate(s1) > CDate(s2), s1, s2)
                        en = IIf(CDate(e1) < CDate(e2), e1, e2)
                        If CDate(st) <= CDate(en) Then
                            judge = "��������"
                        Else
                            GoTo NextPair
                        End If
                    End If
                    dst.Cells(outR, 1).Value = "CO" & Format(coNo, "000000")
                    dst.Cells(outR, 2).Value = p1
                    dst.Cells(outR, 3).Value = GetPersonValue(p1, P_DISPLAY)
                    dst.Cells(outR, 4).Value = GetPersonValue(p1, P_REL_DEC)
                    dst.Cells(outR, 5).Value = p2
                    dst.Cells(outR, 6).Value = GetPersonValue(p2, P_DISPLAY)
                    dst.Cells(outR, 7).Value = GetPersonValue(p2, P_REL_DEC)
                    dst.Cells(outR, 8).Value = wa.Cells(r1, A_TEXT).Value
                    dst.Cells(outR, 9).Value = wa.Cells(r1, A_KEY).Value
                    dst.Cells(outR, 10).Value = st
                    dst.Cells(outR, 11).Value = en
                    dst.Cells(outR, 12).Value = PeriodText(st, en)
                    dst.Cells(outR, 13).Value = judge
                    coNo = coNo + 1
                    outR = outR + 1
                End If
NextPair:
            Next r2
        End If
    Next r1
    If outR > 2 Then dst.Range("J2:K" & CStr(outR - 1)).NumberFormatLocal = "yyyy/m/d"
    dst.Columns.AutoFit
    CapUsedColumnWidths dst, 42
End Sub


Private Sub AddCommonDataControlSheets(ByVal wb As Workbook)

    Dim ws As Worksheet, decId As String, inheritDate As Variant, baseDate As Variant

    decId = GetDecedentId()

    inheritDate = GetInheritanceDate()

    baseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value



    Set ws = wb.Worksheets.Add(Before:=wb.Worksheets(1))

    ws.Name = "T_�A�g�ݒ�"

    ws.Range("A1:C1").Value = Array("�L�[", "�l", "����")

    ws.Range("A2:C2").Value = Array("�X�L�[�}�o�[�W����", "common-data-v1.1", "�݊��p�B���ʃf�[�^�S�̂̃X�L�[�}�o�[�W����")

    ws.Range("A3:C3").Value = Array("���ʃX�L�[�}�o�[�W����", "common-data-v1.1", "4�c�[�����ʂ̌Œ�X�L�[�}")

    ws.Range("A4:C4").Value = Array("�l���X�L�[�}�o�[�W����", "PERSON_INFO_V8", "�l���Z�����n��c�[���̏o�͎d�l")

    ws.Range("A5:C5").Value = Array("�����X�L�[�}�o�[�W����", "���쐬", "02�c�[���ۑ���� T_�����A�g�ݒ� �ōX�V�E�m�F����")

    ws.Range("A6:C6").Value = Array("���̓X�L�[�}�o�[�W����", "���쐬", "03�c�[���ۑ���� T_���͘A�g�ݒ� �ōX�V�E�m�F����")

    ws.Range("A7:C7").Value = Array("�`�[�˗��X�L�[�}�o�[�W����", "���쐬", "04�c�[���ۑ���� T_�`�[�˗��A�g�ݒ� �ōX�V�E�m�F����")

    ws.Range("A8:C8").Value = Array("�Č�ID", "�g�p���Ȃ�", "1�Č�1�t�H���_�^�p�̂��߈Č�ID�͎����Ȃ�")

    ws.Range("A9:C9").Value = Array("�푊���l�l��ID", decId, "T_�l���̐l��ID�B�����n�Ŕ푊���l�����𔻒肷��")

    ws.Range("A10:C10").Value = Array("�����J�n��", inheritDate, "�����֘A�V�t�g����Ɏg��")

    ws.Range("A11:C11").Value = Array("�쐬���", baseDate, "�Z���I�����⊮�E���n��ŏI�N�Ɏg��")

    ws.Range("A12:C12").Value = Array("�ۑ�����", Now, "���̋��ʃf�[�^���쐬��������")

    ws.Range("A13:C13").Value = Array("�㑱�c�[��", "02_��������\_�c�����ڕ\�쐬�⏕�c�[��;03_�����ړ����̓c�[��;04_�`�[�˗��\�쐬�c�[��", "�ǂݍ��ݑ��̑z��")

    ws.Range("A14:C14").Value = Array("��v�L�[", "�l��ID;�Z���L�[;����ID;���ID;��������ID", "�e�c�[���Ԃ̘A�g�L�[")

    ws.Range("A1:C1").Font.Bold = True

    ws.Range("A1:C1").Interior.Color = ThemeColor("text")

    ws.Range("A1:C1").Font.Color = vbWhite

    ws.Columns("A:C").AutoFit



    Set ws = wb.Worksheets.Add(After:=wb.Worksheets("T_�A�g�ݒ�"))

    ws.Name = "T_���ʃf�[�^����"

    ws.Range("A1:D1").Value = Array("�e�[�u����", "��L�[", "��ȗp�r", "�㑱�c�[��")

    ws.Range("A2:D2").Value = Array("T_�l��", "�l��ID", "�������`�l���A�����\���A�푊���l����", "�����֌W�E���́E�˗�")

    ws.Range("A3:D3").Value = Array("T_�֌W", "�֌WID", "�z��ҁE�e�q�E�������E�������̎Q��", "���́E���n��")

    ws.Range("A4:D4").Value = Array("T_�Z�����", "�Z�����ID", "�Z���ė��p�E�Z���L�[�Ǘ�", "����")

    ws.Range("A5:D5").Value = Array("T_�Z������", "�Z��ID", "�Z�������E��������E�����J�n���Z��", "����")

    ws.Range("A6:D6").Value = Array("T_��������", "��������ID", "�Z���L�[��v�����ԏd���̌���", "����")

    ws.Range("A7:D7").Value = Array("T_�C�x���g", "�C�x���gID", "���n��E�㑱�C�x���g�ǉ��̓y��", "����")

    ws.Range("A8:D8").Value = Array("T_�A�g�ݒ�", "�L�[", "�����J�n���A�푊���l�l��ID�A���ʁE�l���ʃX�L�[�}�o�[�W����", "�S�c�[��")

    ws.Range("A1:D1").Font.Bold = True

    ws.Range("A1:D1").Interior.Color = ThemeColor("text")

    ws.Range("A1:D1").Font.Color = vbWhite

    ws.Columns("A:D").AutoFit

End Sub



Public Sub ExportPersonInfoWorkbook()
    On Error GoTo EH
    Dim outFolder As String, outPath As String, wb As Workbook, shNames As Variant, i As Long
    Dim oldVis As Object, shName As String
    Set oldVis = CreateObject("Scripting.Dictionary")
    outFolder = EnsureOutputFolder()
    If Len(outFolder) = 0 Then
        MsgBox "��ɂ��̃u�b�N���Č��t�H���_�֕ۑ����Ă��������B", vbExclamation
        GoTo CleanExit
    End If
    AppBegin
    outPath = outFolder & Application.PathSeparator & "01_�l����񐮗�����.xlsx"
    RefreshRepresentativeAddresses
    GenerateEvents
    BuildConfirmList
    RunChecks
    BuildRelationshipDiagram
    BuildAddressHistoryTable
    BuildCohabitationTable
    BuildTimelineTable
    BuildPersonList
    ApplyOutputUsability
    shNames = Array(SH_DIAGRAM, SH_ADDR_TABLE, SH_COHAB, SH_TIMELINE, SH_PERSON_LIST, SH_CONFIRM, SH_CHECK)
    For i = LBound(shNames) To UBound(shNames)
        shName = CStr(shNames(i))
        oldVis(shName) = ThisWorkbook.Worksheets(shName).Visible
        ThisWorkbook.Worksheets(shName).Visible = xlSheetVisible
    Next i

    Set wb = Workbooks.Add(xlWBATWorksheet)
    For i = LBound(shNames) To UBound(shNames)
        shName = CStr(shNames(i))
        ThisWorkbook.Worksheets(shName).Copy After:=wb.Worksheets(wb.Worksheets.Count)
        wb.Worksheets(wb.Worksheets.Count).Name = shName
        wb.Worksheets(wb.Worksheets.Count).Visible = xlSheetVisible
    Next i
    Application.DisplayAlerts = False
    If wb.Worksheets.Count > 1 Then wb.Worksheets(1).Delete
    Application.DisplayAlerts = True
    DeleteUiButtonsInWorkbook wb
    Application.CutCopyMode = False
    RuntimeSafeSaveAsXlsxAndClose wb, outPath, "ExportPersonInfoWorkbook", "�l����񐮗������ۑ�"
    LogAction "�l����񐮗������o��", outPath
CleanExit:
    RestoreExportSourceSheetVisibility shNames, oldVis
    AppEnd
    If Len(outPath) > 0 Then MsgBox "�l����񐮗��������o�͂��܂���: " & outPath, vbInformation
    Exit Sub
EH:
    Dim errNum As Long, errDesc As String, errSrc As String
    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source
    On Error Resume Next
    Application.DisplayAlerts = True
    RestoreExportSourceSheetVisibility shNames, oldVis
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppEnd
    On Error GoTo 0
    RuntimeShowErrorValues "ExportPersonInfoWorkbook", "�l����񐮗������o��", "�o�͐�t�@�C�����J���Ă��Ȃ����A�o�̓t�H���_�֏������߂邩�m�F���Ă��������B", outPath, errNum, errDesc, errSrc
End Sub

Private Sub RestoreExportSourceSheetVisibility(ByVal shNames As Variant, ByVal oldVis As Object)
    Dim i As Long, shName As String
    On Error Resume Next
    If oldVis Is Nothing Then Exit Sub
    If IsEmpty(shNames) Then Exit Sub
    For i = LBound(shNames) To UBound(shNames)
        shName = CStr(shNames(i))
        If oldVis.Exists(shName) Then ThisWorkbook.Worksheets(shName).Visible = oldVis(shName)
    Next i
    On Error GoTo 0
End Sub

Private Sub DeleteUiButtonsInWorkbook(ByVal wb As Workbook)
    Dim ws As Worksheet, i As Long
    On Error Resume Next
    For Each ws In wb.Worksheets
        For i = ws.Shapes.Count To 1 Step -1
            If Left$(ws.Shapes(i).Name, 4) = "btn_" Then ws.Shapes(i).Delete
        Next i
    Next ws
    On Error GoTo 0
End Sub

Private Sub LogAction(ByVal actionName As String, ByVal detail As String)
    Dim ws As Worksheet, r As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_LOG)
    r = NextBlankRow(ws, 1)
    ws.Cells(r, 1).Value = Now
    ws.Cells(r, 2).Value = actionName
    ws.Cells(r, 3).Value = detail
End Sub

Private Sub PrepareOutputPathWithBackup(ByVal filePath As String)
    If Len(filePath) = 0 Then Exit Sub
    If Len(Dir$(filePath)) = 0 Then Exit Sub
    RuntimeBackupAndRemoveExistingFile filePath, "PrepareOutputPathWithBackup"
    AppendLinkLog "�����o�͑ޔ�", "�쐬", filePath
End Sub

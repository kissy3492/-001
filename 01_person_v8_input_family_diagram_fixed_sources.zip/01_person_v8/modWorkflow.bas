Attribute VB_Name = "modWorkflow"

Option Explicit

Public Sub BeginDecedentEntry()

    PrepareInput MODE_DECEDENT

End Sub

Public Sub BeginAddSpouse()

    PrepareInput MODE_SPOUSE

End Sub

Public Sub BeginAddFather()

    PrepareInput MODE_FATHER

End Sub

Public Sub BeginAddMother()

    PrepareInput MODE_MOTHER

End Sub

Public Sub BeginAddChild()

    PrepareInput MODE_CHILD

End Sub

Public Sub BeginAddSibling()

    PrepareInput MODE_SIBLING

End Sub

Public Sub BeginAddGrandchild()

    PrepareInput MODE_GRANDCHILD

End Sub

Public Sub BeginAddOther()

    PrepareInput MODE_OTHER

End Sub

Private Sub PrepareInput(ByVal modeName As String)

    On Error GoTo EH

    Dim ws As Worksheet, baseId As String, autoSurname As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    ws.Unprotect Password:=TOOL_PASSWORD

    If modeName <> MODE_DECEDENT Then

        baseId = CleanText(ws.Range(CELL_BASE_ID).Value)

        If Len(baseId) = 0 Then

            MsgBox "��Ɋ�l����I��ł��������B�푊���l�o�^��͎����Ŋ�l���ɂȂ�܂��B", vbExclamation

            GoTo CleanExit

        End If

    End If

    ws.Range(CELL_PERSON_ID & ":" & CELL_DEATH_PLACE).ClearContents

    ws.Range(CELL_PENDING_ADDR_KEY).ClearContents

    ws.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents

    ws.Range(CELL_MODE).Value = modeName

    ws.Range(CELL_SHOW_DIAGRAM).Value = SHOW_YES

    autoSurname = SuggestSurname(modeName, baseId)

    ws.Range(CELL_AUTO_SURNAME).Value = autoSurname

    ws.Range(CELL_SURNAME).Value = autoSurname

    ws.Range(CELL_GENDER).Value = SuggestedGender(modeName, baseId)

    Select Case modeName

        Case MODE_DECEDENT

            ws.Range(CELL_REL_TO_DECEDENT).Value = MODE_DECEDENT

            ws.Range(CELL_SURNAME).ClearContents

        Case Else

            ws.Range(CELL_REL_TO_DECEDENT).Value = ResolveRelationTextForRegistration(modeName, baseId, "", _
                CleanText(ws.Range(CELL_GENDER).Value), ws.Range(CELL_BIRTH).Value)

    End Select

    CopyBaseCurrentAddress False

    EnsureCandidatesWarmForInputMode

    UpdateInputGuide modeName

    ws.Range(CELL_GIVEN_NAME).Select

CleanExit:

    On Error Resume Next

    EnsurePersonInputValidationOnly ws

    ApplyInputUsability

    On Error GoTo 0

    Exit Sub

EH:

    Dim errNum As Long, errDesc As String, errSrc As String

    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source

    On Error Resume Next

    EnsurePersonInputValidationOnly ws

    ApplyInputUsability

    On Error GoTo 0

    RuntimeShowErrorValues "PrepareInput", "�l�����͊J�n", _
        "��l���E���͌��E�V�[�g�ی��Ԃ��m�F���Ă��������B", "", errNum, errDesc, errSrc

End Sub

Public Sub ClearPersonInput()

    On Error GoTo EH

    Dim ws As Worksheet, pendingKey As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    ws.Unprotect Password:=TOOL_PASSWORD

    pendingKey = CleanText(ws.Range(CELL_PENDING_ADDR_KEY).Value)
    If Len(pendingKey) > 0 Then ClearPendingAddresses pendingKey

    ws.Range(CELL_PERSON_ID & ":" & CELL_DEATH_PLACE).ClearContents

    ws.Range(CELL_PENDING_ADDR_KEY).ClearContents

    ws.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents

    ws.Range(CELL_SHOW_DIAGRAM).Value = SHOW_YES

CleanExit:

    EnsurePersonInputValidationOnly ws

    ApplyInputUsability

    Exit Sub

EH:

    Resume CleanExit

End Sub

Private Function SuggestSurname(ByVal modeName As String, ByVal baseId As String) As String

    Dim decId As String, s As String

    If modeName = MODE_OTHER Then

        SuggestSurname = ""

        Exit Function

    End If

    If modeName = MODE_DECEDENT Then

        SuggestSurname = ""

        Exit Function

    End If

    If Len(baseId) > 0 Then s = GetPersonValue(baseId, P_SURNAME)

    decId = GetDecedentId()

    Select Case modeName

        Case MODE_FATHER, MODE_MOTHER, MODE_SIBLING

            If Len(decId) > 0 Then SuggestSurname = GetPersonValue(decId, P_SURNAME) Else SuggestSurname = s

        Case Else

            SuggestSurname = s

    End Select

End Function

Public Sub LoadBaseFromSelection()

    Dim ws As Worksheet, sel As String, pid As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    sel = CleanText(ws.Range(CELL_BASE_SELECT).Value)

    pid = ParseIdFromCandidate(sel)

    If Len(pid) = 0 Or FindPersonRow(pid) = 0 Then

        MsgBox "��l����₩��l����I��ł��������B", vbExclamation

        Exit Sub

    End If

    SetBasePerson pid

End Sub

Public Sub SetDecedentAsBase()

    Dim pid As String

    pid = GetDecedentId()

    If Len(pid) = 0 Then

        MsgBox "�푊���l���܂��o�^����Ă��܂���B", vbExclamation

        Exit Sub

    End If

    SetBasePerson pid

End Sub

Public Sub SetBasePerson(ByVal personId As String)

    Dim ws As Worksheet, r As Long, addr As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    r = FindPersonRow(personId)

    If r = 0 Then Exit Sub

    ws.Range(CELL_BASE_ID).Value = personId

    ws.Range(CELL_BASE_NAME).Value = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, P_DISPLAY).Value

    ws.Range(CELL_BASE_REL).Value = ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, P_REL_DEC).Value

    addr = GetCurrentAddressText(personId)

    ws.Range(CELL_BASE_ADDRESS).Value = addr

    ws.Range(CELL_BASE_SELECT).Value = personId & " " & ws.Range(CELL_BASE_NAME).Value

    If Len(CleanText(ws.Range(CELL_MODE).Value)) > 0 Then UpdateInputGuide CleanText(ws.Range(CELL_MODE).Value)

End Sub

Public Function FindPersonRow(ByVal personId As String) As Long

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, P_ID).Value) = personId And CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            FindPersonRow = r

            Exit Function

        End If

    Next r

End Function

Public Function GetPersonValue(ByVal personId As String, ByVal colNum As Long) As String

    Dim r As Long

    r = FindPersonRow(personId)

    If r > 0 Then GetPersonValue = CStr(ThisWorkbook.Worksheets(SH_W_PERSON).Cells(r, colNum).Value)

End Function

Public Function GetDecedentId() As String

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, P_TYPE).Value) = MODE_DECEDENT And CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            GetDecedentId = CStr(ws.Cells(r, P_ID).Value)

            Exit Function

        End If

    Next r

End Function

Public Function GetInheritanceDate() As Variant

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_CONFIG)

    If IsDate(ws.Range(CELL_CONFIG_INHERIT_DATE).Value) Then

        GetInheritanceDate = ws.Range(CELL_CONFIG_INHERIT_DATE).Value

    Else

        GetInheritanceDate = ""

    End If

End Function

Public Sub RegisterInputPerson()

    On Error GoTo EH

    AppBegin

    Dim wsIn As Worksheet, wsP As Worksheet, modeName As String, pid As String, r As Long

    Dim surname As String, givenName As String, former As String, autoSurname As String

    Dim displayName As String, personType As String, relationText As String, baseId As String

    Dim gender As String, birthDate As Variant, deathDate As Variant, occupation As String, note As String

    Dim deathPlace As String, pendingKey As String, relationBaseId As String

    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)

    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)

    modeName = CleanText(wsIn.Range(CELL_MODE).Value)

    If Len(modeName) = 0 Then modeName = MODE_DECEDENT

    baseId = CleanText(wsIn.Range(CELL_BASE_ID).Value)

    If modeName <> MODE_DECEDENT And Len(baseId) = 0 Then Err.Raise 5, , "��l�������ݒ�ł��B"

    surname = CleanText(wsIn.Range(CELL_SURNAME).Value)

    givenName = CleanText(wsIn.Range(CELL_GIVEN_NAME).Value)

    former = CleanText(wsIn.Range(CELL_FORMER_SURNAME).Value)

    autoSurname = CleanText(wsIn.Range(CELL_AUTO_SURNAME).Value)

    If Len(surname) = 0 And Len(autoSurname) > 0 Then surname = autoSurname

    If Len(givenName) = 0 Then Err.Raise 5, , "������͂��Ă��������B"

    If Len(surname) = 0 Then Err.Raise 5, , "������͂��Ă��������B"

    If modeName = MODE_SPOUSE And Not IsDate(wsIn.Range(CELL_MARRIAGE).Value) Then _
        Err.Raise 5, , "�z��҂�l���Ƃ��ēo�^����ꍇ�͍���������͂��Ă��������B�����ς݂ő����o�^���Ȃ��ꍇ�́u�������������o�^�v���g���Ă��������B"

    If modeName <> MODE_SPOUSE And Len(autoSurname) > 0 And surname <> autoSurname And Len(former) = 0 Then

        former = autoSurname

        wsIn.Range(CELL_FORMER_SURNAME).Value = former

    End If

    displayName = ComposeDisplayName(surname, givenName, former)

    gender = CleanText(wsIn.Range(CELL_GENDER).Value)

    relationText = CleanText(wsIn.Range(CELL_REL_TO_DECEDENT).Value)

    birthDate = SameDateOrBlank(wsIn.Range(CELL_BIRTH).Value)

    deathDate = SameDateOrBlank(wsIn.Range(CELL_DEATH).Value)

    relationText = ResolveRelationTextForRegistration(modeName, baseId, relationText, gender, birthDate)

    personType = IIf(modeName = MODE_DECEDENT, MODE_DECEDENT, IIf(modeName = MODE_OTHER, "�֌W��", "�e��"))

    If modeName = MODE_CHILD Or modeName = MODE_GRANDCHILD Then personType = IIf(InStr(relationText, "�z��҂̎q") > 0, "�e��", "�����l")

    If modeName = MODE_SPOUSE And baseId = GetDecedentId() Then personType = "�����l"

    occupation = CleanText(wsIn.Range(CELL_OCCUPATION).Value)

    note = CleanText(wsIn.Range(CELL_NOTE).Value)

    deathPlace = CleanText(wsIn.Range(CELL_DEATH_PLACE).Value)
    If modeName <> MODE_DECEDENT Then deathPlace = ""
    pendingKey = CleanText(wsIn.Range(CELL_PENDING_ADDR_KEY).Value)
    pid = CleanText(wsIn.Range(CELL_PERSON_ID).Value)
    If Len(pid) = 0 Then
        r = FindLikelyExistingPersonRow(displayName, birthDate, deathDate, modeName)
        If r > 0 Then
            pid = CStr(wsP.Cells(r, P_ID).Value)
        Else
            pid = NextId("�l��")
            r = NextBlankRow(wsP, 1)
            wsP.Cells(r, P_CREATED).Value = Now
        End If
    Else
        r = FindPersonRow(pid)
        If r = 0 Then r = NextBlankRow(wsP, 1)
    End If
    wsP.Cells(r, P_ID).Value = pid

    wsP.Cells(r, P_ORDER).Value = IIf(Len(wsP.Cells(r, P_ORDER).Value) = 0, r - 1, wsP.Cells(r, P_ORDER).Value)

    wsP.Cells(r, P_TYPE).Value = personType

    wsP.Cells(r, P_SURNAME).Value = surname

    wsP.Cells(r, P_GIVEN).Value = givenName

    wsP.Cells(r, P_FORMER).Value = former

    wsP.Cells(r, P_DISPLAY).Value = displayName

    wsP.Cells(r, P_SUR_MODE).Value = IIf(Len(autoSurname) > 0 And surname = autoSurname, "����", "�����")

    wsP.Cells(r, P_SUR_SRC).Value = IIf(Len(autoSurname) > 0, baseId, "")

    wsP.Cells(r, P_REL_DEC).Value = relationText

    wsP.Cells(r, P_REL_DISP).Value = relationText

    wsP.Cells(r, P_GENDER).Value = gender

    wsP.Cells(r, P_BIRTH).Value = birthDate

    wsP.Cells(r, P_DEATH).Value = deathDate

    wsP.Cells(r, P_OCC).Value = occupation

    wsP.Cells(r, P_SHOW).Value = IIf(Len(CleanText(wsIn.Range(CELL_SHOW_DIAGRAM).Value)) = 0, SHOW_YES, wsIn.Range(CELL_SHOW_DIAGRAM).Value)

    wsP.Cells(r, P_NOTE).Value = note

    wsP.Cells(r, P_DEATH_PLACE).Value = deathPlace

    wsP.Cells(r, P_STATUS).Value = STATUS_ACTIVE

    wsP.Cells(r, P_UPDATED).Value = Now

    wsIn.Range(CELL_PERSON_ID).Value = pid

    If modeName = MODE_DECEDENT Then

        ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_INHERIT_DATE).Value = deathDate

    Else

        relationBaseId = RelationBaseForRegistration(modeName, baseId, birthDate)
        AddRelationIfNeeded relationBaseId, pid, modeName, relationText, wsIn.Range(CELL_MARRIAGE).Value, wsIn.Range(CELL_DIVORCE).Value

    End If

    RegisterAddressFromInput pid
    If Len(pendingKey) > 0 Then
        FlushPendingAddressesToPerson pendingKey, pid
        wsIn.Range(CELL_PENDING_ADDR_KEY).ClearContents
    End If

    RefreshCandidatesAfterPersonRegister pid

    Dim nextBaseId As String

    nextBaseId = pid

    SetBasePerson nextBaseId

    wsIn.Range(CELL_BASE_SELECT).Value = nextBaseId & " " & GetPersonValue(nextBaseId, P_DISPLAY)

    ApplyInputUsability False

    WriteGuideAfterRegister modeName, displayName, nextBaseId

    SetPersonInputStatus "�o�^����: " & displayName & "�B�����Ċ֌W�{�^�����玟�̐l������͂ł��܂��B"

CleanExit:

    AppEnd

    Exit Sub

EH:

    Dim errNum As Long, errDesc As String, errSrc As String

    errNum = Err.Number: errDesc = Err.Description: errSrc = Err.Source

    On Error Resume Next

    If Not wsIn Is Nothing Then

        EnsurePersonInputValidationOnly wsIn

        ApplyInputUsability

    End If

    AppEnd

    On Error GoTo 0

    RuntimeShowErrorValues "RegisterInputPerson", "�l���o�^", _
        "�K�{���ځA��l���A���V�[�g�A�V�[�g�ی��Ԃ��m�F���Ă��������B", _
        "", errNum, errDesc, errSrc

End Sub

Private Function FindLikelyExistingPersonRow(ByVal displayName As String, _
        ByVal birthDate As Variant, _
        ByVal deathDate As Variant, _
        ByVal modeName As String) As Long
    '�l��ID����̂܂ܓ����l�����ēo�^�������ɁA���ʂȏd���l�������Ȃ��B
    '���������ł͓����������득�������邽�߁A���t��񂪂���ꍇ�A�܂��͔푊���l������1������ꍇ���������X�V����B
    Dim ws As Worksheet, r As Long, lastR As Long
    If Len(displayName) = 0 Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            If CStr(ws.Cells(r, P_DISPLAY).Value) = displayName Then
                If modeName = MODE_DECEDENT And CStr(ws.Cells(r, P_TYPE).Value) = MODE_DECEDENT Then
                    FindLikelyExistingPersonRow = r
                    Exit Function
                End If
                If HasAnyDateForDuplicate(birthDate, deathDate) Then
                    If SameDateValueOrBlank(ws.Cells(r, P_BIRTH).Value, birthDate) _
                            And SameDateValueOrBlank(ws.Cells(r, P_DEATH).Value, deathDate) Then
                        FindLikelyExistingPersonRow = r
                        Exit Function
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function HasAnyDateForDuplicate(ByVal birthDate As Variant, ByVal deathDate As Variant) As Boolean
    HasAnyDateForDuplicate = (IsDate(birthDate) Or IsDate(deathDate))
End Function

Private Function RecommendedNextBase(ByVal modeName As String, ByVal baseId As String, ByVal newPersonId As String) As String

    '�o�^�����l�������̂܂܎��̊�l���ɂ���B

    '�u�����͂��Ă���l���̊֌W�҂𑱂��ēo�^����v������D�悷��B

    RecommendedNextBase = newPersonId

End Function

Private Function NextActionMessage(ByVal modeName As String, ByVal nextBaseId As String) As String

    Dim baseName As String

    baseName = GetPersonValue(nextBaseId, P_DISPLAY)

    NextActionMessage = "���݂̊�l�����u" & baseName & "�v�ɂ��܂����B" & _
        "���́A���̐l���̔z��ҁE���E��E�q�E�Z��o���Ȃǂ��֌W�{�^������ǉ����Ă��������B" & _
        "�ʂ̐l���̊֌W�҂֖߂�ꍇ�́A��l�����őI�Ԃ��u�푊���l�ɖ߂�v�������܂��B"

End Function

Private Sub WriteGuideAfterRegister(ByVal modeName As String, ByVal displayName As String, ByVal nextBaseId As String)

    Dim ws As Worksheet, guide As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    guide = "�o�^�����F" & displayName & vbLf & _
            NextActionMessage(modeName, nextBaseId) & vbLf & _
            "���[�m�F�F���i�̑����}�쐬�E�Z���ꗗ�쐬�E���n��쐬�ŁA�K�v�Ȓ��[���������m�F�ł��܂��B" & vbLf & _
            "���͂̌����F�������E�Z���E�������E�����͌�₩��I�сA�������e���x���͂��Ȃ��B�Z���L�[�������Ȃ瓯������ɔ��f����܂��B"

    ws.Range("B38").Value = guide

End Sub

Private Sub SetPersonInputStatus(ByVal messageText As String)

    On Error Resume Next

    Application.StatusBar = messageText

    ThisWorkbook.Worksheets(SH_INPUT).Range("B46").Value = messageText

    On Error GoTo 0

End Sub

Private Sub UpdateInputGuide(ByVal modeName As String)

    Dim ws As Worksheet, guide As String, baseId As String, baseName As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)

    baseName = GetPersonValue(baseId, P_DISPLAY)

    Select Case modeName

        Case MODE_DECEDENT

            guide = "�菇1�F�푊���l��o�^���܂��B���E���E���S���E�Z������͂��Ă��������B���S���������J�n���ɂȂ�܂��B�o�^��A�z��ҁA���A��A�q�̏��Ɋ֌W�҂�ǉ����܂��B"

        Case MODE_SPOUSE

            guide = "�z��Ғǉ��F�l���Ƃ��ēo�^����ꍇ�͍�������K������܂��B�����ς݂ő����l���o�^���Ȃ��ꍇ�́A�������E��������������āu�������������o�^�v���g���܂��B�����͕K�v�Ȑl�������͂��܂��B"

        Case MODE_FATHER

            guide = "���ǉ��F���͔푊���l���̐��������\�����܂��B�Z���͔푊���l��O��Z������R�s�[�ł��܂��B�o�^��͔푊���l����ɖ߂��Ď���ǉ����܂��B"

        Case MODE_MOTHER

            guide = "��ǉ��F���͔푊���l���̐��������\�����܂��B�����͕�����ꍇ�������͂��܂��B�Z���͊�l���Ɠ��l�A�܂��͑O��Z��������őI�ׂ܂��B"

        Case MODE_CHILD

            guide = "�q�ǉ��F���͐e�̐��������\�����܂��B���ʂ�����ƒ��j�E��������������≻���܂��B��l�����q�̔z��҂ŁA���N�������������Ԓ��Ȃ�푊���l���猩�������͑��ɂȂ�܂��B"

        Case MODE_SIBLING

            guide = "�Z��o���ǉ��F���͔푊���l���̐��������\�����܂��B���ʂƐ��N����������ΌZ�E��E�o�E�����������肵�܂��B"

        Case MODE_GRANDCHILD

            guide = "���ǉ��F�q�܂��͎q�̔z��҂���ɓo�^���܂��B���N�������������Ԓ��Ȃ瑷�A�������ԊO�Ȃ�O�z��҂Ƃ̎q�Ƃ��Ď������肵�܂��B�Z���͊�l���Ɠ��l�����őI�ׂ܂��B"

        Case Else

            guide = "���̑��֌W�ҁF���E�Z���E�����͌�₩��I�ׂ܂��B�֌W����l�ɁA������̈ʒu�t����Z������Ă��������B"

    End Select

    If Len(baseName) > 0 Then guide = "��l���F" & baseName & vbLf & guide

    ws.Range("B38").Value = guide

End Sub

Private Function AutoRelationText(ByVal modeName As String, _
        ByVal baseId As String, _
        ByVal gender As String, _
        ByVal birthDate As Variant) As String

    Dim decId As String, baseRel As String

    decId = GetDecedentId()

    baseRel = GetPersonValue(baseId, P_REL_DEC)

    If Len(baseRel) = 0 Then baseRel = "��l��"

    Select Case modeName

        Case MODE_DECEDENT

            AutoRelationText = "�푊���l"

        Case MODE_SPOUSE

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = "�z���"

            Else

                AutoRelationText = RelationViaBase(baseRel, "�z���", "�z���")

            End If

        Case MODE_FATHER

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = "��"

            Else

                AutoRelationText = RelationViaBase(baseRel, "��", "��")

            End If

        Case MODE_MOTHER

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = "��"

            Else

                AutoRelationText = RelationViaBase(baseRel, "��", "��")

            End If

        Case MODE_CHILD

            If Len(baseId) > 0 And baseId <> decId Then

                If BaseIsDirectChildRelation(baseRel) Then

                    AutoRelationText = "��"

                Else

                    AutoRelationText = RelationViaBase(baseRel, "�q", "�q")

                End If

            Else

                AutoRelationText = ChildRelationText(gender)

            End If

        Case MODE_SIBLING

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = SiblingRelationText(gender, birthDate)

            Else

                AutoRelationText = RelationViaBase(baseRel, "�Z��o��", "�Z��o��")

            End If

        Case MODE_GRANDCHILD

            If Len(baseId) = 0 Or baseId = decId Then

                AutoRelationText = "��"

            Else

                AutoRelationText = RelationViaBase(baseRel, "��", "��")

            End If

        Case Else

            If Len(baseId) > 0 And baseId <> decId Then

                AutoRelationText = RelationViaBase(baseRel, "�֌W��", "�֌W��")

            Else

                AutoRelationText = "�֌W��"

            End If

    End Select

End Function

Private Function ResolveRelationTextForRegistration(ByVal modeName As String, _
        ByVal baseId As String, _
        ByVal currentText As String, _
        ByVal gender As String, _
        ByVal birthDate As Variant) As String

    Dim suggested As String, directChildId As String, marriageDate As Variant, divorceDate As Variant
    suggested = currentText
    If Len(suggested) = 0 Or suggested = "�q" Or suggested = "�Z��o��" Or suggested = "��l���̎q" Then
        suggested = AutoRelationText(modeName, baseId, gender, birthDate)
    End If

    If modeName = MODE_CHILD Then
        If IsBaseSpouseOfDirectChild(baseId, directChildId, marriageDate, divorceDate) Then
            If Not IsDate(birthDate) Then
                ResolveRelationTextForRegistration = "���i�������ԗv�m�F�j"
            ElseIf DateWithinMarriagePeriod(birthDate, marriageDate, divorceDate) Then
                ResolveRelationTextForRegistration = "��"
            Else
                ResolveRelationTextForRegistration = GetPersonValue(directChildId, P_REL_DEC) & "�̔z��҂̎q�i�O�z��҂Ƃ̎q�j"
            End If
            Exit Function
        ElseIf BaseIsDirectChildRelation(GetPersonValue(baseId, P_REL_DEC)) Then
            If HasSpousePeriodForPerson(baseId, marriageDate, divorceDate) Then
                If Not IsDate(birthDate) Then
                    ResolveRelationTextForRegistration = "���i�������ԗv�m�F�j"
                    Exit Function
                ElseIf Not DateWithinMarriagePeriod(birthDate, marriageDate, divorceDate) Then
                    ResolveRelationTextForRegistration = "���i�O�z��҂Ƃ̎q�j"
                    Exit Function
                End If
            End If
            ResolveRelationTextForRegistration = "��"
            Exit Function
        End If
    End If

    ResolveRelationTextForRegistration = suggested

End Function

Private Function RelationBaseForRegistration(ByVal modeName As String, ByVal baseId As String, ByVal birthDate As Variant) As String

    Dim directChildId As String, marriageDate As Variant, divorceDate As Variant
    RelationBaseForRegistration = baseId
    If modeName = MODE_CHILD Then
        If IsBaseSpouseOfDirectChild(baseId, directChildId, marriageDate, divorceDate) Then
            If IsDate(birthDate) Then
                If DateWithinMarriagePeriod(birthDate, marriageDate, divorceDate) Then RelationBaseForRegistration = directChildId
            End If
        End If
    End If

End Function

Private Function IsBaseSpouseOfDirectChild(ByVal baseId As String, _
        ByRef directChildId As String, _
        ByRef marriageDate As Variant, _
        ByRef divorceDate As Variant) As Boolean

    Dim wr As Worksheet, r As Long, otherId As String
    If Len(baseId) = 0 Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" Then
            otherId = ""
            If CStr(wr.Cells(r, R_BASE_ID).Value) = baseId Then
                otherId = CStr(wr.Cells(r, R_OTHER_ID).Value)
            ElseIf CStr(wr.Cells(r, R_OTHER_ID).Value) = baseId Then
                otherId = CStr(wr.Cells(r, R_BASE_ID).Value)
            End If
            If Len(otherId) > 0 Then
                If BaseIsDirectChildRelation(GetPersonValue(otherId, P_REL_DEC)) Then
                    directChildId = otherId
                    marriageDate = wr.Cells(r, R_MARRIAGE).Value
                    divorceDate = wr.Cells(r, R_DIVORCE).Value
                    IsBaseSpouseOfDirectChild = True
                    Exit Function
                End If
            End If
        End If
    Next r

End Function

Private Function HasSpousePeriodForPerson(ByVal personId As String, ByRef marriageDate As Variant, ByRef divorceDate As Variant) As Boolean

    Dim wr As Worksheet, r As Long
    If Len(personId) = 0 Then Exit Function
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    For r = 2 To LastRow(wr, 1)
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL And CStr(wr.Cells(r, R_TYPE).Value) = "�z���" Then
            If CStr(wr.Cells(r, R_BASE_ID).Value) = personId Or CStr(wr.Cells(r, R_OTHER_ID).Value) = personId Then
                marriageDate = wr.Cells(r, R_MARRIAGE).Value
                divorceDate = wr.Cells(r, R_DIVORCE).Value
                HasSpousePeriodForPerson = (IsDate(marriageDate) Or IsDate(divorceDate))
                Exit Function
            End If
        End If
    Next r

End Function

Private Function DateWithinMarriagePeriod(ByVal targetDate As Variant, ByVal marriageDate As Variant, ByVal divorceDate As Variant) As Boolean

    If Not IsDate(targetDate) Then DateWithinMarriagePeriod = True: Exit Function
    If IsDate(marriageDate) Then
        If CDate(targetDate) < CDate(marriageDate) Then Exit Function
    End If
    If IsDate(divorceDate) Then
        If CDate(targetDate) > CDate(divorceDate) Then Exit Function
    End If
    DateWithinMarriagePeriod = True

End Function

Private Function RelationViaBase(ByVal baseRel As String, ByVal suffixText As String, ByVal fallbackText As String) As String

    baseRel = CleanText(baseRel)

    If Len(baseRel) = 0 Or baseRel = "�푊���l" Then

        RelationViaBase = fallbackText

    ElseIf InStr(baseRel, "��") > 0 Then

        RelationViaBase = baseRel & "�E" & suffixText

    Else

        RelationViaBase = baseRel & "��" & suffixText

    End If

End Function

Private Function BaseIsDirectChildRelation(ByVal baseRel As String) As Boolean

    baseRel = CleanText(baseRel)

    BaseIsDirectChildRelation = (baseRel = "�q" Or baseRel = "���j" Or baseRel = "��j" Or _
        baseRel = "�O�j" Or baseRel = "�l�j" Or baseRel = "�ܒj" Or _
        baseRel = "����" Or baseRel = "��" Or baseRel = "�O��" Or _
        baseRel = "�l��" Or baseRel = "�܏�")

End Function

Private Function SuggestedGender(ByVal modeName As String, ByVal baseId As String) As String

    Dim baseGender As String

    Select Case modeName

        Case MODE_FATHER

            SuggestedGender = "�j"

        Case MODE_MOTHER

            SuggestedGender = "��"

        Case MODE_SPOUSE

            baseGender = GetPersonValue(baseId, P_GENDER)

            If baseGender = "�j" Then

                SuggestedGender = "��"

            ElseIf baseGender = "��" Then

                SuggestedGender = "�j"

            End If

    End Select

End Function

Public Sub RefreshCurrentRelationText()

    Dim ws As Worksheet, modeName As String, baseId As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    modeName = CleanText(ws.Range(CELL_MODE).Value)

    If Len(modeName) = 0 Then Exit Sub

    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)

    ws.Range(CELL_REL_TO_DECEDENT).Value = ResolveRelationTextForRegistration(modeName, baseId, _
        CleanText(ws.Range(CELL_REL_TO_DECEDENT).Value), CleanText(ws.Range(CELL_GENDER).Value), ws.Range(CELL_BIRTH).Value)

End Sub

Private Function ChildRelationText(ByVal gender As String) As String

    Dim n As Long

    If gender = "�j" Then

        n = CountRelationStartsWith("���j", "��j", "�O�j", "�j") + 1

        ChildRelationText = Array("", "���j", "��j", "�O�j", "�l�j", "�ܒj")(Application.Min(n, 5))

    ElseIf gender = "��" Then

        n = CountRelationStartsWith("����", "��", "�O��", "��") + 1

        ChildRelationText = Array("", "����", "��", "�O��", "�l��", "�܏�")(Application.Min(n, 5))

    Else

        ChildRelationText = "�q"

    End If

End Function

Private Function CountRelationStartsWith(ByVal a As String, ByVal b As String, ByVal c As String, ByVal g As String) As Long

    Dim ws As Worksheet, r As Long, lastR As Long, v As String

    Set ws = ThisWorkbook.Worksheets(SH_W_PERSON)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        v = CStr(ws.Cells(r, P_REL_DEC).Value)

        If v = a Or v = b Or v = c Or InStr(v, g) > 0 Then CountRelationStartsWith = CountRelationStartsWith + 1

    Next r

End Function

Private Function SiblingRelationText(ByVal gender As String, ByVal birthDate As Variant) As String

    Dim decId As String, decBirth As Variant, older As Boolean

    decId = GetDecedentId()

    decBirth = GetPersonValue(decId, P_BIRTH)

    If IsDate(birthDate) And IsDate(decBirth) Then older = CDate(birthDate) < CDate(decBirth)

    If gender = "�j" Then

        SiblingRelationText = IIf(older, "�Z", "��")

    ElseIf gender = "��" Then

        SiblingRelationText = IIf(older, "�o", "��")

    Else

        SiblingRelationText = "�Z��o��"

    End If

End Function

Private Sub AddRelationIfNeeded(ByVal baseId As String, _
        ByVal otherId As String, _
        ByVal modeName As String, _
        ByVal relationText As String, _
        ByVal marriageDate As Variant, _
        ByVal divorceDate As Variant)
    If Len(baseId) = 0 Or Len(otherId) = 0 Then Exit Sub
    If baseId = otherId Then Exit Sub
    Dim ws As Worksheet, r As Long, relationType As String
    Set ws = ThisWorkbook.Worksheets(SH_W_REL)
    relationType = "���̑�"
    If modeName = MODE_SPOUSE Then relationType = "�z���"
    If modeName = MODE_CHILD Or modeName = MODE_FATHER Or modeName = MODE_MOTHER Or modeName = MODE_GRANDCHILD Then relationType = "�e�q"
    If modeName = MODE_SIBLING Then relationType = "�Z��o��"

    r = FindExistingRelationRow(baseId, otherId, relationType)
    If r = 0 Then
        r = FindExistingRelationRow(otherId, baseId, relationType)
    End If
    If r = 0 Then
        r = NextBlankRow(ws, 1)
        ws.Cells(r, R_ID).Value = NextId("�֌W")
        ws.Cells(r, R_CREATED).Value = Now
    End If
    ws.Cells(r, R_BASE_ID).Value = baseId
    ws.Cells(r, R_OTHER_ID).Value = otherId
    ws.Cells(r, R_TYPE).Value = relationType
    ws.Cells(r, R_DISPLAY).Value = relationText
    If relationType = "�z���" Then
        ws.Cells(r, R_MARRIAGE).Value = SameDateOrBlank(marriageDate)
        ws.Cells(r, R_DIVORCE).Value = SameDateOrBlank(divorceDate)
    Else
        ws.Cells(r, R_MARRIAGE).ClearContents
        ws.Cells(r, R_DIVORCE).ClearContents
    End If
    ws.Cells(r, R_AUTO).Value = "����"
    ws.Cells(r, R_STATUS).Value = STATUS_ACTIVE
    ws.Cells(r, R_UPDATED).Value = Now
End Sub

Private Function FindExistingRelationRow(ByVal baseId As String, ByVal otherId As String, ByVal relationType As String) As Long
    Dim ws As Worksheet, r As Long, lastR As Long
    Set ws = ThisWorkbook.Worksheets(SH_W_REL)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            If CStr(ws.Cells(r, R_BASE_ID).Value) = baseId _
                    And CStr(ws.Cells(r, R_OTHER_ID).Value) = otherId _
                    And CStr(ws.Cells(r, R_TYPE).Value) = relationType Then
                FindExistingRelationRow = r
                Exit Function
            End If
        End If
    Next r
End Function

Private Sub RegisterAddressFromInput(ByVal personId As String)

    Dim wsIn As Worksheet, addressText As String, addressKey As String, candId As String

    Dim addrId As String, r As Long, wsA As Worksheet, personRow As Long

    Dim addrType As String, startValue As Variant, endValue As Variant

    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)

    addressText = CleanText(wsIn.Range(CELL_ADDR_TEXT).Value)

    If Len(addressText) = 0 Or Len(personId) = 0 Then Exit Sub

    addressKey = CleanText(wsIn.Range(CELL_ADDR_KEY).Value)

    If Len(addressKey) = 0 Then addressKey = NormalizeAddress(addressText)

    wsIn.Range(CELL_ADDR_KEY).Value = addressKey

    addrType = CleanText(wsIn.Range(CELL_ADDR_TYPE).Value)

    If Len(addrType) = 0 Then addrType = "���Z�n"

    startValue = SameDateOrBlank(wsIn.Range(CELL_ADDR_START).Value)

    endValue = SameDateOrBlank(wsIn.Range(CELL_ADDR_END).Value)

    candId = GetOrCreateAddressCandidate(addressText, addressKey, personId)

    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    r = FindMatchingAddressHistoryRow(personId, addressKey, addrType, startValue, endValue)

    If r > 0 Then

        addrId = CStr(wsA.Cells(r, A_ID).Value)

        wsA.Cells(r, A_CAND_ID).Value = candId

        wsA.Cells(r, A_TEXT).Value = addressText

        wsA.Cells(r, A_KEY).Value = addressKey

        wsA.Cells(r, A_SOURCE).Value = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)

        wsA.Cells(r, A_COPY_PERSON_ID).Value = CleanText(wsIn.Range(CELL_BASE_ID).Value)

        wsA.Cells(r, A_NOTE).Value = CleanText(wsIn.Range(CELL_ADDR_NOTE).Value)

        wsA.Cells(r, A_STATUS).Value = STATUS_ACTIVE

        wsA.Cells(r, A_UPDATED).Value = Now

    Else

        r = NextBlankRow(wsA, 1)

        addrId = NextId("�Z������")

        wsA.Cells(r, A_ID).Value = addrId

        wsA.Cells(r, A_PERSON_ID).Value = personId

        wsA.Cells(r, A_CAND_ID).Value = candId

        wsA.Cells(r, A_TYPE).Value = addrType

        wsA.Cells(r, A_START).Value = startValue

        wsA.Cells(r, A_END).Value = endValue

        wsA.Cells(r, A_TEXT).Value = addressText

        wsA.Cells(r, A_KEY).Value = addressKey

        wsA.Cells(r, A_SOURCE).Value = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)

        wsA.Cells(r, A_COPY_PERSON_ID).Value = CleanText(wsIn.Range(CELL_BASE_ID).Value)

        wsA.Cells(r, A_NOTE).Value = CleanText(wsIn.Range(CELL_ADDR_NOTE).Value)

        wsA.Cells(r, A_STATUS).Value = STATUS_ACTIVE

        wsA.Cells(r, A_CREATED).Value = Now

        wsA.Cells(r, A_UPDATED).Value = Now

    End If

    UpdateRepresentativeAddressId personId

End Sub

Private Function FindMatchingAddressHistoryRow(ByVal personId As String, _
        ByVal addressKey As String, _
        ByVal addrType As String, _
        ByVal startValue As Variant, _
        ByVal endValue As Variant) As Long

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, A_PERSON_ID).Value) = personId _
                And CStr(ws.Cells(r, A_STATUS).Value) <> STATUS_CANCEL _
                And CStr(ws.Cells(r, A_KEY).Value) = addressKey _
                And CleanText(ws.Cells(r, A_TYPE).Value) = addrType _
                And SameDateValueOrBlank(ws.Cells(r, A_START).Value, startValue) _
                And SameDateValueOrBlank(ws.Cells(r, A_END).Value, endValue) Then

            FindMatchingAddressHistoryRow = r

            Exit Function

        End If

    Next r

End Function

Private Function SameDateValueOrBlank(ByVal a As Variant, ByVal b As Variant) As Boolean

    If IsDate(a) Or IsDate(b) Then

        If IsDate(a) And IsDate(b) Then SameDateValueOrBlank = (CLng(CDate(a)) = CLng(CDate(b)))

    Else

        SameDateValueOrBlank = (Len(CleanText(a)) = 0 And Len(CleanText(b)) = 0)

    End If

End Function

Private Function GetOrCreateAddressCandidate(ByVal addressText As String, ByVal addressKey As String, ByVal personId As String) As String

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, AC_KEY).Value) = addressKey Then

            ws.Cells(r, AC_LAST_PERSON).Value = personId

            ws.Cells(r, AC_USE_COUNT).Value = Val(ws.Cells(r, AC_USE_COUNT).Value) + 1

            ws.Cells(r, AC_LAST_USED).Value = Now

            GetOrCreateAddressCandidate = CStr(ws.Cells(r, AC_ID).Value)

            Exit Function

        End If

    Next r

    r = NextBlankRow(ws, 1)

    GetOrCreateAddressCandidate = NextId("�Z�����")

    ws.Cells(r, AC_ID).Value = GetOrCreateAddressCandidate

    ws.Cells(r, AC_TEXT).Value = addressText

    ws.Cells(r, AC_KEY).Value = addressKey

    ws.Cells(r, AC_FIRST_PERSON).Value = personId

    ws.Cells(r, AC_LAST_PERSON).Value = personId

    ws.Cells(r, AC_USE_COUNT).Value = 1

    ws.Cells(r, AC_LAST_USED).Value = Now

End Function

Public Sub AddAddressAndStartNext()
    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, pid As String, addedEnd As Variant

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)

    If Len(CleanText(ws.Range(CELL_ADDR_TEXT).Value)) = 0 Then Err.Raise 5, , "�ǉ�����Z������͂��Ă��������B"

    addedEnd = ws.Range(CELL_ADDR_END).Value

    If Len(pid) = 0 Then
        StageAddressFromInput PendingAddressKeyForInput(True)
        BeginNextAddressForCurrentPerson addedEnd
        SetPersonInputStatus "�Z�������ǉ����܂����B�l����o�^����ƁA���̏Z���������܂Ƃ߂ēo�^����܂��B"
    Else
        RegisterAddressFromInput pid
        RefreshAddressCandidateListOnly
        BeginNextAddressForCurrentPerson addedEnd
        SetPersonInputStatus "�Z��������ǉ����܂����B���̏Z���𑱂��ē��͂ł��܂��B"
    End If
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "AddAddressAndStartNext", "�Z������ǉ�", "�l��ID�E�Z���E�c���J�n���E�I�����̓��͏�Ԃ��m�F���Ă��������B"

End Sub

Public Sub AddAddressForCurrentPerson()
    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, pid As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    pid = CleanText(ws.Range(CELL_PERSON_ID).Value)

    If Len(CleanText(ws.Range(CELL_ADDR_TEXT).Value)) = 0 Then Err.Raise 5, , "�ǉ�����Z������͂��Ă��������B"

    If Len(pid) = 0 Then
        StageAddressFromInput PendingAddressKeyForInput(True)
        SetPersonInputStatus "�Z�������ǉ����܂����B�l����o�^����ƁA���̏Z���������܂Ƃ߂ēo�^����܂��B"
    Else
        RegisterAddressFromInput pid
        RefreshAddressCandidateListOnly
        SetPersonInputStatus "�Z��������ǉ����܂����B"
    End If

    ApplyInputUsability False
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "AddAddressForCurrentPerson", "�Z������ǉ�", "�l��ID�E�Z���E�c���J�n���E�I�����̓��͏�Ԃ��m�F���Ă��������B"

End Sub

Public Sub BeginNextAddressForCurrentPerson(Optional ByVal previousEndDate As Variant)

    On Error Resume Next

    Dim ws As Worksheet, nextStart As Variant

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If IsMissing(previousEndDate) Then previousEndDate = ws.Range(CELL_ADDR_END).Value

    If IsDate(previousEndDate) Then nextStart = DateAdd("d", 1, CDate(previousEndDate))

    ws.Range(CELL_ADDR_CAND & ":" & CELL_ADDR_NOTE).ClearContents

    ws.Range(CELL_ADDR_TYPE).Value = "���Z�n"

    If IsDate(nextStart) Then ws.Range(CELL_ADDR_START).Value = nextStart

    ApplyInputUsability

    ws.Range(CELL_ADDR_TEXT).Select

    On Error GoTo 0

End Sub

Private Function PendingAddressKeyForInput(Optional ByVal createIfMissing As Boolean = True) As String

    Dim ws As Worksheet, k As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    k = CleanText(ws.Range(CELL_PENDING_ADDR_KEY).Value)
    If Len(k) = 0 And createIfMissing Then
        k = "TMP" & Format(Now, "yyyymmddhhmmss") & Format(Int(Rnd() * 10000), "0000")
        ws.Range(CELL_PENDING_ADDR_KEY).Value = k
    End If
    PendingAddressKeyForInput = k

End Function

Private Sub StageAddressFromInput(ByVal pendingKey As String)

    Dim wsIn As Worksheet, wsP As Worksheet, r As Long, addressText As String, addressKey As String
    If Len(pendingKey) = 0 Then Exit Sub
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    Set wsP = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    addressText = CleanText(wsIn.Range(CELL_ADDR_TEXT).Value)
    If Len(addressText) = 0 Then Exit Sub
    addressKey = CleanText(wsIn.Range(CELL_ADDR_KEY).Value)
    If Len(addressKey) = 0 Then addressKey = NormalizeAddress(addressText)
    wsIn.Range(CELL_ADDR_KEY).Value = addressKey
    r = NextBlankRow(wsP, 1)
    wsP.Cells(r, AP_KEY).Value = pendingKey
    wsP.Cells(r, AP_SEQ).Value = PendingAddressCount(pendingKey) + 1
    wsP.Cells(r, AP_ADDR_TEXT).Value = addressText
    wsP.Cells(r, AP_ADDR_KEY).Value = addressKey
    wsP.Cells(r, AP_ADDR_TYPE).Value = IIf(Len(CleanText(wsIn.Range(CELL_ADDR_TYPE).Value)) = 0, "���Z�n", CleanText(wsIn.Range(CELL_ADDR_TYPE).Value))
    wsP.Cells(r, AP_START).Value = SameDateOrBlank(wsIn.Range(CELL_ADDR_START).Value)
    wsP.Cells(r, AP_END).Value = SameDateOrBlank(wsIn.Range(CELL_ADDR_END).Value)
    wsP.Cells(r, AP_SOURCE).Value = CleanText(wsIn.Range(CELL_ADDR_SOURCE).Value)
    wsP.Cells(r, AP_NOTE).Value = CleanText(wsIn.Range(CELL_ADDR_NOTE).Value)
    wsP.Cells(r, AP_COPY_PERSON_ID).Value = CleanText(wsIn.Range(CELL_BASE_ID).Value)
    wsP.Cells(r, AP_CREATED).Value = Now
    wsP.Cells(r, AP_STATUS).Value = STATUS_ACTIVE

End Sub

Private Function PendingAddressCount(ByVal pendingKey As String) As Long

    Dim ws As Worksheet, r As Long
    If Len(pendingKey) = 0 Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, AP_KEY).Value) = pendingKey And CStr(ws.Cells(r, AP_STATUS).Value) = STATUS_ACTIVE Then PendingAddressCount = PendingAddressCount + 1
    Next r

End Function

Private Sub FlushPendingAddressesToPerson(ByVal pendingKey As String, ByVal personId As String)

    Dim wsIn As Worksheet, wsP As Worksheet, r As Long
    If Len(pendingKey) = 0 Or Len(personId) = 0 Then Exit Sub
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)
    Set wsP = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    For r = 2 To LastRow(wsP, 1)
        If CStr(wsP.Cells(r, AP_KEY).Value) = pendingKey And CStr(wsP.Cells(r, AP_STATUS).Value) = STATUS_ACTIVE Then
            wsIn.Range(CELL_ADDR_TEXT).Value = wsP.Cells(r, AP_ADDR_TEXT).Value
            wsIn.Range(CELL_ADDR_KEY).Value = wsP.Cells(r, AP_ADDR_KEY).Value
            wsIn.Range(CELL_ADDR_TYPE).Value = wsP.Cells(r, AP_ADDR_TYPE).Value
            wsIn.Range(CELL_ADDR_START).Value = wsP.Cells(r, AP_START).Value
            wsIn.Range(CELL_ADDR_END).Value = wsP.Cells(r, AP_END).Value
            wsIn.Range(CELL_ADDR_SOURCE).Value = wsP.Cells(r, AP_SOURCE).Value
            wsIn.Range(CELL_ADDR_NOTE).Value = wsP.Cells(r, AP_NOTE).Value
            RegisterAddressFromInput personId
            wsP.Cells(r, AP_STATUS).Value = "�o�^��"
        End If
    Next r
    RefreshAddressCandidateListOnly

End Sub

Private Sub ClearPendingAddresses(ByVal pendingKey As String)

    Dim ws As Worksheet, r As Long
    If Len(pendingKey) = 0 Then Exit Sub
    If Not SheetExists(SH_W_ADDR_PENDING, ThisWorkbook) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_PENDING)
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, AP_KEY).Value) = pendingKey Then ws.Cells(r, AP_STATUS).Value = STATUS_CANCEL
    Next r

End Sub

Public Sub RegisterMarriageFactForBasePerson()

    On Error GoTo EH
    AppBegin
    Dim ws As Worksheet, pid As String, mDate As Variant, dDate As Variant, counterpart As String
    Set ws = ThisWorkbook.Worksheets(SH_INPUT)
    pid = CleanText(ws.Range(CELL_BASE_ID).Value)
    If Len(pid) = 0 Then pid = CleanText(ws.Range(CELL_PERSON_ID).Value)
    If Len(pid) = 0 Then Err.Raise 5, , "����������R�Â���l�����A��l���Ƃ��đI��ł��������B"
    mDate = ws.Range(CELL_MARRIAGE).Value
    dDate = ws.Range(CELL_DIVORCE).Value
    If Not IsDate(mDate) And Not IsDate(dDate) Then Err.Raise 5, , "�������܂��͗���������͂��Ă��������B"
    counterpart = CleanText(Trim(CleanText(ws.Range(CELL_SURNAME).Value) & " " & CleanText(ws.Range(CELL_GIVEN_NAME).Value)))
    If Len(counterpart) = 0 Then counterpart = CleanText(ws.Range(CELL_NOTE).Value)
    If IsDate(mDate) Then UpsertManualTimelineEvent pid, mDate, "����", "����", "��������", "����|" & Format(CDate(mDate), "yyyymmdd")
    If IsDate(dDate) Then
        If Len(counterpart) > 0 Then
            UpsertManualTimelineEvent pid, dDate, "����", "�����F" & counterpart, "��������", "����|" & Format(CDate(dDate), "yyyymmdd") & "|" & counterpart
        Else
            UpsertManualTimelineEvent pid, dDate, "����", "����", "��������", "����|" & Format(CDate(dDate), "yyyymmdd")
        End If
    End If
    RefreshCandidatesAfterPersonRegister pid
    SetPersonInputStatus "�����E�����̎��������n��C�x���g�Ƃ��ēo�^���܂����B"
    AppEnd
    Exit Sub
EH:
    AppEnd
    RuntimeShowError "RegisterMarriageFactForBasePerson", "���������o�^", "��l���A�������E�������A���薼�������m�F���Ă��������B"

End Sub

Private Sub UpsertManualTimelineEvent(ByVal personId As String, _
        ByVal eventDate As Variant, _
        ByVal eventType As String, _
        ByVal content As String, _
        ByVal srcType As String, _
        ByVal srcId As String)

    Dim ws As Worksheet, r As Long
    If Len(personId) = 0 Or Not IsDate(eventDate) Then Exit Sub
    Set ws = ThisWorkbook.Worksheets(SH_W_EVENT)
    For r = 2 To LastRow(ws, 1)
        If CStr(ws.Cells(r, E_PERSON_ID).Value) = personId _
                And IsDate(ws.Cells(r, E_DATE).Value) _
                And CLng(CDate(ws.Cells(r, E_DATE).Value)) = CLng(CDate(eventDate)) _
                And CStr(ws.Cells(r, E_TYPE).Value) = eventType _
                And CStr(ws.Cells(r, E_SOURCE_TYPE).Value) = srcType _
                And CStr(ws.Cells(r, E_SOURCE_ID).Value) = srcId Then
            ws.Cells(r, E_CONTENT).Value = content
            ws.Cells(r, E_AUTO).Value = "�����"
            ws.Cells(r, E_SHOW).Value = SHOW_YES
            ws.Cells(r, E_STATUS).Value = STATUS_ACTIVE
            Exit Sub
        End If
    Next r
    r = NextBlankRow(ws, 1)
    ws.Cells(r, E_ID).Value = NextId("�C�x���g")
    ws.Cells(r, E_PERSON_ID).Value = personId
    ws.Cells(r, E_DATE).Value = eventDate
    ws.Cells(r, E_YEAR).Value = Year(CDate(eventDate))
    ws.Cells(r, E_TYPE).Value = eventType
    ws.Cells(r, E_CONTENT).Value = content
    ws.Cells(r, E_AUTO).Value = "�����"
    ws.Cells(r, E_SOURCE_TYPE).Value = srcType
    ws.Cells(r, E_SOURCE_ID).Value = srcId
    ws.Cells(r, E_SHOW).Value = SHOW_YES
    ws.Cells(r, E_STATUS).Value = STATUS_ACTIVE

End Sub

Public Sub MakeAddressKeyFromInput()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    ws.Range(CELL_ADDR_KEY).Value = NormalizeAddress(ws.Range(CELL_ADDR_TEXT).Value)

End Sub

Public Sub ApplySelectedAddressCandidate()

    Dim ws As Worksheet, sel As String, id As String, r As Long

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    sel = CleanText(ws.Range(CELL_ADDR_CAND).Value)

    If Len(sel) = 0 Then Exit Sub

    If InStr(sel, "��l���Ɠ��l") > 0 Then
        CopyBaseCurrentAddress False
        Exit Sub
    End If

    id = ParseIdFromCandidate(sel)

    r = FindAddressCandidateRow(id)

    If r = 0 Then Exit Sub

    ws.Range(CELL_ADDR_TEXT).Value = ThisWorkbook.Worksheets(SH_W_ADDR_CAND).Cells(r, AC_TEXT).Value

    ws.Range(CELL_ADDR_KEY).Value = ThisWorkbook.Worksheets(SH_W_ADDR_CAND).Cells(r, AC_KEY).Value

End Sub

Public Sub CopyBaseCurrentAddress(Optional ByVal showMessage As Boolean = True)

    Dim ws As Worksheet, baseId As String, addrText As String, addrKey As String

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    baseId = CleanText(ws.Range(CELL_BASE_ID).Value)

    If Len(baseId) = 0 Then Exit Sub

    GetCurrentAddressParts baseId, addrText, addrKey

    If Len(addrText) > 0 Then

        ws.Range(CELL_ADDR_TEXT).Value = addrText

        ws.Range(CELL_ADDR_KEY).Value = addrKey

        If showMessage Then MsgBox "��l���̏Z�����R�s�[���܂����B", vbInformation

    End If

End Sub

Public Sub CopyLastAddress()

    Dim ws As Worksheet, r As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    r = LastRow(ws, AC_LAST_USED)

    If r < 2 Then Exit Sub

    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_TEXT).Value = ws.Cells(r, AC_TEXT).Value

    ThisWorkbook.Worksheets(SH_INPUT).Range(CELL_ADDR_KEY).Value = ws.Cells(r, AC_KEY).Value

End Sub

Public Sub UseMarriageDateAsAddressStart()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If IsDate(ws.Range(CELL_MARRIAGE).Value) Then ws.Range(CELL_ADDR_START).Value = ws.Range(CELL_MARRIAGE).Value

End Sub

Public Sub UseBirthDateAsAddressStart()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If IsDate(ws.Range(CELL_BIRTH).Value) Then ws.Range(CELL_ADDR_START).Value = ws.Range(CELL_BIRTH).Value

End Sub

Public Sub UseDeathDateAsAddressEnd()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If IsDate(ws.Range(CELL_DEATH).Value) Then ws.Range(CELL_ADDR_END).Value = ws.Range(CELL_DEATH).Value

End Sub

Public Sub UseDivorceDateAsAddressEnd()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets(SH_INPUT)

    If IsDate(ws.Range(CELL_DIVORCE).Value) Then ws.Range(CELL_ADDR_END).Value = ws.Range(CELL_DIVORCE).Value

End Sub

Public Function FindAddressCandidateRow(ByVal candId As String) As Long

    Dim ws As Worksheet, r As Long, lastR As Long

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    lastR = LastRow(ws, 1)

    For r = 2 To lastR

        If CStr(ws.Cells(r, AC_ID).Value) = candId Then FindAddressCandidateRow = r: Exit Function

    Next r

End Function

Public Sub GetCurrentAddressParts(ByVal personId As String, ByRef addressText As String, ByRef addressKey As String)

    Dim ws As Worksheet, bestR As Long

    If Len(CleanText(personId)) = 0 Then Exit Sub

    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Sub

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    bestR = BestAddressHistoryRowForPerson(personId)

    If bestR > 0 Then

        addressText = CStr(ws.Cells(bestR, A_TEXT).Value)

        addressKey = CStr(ws.Cells(bestR, A_KEY).Value)

    End If

End Sub

Public Function GetCurrentAddressText(ByVal personId As String) As String

    Dim t As String, k As String

    GetCurrentAddressParts personId, t, k

    GetCurrentAddressText = t

End Function

Public Sub RefreshRepresentativeAddresses()

    On Error Resume Next

    Dim wsP As Worksheet, r As Long, pid As String

    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub

    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)

    For r = 2 To LastRow(wsP, 1)

        pid = CleanText(wsP.Cells(r, P_ID).Value)

        If Len(pid) > 0 And CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            UpdateRepresentativeAddressId pid

        End If

    Next r

    On Error GoTo 0

End Sub

Public Sub UpdateRepresentativeAddressId(ByVal personId As String)

    Dim personRow As Long, bestR As Long

    If Len(CleanText(personId)) = 0 Then Exit Sub

    personRow = FindPersonRow(personId)

    If personRow = 0 Then Exit Sub

    bestR = BestAddressHistoryRowForPerson(personId)

    If bestR > 0 Then

        ThisWorkbook.Worksheets(SH_W_PERSON).Cells(personRow, P_REP_ADDR_ID).Value = _
            ThisWorkbook.Worksheets(SH_W_ADDR_HIST).Cells(bestR, A_ID).Value

    End If

End Sub

Private Function BestAddressHistoryRowForPerson(ByVal personId As String) As Long

    Dim ws As Worksheet, r As Long, lastR As Long

    Dim bestScore As Double, score As Double

    If Not SheetExists(SH_W_ADDR_HIST, ThisWorkbook) Then Exit Function

    Set ws = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    lastR = LastRow(ws, 1)

    bestScore = -1E+20

    For r = 2 To lastR

        If CStr(ws.Cells(r, A_PERSON_ID).Value) = personId _
                And CStr(ws.Cells(r, A_STATUS).Value) <> STATUS_CANCEL _
                And Len(CStr(ws.Cells(r, A_ID).Value)) > 0 Then

            score = AddressRepresentativeScore(ws, r)

            If score > bestScore Then

                bestScore = score

                BestAddressHistoryRowForPerson = r

            End If

        End If

    Next r

End Function

Private Function AddressRepresentativeScore(ByVal ws As Worksheet, ByVal rowNo As Long) As Double

    Dim baseDate As Variant, st As Variant, en As Variant, score As Double

    baseDate = PreferredAddressBaseDate()

    st = ws.Cells(rowNo, A_START).Value

    en = ws.Cells(rowNo, A_END).Value

    score = rowNo

    If CleanText(ws.Cells(rowNo, A_TYPE).Value) = "���Z�n" Then score = score + 100000

    If IsDate(st) Then score = score + CDbl(CDate(st)) / 100

    If IsDate(baseDate) Then

        If IsDate(st) Then

            If CDate(st) <= CDate(baseDate) Then score = score + 200000 Else score = score - 50000

        End If

        If IsDate(en) Then

            If CDate(en) >= CDate(baseDate) Then score = score + 200000 Else score = score - 20000

        Else

            score = score + 150000

        End If

    ElseIf Not IsDate(en) Then

        score = score + 50000

    End If

    AddressRepresentativeScore = score

End Function

Private Function PreferredAddressBaseDate() As Variant

    On Error Resume Next

    PreferredAddressBaseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_INHERIT_DATE).Value

    If Not IsDate(PreferredAddressBaseDate) Then _
        PreferredAddressBaseDate = ThisWorkbook.Worksheets(SH_CONFIG).Range(CELL_CONFIG_BASE_DATE).Value

    If Not IsDate(PreferredAddressBaseDate) Then PreferredAddressBaseDate = Date

    On Error GoTo 0

End Function

Private Sub EnsureCandidatesWarmForInputMode()

    '���̓��[�h�ؑւ̃z�b�g�p�X�ł͌��S�Đ����𑖂点�Ȃ��B
    '���V�[�g�����\�z�E��̏ꍇ�����A�C���Ƃ��Ĉ�x�����č\�z����B
    On Error GoTo EH
    Dim wsC As Worksheet
    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    If LastRow(wsC, 4) < 2 And LastRow(ThisWorkbook.Worksheets(SH_W_PERSON), 1) >= 2 Then
        RefreshCandidates
    End If
    Exit Sub
EH:
    RuntimeAppendLog "WARN", "EnsureCandidatesWarmForInputMode", "��≷��", "���͐ؑ�", Err.Number, Err.Description, Err.Source
    Err.Clear

End Sub

Public Sub RefreshCandidates()

    Dim wsC As Worksheet, wsP As Worksheet, wsA As Worksheet, r As Long, outR As Long, dict As Object, key As Variant

    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)

    wsC.Range("A2:N" & Application.Max(500, LastRow(wsC, 1), LastRow(wsC, 2), LastRow(wsC, 4), LastRow(wsC, 12))).ClearContents

    Set dict = CreateObject("Scripting.Dictionary")

    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)

    For r = 2 To LastRow(wsP, 1)

        If CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            If Len(CStr(wsP.Cells(r, P_SURNAME).Value)) > 0 Then dict(CStr(wsP.Cells(r, P_SURNAME).Value)) = 1

            If Len(CStr(wsP.Cells(r, P_FORMER).Value)) > 0 Then dict(CStr(wsP.Cells(r, P_FORMER).Value)) = 1

        End If

    Next r

    outR = 2

    For Each key In dict.Keys

        wsC.Cells(outR, 1).Value = key

        outR = outR + 1

    Next key

    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    outR = 2
    wsC.Cells(outR, 2).Value = "��l���Ɠ��l"
    wsC.Cells(outR, 3).Value = "__BASE__"
    outR = outR + 1
    For r = 2 To LastRow(wsA, 1)

        If Len(CStr(wsA.Cells(r, AC_ID).Value)) > 0 Then

            wsC.Cells(outR, 2).Value = wsA.Cells(r, AC_ID).Value & " " & wsA.Cells(r, AC_TEXT).Value

            wsC.Cells(outR, 3).Value = wsA.Cells(r, AC_ID).Value

            outR = outR + 1

        End If

    Next r

    outR = 2
    For r = 2 To LastRow(wsP, 1)

        If Len(CStr(wsP.Cells(r, P_ID).Value)) > 0 And CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            wsC.Cells(outR, 4).Value = wsP.Cells(r, P_ID).Value & " " & wsP.Cells(r, P_DISPLAY).Value & "�i" & wsP.Cells(r, P_REL_DEC).Value & "�j"

            wsC.Cells(outR, 5).Value = wsP.Cells(r, P_ID).Value

            outR = outR + 1

        End If

    Next r

    FillStaticCandidates wsC

    FillDateCandidates wsC

    CompactCandidateColumn wsC, 1
    CompactCandidatePairColumns wsC, 2, 3
    CompactCandidatePairColumns wsC, 4, 5
    CompactCandidateColumn wsC, 12
    CompactCandidateColumn wsC, 13
    CompactCandidateColumn wsC, 14

End Sub

Private Sub RefreshAddressCandidateListOnly()

    '�Z���ǉ���̃z�b�g�p�X�ł́A�l��������t���܂ō�蒼���Ȃ��B
    '�Z�����񂾂����X�V���A�o�^����̌y���Ɠ��͌��̈ێ��𗼗�����B
    Dim wsC As Worksheet, wsA As Worksheet, r As Long, clearLast As Long, outR As Long

    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_CAND)

    clearLast = Application.Max(500, LastRow(wsC, 2), LastRow(wsC, 3), LastRow(wsA, 1))
    wsC.Range("B2:C" & clearLast).ClearContents

    outR = 2
    wsC.Cells(outR, 2).Value = "��l���Ɠ��l"
    wsC.Cells(outR, 3).Value = "__BASE__"
    outR = outR + 1
    For r = 2 To LastRow(wsA, 1)

        If Len(CStr(wsA.Cells(r, AC_ID).Value)) > 0 Then

            wsC.Cells(outR, 2).Value = wsA.Cells(r, AC_ID).Value & " " & wsA.Cells(r, AC_TEXT).Value
            wsC.Cells(outR, 3).Value = wsA.Cells(r, AC_ID).Value
            outR = outR + 1

        End If

    Next r

    CompactCandidatePairColumns wsC, 2, 3

End Sub

Private Sub RefreshCandidatesAfterPersonRegister(ByVal personId As String)

    '�l���o�^����̃z�b�g�p�X�ł� W_��� �S�̂������č�蒼���Ȃ��B
    '���E�l�����E�Z�����E������͂������t�������������f����B
    On Error GoTo EH

    Dim wsC As Worksheet, wsP As Worksheet, wsIn As Worksheet
    Dim pr As Long, candidateText As String

    If Len(personId) = 0 Then Exit Sub

    Set wsC = ThisWorkbook.Worksheets(SH_W_CAND)
    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)
    Set wsIn = ThisWorkbook.Worksheets(SH_INPUT)

    pr = FindPersonRow(personId)
    If pr > 0 Then
        AddCandidateTextUnique wsC, 1, CStr(wsP.Cells(pr, P_SURNAME).Value), 0
        AddCandidateTextUnique wsC, 1, CStr(wsP.Cells(pr, P_FORMER).Value), 0
        candidateText = CStr(wsP.Cells(pr, P_ID).Value) & " " & _
            CStr(wsP.Cells(pr, P_DISPLAY).Value) & "�i" & CStr(wsP.Cells(pr, P_REL_DEC).Value) & "�j"
        UpsertPersonCandidate wsC, CStr(wsP.Cells(pr, P_ID).Value), candidateText
    End If

    RefreshAddressCandidateListOnly
    AddDateCandidateToColumnUnique wsC, 12, wsIn.Range(CELL_MARRIAGE).Value, 0
    AddDateCandidateToColumnUnique wsC, 13, wsIn.Range(CELL_DIVORCE).Value, 0
    AddDateCandidateToColumnUnique wsC, 14, wsIn.Range(CELL_BIRTH).Value, 0
    AddDateCandidateToColumnUnique wsC, 14, wsIn.Range(CELL_DEATH).Value, 0
    AddDateCandidateToColumnUnique wsC, 14, wsIn.Range(CELL_ADDR_START).Value, 0
    AddDateCandidateToColumnUnique wsC, 14, wsIn.Range(CELL_ADDR_END).Value, 0
    Exit Sub

EH:
    RuntimeAppendLog "WARN", "RefreshCandidatesAfterPersonRegister", "��⍷���X�V", personId, Err.Number, Err.Description, Err.Source
    Err.Clear

End Sub

Private Sub UpsertPersonCandidate(ByVal wsC As Worksheet, ByVal personId As String, ByVal candidateText As String)

    Dim r As Long, firstBlank As Long
    personId = CleanText(personId)
    candidateText = CleanText(candidateText)
    If Len(personId) = 0 Or Len(candidateText) = 0 Then Exit Sub

    Dim maxRow As Long
    maxRow = Application.Max(LastRow(wsC, 4) + 50, LastRow(wsC, 5) + 50, 500)
    For r = 2 To maxRow
        If CleanText(wsC.Cells(r, 5).Value) = personId Then
            wsC.Cells(r, 4).Value = candidateText
            wsC.Cells(r, 5).Value = personId
            Exit Sub
        End If
        If firstBlank = 0 Then
            If Len(CleanText(wsC.Cells(r, 4).Value)) = 0 And Len(CleanText(wsC.Cells(r, 5).Value)) = 0 Then firstBlank = r
        End If
    Next r

    If firstBlank > 0 Then
        wsC.Cells(firstBlank, 4).Value = candidateText
        wsC.Cells(firstBlank, 5).Value = personId
    End If

End Sub

Private Sub AddCandidateTextUnique(ByVal wsC As Worksheet, ByVal colNum As Long, ByVal textValue As String, ByVal maxRow As Long)

    Dim r As Long, firstBlank As Long, v As String
    v = CleanText(textValue)
    If Len(v) = 0 Then Exit Sub
    If maxRow < 2 Then maxRow = Application.Max(LastRow(wsC, colNum) + 50, 500)

    For r = 2 To maxRow
        If StrComp(CleanText(wsC.Cells(r, colNum).Value), v, vbTextCompare) = 0 Then Exit Sub
        If firstBlank = 0 And Len(CleanText(wsC.Cells(r, colNum).Value)) = 0 Then firstBlank = r
    Next r

    If firstBlank > 0 Then wsC.Cells(firstBlank, colNum).Value = v

End Sub

Private Sub AddDateCandidateToColumnUnique(ByVal wsC As Worksheet, ByVal colNum As Long, ByVal dateValue As Variant, ByVal maxRow As Long)

    Dim r As Long, firstBlank As Long, serialValue As Long
    If Not IsDate(dateValue) Then Exit Sub
    If maxRow < 2 Then maxRow = Application.Max(LastRow(wsC, colNum) + 50, 500)
    serialValue = CLng(DateValue(CDate(dateValue)))

    For r = 2 To maxRow
        If IsDate(wsC.Cells(r, colNum).Value) Then
            If CLng(DateValue(CDate(wsC.Cells(r, colNum).Value))) = serialValue Then Exit Sub
        End If
        If firstBlank = 0 And Len(CleanText(wsC.Cells(r, colNum).Value)) = 0 Then firstBlank = r
    Next r

    If firstBlank > 0 Then
        wsC.Cells(firstBlank, colNum).Value = CDate(dateValue)
        wsC.Cells(firstBlank, colNum).NumberFormatLocal = "yyyy/m/d"
    End If

End Sub

Private Sub CompactCandidateColumn(ByVal wsC As Worksheet, ByVal colNum As Long)

    Dim lastR As Long, r As Long, outR As Long, values As Collection, v As Variant
    If wsC Is Nothing Then Exit Sub
    lastR = LastRow(wsC, colNum)
    If lastR < 2 Then Exit Sub

    Set values = New Collection
    For r = 2 To lastR
        If Len(CleanText(wsC.Cells(r, colNum).Value)) > 0 Then values.Add wsC.Cells(r, colNum).Value
    Next r

    wsC.Range(wsC.Cells(2, colNum), wsC.Cells(lastR, colNum)).ClearContents
    outR = 2
    For Each v In values
        wsC.Cells(outR, colNum).Value = v
        outR = outR + 1
    Next v

End Sub

Private Sub CompactCandidatePairColumns(ByVal wsC As Worksheet, ByVal displayCol As Long, ByVal idCol As Long)

    Dim lastR As Long, r As Long, outR As Long
    Dim displayValues As Collection, idValues As Collection

    If wsC Is Nothing Then Exit Sub
    lastR = Application.Max(LastRow(wsC, displayCol), LastRow(wsC, idCol))
    If lastR < 2 Then Exit Sub

    Set displayValues = New Collection
    Set idValues = New Collection
    For r = 2 To lastR
        If Len(CleanText(wsC.Cells(r, displayCol).Value)) > 0 Or Len(CleanText(wsC.Cells(r, idCol).Value)) > 0 Then
            displayValues.Add wsC.Cells(r, displayCol).Value
            idValues.Add wsC.Cells(r, idCol).Value
        End If
    Next r

    wsC.Range(wsC.Cells(2, displayCol), wsC.Cells(lastR, idCol)).ClearContents
    outR = 2
    For r = 1 To displayValues.Count
        wsC.Cells(outR, displayCol).Value = displayValues(r)
        wsC.Cells(outR, idCol).Value = idValues(r)
        outR = outR + 1
    Next r

End Sub

Private Sub FillDateCandidates(ByVal wsC As Worksheet)

    Dim dictM As Object, dictD As Object, dictA As Object

    Dim wsR As Worksheet, wsP As Worksheet, wsA As Worksheet, r As Long, key As Variant, outR As Long

    Set dictM = CreateObject("Scripting.Dictionary")

    Set dictD = CreateObject("Scripting.Dictionary")

    Set dictA = CreateObject("Scripting.Dictionary")

    Set wsR = ThisWorkbook.Worksheets(SH_W_REL)

    For r = 2 To LastRow(wsR, 1)

        If CStr(wsR.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then

            AddDateCandidate dictM, wsR.Cells(r, R_MARRIAGE).Value

            AddDateCandidate dictA, wsR.Cells(r, R_MARRIAGE).Value

            AddDateCandidate dictD, wsR.Cells(r, R_DIVORCE).Value

            AddDateCandidate dictA, wsR.Cells(r, R_DIVORCE).Value

        End If

    Next r

    Set wsP = ThisWorkbook.Worksheets(SH_W_PERSON)

    For r = 2 To LastRow(wsP, 1)

        If CStr(wsP.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then

            AddDateCandidate dictA, wsP.Cells(r, P_BIRTH).Value

            AddDateCandidate dictA, wsP.Cells(r, P_DEATH).Value

        End If

    Next r

    Set wsA = ThisWorkbook.Worksheets(SH_W_ADDR_HIST)

    For r = 2 To LastRow(wsA, 1)

        If CStr(wsA.Cells(r, A_STATUS).Value) <> STATUS_CANCEL Then

            AddDateCandidate dictA, wsA.Cells(r, A_START).Value

            AddDateCandidate dictA, wsA.Cells(r, A_END).Value

        End If

    Next r

    outR = 2

    For Each key In dictM.Keys

        wsC.Cells(outR, 12).Value = CDate(dictM(key))

        outR = outR + 1

    Next key

    outR = 2

    For Each key In dictD.Keys

        wsC.Cells(outR, 13).Value = CDate(dictD(key))

        outR = outR + 1

    Next key

    outR = 2

    For Each key In dictA.Keys

        wsC.Cells(outR, 14).Value = CDate(dictA(key))

        outR = outR + 1

    Next key

    wsC.Range("L2:N500").NumberFormatLocal = "yyyy/m/d"

End Sub

Private Sub AddDateCandidate(ByVal dict As Object, ByVal v As Variant)

    If IsDate(v) Then dict(Format(CDate(v), "yyyy/mm/dd")) = CDate(v)

End Sub

Private Sub FillStaticCandidates(ByVal wsC As Worksheet)

    Dim arr, i As Long

    arr = Array("�ː�", "�ːЕ��[", "�Z���[", "�\�q", "���Z����", "���̑�")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 6).Value = arr(i)
    Next i

    arr = Array("���E", "��Ј�", "��Ж���", "���c��", "������", "�N��", "���̑�")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 7).Value = arr(i)
    Next i

    arr = Array("�푊���l", "�z���", "��", "��", "���j", "��j", "�O�j", "����", "��", "�O��", "�q", "��", "�Z", "��", "�o", "��", "�֌W��")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 8).Value = arr(i)
    Next i

    arr = Array("���Z�n", "�Z���[�Z��", "������", "�{��", "���̑�")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 9).Value = arr(i)
    Next i

    arr = Array("�j", "��", "�s��")
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 10).Value = arr(i)
    Next i

    arr = Array(SHOW_YES, SHOW_NO)
    For i = 0 To UBound(arr)
        wsC.Cells(2 + i, 11).Value = arr(i)
    Next i

End Sub


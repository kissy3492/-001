# -*- coding: utf-8 -*-
"""
リンク管理 - 単体ローカルアプリ
SharePoint / OneDrive / Web / ローカルファイルのリンクを集め、整理し、確認するためのツール。
"""
import os
import re
import csv
import json
import time
import uuid
import html
import hmac
import shutil
import ctypes
import pathlib
import webbrowser
import threading
import subprocess
import urllib.parse
import urllib.request
import urllib.error
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

APP_TITLE = "リンク管理"
APP_VERSION = "10.1.1"
HOST = "127.0.0.1"
URL_RE = re.compile(r"(?i)\b(?:(?:https?|ftp|file)://|(?:ms-word|ms-excel|ms-powerpoint|ms-visio|onenote|msteams|ms-teams|mailto|tel|webcal|slack|zoommtg|odopen):)[^\s<>'\"\u3000】』]+")
# 引用されたパスは空白・日本語をそのまま許可。通常文中のパスは、説明文や次のURLの手前で止めます。
# `C:\\...` と `C:/...` の両方を対象にします。
WIN_PATH_RE = re.compile(
    r'''(?ix)(?:
        (?<=")(?:[a-z]:[\\/]|\\\\[^\\/\s"]+[\\/][^\\/\s"]+)[^"\r\n<>|]*(?=")
      | (?<=')(?:[a-z]:[\\/]|\\\\[^\\/\s']+[\\/][^\\/\s']+)[^'\r\n<>|]*(?=')
      | (?<![a-z0-9])(?:[a-z]:[\\/]|\\\\[^\s\\/]+[\\/][^\s\\/]+)(?:(?!\s+(?:https?://|ftp://|file://|[^\x00-\x7f]))[^\r\n\t<>"|])*
    )'''
)
CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0

DEV_EXTS = {'.py', '.pyw', '.ipynb', '.ps1', '.bat', '.cmd', '.vbs', '.js', '.ts', '.tsx', '.jsx'}
DEV_WORDS = [
    'site-packages', '__pycache__', '\\venv\\', '\\.venv\\', '\\env\\', '\\node_modules\\',
    'python.exe', 'pythonw.exe', 'powershell.exe', 'cmd.exe', 'code.exe', 'cursor.exe', 'pycharm',
]

SHAREPOINT_WORDS = ['sharepoint.com', 'sharepoint-df.com']
ONEDRIVE_WORDS = ['onedrive.live.com', '1drv.ms', '-my.sharepoint.com']
CLOUD_WORDS = ['drive.google.com', 'docs.google.com', 'dropbox.com', 'box.com', 'icloud.com']

OFFICE_EXT_SCHEME = {
    '.doc':'ms-word', '.docx':'ms-word', '.docm':'ms-word', '.dot':'ms-word', '.dotx':'ms-word', '.rtf':'ms-word',
    '.xls':'ms-excel', '.xlsx':'ms-excel', '.xlsm':'ms-excel', '.xlsb':'ms-excel', '.csv':'ms-excel',
    '.ppt':'ms-powerpoint', '.pptx':'ms-powerpoint', '.pptm':'ms-powerpoint',
    '.vsd':'ms-visio', '.vsdx':'ms-visio', '.vsdm':'ms-visio', '.one':'onenote'
}
BROWSER_NAMES = {
    'edge': ['msedge.exe','msedge'],
    'chrome': ['chrome.exe','chrome'],
    'firefox': ['firefox.exe','firefox'],
    'brave': ['brave.exe','brave'],
}

def now_text():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def compact_now():
    return datetime.now().strftime('%Y%m%d_%H%M%S')


def home_documents():
    docs = pathlib.Path.home() / 'Documents'
    if docs.exists():
        return docs
    return pathlib.Path.home()


def default_save_dir():
    p = home_documents() / 'リンク管理'
    p.mkdir(parents=True, exist_ok=True)
    return p


def default_data_file():
    # 通常使用ではこの1ファイルに自動保存します。明示的な出力は別途ボタンで作成します。
    return default_save_dir() / 'リンク管理データ.linkbook.json'


def unwrap_office_protocol(u):
    u = clean_text(u)
    m = re.match(r'(?i)^(ms-word|ms-excel|ms-powerpoint|ms-visio):(?:ofe|ofv)\|u\|(.+)$', u)
    if m:
        return clean_url(m.group(2))
    if u.lower().startswith('onenote:') and len(u) > 8:
        return clean_url(u.split(':', 1)[1])
    return u


def is_cloud_sync_path(path_text):
    p = clean_text(path_text).lower().replace('/', '\\')
    if not p:
        return False
    names = ['onedrive', 'sharepoint', 'teams', 'dropbox', 'google drive', 'box']
    envs = [os.environ.get('OneDrive'), os.environ.get('OneDriveCommercial'), os.environ.get('OneDriveConsumer')]
    if any(e and p.startswith(clean_text(e).lower().replace('/', '\\')) for e in envs):
        return True
    return any(name in p for name in names)


def clean_text(s):
    if s is None:
        return ''
    s = str(s).replace('\x00', '').strip()
    return s


def clean_zone_name(value):
    """Normalize a user-facing zone name without restricting Japanese or symbols."""
    return re.sub(r'\s+', ' ', clean_text(value)).strip()


def zone_name_key(value):
    return clean_zone_name(value).casefold()


def clean_url(u):
    u = clean_text(u)
    # 外側の引用符・山括弧だけを外します。URL中の正当な括弧は保持します。
    u = u.strip(' \t\r\n\x00')
    pairs = {'"': '"', "'": "'", '<': '>'}
    if len(u) >= 2 and u[0] in pairs and u[-1] == pairs[u[0]]:
        u = u[1:-1].strip()
    # 文末の区切りだけ外し、URLとして正当な ? / ! は保持します。
    while u and u[-1] in '.,;、。，；':
        u = u[:-1]
    for opening, closing in [('(', ')'), ('（', '）'), ('[', ']'), ('【', '】')]:
        while u.endswith(closing) and u.count(closing) > u.count(opening):
            u = u[:-len(closing)]
    return u


def is_url(u):
    return bool(re.match(r'(?i)^((https?|ftp|file)://|(ms-word|ms-excel|ms-powerpoint|ms-visio|onenote|msteams|ms-teams|mailto|tel|webcal|slack|zoommtg|odopen):)', clean_text(u)))


def is_supported_target(u):
    """登録・起動・出力してよいリンク形式だけを通します。"""
    u = clean_text(u)
    return bool(u) and (is_url(u) or looks_like_path(u))


def is_preservable_custom_target(u):
    """旧データの独自アプリURLを、危険な形式だけ除外して保持します。"""
    match = re.match(r'(?i)^([a-z][a-z0-9+.-]{1,31}):', clean_text(u))
    if not match:
        return False
    blocked = {'javascript', 'data', 'vbscript', 'about', 'blob', 'view-source', 'shell', 'powershell', 'cmd'}
    return match.group(1).lower() not in blocked


def to_file_url(path):
    try:
        return pathlib.Path(path).resolve().as_uri()
    except Exception:
        return 'file:///' + str(path).replace('\\', '/')


def looks_like_path(s):
    s = clean_text(s).strip('"')
    return bool(re.match(r'(?i)^[a-z]:[\\/]', s)) or s.startswith(('\\\\', '//'))


def looks_like_web_address(s):
    """Return True for a hostname pasted without http(s)://.

    A bare host is common when copying from Office or an address bar.  It must
    not contain spaces and must have either a familiar host prefix or a dotted
    DNS name.  Windows drive paths are excluded before this function is used.
    """
    s = clean_text(s).strip('"')
    if not s or any(ch.isspace() for ch in s):
        return False
    head = s.split('/', 1)[0].split('?', 1)[0].split('#', 1)[0]
    if head.lower().startswith('www.'):
        return True
    return bool(re.fullmatch(r'(?i)(?:[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?\.)+[a-z]{2,63}(?::\d{1,5})?', head))


def normalize_input_to_url(s):
    s = clean_text(s).strip('"')
    if not s:
        return ''
    if is_url(s):
        return clean_url(s)
    if looks_like_path(s):
        return to_file_url(os.path.expandvars(s))
    if looks_like_web_address(s):
        return clean_url('https://' + s)
    return s


def safe_identifier(value):
    value = clean_text(value)
    if re.fullmatch(r'[A-Za-z0-9_-]{6,64}', value):
        return value
    return ''


def link_identity_key(value):
    """Deduplicate without lowercasing case-sensitive URL paths/queries."""
    value = normalize_input_to_url(value)
    if not value:
        return ''
    if value.lower().startswith('file://') or looks_like_path(value):
        path = os.path.normpath(url_to_path(value))
        return 'file:' + (os.path.normcase(path) if os.name == 'nt' else path)
    try:
        p = urllib.parse.urlsplit(value)
        if p.scheme.lower() in ('http', 'https', 'ftp'):
            return urllib.parse.urlunsplit((p.scheme.lower(), p.netloc.lower(), p.path, p.query, p.fragment))
        if p.scheme:
            return p.scheme.lower() + ':' + value.split(':', 1)[1]
    except Exception:
        pass
    return value


def url_to_path(u):
    u = clean_text(u)
    if u.lower().startswith('file://'):
        try:
            parsed = urllib.parse.urlparse(u)
            path = urllib.request.url2pathname(parsed.path)
            # file://server/share/file.txt は UNC パスです。netloc を捨てると
            # /share/file.txt のように壊れるため、共有名を保持します。
            if parsed.netloc:
                if os.name == 'nt':
                    return '\\\\' + parsed.netloc + path.replace('/', '\\')
                return '//' + parsed.netloc + path
            return path
        except Exception:
            return u[7:]
    return u


def host_of_url(u):
    try:
        return urllib.parse.urlparse(u).netloc.lower()
    except Exception:
        return ''


def classify_link(u):
    u = clean_text(u)
    low = u.lower()
    host = host_of_url(u)
    if not u:
        return '未分類'
    if low.startswith(('ms-word:', 'ms-excel:', 'ms-powerpoint:', 'ms-visio:', 'onenote:')):
        return 'Office起動リンク'
    if low.startswith(('msteams:', 'ms-teams:')):
        return 'Teams'
    if low.startswith('mailto:'):
        return 'メール'
    if low.startswith(('slack:', 'zoommtg:')):
        return 'アプリ起動リンク'
    if low.startswith('file://') or looks_like_path(u):
        p = url_to_path(u)
        if is_cloud_sync_path(p):
            return 'OneDrive'
        try:
            return 'フォルダ' if pathlib.Path(p).is_dir() else 'ファイル'
        except Exception:
            return 'ファイル'
    if any(w in host for w in SHAREPOINT_WORDS):
        if any(w in host for w in ONEDRIVE_WORDS):
            return 'OneDrive'
        return 'SharePoint'
    if any(w in host for w in ONEDRIVE_WORDS):
        return 'OneDrive'
    if any(w in host for w in CLOUD_WORDS):
        return 'クラウド'
    if low.startswith(('http://', 'https://')):
        return 'Web'
    return '未分類'


def title_from_url(u):
    u = clean_text(u)
    if not u:
        return ''
    if u.lower().startswith('file://') or looks_like_path(u):
        p = pathlib.Path(url_to_path(u))
        return p.name or str(p)
    try:
        parsed = urllib.parse.urlparse(u)
        path_name = pathlib.PurePosixPath(urllib.parse.unquote(parsed.path)).name
        if path_name:
            return path_name[:120]
        return parsed.netloc or u[:120]
    except Exception:
        return u[:120]


def should_exclude_dev(text):
    low = clean_text(text).lower()
    if not low:
        return False
    for w in DEV_WORDS:
        if w.lower() in low:
            return True
    if looks_like_path(low) or low.startswith('file://'):
        p = pathlib.Path(url_to_path(low))
        if p.suffix.lower() in DEV_EXTS:
            return True
    return False


def is_probable_tab_url(u):
    u = clean_url(urllib.parse.unquote(clean_text(u)))
    if not u or len(u) > 4096:
        return False
    if any(ch in u for ch in ('\r', '\n', '\t', '\x00')):
        return False
    if not re.match(r'(?i)^https?://', u):
        return False
    low = u.lower()
    if low.startswith(('http://localhost', 'https://localhost', 'http://127.', 'https://127.')):
        return False
    if any(low.endswith(ext) for ext in ('.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.css', '.js', '.map', '.ico', '.woff', '.woff2')):
        return False
    return True


def split_tags(s):
    if isinstance(s, list):
        return [clean_text(x) for x in s if clean_text(x)]
    return [x.strip() for x in re.split(r'[,、\s]+', clean_text(s)) if x.strip()]


def spreadsheet_safe(value):
    """Prevent CSV/XLSX cells from being interpreted as formulas."""
    value = clean_text(value)
    if value.lstrip().startswith(('=', '+', '-', '@', '\t', '\r')):
        return "'" + value
    return value


def run_powershell_json(script, timeout=15):
    if os.name != 'nt':
        return []
    exe = shutil.which('powershell.exe') or shutil.which('powershell')
    if not exe:
        return []
    try:
        cp = subprocess.run(
            [exe, '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', script],
            capture_output=True, text=True, encoding='utf-8', errors='ignore', timeout=timeout,
            creationflags=CREATE_NO_WINDOW
        )
        out = (cp.stdout or '').strip()
        if not out:
            return []
        data = json.loads(out)
        if isinstance(data, dict):
            return [data]
        if isinstance(data, list):
            return data
    except Exception:
        return []
    return []


_LAUNCH_RESULT = threading.local()


def _remember_launch(ok, target, method='', message=''):
    result = {
        'ok': bool(ok),
        'target': clean_text(target),
        'method': clean_text(method),
        'message': clean_text(message),
    }
    _LAUNCH_RESULT.value = result
    return bool(ok)


def last_launch_result():
    value = getattr(_LAUNCH_RESULT, 'value', None)
    if isinstance(value, dict):
        return dict(value)
    return {'ok': False, 'target': '', 'method': '', 'message': '起動結果を確認できませんでした。'}


def _windows_shell_open(target):
    """Open through the Windows shell and verify ShellExecute's return code."""
    try:
        fn = ctypes.windll.shell32.ShellExecuteW
        fn.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_wchar_p,
                       ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_int]
        fn.restype = ctypes.c_ssize_t
        code = int(fn(None, 'open', target, None, None, 1))
        if code > 32:
            return True, ''
        messages = {
            2: 'ファイルが見つかりません。', 3: '保存場所が見つかりません。',
            5: '開く権限がありません。', 8: '起動に必要なメモリが不足しています。',
            26: '共有先に接続できません。', 27: '関連付けられたアプリを確認できません。',
            31: 'この種類を開くアプリが関連付けられていません。',
        }
        return False, messages.get(code, f'Windowsの起動処理が失敗しました（コード {code}）。')
    except Exception as e:
        return False, f'Windowsの起動処理を実行できませんでした: {e}'


def open_path_or_url(target):
    """Reliably open a URL/path and retain a user-facing diagnostic.

    ``webbrowser.open`` may return False without raising.  The former code
    ignored that result and reported success even when nothing opened.  On
    Windows we now use ShellExecute first, which also survives long-idle Edge
    sessions better than a cached ``webbrowser`` controller.
    """
    original = clean_text(target)
    target = normalize_input_to_url(original)
    if not target:
        return _remember_launch(False, original, message='開くリンクが空です。')
    if not is_url(target) and not looks_like_path(target):
        return _remember_launch(False, target, message='URLまたはファイルパスとして認識できません。')

    launch_target = target
    if target.lower().startswith('file://'):
        launch_target = url_to_path(target)
    elif looks_like_path(target):
        launch_target = os.path.expandvars(target)

    if (target.lower().startswith('file://') or looks_like_path(target)) and not pathlib.Path(launch_target).exists():
        return _remember_launch(False, target, message='ファイルまたはフォルダが見つかりません。')

    if os.name == 'nt':
        ok, message = _windows_shell_open(launch_target)
        if ok:
            return _remember_launch(True, target, 'Windows')
        # HTTP(S)だけは、関連付け不良時にEdgeを明示起動して救済します。
        if re.match(r'(?i)^https?://', target):
            exe = find_browser_exe('edge')
            if exe:
                try:
                    subprocess.Popen([exe, target], creationflags=CREATE_NO_WINDOW)
                    return _remember_launch(True, target, 'Edge')
                except Exception as e:
                    message = f'{message} Edgeも起動できませんでした: {e}'
        return _remember_launch(False, target, 'Windows', message)

    browser_target = to_file_url(launch_target) if looks_like_path(launch_target) else target
    try:
        opened = bool(webbrowser.open(browser_target, new=2))
        return _remember_launch(opened, target, '既定のブラウザ', '' if opened else '既定のブラウザが起動要求を受け付けませんでした。')
    except Exception as e:
        return _remember_launch(False, target, '既定のブラウザ', f'開けませんでした: {e}')


def start_custom_url(target):
    return open_path_or_url(target)


def parsed_url(u):
    try:
        return urllib.parse.urlparse(clean_text(u))
    except Exception:
        return urllib.parse.urlparse('')


def url_ext(u):
    u = clean_text(u)
    if u.lower().startswith('file://') or looks_like_path(u):
        try:
            return pathlib.Path(url_to_path(u)).suffix.lower()
        except Exception:
            return ''
    try:
        path = urllib.parse.unquote(parsed_url(u).path)
        return pathlib.Path(path).suffix.lower()
    except Exception:
        return ''


def guess_office_scheme_for_url(u):
    u = unwrap_office_protocol(normalize_input_to_url(u))
    low = urllib.parse.unquote(clean_text(u)).lower()
    ext = url_ext(low)
    if ext in OFFICE_EXT_SCHEME:
        return OFFICE_EXT_SCHEME[ext]
    # SharePoint の共有リンクは .xlsx などの拡張子が出ない形があるため、
    # URLの形からOfficeアプリを軽く推定します。推定できない場合は空にします。
    if any(x in low for x in ('/:x:/', '/x/_layouts/', 'xlviewer.aspx', 'excel.aspx', 'excel.officeapps.live.com', 'excel.office.com')):
        return 'ms-excel'
    if any(x in low for x in ('/:w:/', '/w/_layouts/', 'wordviewer.aspx', 'word.aspx', 'word-edit.officeapps.live.com', 'word.office.com')):
        return 'ms-word'
    if any(x in low for x in ('/:p:/', '/p/_layouts/', 'powerpoint.aspx', 'powerpoint.officeapps.live.com', 'powerpoint.office.com')):
        return 'ms-powerpoint'
    if any(x in low for x in ('visio', '.vsdx', '.vsdm')):
        return 'ms-visio'
    if 'onenote' in low or '.one' in low:
        return 'onenote'
    return ''


def build_specific_office_desktop_url(u, scheme='ms-excel', view=False):
    u = unwrap_office_protocol(normalize_input_to_url(u))
    scheme = clean_text(scheme or '').lower()
    if not u or not scheme:
        return ''
    if scheme == 'onenote':
        return f'onenote:{u}'
    if scheme not in ('ms-word', 'ms-excel', 'ms-powerpoint', 'ms-visio'):
        return ''
    return f'{scheme}:{"ofv" if view else "ofe"}|u|{u}'


def build_office_desktop_url(u):
    scheme = guess_office_scheme_for_url(u)
    if not scheme:
        return ''
    return build_specific_office_desktop_url(u, scheme, view=False)


def build_office_desktop_view_url(u):
    scheme = guess_office_scheme_for_url(u)
    if not scheme:
        return ''
    return build_specific_office_desktop_url(u, scheme, view=True)


def find_browser_exe(browser):
    browser = clean_text(browser or 'edge').lower()
    names = BROWSER_NAMES.get(browser, BROWSER_NAMES['edge'])
    candidates = []
    if os.name == 'nt':
        pf = os.environ.get('ProgramFiles','')
        pfx = os.environ.get('ProgramFiles(x86)','')
        local = os.environ.get('LOCALAPPDATA','')
        if browser == 'edge':
            for base in [pf, pfx, local]:
                if base: candidates.append(os.path.join(base, 'Microsoft', 'Edge', 'Application', 'msedge.exe'))
        if browser == 'chrome':
            for base in [pf, pfx, local]:
                if base: candidates.append(os.path.join(base, 'Google', 'Chrome', 'Application', 'chrome.exe'))
        if browser == 'brave':
            for base in [pf, pfx, local]:
                if base: candidates.append(os.path.join(base, 'BraveSoftware', 'Brave-Browser', 'Application', 'brave.exe'))
        if browser == 'firefox':
            for base in [pf, pfx]:
                if base: candidates.append(os.path.join(base, 'Mozilla Firefox', 'firefox.exe'))
    for c in candidates:
        if c and os.path.exists(c):
            return c
    for n in names:
        exe = shutil.which(n)
        if exe:
            return exe
    return ''


def open_with_browser(u, browser='edge', mode='normal'):
    u = normalize_input_to_url(u)
    if not u:
        return _remember_launch(False, u, message='開くリンクが空です。')
    exe = find_browser_exe(browser)
    if not exe:
        return open_path_or_url(u)
    browser = clean_text(browser or 'edge').lower()
    args = [exe]
    if mode == 'private':
        if browser == 'firefox':
            args += ['-private-window', u]
        elif browser == 'edge':
            args += ['--inprivate', '--new-window', u]
        else:
            args += ['--incognito', '--new-window', u]
    elif mode == 'app':
        if browser in ('edge','chrome','brave') and is_url(u):
            args += [f'--app={u}', '--new-window']
        else:
            args += ['--new-window', u]
    elif mode == 'window':
        args += ['--new-window', u] if browser != 'firefox' else ['-new-window', u]
    else:
        args += [u]
    try:
        subprocess.Popen(args, creationflags=CREATE_NO_WINDOW)
        return _remember_launch(True, u, browser)
    except Exception as e:
        _remember_launch(False, u, browser, f'{browser}を起動できませんでした: {e}')
        return open_path_or_url(u)


def open_url_action(u, action='default', browser='edge'):
    u = normalize_input_to_url(u)
    action = clean_text(action or 'default').lower()
    if action in ('', 'auto'):
        action = 'default'
    if action == 'default':
        if re.match(r'(?i)^https?://', u) and clean_text(browser).lower() in BROWSER_NAMES:
            return open_with_browser(u, browser, 'normal')
        return open_path_or_url(u)
    if action == 'browser':
        return open_with_browser(u, browser, 'normal')
    if action == 'window':
        return open_with_browser(u, browser, 'window')
    if action == 'private':
        return open_with_browser(u, browser, 'private')
    if action == 'app':
        return open_with_browser(u, browser, 'app')
    if action == 'desktop' or (action.startswith('desktop_') and not action.endswith('_view')):
        if u.lower().startswith('file://') or looks_like_path(u):
            return open_path_or_url(u)
        od = build_office_desktop_url(u)
        if od and start_custom_url(od):
            return True
        return open_path_or_url(u)
    if action == 'desktop_view' or action.startswith('desktop_') and action.endswith('_view'):
        if u.lower().startswith('file://') or looks_like_path(u):
            return open_path_or_url(u)
        od = build_office_desktop_view_url(u)
        if od and start_custom_url(od):
            return True
        return open_path_or_url(u)
    return open_path_or_url(u)


class LinkApp:
    def __init__(self):
        self.lock = threading.RLock()
        self.links = []
        self.zones = []
        self.candidates = []
        self.task = {
            'running': False,
            'kind': '',
            'message': '待機中',
            'progress': 0,
            'total': 0,
            'stopped': False,
        }
        self.stop_event = threading.Event()
        self.server = None
        self.port = None
        self.default_dir = str(default_save_dir())
        self.current_json_path = str(default_data_file())
        self.autosave_path = str(default_data_file())
        self.shutdown_started = False
        self.closed_event = threading.Event()
        self.instance_id = uuid.uuid4().hex
        self.window_marker = 'LM-' + self.instance_id[:12]
        self.window_hwnd = 0
        self.window_attached = False
        self.api_token = uuid.uuid4().hex
        self._clients = {}
        self._client_close_serial = 0
        self.last_save_error = ''
        self._autosave_blocked = False
        self.revision = 0
        self._save_event = threading.Event()
        self._save_io_lock = threading.Lock()
        self._pending_save = None
        self._save_generation = 0
        self._saved_generation = 0
        self.load_autosave()
        self._autosave_thread = threading.Thread(target=self._autosave_worker, daemon=True)
        self._autosave_thread.start()

    def ping_state(self):
        with self.lock:
            return {
                'ok': True,
                'instanceId': self.instance_id,
                'revision': self.revision,
                'task': dict(self.task),
                'lastSaveError': self.last_save_error,
            }

    @staticmethod
    def _valid_client_id(value):
        value = clean_text(value)
        return value if re.fullmatch(r'[A-Za-z0-9_-]{6,80}', value) else ''

    def _valid_client_request(self, client_id, page_id, instance_id):
        client_id = self._valid_client_id(client_id)
        page_id = self._valid_client_id(page_id)
        instance_id = clean_text(instance_id)
        if not client_id or not page_id:
            return '', '', '画面識別子が不正です。'
        if instance_id and not hmac.compare_digest(instance_id, self.instance_id):
            return '', '', '別の起動中インスタンスからの通知を無視しました。'
        return client_id, page_id, ''

    def client_open(self, client_id='', page_id='', instance_id=''):
        client_id, page_id, error = self._valid_client_request(client_id, page_id, instance_id)
        if error:
            result = self.ping_state()
            result.update({'clientRegistered': False, 'message': error})
            return result
        with self.lock:
            # sessionStorageのclientIdはreload後も同じ。新しいpageIdで
            # 古いclose候補を上書きし、再読込みを終了と誤判定しない。
            self._clients[client_id] = {
                'pageId': page_id,
                'lastSeen': time.monotonic(),
                'closingSerial': 0,
            }
        result = self.ping_state()
        result['clientRegistered'] = True
        return result

    def client_ping(self, client_id='', page_id='', instance_id=''):
        client_id, page_id, error = self._valid_client_request(client_id, page_id, instance_id)
        if client_id and page_id and not error:
            with self.lock:
                current = self._clients.get(client_id)
                if current and current.get('pageId') == page_id:
                    # close通知より前に送られたpingが後着しても、
                    # closingSerialは取り消さない。復帰取消はopen通知だけで行う。
                    current['lastSeen'] = time.monotonic()
                    result = self.ping_state()
                    result['clientRegistered'] = True
                    return result
            # open通知が通信タイミングで落ちても、新pageIdの
            # 最初のpollで必ず復帰する。
            return self.client_open(client_id, page_id, instance_id)
        result = self.ping_state()
        result['clientRegistered'] = False
        return result

    def client_closing(self, client_id='', page_id='', instance_id=''):
        client_id, page_id, error = self._valid_client_request(client_id, page_id, instance_id)
        if error:
            return {'ok': False, 'scheduled': False, 'message': error}
        with self.lock:
            current = self._clients.get(client_id)
            if not current or current.get('pageId') != page_id:
                return {'ok': True, 'scheduled': False, 'message': '更新前の画面からの終了通知を無視しました。'}
            self._client_close_serial += 1
            serial = self._client_close_serial
            current['closingSerial'] = serial
        threading.Thread(
            target=self._confirm_client_close,
            args=(client_id, page_id, serial),
            daemon=True,
        ).start()
        return {'ok': True, 'scheduled': True, 'message': '画面が戻らない場合は終了します。'}

    def _confirm_client_close(self, client_id, page_id, serial):
        time.sleep(2.5)
        should_shutdown = False
        with self.lock:
            current = self._clients.get(client_id)
            if (not current or current.get('pageId') != page_id or
                    current.get('closingSerial') != serial):
                return
            self._clients.pop(client_id, None)
            # HWNDを一度捕捉したWindowsアプリ窓はWin32監視を正とする。
            # pagehideだけではreloadやBFCacheを完全に区別できないため。
            if os.name == 'nt' and self.window_attached:
                return
            now = time.monotonic()
            stale = [key for key, value in self._clients.items()
                     if now - float(value.get('lastSeen') or 0) > 45]
            for key in stale:
                self._clients.pop(key, None)
            should_shutdown = not self._clients
        if should_shutdown:
            self.shutdown('window-frame-closed')

    def load_autosave(self):
        p = pathlib.Path(getattr(self, 'autosave_path', '') or default_data_file())
        backup = p.with_name(p.name + '.bak')
        if not p.exists() and not backup.exists():
            return
        data = None
        loaded_from = None
        read_errors = []
        future_schema_version = 0
        try:
            for candidate in (p, backup):
                if not candidate.exists():
                    continue
                try:
                    candidate_data = json.loads(candidate.read_text(encoding='utf-8'))
                    if not isinstance(candidate_data, dict):
                        raise ValueError('保存データの形式が不正です。')
                    try:
                        schema_version = int(candidate_data.get('schemaVersion') or 1)
                    except Exception as e:
                        raise ValueError('保存形式の版番号が不正です。') from e
                    if schema_version > 2:
                        # A newer application may own fields or shapes this version does
                        # not know.  Show only recognizable lists and never overwrite it.
                        candidate_data = dict(candidate_data)
                        if not isinstance(candidate_data.get('links'), list):
                            candidate_data['links'] = []
                        if not isinstance(candidate_data.get('zones'), list):
                            candidate_data['zones'] = []
                        self._autosave_blocked = True
                        future_schema_version = schema_version
                    else:
                        if 'links' not in candidate_data or not isinstance(candidate_data.get('links'), list):
                            raise ValueError('保存データの形式が不正です。')
                        if 'zones' in candidate_data and not isinstance(candidate_data.get('zones'), list):
                            raise ValueError('ゾーンデータの形式が不正です。')
                        for raw_zone in candidate_data.get('zones', []):
                            zone_name = clean_zone_name(raw_zone.get('name')) if isinstance(raw_zone, dict) else ''
                            if not zone_name or len(zone_name) > 40:
                                raise ValueError('ゾーンデータに不正な項目があります。')
                    data = candidate_data
                    loaded_from = candidate
                    break
                except Exception as e:
                    read_errors.append((candidate, e))
            if data is None:
                raise ValueError('主データとバックアップを読み取れません。')
            links = data.get('links', []) if isinstance(data, dict) else []
            raw_zones = data.get('zones', []) if isinstance(data, dict) else []
            clean_zones = []
            used_zone_ids = set()
            used_zone_names = {}
            zone_id_map = {}
            for raw_zone in raw_zones if isinstance(raw_zones, list) else []:
                if not isinstance(raw_zone, dict):
                    continue
                old_zone_id = clean_text(raw_zone.get('id'))
                name = clean_zone_name(raw_zone.get('name'))[:40]
                if not name:
                    continue
                name_key = zone_name_key(name)
                if name_key in used_zone_names:
                    if old_zone_id:
                        zone_id_map[old_zone_id] = used_zone_names[name_key]
                    continue
                zone_id = safe_identifier(old_zone_id)
                if not zone_id or zone_id in used_zone_ids:
                    zone_id = uuid.uuid4().hex[:12]
                used_zone_ids.add(zone_id)
                used_zone_names[name_key] = zone_id
                if old_zone_id:
                    zone_id_map[old_zone_id] = zone_id
                clean_zones.append({
                    'id': zone_id,
                    'name': name,
                    'collapsed': raw_zone.get('collapsed') is True,
                    'order': len(clean_zones),
                    'createdAt': clean_text(raw_zone.get('createdAt')) or now_text(),
                    'updatedAt': clean_text(raw_zone.get('updatedAt')) or now_text(),
                })
            clean = []
            used_ids = set()
            id_map = {}
            preserved_custom = 0
            rejected_unsafe = 0
            for x in links:
                if not isinstance(x, dict):
                    continue
                url = normalize_input_to_url(x.get('url') or x.get('path') or '')
                if not url:
                    continue
                supported = is_supported_target(url)
                if not supported and not is_preservable_custom_target(url):
                    rejected_unsafe += 1
                    continue
                if not supported:
                    preserved_custom += 1
                old_id = clean_text(x.get('id'))
                item_id = safe_identifier(old_id)
                if not item_id or item_id in used_ids:
                    item_id = uuid.uuid4().hex[:12]
                used_ids.add(item_id)
                if old_id:
                    id_map[old_id] = item_id
                raw_zone_id = clean_text(x.get('zoneId'))
                zone_id = zone_id_map.get(raw_zone_id, raw_zone_id)
                if zone_id not in used_zone_ids:
                    zone_id = ''
                clean.append({
                    'id': item_id,
                    'title': clean_text(x.get('title')) or title_from_url(url),
                    'url': clean_url(url),
                    'kind': clean_text(x.get('kind')) or classify_link(url),
                    'source': clean_text(x.get('source')) or '保存データ',
                    'tags': split_tags(x.get('tags', [])),
                    'note': clean_text(x.get('note')),
                    'status': '要確認' if not supported else (clean_text(x.get('status')) or '未確認'),
                    'statusText': ('この形式は安全のため自動起動・HTMLリンク化の対象外です。' if not supported else clean_text(x.get('statusText'))),
                    'favorite': x.get('favorite') is True,
                    'pinned': x.get('pinned') is True,
                    'zoneId': zone_id,
                    'createdAt': clean_text(x.get('createdAt')) or now_text(),
                    'updatedAt': clean_text(x.get('updatedAt')) or now_text(),
                    'checkedAt': clean_text(x.get('checkedAt')),
                    'originalUrl': clean_text(x.get('originalUrl')),
                    'workUrl': clean_text(x.get('workUrl')),
                    'workPath': clean_text(x.get('workPath')),
                    'relation': clean_text(x.get('relation')),
                    'sourceId': clean_text(x.get('sourceId')),
                    'openMode': clean_text(x.get('openMode')),
                    'openCount': int(x.get('openCount') or 0) if str(x.get('openCount') or '').isdigit() else 0,
                    'openedAt': clean_text(x.get('openedAt')),
                })
            for item in clean:
                if item.get('sourceId') in id_map:
                    item['sourceId'] = id_map[item.get('sourceId')]
            self.zones = clean_zones
            self.links = clean
            load_notes = []
            if future_schema_version:
                load_notes.append(f'このデータは新しい保存形式（版{future_schema_version}）です。未知の情報を保護するため自動保存を停止しています。新しい版のリンク管理で開いてください。')
            if preserved_custom:
                load_notes.append(f'旧データの独自形式リンク{preserved_custom}件を「要確認」として保持しました。')
            if rejected_unsafe:
                load_notes.append(f'安全でない形式のリンク{rejected_unsafe}件は読み込みませんでした。')
            if loaded_from == backup:
                # 次回保存で壊れた主データが正常な .bak を上書きしないよう退避します。
                if p.exists():
                    moved = self._quarantine_files([p])
                    if not moved:
                        self._autosave_blocked = True
                if self._autosave_blocked:
                    load_notes.insert(0, 'バックアップから復元しました。壊れた主データを退避できないため、自動保存を停止しています。')
                else:
                    load_notes.insert(0, '主データを読めなかったため、バックアップから復元しました。壊れた主データは上書きしていません。')
            if load_notes:
                self.last_save_error = ' '.join(load_notes)
        except Exception:
            self.links = []
            self.zones = []
            broken = [candidate for candidate, _ in read_errors]
            moved = self._quarantine_files(broken)
            self._autosave_blocked = len(moved) != len(broken)
            if self._autosave_blocked:
                self.last_save_error = '保存データを読み取れません。原本を保護するため自動保存を停止しています。別名で保存してください。'
            else:
                self.last_save_error = '保存データを読み取れなかったため空の台帳で開きました。壊れたデータは .corrupt ファイルへ退避し、上書きしていません。'

    def _quarantine_files(self, paths):
        moved = []
        stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        for source in paths:
            try:
                if not source.exists():
                    continue
                target = source.with_name(source.name + f'.corrupt-{stamp}')
                suffix = 1
                while target.exists():
                    target = source.with_name(source.name + f'.corrupt-{stamp}-{suffix}')
                    suffix += 1
                source.replace(target)
                moved.append(target)
            except Exception:
                continue
        return moved

    def _snapshot_data(self):
        return {
            'schemaVersion': 2,
            'app': APP_TITLE,
            'version': APP_VERSION,
            'savedAt': now_text(),
            'zones': [dict(x) for x in self.zones],
            'links': [dict(x) for x in self.links],
        }

    def autosave(self):
        """Queue an atomic save without making link opening wait for disk I/O."""
        flush_now = False
        with self.lock:
            if self._autosave_blocked:
                self.last_save_error = '保存データの原本を保護するため自動保存を停止しています。別名で保存してください。'
                self.revision += 1
                return
            p = pathlib.Path(getattr(self, 'autosave_path', '') or default_data_file())
            data = self._snapshot_data()
            payload = json.dumps(data, ensure_ascii=False, indent=2)
            self._save_generation += 1
            self._pending_save = (self._save_generation, p, payload)
            self.revision += 1
            if self.shutdown_started:
                # The background worker has already stopped.  Persist any
                # in-flight request/task update synchronously instead of
                # leaving a dead pending snapshot behind.
                flush_now = True
            else:
                self._save_event.set()
        if flush_now:
            self.flush_autosave()

    def _write_autosave(self, pending):
        if not pending:
            return
        generation, p, payload = pending
        try:
            with self._save_io_lock:
                # 旧workerが終了時の最新snapshotより後から完了しても、
                # 新しい保存データを巻き戻さない。
                if generation <= self._saved_generation:
                    return
                p.parent.mkdir(parents=True, exist_ok=True)
                if p.exists():
                    backup = p.with_name(p.name + '.bak')
                    backup_tmp = backup.with_name(backup.name + '.tmp')
                    shutil.copy2(p, backup_tmp)
                    backup_tmp.replace(backup)
                tmp = p.with_name(p.name + '.tmp')
                tmp.write_text(payload, encoding='utf-8')
                tmp.replace(p)
                self._saved_generation = generation
            with self.lock:
                self.current_json_path = str(p)
                self.last_save_error = ''
        except Exception as e:
            with self.lock:
                self.last_save_error = str(e)[:220]

    def flush_autosave(self):
        with self.lock:
            pending = self._pending_save
            self._pending_save = None
            self._save_event.clear()
        self._write_autosave(pending)

    def _autosave_worker(self):
        while True:
            if self.shutdown_started:
                return
            if not self._save_event.wait(0.5):
                continue
            # Coalesce bursts such as opening several selected links.
            time.sleep(0.18)
            self.flush_autosave()

    def link_to_public(self, item):
        public = dict(item)
        public['tags'] = list(item.get('tags', []))
        return public

    def state(self):
        with self.lock:
            return {
                'title': APP_TITLE,
                'version': APP_VERSION,
                'instanceId': self.instance_id,
                'links': [self.link_to_public(x) for x in self.links],
                'zones': [dict(x) for x in self.zones],
                'candidates': [dict(x) for x in self.candidates],
                'task': dict(self.task),
                'defaultDir': self.default_dir,
                'currentJsonPath': self.current_json_path,
                'autosavePath': self.autosave_path,
                'lastSaveError': self.last_save_error,
                'stats': self.stats(),
                'revision': self.revision,
            }

    def stats(self):
        kinds = {}
        statuses = {}
        for x in self.links:
            kinds[x.get('kind','未分類')] = kinds.get(x.get('kind','未分類'), 0) + 1
            statuses[x.get('status','未確認')] = statuses.get(x.get('status','未確認'), 0) + 1
        return {
            'total': len(self.links),
            'pinned': sum(1 for x in self.links if x.get('pinned')),
            'zones': len(self.zones),
            'kinds': kinds,
            'statuses': statuses,
        }

    def add_zone(self, name):
        name = clean_zone_name(name)
        if not name:
            return {'ok': False, 'message': 'ゾーン名を入力してください。'}
        if len(name) > 40:
            return {'ok': False, 'message': 'ゾーン名は40文字以内にしてください。'}
        with self.lock:
            if any(zone_name_key(x.get('name')) == zone_name_key(name) for x in self.zones):
                return {'ok': False, 'message': '同じ名前のゾーンがあります。'}
            zone = {
                'id': uuid.uuid4().hex[:12],
                'name': name,
                'collapsed': False,
                'order': len(self.zones),
                'createdAt': now_text(),
                'updatedAt': now_text(),
            }
            self.zones.append(zone)
            self.autosave()
            return {'ok': True, 'item': dict(zone)}

    def update_zone(self, item):
        zone_id = clean_text(item.get('id')) if isinstance(item, dict) else ''
        with self.lock:
            zone = next((x for x in self.zones if x.get('id') == zone_id), None)
            if not zone:
                return {'ok': False, 'message': '対象のゾーンが見つかりません。'}
            changed = False
            if 'name' in item:
                name = clean_zone_name(item.get('name'))
                if not name:
                    return {'ok': False, 'message': 'ゾーン名を入力してください。'}
                if len(name) > 40:
                    return {'ok': False, 'message': 'ゾーン名は40文字以内にしてください。'}
                if any(x.get('id') != zone_id and zone_name_key(x.get('name')) == zone_name_key(name) for x in self.zones):
                    return {'ok': False, 'message': '同じ名前のゾーンがあります。'}
                if zone.get('name') != name:
                    zone['name'] = name
                    changed = True
            if 'collapsed' in item and isinstance(item.get('collapsed'), bool):
                collapsed = item.get('collapsed') is True
                if bool(zone.get('collapsed')) != collapsed:
                    zone['collapsed'] = collapsed
                    changed = True
            if changed:
                zone['updatedAt'] = now_text()
                self.autosave()
            return {'ok': True, 'item': dict(zone), 'changed': changed}

    def delete_zone(self, zone_id):
        zone_id = clean_text(zone_id)
        with self.lock:
            zone = next((x for x in self.zones if x.get('id') == zone_id), None)
            if not zone:
                return {'ok': False, 'message': '対象のゾーンが見つかりません。'}
            self.zones = [x for x in self.zones if x.get('id') != zone_id]
            for index, item in enumerate(self.zones):
                item['order'] = index
            moved = 0
            for link in self.links:
                if link.get('zoneId') == zone_id:
                    link['zoneId'] = ''
                    link['updatedAt'] = now_text()
                    moved += 1
            self.autosave()
            return {'ok': True, 'deleted': 1, 'moved': moved, 'name': zone.get('name', '')}

    def set_link_flag(self, link_id, field, value):
        if field not in ('pinned', 'favorite') or not isinstance(value, bool):
            return {'ok': False, 'message': '変更内容が不正です。'}
        with self.lock:
            link = next((x for x in self.links if x.get('id') == clean_text(link_id)), None)
            if not link:
                return {'ok': False, 'message': '対象のリンクが見つかりません。'}
            link[field] = value
            link['updatedAt'] = now_text()
            self.autosave()
            return {'ok': True, 'item': self.link_to_public(link)}

    def assign_links_zone(self, ids, zone_id=''):
        wanted = {clean_text(x) for x in (ids or []) if clean_text(x)}
        zone_id = clean_text(zone_id)
        with self.lock:
            if zone_id and not any(x.get('id') == zone_id for x in self.zones):
                return {'ok': False, 'message': '移動先のゾーンが見つかりません。'}
            updated = 0
            for link in self.links:
                if link.get('id') in wanted and link.get('zoneId', '') != zone_id:
                    link['zoneId'] = zone_id
                    link['updatedAt'] = now_text()
                    updated += 1
            if updated:
                self.autosave()
            return {'ok': True, 'updated': updated, 'zoneId': zone_id}

    def set_task(self, **kwargs):
        with self.lock:
            self.task.update(kwargs)

    def start_task(self, kind, target, *args, **kwargs):
        with self.lock:
            if self.task.get('running'):
                return {'ok': False, 'message': '処理中です。完了するまでお待ちください。'}
            self.stop_event.clear()
            self.task = {'running': True, 'kind': kind, 'message': '開始しています', 'progress': 0, 'total': 0, 'stopped': False}
        th = threading.Thread(target=self._task_wrapper, args=(target, args, kwargs), daemon=True)
        th.start()
        return {'ok': True, 'message': '開始しました'}

    def _task_wrapper(self, target, args, kwargs):
        try:
            target(*args, **kwargs)
        except Exception as e:
            self.set_task(message=f'途中で確認できない項目がありました: {e}', running=False)
        finally:
            with self.lock:
                self.task['running'] = False
                if self.stop_event.is_set():
                    self.task['stopped'] = True
                    self.task['message'] = '途中で停止しました。'

    def stop(self):
        if not self.task.get('running'):
            return {'ok': True, 'message': '実行中の処理はありません。'}
        self.stop_event.set()
        self.set_task(message='停止を受け付けました。区切りのよいところで止まります。')
        return {'ok': True, 'message': '停止を受け付けました。区切りのよいところで止まります。'}

    def make_item(self, url, title='', source='手入力', note='', tags=None):
        url = normalize_input_to_url(url)
        kind = classify_link(url)
        return {
            'id': uuid.uuid4().hex[:12],
            'title': clean_text(title) or title_from_url(url),
            'url': clean_url(url),
            'kind': kind,
            'source': clean_text(source),
            'tags': split_tags(tags or ''),
            'note': clean_text(note),
            'status': '未確認',
            'statusText': '',
            'favorite': False,
            'pinned': False,
            'zoneId': '',
            'createdAt': now_text(),
            'updatedAt': now_text(),
            'originalUrl': '',
            'workUrl': '',
            'workPath': '',
            'relation': '',
            'sourceId': '',
            'openMode': '',
            'openCount': 0,
            'openedAt': '',
        }

    def add_links(self, items, allow_custom=False):
        if isinstance(items, dict):
            items = [items]
        added = 0
        skipped = 0
        invalid = 0
        added_items = []
        skipped_ids = []
        with self.lock:
            existing = {link_identity_key(x.get('url','')): x for x in self.links}
            used_ids = {x.get('id') for x in self.links if x.get('id')}
            imported_id_map = {}
            for it in items:
                if not isinstance(it, dict):
                    invalid += 1
                    continue
                url = clean_url(it.get('url') or it.get('path') or '')
                url = normalize_input_to_url(url)
                supported = is_supported_target(url)
                if not url or (not supported and not (allow_custom and is_preservable_custom_target(url))):
                    invalid += 1
                    continue
                key = link_identity_key(url)
                if key in existing:
                    # 既存リンクは増やさず、タグ・メモ・開き方を必要な範囲だけ補完します。
                    ex = existing[key]
                    for t in split_tags(it.get('tags','')):
                        if t not in ex['tags']:
                            ex['tags'].append(t)
                    if it.get('note') and not ex.get('note'):
                        ex['note'] = clean_text(it.get('note'))
                    if it.get('openMode') and not ex.get('openMode'):
                        ex['openMode'] = clean_text(it.get('openMode'))
                    if it.get('favorite') is True:
                        ex['favorite'] = True
                    if it.get('pinned') is True:
                        ex['pinned'] = True
                    imported_zone_id = clean_text(it.get('zoneId'))
                    if imported_zone_id and not ex.get('zoneId') and any(z.get('id') == imported_zone_id for z in self.zones):
                        ex['zoneId'] = imported_zone_id
                    if str(it.get('openCount') or '').isdigit():
                        ex['openCount'] = max(int(ex.get('openCount') or 0), int(it.get('openCount') or 0))
                    imported_opened_at = clean_text(it.get('openedAt'))
                    if imported_opened_at > clean_text(ex.get('openedAt')):
                        ex['openedAt'] = imported_opened_at
                    ex['updatedAt'] = now_text()
                    old_id = clean_text(it.get('id'))
                    if old_id and ex.get('id'):
                        imported_id_map.setdefault(old_id, ex.get('id'))
                    if ex.get('id'):
                        skipped_ids.append(ex.get('id'))
                    skipped += 1
                    continue
                item = self.make_item(url, it.get('title',''), it.get('source','手入力'), it.get('note',''), it.get('tags',''))
                old_id = clean_text(it.get('id'))
                preferred_id = safe_identifier(old_id)
                if preferred_id and preferred_id not in used_ids:
                    item['id'] = preferred_id
                while item['id'] in used_ids:
                    item['id'] = uuid.uuid4().hex[:12]
                used_ids.add(item['id'])
                if old_id:
                    imported_id_map[old_id] = item['id']
                for field in ('originalUrl','workUrl','workPath','relation','sourceId','openMode','openedAt'):
                    if it.get(field):
                        item[field] = clean_text(it.get(field))
                for field in ('status','statusText','checkedAt','createdAt','updatedAt'):
                    if clean_text(it.get(field)):
                        item[field] = clean_text(it.get(field))
                if 'favorite' in it:
                    item['favorite'] = it.get('favorite') is True
                if 'pinned' in it:
                    item['pinned'] = it.get('pinned') is True
                imported_zone_id = clean_text(it.get('zoneId'))
                if imported_zone_id and any(z.get('id') == imported_zone_id for z in self.zones):
                    item['zoneId'] = imported_zone_id
                if str(it.get('openCount') or '').isdigit():
                    item['openCount'] = max(0, int(it.get('openCount') or 0))
                if not supported:
                    item['status'] = '要確認'
                    item['statusText'] = 'この形式は安全のため自動起動・HTMLリンク化の対象外です。'
                self.links.append(item)
                existing[key] = item
                added_items.append(item)
                added += 1
            if imported_id_map:
                # 既存リンクの関係は触らず、今回追加した項目だけを同じ取込内のIDへつなぎ直します。
                for item in added_items:
                    if item.get('sourceId') in imported_id_map:
                        item['sourceId'] = imported_id_map[item.get('sourceId')]
            if added or skipped:
                self.autosave()
        public_added = [dict(x) for x in added_items]
        return {'ok': True, 'added': added, 'skipped': skipped, 'invalid': invalid, 'addedIds': [x.get('id') for x in public_added], 'skippedIds': skipped_ids, 'items': public_added}

    def update_link(self, item):
        link_id = item.get('id')
        new_url = normalize_input_to_url(item.get('url', ''))
        supported = is_supported_target(new_url)
        if not new_url or not (supported or is_preservable_custom_target(new_url)):
            return {'ok': False, 'message': '対応しているURLまたはファイルパスを入力してください。'}
        with self.lock:
            new_key = link_identity_key(new_url)
            duplicate = next((x for x in self.links if x.get('id') != link_id and link_identity_key(x.get('url','')) == new_key), None)
            if duplicate:
                return {'ok': False, 'message': '同じリンクがすでに登録されています。'}
            requested_zone = clean_text(item.get('zoneId')) if 'zoneId' in item else None
            if requested_zone and not any(z.get('id') == requested_zone for z in self.zones):
                return {'ok': False, 'message': '選択したゾーンが見つかりません。'}
            for x in self.links:
                if x.get('id') == link_id:
                    x['title'] = clean_text(item.get('title', x.get('title',''))) or title_from_url(new_url)
                    x['url'] = new_url
                    x['kind'] = classify_link(x['url'])
                    x['tags'] = split_tags(item.get('tags', x.get('tags', [])))
                    x['note'] = clean_text(item.get('note', x.get('note','')))
                    if isinstance(item.get('favorite'), bool):
                        x['favorite'] = item.get('favorite') is True
                    if isinstance(item.get('pinned'), bool):
                        x['pinned'] = item.get('pinned') is True
                    if requested_zone is not None:
                        x['zoneId'] = requested_zone
                    for field in ('originalUrl','workUrl','workPath','relation','sourceId','openMode'):
                        if field in item:
                            x[field] = clean_text(item.get(field, x.get(field,'')))
                    if not supported:
                        x['status'] = '要確認'
                        x['statusText'] = 'この形式は安全のため自動起動・HTMLリンク化の対象外です。'
                    x['updatedAt'] = now_text()
                    self.autosave()
                    return {'ok': True, 'item': x}
        return {'ok': False, 'message': '対象が見つかりません。'}

    def delete_links(self, ids):
        ids = set(ids or [])
        with self.lock:
            before = len(self.links)
            self.links = [x for x in self.links if x.get('id') not in ids]
            deleted = before - len(self.links)
            if deleted:
                self.autosave()
            return {'ok': True, 'deleted': deleted}

    def duplicate_cleanup(self):
        with self.lock:
            seen = {}; new = []; removed = 0
            for x in self.links:
                key = link_identity_key(x.get('url',''))
                if not key:
                    removed += 1; continue
                if key in seen:
                    kept = seen[key]
                    kept['favorite'] = bool(kept.get('favorite') or x.get('favorite'))
                    kept['pinned'] = bool(kept.get('pinned') or x.get('pinned'))
                    if not kept.get('zoneId') and x.get('zoneId'):
                        kept['zoneId'] = x.get('zoneId')
                    kept['openCount'] = max(max(0, int(kept.get('openCount') or 0)), max(0, int(x.get('openCount') or 0)))
                    if clean_text(x.get('openedAt')) > clean_text(kept.get('openedAt')):
                        kept['openedAt'] = clean_text(x.get('openedAt'))
                    for tag in x.get('tags', []):
                        if tag not in kept.get('tags', []):
                            kept.setdefault('tags', []).append(tag)
                    removed += 1
                    continue
                seen[key] = x
                new.append(x)
            self.links = new
            if removed:
                self.autosave()
        return {'ok': True, 'removed': removed}

    def import_text(self, text, source='貼り付け'):
        items = []
        for m in URL_RE.finditer(text or ''):
            items.append({'url': clean_url(m.group(0)), 'source': source})
        # Windowsパスも拾う
        for m in WIN_PATH_RE.finditer(text or ''):
            p = clean_text(m.group(0)).strip('"')
            if p and not should_exclude_dev(p):
                items.append({'url': to_file_url(p), 'source': source})
        return self.add_links(items)

    def read_clipboard_text(self):
        if os.name == 'nt':
            exe = shutil.which('powershell.exe') or shutil.which('powershell')
            if exe:
                try:
                    cp = subprocess.run([exe, '-NoProfile', '-Command', 'Get-Clipboard -Raw'], capture_output=True, text=True, encoding='utf-8', errors='ignore', timeout=5, creationflags=CREATE_NO_WINDOW)
                    return cp.stdout or ''
                except Exception:
                    pass
        # tkinter fallback
        try:
            import tkinter as tk
            r = tk.Tk(); r.withdraw()
            s = r.clipboard_get()
            r.destroy()
            return s
        except Exception:
            return ''

    def extract_urls_from_bytes(self, data, limit=500):
        # 互換用。ブラウザタブ取得ではセッション全体のURL総ざらいは使いません。
        found = []
        for m in re.finditer(rb'https?://[^\x00-\x1f\s<>"\']+', data):
            try:
                u = urllib.parse.unquote(m.group(0).decode('utf-8', errors='ignore'))
            except Exception:
                continue
            if is_probable_tab_url(u):
                found.append(clean_url(u))
                if len(found) >= limit:
                    break
        return found

    def add_candidates(self, ids):
        ids = set(ids or [])
        with self.lock:
            targets = [c for c in self.candidates if c.get('id') in ids]
        res = self.add_links(targets)
        if ids:
            with self.lock:
                before = len(self.candidates)
                self.candidates = [c for c in self.candidates if c.get('id') not in ids]
                res['removedCandidates'] = before - len(self.candidates)
                if res['removedCandidates']:
                    self.revision += 1
        return res

    def clear_candidates(self):
        with self.lock:
            if self.candidates:
                self.candidates = []
                self.revision += 1
        return {'ok': True}

    def check_start(self, ids=None):
        return self.start_task('check', self.check_links, ids or [])

    def check_links(self, ids=None):
        with self.lock:
            if ids:
                wanted = set(ids)
                targets = [x for x in self.links if x.get('id') in wanted]
            else:
                targets = list(self.links)
        total = len(targets)
        self.set_task(total=total, progress=0, message='リンクを確認しています。')
        for idx, item in enumerate(targets, start=1):
            if self.stop_event.is_set():
                break
            self.set_task(progress=idx-1, message=f'{item.get("title") or item.get("url")} を確認しています。')
            status, status_text = self.check_one(item.get('url',''))
            with self.lock:
                for x in self.links:
                    if x.get('id') == item.get('id'):
                        x['status'] = status
                        x['statusText'] = status_text
                        x['checkedAt'] = now_text()
                        x['updatedAt'] = now_text()
                        break
            self.set_task(progress=idx, message=f'{idx}/{total}件を確認しました。')
        # 途中で停止した場合も、確認済みの結果は失わず保存する。
        if targets:
            self.autosave()
        if self.stop_event.is_set():
            done = min(self.task.get('progress', 0), total)
            self.set_task(progress=done, total=total, message=f'{done}/{total}件を確認して停止しました。', running=False, stopped=True)
        else:
            self.set_task(progress=total, total=total, message='リンク確認が完了しました。', running=False)

    def check_one(self, url):
        url = clean_url(url)
        if not url:
            return '要確認', 'URLが空です。'
        scheme = urllib.parse.urlparse(url).scheme.lower()
        if scheme and scheme not in ('http','https','ftp','file'):
            if scheme.startswith('ms-') or scheme in ('mailto','msteams','onenote','odopen'):
                return '利用可', 'アプリ起動用リンクです。リンク先の権限やアプリ状態は開いて確認してください。'
            return '要確認', f'{scheme} 用リンクです。自動確認の対象外です。'
        if url.lower().startswith('file://') or looks_like_path(url):
            p = pathlib.Path(url_to_path(url))
            if p.exists():
                return '利用可', 'ファイルまたはフォルダを確認しました。'
            return '見つからない', 'ファイルまたはフォルダが見つかりません。'
        if not is_url(url):
            return '要確認', 'Webリンクまたはファイルパスとして判定できません。'
        req = urllib.request.Request(url, method='HEAD', headers={'User-Agent': 'Mozilla/5.0 LinkManager/4.0', 'Accept': '*/*'})
        try:
            with urllib.request.urlopen(req, timeout=8) as res:
                code = getattr(res, 'status', 0)
                final_url = clean_text(getattr(res, 'url', '') or res.geturl())
                final_host = host_of_url(final_url)
                if 'login.microsoftonline.com' in final_host or 'login.live.com' in final_host:
                    return 'サインイン必要', f'サインイン画面へ移動しました。HTTP {code}'
                if 200 <= code < 400:
                    return '利用可', f'HTTP {code}'
                if code in (401, 403):
                    return 'サインイン必要', f'HTTP {code}'
                if code in (404, 410):
                    return '見つからない', f'HTTP {code}'
                return '要確認', f'HTTP {code}'
        except urllib.error.HTTPError as e:
            code = e.code
            if code in (401, 403):
                return 'サインイン必要', f'HTTP {code}'
            if code in (404, 410):
                return '見つからない', f'HTTP {code}'
            # HEAD拒否ならGETを試す
            if code in (405, 400):
                try:
                    req2 = urllib.request.Request(url, method='GET', headers={'User-Agent': 'Mozilla/5.0 LinkManager/4.0', 'Range': 'bytes=0-0', 'Accept': '*/*'})
                    with urllib.request.urlopen(req2, timeout=8) as res:
                        c = getattr(res, 'status', 0)
                        if 200 <= c < 400:
                            return '利用可', f'HTTP {c}'
                        return '要確認', f'HTTP {c}'
                except Exception as e2:
                    return '要確認', str(e2)[:120]
            return '要確認', f'HTTP {code}'
        except urllib.error.URLError as e:
            return '確認できない', str(e.reason)[:160]
        except Exception as e:
            return '確認できない', str(e)[:160]

    def mark_opened(self, ids):
        ids = set(ids or [])
        if not ids:
            return
        stamp = now_text()
        changed = 0
        with self.lock:
            for x in self.links:
                if x.get('id') not in ids:
                    continue
                try:
                    x['openCount'] = int(x.get('openCount') or 0) + 1
                except Exception:
                    x['openCount'] = 1
                x['openedAt'] = stamp
                x['updatedAt'] = stamp
                changed += 1
            if changed:
                self.autosave()

    def open_selected(self, ids):
        ids = set(ids or [])
        count = 0
        opened = []
        failed = []
        with self.lock:
            targets = [x for x in self.links if x.get('id') in ids]
        for x in targets:
            action = clean_text(x.get('openMode') or 'default').lower()
            if action in ('', 'auto'):
                action = 'default'
            if open_url_action(x.get('url',''), action, 'edge'):
                count += 1
                if x.get('id'):
                    opened.append(x.get('id'))
            else:
                detail = last_launch_result()
                failed.append({'id': x.get('id',''), 'title': x.get('title',''), 'message': detail.get('message','')})
        if opened:
            self.mark_opened(opened)
        if not targets:
            message = '開くリンクが選ばれていません。'
        elif failed and not opened:
            message = failed[0].get('message') or 'リンクを開けませんでした。'
        elif failed:
            message = f'{count}件へ起動要求を送り、{len(failed)}件は開けませんでした。'
        else:
            message = f'{count}件へ起動要求を送りました。'
        return {'ok': bool(opened), 'opened': count, 'failed': len(failed), 'failures': failed, 'message': message}

    def choose_path(self, kind='file'):
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)
            if kind == 'folder':
                path = filedialog.askdirectory(title='リンクを抽出するフォルダを選択')
            else:
                path = filedialog.askopenfilename(title='リンクを抽出するファイルを選択')
            root.destroy()
            return {'ok': True, 'path': path or ''}
        except Exception as e:
            return {'ok': False, 'message': str(e), 'path': ''}

    def extract_path_start(self, path='', recursive=True, max_files=500):
        return self.start_task('extract', self.extract_from_path, path, bool(recursive), int(max_files or 500))

    def extract_from_path(self, path='', recursive=True, max_files=500):
        p = pathlib.Path(clean_text(path).strip('"'))
        if not p.exists():
            self.set_task(message='指定したファイルまたはフォルダが見つかりません。', running=False)
            return
        files = []
        if p.is_file():
            files = [p]
        else:
            it = p.rglob('*') if recursive else p.glob('*')
            for f in it:
                if self.stop_event.is_set() or len(files) >= max_files:
                    break
                try:
                    if f.is_file() and f.stat().st_size <= 25*1024*1024:
                        files.append(f)
                except Exception:
                    continue
        collected = []
        self.set_task(total=len(files), progress=0, message='ファイル内のリンクを探しています。')
        for i, f in enumerate(files, start=1):
            if self.stop_event.is_set():
                break
            self.set_task(progress=i-1, message=f'{f.name} を確認しています。')
            try:
                collected.extend(self.extract_links_from_file(f))
            except Exception:
                pass
            self.set_task(progress=i, message=f'{i}/{len(files)}件を確認しました。')
        seen = set(); final = []
        for it in collected:
            u = normalize_input_to_url(it.get('url',''))
            if not u or should_exclude_dev(u):
                continue
            key = link_identity_key(u)
            if key in seen:
                continue
            seen.add(key)
            final.append({'id': uuid.uuid4().hex[:12], 'title': clean_text(it.get('title')) or title_from_url(u), 'url': clean_url(u), 'kind': classify_link(u), 'source': clean_text(it.get('source')) or 'ファイル抽出', 'note': clean_text(it.get('note','')), 'tags': split_tags(it.get('tags',''))})
        with self.lock:
            self.candidates = final
            self.revision += 1
        self.set_task(progress=len(files), total=len(files), message=f'{len(final)}件のリンク候補を見つけました。', running=False)

    def extract_links_from_file(self, f):
        items = []
        suffix = f.suffix.lower()
        def add_text_links(text, source_note=''):
            for m in URL_RE.finditer(text or ''):
                items.append({'url': clean_url(m.group(0)), 'title': title_from_url(m.group(0)), 'source': 'ファイル抽出', 'note': source_note or f.name})
            for m in WIN_PATH_RE.finditer(text or ''):
                path = clean_text(m.group(0)).strip('"')
                if path:
                    items.append({'url': to_file_url(path), 'title': pathlib.Path(path).name, 'source': 'ファイル抽出', 'note': source_note or f.name})
        try:
            if suffix == '.url':
                txt = f.read_text(encoding='utf-8', errors='ignore')
                add_text_links(txt, f.name)
            elif suffix in ('.txt','.md','.csv','.tsv','.html','.htm','.xml','.json','.log','.eml','.msg'):
                txt = f.read_text(encoding='utf-8', errors='ignore')
                add_text_links(txt, f.name)
            elif suffix in ('.docx','.xlsx','.xlsm','.pptx','.pptm'):
                import zipfile
                if f.stat().st_size > 256 * 1024 * 1024:
                    return items
                with zipfile.ZipFile(f, 'r') as z:
                    total_xml = 0
                    visited = 0
                    for info in z.infolist():
                        name = info.filename
                        if not (name.endswith('.rels') or name.endswith('.xml')):
                            continue
                        visited += 1
                        if visited > 2000 or total_xml >= 32 * 1024 * 1024:
                            break
                        if info.file_size < 0 or info.file_size > 8 * 1024 * 1024:
                            continue
                        remaining = 32 * 1024 * 1024 - total_xml
                        try:
                            with z.open(info, 'r') as member:
                                raw = member.read(min(8 * 1024 * 1024, remaining) + 1)
                            if len(raw) > 8 * 1024 * 1024 or len(raw) > remaining:
                                continue
                            total_xml += len(raw)
                            data = raw.decode('utf-8', errors='ignore')
                        except Exception:
                            continue
                        add_text_links(data, f.name)
            elif suffix == '.lnk' and os.name == 'nt':
                script = f"""
$w = New-Object -ComObject WScript.Shell
try {{ $s = $w.CreateShortcut('{str(f).replace("'", "''")}'); [pscustomobject]@{{target=$s.TargetPath; args=$s.Arguments}} | ConvertTo-Json -Compress }} catch {{}}
"""
                data = run_powershell_json(script, timeout=5)
                for x in data:
                    t = x.get('target','')
                    a = x.get('args','')
                    if t and (is_url(t) or looks_like_path(t)):
                        items.append({'url': normalize_input_to_url(t), 'title': f.stem, 'source': 'ショートカット', 'note': f.name})
                    add_text_links(a, f.name)
            elif suffix in ('.pdf', '.bin'):
                data = f.read_bytes()[:8*1024*1024]
                for u in self.extract_urls_from_bytes(data, limit=200):
                    items.append({'url': u, 'title': title_from_url(u), 'source': 'ファイル抽出', 'note': f.name})
        except Exception:
            pass
        return items
    def copy_selected_to_clipboard(self, ids):
        ids = set(ids or [])
        with self.lock:
            lines = [x.get('url','') for x in self.links if x.get('id') in ids]
        text = '\n'.join(lines)
        if os.name == 'nt':
            exe = shutil.which('powershell.exe') or shutil.which('powershell')
            if exe:
                try:
                    subprocess.run([exe, '-NoProfile', '-Command', 'Set-Clipboard -Value ([Console]::In.ReadToEnd())'], input=text, text=True, encoding='utf-8', timeout=5, creationflags=CREATE_NO_WINDOW)
                    return {'ok': True, 'copied': len(lines)}
                except Exception:
                    pass
        try:
            import tkinter as tk
            r = tk.Tk(); r.withdraw(); r.clipboard_clear(); r.clipboard_append(text); r.update(); r.destroy()
            return {'ok': True, 'copied': len(lines)}
        except Exception as e:
            return {'ok': False, 'message': str(e)}

    def save_json(self, path=''):
        try:
            if self._autosave_blocked:
                if not clean_text(path):
                    return {'ok': False, 'message': '新しい形式または破損した原本を保護しているため、このファイルへは保存できません。新しい版で開くか、別名の保存先を指定してください。'}
                try:
                    if pathlib.Path(path).resolve() == pathlib.Path(self.autosave_path).resolve():
                        return {'ok': False, 'message': '保護中の原本と同じ場所には保存できません。別名で保存してください。'}
                except Exception:
                    return {'ok': False, 'message': '安全な別名保存先を確認できません。'}
            p = pathlib.Path(path or self.current_json_path or (default_save_dir() / f'リンク一覧_{compact_now()}.linkbook.json'))
            if p.is_dir():
                p = p / f'リンク一覧_{compact_now()}.linkbook.json'
            with self.lock:
                data = self._snapshot_data()
                payload = json.dumps(data, ensure_ascii=False, indent=2)
            with self._save_io_lock:
                p.parent.mkdir(parents=True, exist_ok=True)
                tmp = p.with_name(p.name + '.tmp')
                tmp.write_text(payload, encoding='utf-8')
                tmp.replace(p)
            with self.lock:
                self.current_json_path = str(p)
                self.last_save_error = ''
            return {'ok': True, 'path': str(p)}
        except Exception as e:
            self.last_save_error = str(e)[:220]
            return {'ok': False, 'message': '保存できませんでした: ' + self.last_save_error}

    def load_json_data(self, data, replace=False):
        """保存データを読み込みます。

        既定では追加インポートにし、壊れたJSONや空データで既存台帳を消さないようにします。
        replace=True のときだけ、検証済みリンクが1件以上ある場合に置換します。
        """
        replace = replace is True
        raw_zones = []
        if isinstance(data, dict):
            try:
                if int(data.get('schemaVersion') or 1) > 2:
                    return {'ok': False, 'added': 0, 'skipped': 0, 'invalid': 0, 'message': 'このファイルは新しい版で作成されています。現在の版では安全に読み込めません。'}
            except Exception:
                return {'ok': False, 'added': 0, 'skipped': 0, 'invalid': 0, 'message': '保存形式の版番号が不正です。'}
            links = data.get('links', [])
            raw_zones = data.get('zones', [])
        elif isinstance(data, list):
            links = data
        else:
            return {'ok': False, 'added': 0, 'skipped': 0, 'invalid': 0, 'message': '読み込めるリンクデータではありません。'}
        if not isinstance(links, list) or not isinstance(raw_zones, list):
            return {'ok': False, 'added': 0, 'skipped': 0, 'invalid': 0, 'message': 'links が一覧形式ではありません。'}
        valid = []
        invalid = 0
        for it in links:
            if not isinstance(it, dict):
                invalid += 1
                continue
            url = normalize_input_to_url(it.get('url') or it.get('path') or '')
            if not url or not (is_supported_target(url) or is_preservable_custom_target(url)):
                invalid += 1
                continue
            clean_item = dict(it)
            clean_item['url'] = url
            valid.append(clean_item)
        valid_zones = [
            raw_zone for raw_zone in raw_zones
            if isinstance(raw_zone, dict)
            and clean_zone_name(raw_zone.get('name'))
            and len(clean_zone_name(raw_zone.get('name'))) <= 40
        ]
        if not valid and replace:
            return {'ok': False, 'added': 0, 'skipped': 0, 'invalid': invalid, 'message': '追加できるリンクがありません。現在の台帳は変更していません。'}
        if not valid and not valid_zones:
            return {'ok': False, 'added': 0, 'skipped': 0, 'invalid': invalid, 'message': '追加できるリンクやゾーンがありません。現在の台帳は変更していません。'}
        with self.lock:
            if replace:
                self.links = []
                self.zones = []
            zone_id_map = {}
            names = {zone_name_key(x.get('name')): x for x in self.zones}
            used_ids = {x.get('id') for x in self.zones}
            zones_before = len(self.zones)
            for raw_zone in valid_zones:
                old_id = clean_text(raw_zone.get('id'))
                name = clean_zone_name(raw_zone.get('name'))
                existing = names.get(zone_name_key(name))
                if existing:
                    if old_id:
                        zone_id_map[old_id] = existing.get('id')
                    continue
                zone_id = safe_identifier(old_id)
                if not zone_id or zone_id in used_ids:
                    zone_id = uuid.uuid4().hex[:12]
                zone = {
                    'id': zone_id,
                    'name': name,
                    'collapsed': raw_zone.get('collapsed') is True if replace else False,
                    'order': len(self.zones),
                    'createdAt': clean_text(raw_zone.get('createdAt')) or now_text(),
                    'updatedAt': clean_text(raw_zone.get('updatedAt')) or now_text(),
                }
                self.zones.append(zone)
                names[zone_name_key(name)] = zone
                used_ids.add(zone_id)
                if old_id:
                    zone_id_map[old_id] = zone_id
            for item in valid:
                old_zone_id = clean_text(item.get('zoneId'))
                mapped_zone_id = zone_id_map.get(old_zone_id, old_zone_id)
                item['zoneId'] = mapped_zone_id if mapped_zone_id in used_ids else ''
            res = self.add_links(valid, allow_custom=True)
            zones_added = len(self.zones) - zones_before
            if zones_added and not valid:
                self.autosave()
        res['invalid'] = invalid
        res['zonesAdded'] = zones_added
        res['replaced'] = replace
        res['message'] = f"リンク{res.get('added', 0)}件、ゾーン{zones_added}件を読み込みました。" + (f" {invalid}件は無効として無視しました。" if invalid else '')
        return res

    def export_csv(self):
        p = default_save_dir() / f'リンク一覧_{compact_now()}.csv'
        with p.open('w', encoding='utf-8-sig', newline='') as f:
            w = csv.writer(f)
            w.writerow(['名前','ゾーン','ピン留め','お気に入り','開いた回数','最終使用','種類','URL','作業用','原本','状態','確認内容','タグ','メモ','登録元','更新日時'])
            with self.lock:
                zone_names = {x.get('id'): x.get('name', '') for x in self.zones}
                for x in self.links:
                    row = [x.get('title',''), zone_names.get(x.get('zoneId'), ''), 'はい' if x.get('pinned') else '', 'はい' if x.get('favorite') else '', x.get('openCount', 0), x.get('openedAt',''), x.get('kind',''), x.get('url',''), x.get('workUrl') or x.get('workPath',''), x.get('originalUrl',''), x.get('status',''), x.get('statusText',''), '、'.join(x.get('tags',[])), x.get('note',''), x.get('source',''), x.get('updatedAt','')]
                    w.writerow([spreadsheet_safe(v) for v in row])
        return {'ok': True, 'path': str(p)}

    def export_html(self):
        p = default_save_dir() / f'リンク一覧_{compact_now()}.html'
        rows = []
        with self.lock:
            items = list(self.links)
            zone_names = {x.get('id'): x.get('name', '') for x in self.zones}
        for x in items:
            raw_url = clean_text(x.get('url',''))
            url = html.escape(raw_url, quote=True)
            title = html.escape(x.get('title',''))
            linked_title = f"<a href='{url}' rel='noopener noreferrer'>{title}</a>" if is_supported_target(raw_url) else title
            rows.append(f"<tr><td>{linked_title}</td><td>{html.escape(zone_names.get(x.get('zoneId'), ''))}</td><td>{'はい' if x.get('pinned') else ''}</td><td>{'はい' if x.get('favorite') else ''}</td><td>{int(x.get('openCount') or 0)}</td><td>{url}</td><td>{html.escape(x.get('status',''))}</td><td>{html.escape('、'.join(x.get('tags',[])))}</td><td>{html.escape(x.get('note',''))}</td></tr>")
        doc = f"""<!doctype html><html lang='ja'><meta charset='utf-8'><title>リンク一覧</title><style>body{{font-family:system-ui,'Yu Gothic',sans-serif;margin:32px}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #ddd;padding:8px}}th{{background:#222;color:#fff}}

</style><h1>リンク一覧</h1><p>作成日時: {html.escape(now_text())}</p><table><tr><th>名前</th><th>ゾーン</th><th>ピン留め</th><th>お気に入り</th><th>開いた回数</th><th>URL</th><th>状態</th><th>タグ</th><th>メモ</th></tr>{''.join(rows)}</table></html>"""
        p.write_text(doc, encoding='utf-8')
        return {'ok': True, 'path': str(p)}

    def export_xlsx(self):
        try:
            import openpyxl  # type: ignore
            from openpyxl.styles import Font, PatternFill, Alignment
            p = default_save_dir() / f'リンク一覧_{compact_now()}.xlsx'
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = 'リンク一覧'
            headers = ['名前','ゾーン','ピン留め','お気に入り','開いた回数','最終使用','種類','URL','作業用','原本','状態','確認内容','タグ','メモ','登録元','更新日時']
            ws.append(headers)
            for cell in ws[1]:
                cell.font = Font(bold=True, color='FFFFFF')
                cell.fill = PatternFill('solid', fgColor='222222')
                cell.alignment = Alignment(horizontal='center')
            with self.lock:
                zone_names = {x.get('id'): x.get('name', '') for x in self.zones}
                for x in self.links:
                    row = [x.get('title',''), zone_names.get(x.get('zoneId'), ''), 'はい' if x.get('pinned') else '', 'はい' if x.get('favorite') else '', x.get('openCount', 0), x.get('openedAt',''), x.get('kind',''), x.get('url',''), x.get('workUrl') or x.get('workPath',''), x.get('originalUrl',''), x.get('status',''), x.get('statusText',''), '、'.join(x.get('tags',[])), x.get('note',''), x.get('source',''), x.get('updatedAt','')]
                    ws.append([spreadsheet_safe(v) for v in row])
            widths = [32,22,11,11,12,20,14,72,46,72,16,30,24,40,18,20]
            for i, width in enumerate(widths, start=1):
                ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = width
            ws.freeze_panes = 'A2'
            ws.auto_filter.ref = ws.dimensions
            wb.save(p)
            return {'ok': True, 'path': str(p)}
        except Exception:
            return self.export_csv()

    def open_save_dir(self):
        d = default_save_dir()
        open_path_or_url(str(d))
        return {'ok': True, 'path': str(d)}

    def shutdown(self, source=''):
        source = clean_text(source or 'shutdown')
        with self.lock:
            if self.shutdown_started:
                return {'ok': True, 'message': '終了処理中です。', 'source': source}
            self.shutdown_started = True
            self.stop_event.set()
            self.task['message'] = '終了しています。'
        # workerに新しい処理を取らせず、すでに取得した保存のみ
        # 先に終える。その後に最新snapshotをこのスレッドで必ず書く。
        self._save_event.set()
        worker = getattr(self, '_autosave_thread', None)
        if worker and worker is not threading.current_thread() and worker.is_alive():
            worker.join(timeout=3.0)
        try:
            self.autosave()
            self.flush_autosave()
        except Exception:
            pass

        def later():
            try:
                if self.server:
                    self.server.shutdown()
                    try:
                        self.server.server_close()
                    except Exception:
                        pass
            except Exception:
                pass
            finally:
                clear_runtime_info(self.instance_id)
                release_instance_mutex()
                self.closed_event.set()
        threading.Thread(target=later, daemon=True).start()
        return {'ok': True, 'message': '終了します。', 'source': source}


APP = LinkApp()


HTML_PAGE = r'''<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>リンク管理 · __WINDOW_MARKER__</title>
<style>
:root{
  color-scheme:light;--bg:#f3f6fa;--panel:#fff;--ink:#172033;--muted:#667085;--soft:#98a2b3;
  --line:#dfe5ec;--line-strong:#c9d3df;--blue:#1769e0;--blue2:#0f5bc8;--blue-soft:#edf5ff;
  --navy:#15243b;--green:#16845b;--amber:#a45f06;--red:#c73542;--shadow:0 12px 32px rgba(35,55,80,.10);
  --radius:14px;--header:58px;--status:34px
}
*{box-sizing:border-box}html,body{height:100%;margin:0}body{min-width:1024px;overflow:hidden;background:var(--bg);color:var(--ink);font-family:"Yu Gothic UI","Yu Gothic",Meiryo,system-ui,sans-serif;font-size:14px}
input[type="search"]::-webkit-search-cancel-button{display:none}
.sr-only{position:absolute!important;width:1px!important;height:1px!important;padding:0!important;margin:-1px!important;overflow:hidden!important;clip:rect(0,0,0,0)!important;white-space:nowrap!important;border:0!important}
button,input,textarea,select{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.48}
.app{height:100%;display:grid;grid-template-rows:var(--header) minmax(0,1fr) var(--status)}
.topbar{display:flex;align-items:center;gap:24px;padding:0 20px;border-bottom:1px solid var(--line);background:#fff;box-shadow:0 1px 4px rgba(20,40,70,.04);z-index:10}
.brand{display:flex;align-items:center;gap:10px;min-width:175px}.brand-mark{width:34px;height:34px;display:grid;place-items:center;border-radius:10px;background:linear-gradient(145deg,#2679eb,#1158bd);color:#fff;font-weight:800;box-shadow:0 6px 14px rgba(23,105,224,.24)}
.brand-text{line-height:1.15}.brand-text strong{display:block;font-size:16px}.brand-text span{display:block;margin-top:3px;color:var(--soft);font-size:10px;letter-spacing:.04em}
.tabs{display:flex;align-self:stretch;gap:4px}.tab{position:relative;border:0;background:transparent;color:#5b6677;padding:0 17px;font-weight:700}.tab:hover{color:var(--ink);background:#f7f9fc}.tab.active{color:var(--blue)}.tab.active:after{content:"";position:absolute;left:14px;right:14px;bottom:0;height:3px;border-radius:3px 3px 0 0;background:var(--blue)}
.top-spacer{flex:1}.top-note{color:var(--soft);font-size:12px;white-space:nowrap}.btn{min-height:36px;display:inline-flex;align-items:center;justify-content:center;gap:7px;border:1px solid var(--line-strong);border-radius:9px;padding:7px 12px;background:#fff;color:#344054;font-weight:700;white-space:nowrap;transition:.12s}
.btn:hover{border-color:#9fb4cd;background:#f8fafc}.btn:focus-visible,.icon-btn:focus-visible,.tab:focus-visible,.zone-toggle:focus-visible{outline:3px solid rgba(23,105,224,.20);outline-offset:1px}.btn.primary{border-color:var(--blue);background:var(--blue);color:#fff}.btn.primary:hover{border-color:var(--blue2);background:var(--blue2)}.btn.soft{border-color:#cfe1fa;background:var(--blue-soft);color:#1459b7}.btn.danger{border-color:#f1c5ca;background:#fff6f7;color:var(--red)}.btn.small{min-height:31px;padding:5px 10px;font-size:12px}.btn.link{border-color:transparent;background:transparent;color:var(--blue);padding-inline:8px}.btn.link:hover{background:var(--blue-soft)}
.main{min-height:0;overflow:hidden}.view{display:none;height:100%;min-height:0}.view.active{display:block}.content{height:100%;min-height:0;max-width:1540px;margin:0 auto;padding:16px 20px 14px}
#view-links .content{display:grid;grid-template-rows:auto auto minmax(0,1fr);gap:10px}
.search-panel{display:flex;align-items:center;gap:14px;padding:15px 17px;border:1px solid var(--line);border-radius:var(--radius);background:#fff;box-shadow:0 4px 14px rgba(31,52,80,.05)}
.search-copy{min-width:174px}.search-copy strong{display:block;font-size:17px}.search-copy span{display:block;margin-top:4px;color:var(--muted);font-size:11px}
.search-wrap{position:relative;flex:1}.search-icon{position:absolute;left:16px;top:50%;width:16px;height:16px;transform:translateY(-56%);border:2px solid #66788f;border-radius:50%;pointer-events:none}.search-icon:after{content:"";position:absolute;width:7px;height:2px;right:-6px;bottom:-3px;transform:rotate(45deg);border-radius:2px;background:#66788f}.search-input{width:100%;height:48px;border:2px solid #bdc9d8;border-radius:12px;padding:0 94px 0 44px;background:#fff;color:var(--ink);font-size:16px;outline:none}.search-input:focus{border-color:var(--blue);box-shadow:0 0 0 4px rgba(23,105,224,.11)}.search-clear{position:absolute;right:8px;top:8px;height:32px;border:0;border-radius:8px;background:#f1f4f8;color:#5f6c7e;padding:0 10px}.search-clear:hover{background:#e7edf4}.kbd-hint{min-width:160px;color:var(--muted);font-size:11px;line-height:1.65}.kbd{display:inline-block;min-width:20px;margin:0 2px;padding:1px 5px;border:1px solid #ccd5e0;border-bottom-width:2px;border-radius:5px;background:#fff;color:#4d5a6c;text-align:center;font-size:10px}
.controlbar{display:flex;align-items:center;gap:9px;min-height:40px}.controlbar.has-selection .segmented,.controlbar.has-selection>.field-select,.controlbar.has-selection>.zone-manage{display:none}.segmented{display:flex;gap:3px;padding:3px;border:1px solid var(--line);border-radius:10px;background:#fff}.seg{min-height:30px;border:0;border-radius:7px;padding:5px 11px;background:transparent;color:#5f6b7b;font-size:12px;font-weight:700}.seg:hover{background:#f0f4f8}.seg.active{background:var(--navy);color:#fff}.field-select{height:36px;border:1px solid var(--line-strong);border-radius:9px;padding:0 30px 0 10px;background:#fff;color:#344054;outline:none}.field-select:focus{border-color:var(--blue);box-shadow:0 0 0 3px rgba(23,105,224,.10)}.result-summary{margin-left:auto;color:var(--muted);font-size:12px}.selectionbar{display:none;align-items:center;gap:8px;margin-left:4px}.selectionbar.show{display:flex}.selectionbar .field-select{max-width:156px}.selection-count{color:var(--blue);font-size:12px;font-weight:800}
.results-card{min-height:0;display:grid;grid-template-rows:38px minmax(0,1fr);overflow:hidden;border:1px solid var(--line);border-radius:var(--radius);background:#fff;box-shadow:0 7px 22px rgba(31,52,80,.06)}
.list-head,.link-row{display:grid;grid-template-columns:34px 36px 36px minmax(260px,1.35fr) minmax(155px,.68fr) 112px 170px;align-items:center;column-gap:8px}.list-head{padding:0 13px;border-bottom:1px solid var(--line);background:#f8fafc;color:#7a8698;font-size:11px;font-weight:800}.list-scroll{min-height:0;overflow:auto;scrollbar-gutter:stable}.link-row{min-height:64px;padding:7px 13px;border-bottom:1px solid #edf0f4;cursor:pointer;transition:.1s}.link-row:last-child{border-bottom:0}.link-row:hover{background:#f4f9ff;box-shadow:inset 3px 0 #a8c8f3}.link-row:hover .link-title{color:var(--blue)}.link-row.active{position:relative;background:var(--blue-soft);box-shadow:inset 3px 0 var(--blue)}.link-row.opening{opacity:.7;cursor:progress}.check{width:17px;height:17px;margin:0;accent-color:var(--blue)}
.icon-btn{width:31px;height:31px;display:grid;place-items:center;border:0;border-radius:8px;background:transparent;color:#a3adba}.icon-btn:hover{background:#eef2f7;color:#6e7b8c}.icon-btn.favorite{color:#e0a100}.star:before{content:"";width:17px;height:17px;background:currentColor;clip-path:polygon(50% 0,61% 34%,98% 34%,68% 55%,79% 91%,50% 70%,21% 91%,32% 55%,2% 34%,39% 34%)}.icon-btn.pinned{color:var(--blue)}.pin:before{content:"";width:17px;height:17px;background:currentColor;clip-path:polygon(22% 0,78% 0,68% 30%,90% 50%,57% 50%,57% 70%,50% 100%,43% 70%,43% 50%,10% 50%,32% 30%)}.link-main{min-width:0;display:block;border:0;background:transparent;padding:0;text-align:left;color:inherit}.link-title{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:14px;font-weight:800}.link-title:hover{color:var(--blue);text-decoration:underline;text-underline-offset:2px}.link-url{display:block;margin-top:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#66758a;font-size:12px}.meta{min-width:0}.meta-top{display:flex;align-items:center;gap:5px;overflow:hidden}.kind{display:inline-block;max-width:112px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border-radius:999px;padding:3px 7px;background:#eef2f7;color:#596679;font-size:11px;font-weight:800}.zone-chip{display:inline-block;max-width:110px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border-radius:999px;padding:3px 7px;background:#edf5ff;color:#1758a7;font-size:11px;font-weight:800}.tag{display:inline-block;max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border:1px solid #d7e3f2;border-radius:999px;padding:2px 6px;color:#52667f;font-size:11px}.note-line{margin-top:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#66758a;font-size:11px}.status{font-size:12px;color:#596779}.status.issue{color:var(--red);font-weight:800}.status.warn{color:var(--amber);font-weight:800}.last-used{display:block;margin-top:3px;color:#748196;font-size:11px}.row-actions{display:flex;justify-content:flex-end;gap:5px}.row-actions .btn:first-child{min-width:58px}
.zone-section{border-bottom:1px solid var(--line)}.zone-section:last-child{border-bottom:0}.zone-head{position:sticky;top:0;z-index:3;display:flex;align-items:center;gap:9px;min-height:42px;padding:5px 12px;background:#f5f8fc;border-bottom:1px solid #e4e9f0}.zone-section.pinned-zone .zone-head{background:#edf5ff}.zone-toggle{width:28px;height:28px;display:grid;place-items:center;border:0;border-radius:7px;background:transparent;color:#5c6a7d;font-weight:900}.zone-toggle:hover{background:#e5ebf3}.zone-toggle:before{content:"";width:8px;height:8px;border-right:2px solid currentColor;border-bottom:2px solid currentColor;transform:rotate(45deg) translate(-1px,-1px)}.zone-section.collapsed .zone-toggle:before{transform:rotate(-45deg)}.zone-title{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px;font-weight:900}.zone-count{color:#69768a;font-size:11px}.zone-note{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#7c8899;font-size:11px}.zone-spacer{flex:1}.zone-empty{padding:18px 20px;color:#748196;font-size:12px}.zone-section.collapsed .zone-body{display:none}.zone-edit{min-height:28px;padding:4px 9px;font-size:11px}
.empty{height:100%;min-height:220px;display:grid;place-items:center;padding:38px}.empty-box{text-align:center;max-width:520px}.empty-icon{width:56px;height:56px;display:grid;place-items:center;margin:0 auto 14px;border-radius:16px;background:var(--blue-soft);color:var(--blue);font-size:24px}.empty h2{margin:0 0 7px;font-size:18px}.empty p{margin:0 0 17px;color:var(--muted);line-height:1.7}.empty-actions{display:flex;justify-content:center;gap:8px}
.page{height:100%;min-height:0;overflow:auto}.page-inner{max-width:1180px;margin:0 auto;padding:24px 24px 40px}.page-head{display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:18px}.page-head h1{margin:0;font-size:24px}.page-head p{margin:6px 0 0;color:var(--muted)}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px}.card{border:1px solid var(--line);border-radius:var(--radius);background:#fff;box-shadow:0 5px 18px rgba(31,52,80,.05)}.card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding:17px 18px 12px}.card-head h2{margin:0;font-size:16px}.card-head p{margin:5px 0 0;color:var(--muted);font-size:12px;line-height:1.55}.card-body{padding:0 18px 18px}.label{display:block;margin:14px 0 6px;color:#475467;font-size:12px;font-weight:800}.input,.textarea{width:100%;border:1px solid var(--line-strong);border-radius:9px;background:#fff;color:var(--ink);outline:none}.input{height:40px;padding:0 11px}.textarea{min-height:190px;padding:10px 11px;resize:vertical;line-height:1.6}.input:focus,.textarea:focus{border-color:var(--blue);box-shadow:0 0 0 3px rgba(23,105,224,.10)}.form-row{display:flex;align-items:center;gap:8px}.form-row .input{flex:1}.actions{display:flex;align-items:center;justify-content:flex-end;gap:8px;margin-top:12px}.help{color:var(--muted);font-size:11px;line-height:1.55}.toggle{display:flex;align-items:center;gap:7px;color:#526071;font-size:12px}.toggle input{width:16px;height:16px;accent-color:var(--blue)}
.candidate-card{margin-top:16px}.candidate-toolbar{display:flex;align-items:center;gap:8px;padding:11px 18px;border-top:1px solid var(--line);border-bottom:1px solid var(--line);background:#f8fafc}.candidate-toolbar span{margin-right:auto;color:var(--muted);font-size:12px}.candidate-list{max-height:320px;overflow:auto}.candidate{display:grid;grid-template-columns:30px minmax(0,1fr) 95px;gap:9px;align-items:center;padding:10px 18px;border-bottom:1px solid #edf0f4}.candidate:last-child{border-bottom:0}.candidate strong,.candidate small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.candidate small{margin-top:3px;color:var(--muted)}
.manage-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.manage-card{min-height:220px}.manage-card .card-body{display:flex;flex-direction:column;gap:8px}.manage-icon{width:38px;height:38px;display:grid;place-items:center;border-radius:10px;background:var(--blue-soft);color:var(--blue);font-size:11px;font-weight:900;letter-spacing:.04em}.statline{display:flex;align-items:center;justify-content:space-between;padding:9px 0;border-bottom:1px solid #edf0f4;color:var(--muted)}.statline strong{color:var(--ink)}.button-stack{display:grid;grid-template-columns:1fr 1fr;gap:8px}.path{overflow-wrap:anywhere;border-radius:8px;padding:8px 9px;background:#f6f8fb;color:#6c7889;font-size:10px;line-height:1.5}.shortcut-list{display:grid;grid-template-columns:1fr auto;gap:8px 16px;margin-top:4px;color:#5f6c7d;font-size:12px}.shortcut-list span:nth-child(even){text-align:right}
.statusbar{display:flex;align-items:center;gap:9px;padding:0 18px;border-top:1px solid var(--line);background:#fff;color:#657184;font-size:11px;z-index:8}.status-dot{width:7px;height:7px;border-radius:50%;background:var(--green)}.status-dot.busy{background:var(--blue);animation:pulse 1.2s infinite}.status-dot.error{background:var(--red)}.status-message{max-width:60%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.progress{display:none;width:150px;height:5px;overflow:hidden;border-radius:999px;background:#e7edf3}.progress.show{display:block}.progress i{display:block;height:100%;width:0;background:var(--blue);transition:width .2s}.status-spacer{flex:1}.save-state{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.task-stop{display:none}.task-stop.show{display:inline-flex}
.modal-layer{display:none;position:fixed;inset:0;z-index:40;place-items:center;padding:24px;background:rgba(18,29,45,.48);backdrop-filter:blur(2px)}.modal-layer.open{display:grid}.modal{width:min(760px,calc(100vw - 48px));max-height:calc(100vh - 48px);display:grid;grid-template-rows:auto minmax(0,1fr) auto;overflow:hidden;border:1px solid #cdd7e2;border-radius:16px;background:#fff;box-shadow:0 30px 90px rgba(15,30,50,.28)}.modal-head{display:flex;align-items:center;justify-content:space-between;padding:17px 20px;border-bottom:1px solid var(--line)}.modal-head h2{margin:0;font-size:18px}.close-btn{width:34px;height:34px;border:0;border-radius:8px;background:#f1f4f8;color:#536174;font-size:18px}.close-btn:hover{background:#e6ebf1}.modal-body{overflow:auto;padding:18px 20px}.modal-grid{display:grid;grid-template-columns:1fr 1fr;gap:0 14px}.span2{grid-column:1/-1}.modal-footer{display:flex;align-items:center;justify-content:flex-end;gap:8px;padding:13px 20px;border-top:1px solid var(--line);background:#fbfcfd}.required{color:var(--red)}
.zone-modal{width:min(680px,calc(100vw - 48px))}.zone-create{display:flex;align-items:flex-end;gap:9px;padding-bottom:18px;border-bottom:1px solid var(--line)}.zone-create>div{flex:1}.zone-manager-list{display:flex;flex-direction:column;gap:8px;margin-top:14px}.zone-manager-row{display:grid;grid-template-columns:minmax(0,1fr) auto auto;align-items:center;gap:8px;padding:9px;border:1px solid var(--line);border-radius:10px;background:#fafbfd}.zone-manager-empty{padding:24px 12px;text-align:center;color:var(--muted);line-height:1.7}.zone-help{margin:0 0 14px;color:var(--muted);font-size:12px;line-height:1.65}
.toast-area{position:fixed;right:18px;bottom:48px;z-index:60;display:flex;flex-direction:column;gap:8px;pointer-events:none}.toast{max-width:440px;border:1px solid #cbd8e7;border-left:4px solid var(--blue);border-radius:10px;padding:11px 13px;background:#fff;color:#344054;box-shadow:var(--shadow);line-height:1.5;animation:toast-in .16s ease-out}.toast.error{border-left-color:var(--red)}
@keyframes toast-in{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}@keyframes pulse{50%{opacity:.35}}
@media(max-width:1180px){.top-note{display:none}.list-head,.link-row{grid-template-columns:34px 34px 34px minmax(238px,1.35fr) minmax(130px,.62fr) 156px}.list-head .last-col,.link-row .last-col{display:none}.kbd-hint{min-width:120px}.controlbar{gap:6px}.seg{padding-inline:8px}.zone-manage{padding-inline:9px}}
@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important;animation:none!important;transition:none!important}}
</style>
</head>
<body>
<div class="app">
  <header class="topbar">
    <div class="brand"><div class="brand-mark">L</div><div class="brand-text"><strong>リンク管理</strong><span>DESKTOP LINK LIBRARY</span></div></div>
    <nav class="tabs" aria-label="画面切替">
      <button class="tab active" data-view="links" onclick="showView('links')">リンクを開く</button>
      <button class="tab" data-view="import" onclick="showView('import')">取り込み</button>
      <button class="tab" data-view="manage" onclick="showView('manage')">管理</button>
    </nav>
    <div class="top-spacer"></div><span class="top-note">カードをクリック / Enter で起動</span>
    <button class="btn primary" onclick="openLinkModal()">＋ リンク追加</button>
  </header>

  <main class="main">
    <section class="view active" id="view-links">
      <div class="content">
        <div class="search-panel">
          <div class="search-copy"><strong>リンクを探して開く</strong><span>名前・URL・タグ・メモを検索</span></div>
          <div class="search-wrap"><span class="search-icon" aria-hidden="true"></span><input id="searchInput" class="search-input" type="search" autocomplete="off" spellcheck="false" placeholder="探したいリンクを入力…" aria-label="リンクを検索"><button id="searchClear" class="search-clear" onclick="clearSearch()" hidden>クリア</button></div>
          <div class="kbd-hint"><span class="kbd">上</span><span class="kbd">下</span> 選択　<span class="kbd">Enter</span> 開く<br><span class="kbd">Ctrl</span>＋<span class="kbd">K</span> 検索へ移動</div>
        </div>
        <div class="controlbar" id="controlbar">
          <div class="segmented" aria-label="絞り込み">
            <button class="seg active" data-filter="all" aria-pressed="true" onclick="setFilter('all')">すべて</button><button class="seg" data-filter="pinned" aria-pressed="false" onclick="setFilter('pinned')">ピン留め</button><button class="seg" data-filter="favorite" aria-pressed="false" onclick="setFilter('favorite')">★ お気に入り</button><button class="seg" data-filter="recent" aria-pressed="false" onclick="setFilter('recent')">最近使用</button><button class="seg" data-filter="attention" aria-pressed="false" onclick="setFilter('attention')">要確認</button>
          </div>
          <select id="kindFilter" class="field-select" aria-label="種類で絞り込み" onchange="filterControlChanged()"><option value="">すべての種類</option></select>
          <select id="sortSelect" class="field-select" aria-label="並び順" onchange="filterControlChanged()"><option value="smart">おすすめ順（お気に入り・利用回数）</option><option value="recent">最近開いた順</option><option value="updated">更新順</option><option value="title">名前順</option></select>
          <button class="btn small soft zone-manage" onclick="openZoneModal()">＋ ゾーン</button>
          <div id="selectionbar" class="selectionbar"><span id="selectionCount" class="selection-count"></span><button class="btn small primary" onclick="openSelected()">まとめて開く</button><button class="btn small" onclick="copySelected()">コピー</button><select id="selectionZone" class="field-select" aria-label="選択中のリンクをゾーンへ移動" onchange="assignSelectedZone(this.value)"><option value="__choose__">ゾーンへ移動</option></select><button class="btn small" onclick="checkSelected()">点検</button><button class="btn small danger" onclick="deleteSelected()">削除</button></div>
          <span id="resultSummary" class="result-summary" aria-live="polite"></span>
        </div>
        <div class="results-card">
          <div class="list-head"><label><input id="selectVisible" class="check" type="checkbox" aria-label="表示中をすべて選択"></label><span title="ピン留め">ピン</span><span title="お気に入り">★</span><span>名前 / URL</span><span>ゾーン / 種類</span><span class="last-col">状態 / 最終使用</span><span style="text-align:right">行クリックで開く</span></div>
          <div id="linkList" class="list-scroll" role="list" aria-label="リンク一覧" aria-describedby="linkListHint"></div><span id="linkListHint" class="sr-only">リンクの行をクリックすると開きます。チェック、ピン、お気に入り、コピー、編集はそれぞれの操作だけを実行します。</span>
        </div>
      </div>
    </section>

    <section class="view" id="view-import"><div class="page"><div class="page-inner">
      <div class="page-head"><div><h1>リンクを取り込む</h1><p>複数のURLをまとめて登録するときだけ使う画面です。</p></div><button class="btn" onclick="showView('links')">一覧へ戻る</button></div>
      <div class="grid2">
        <article class="card"><div class="card-head"><div><h2>文章・URLを貼り付け</h2><p>メールやメモの文章からURLとWindowsパスを抽出します。</p></div></div><div class="card-body"><label class="label" for="bulkText">貼り付け内容</label><textarea id="bulkText" class="textarea" placeholder="URLを含む文章をここへ貼り付け…"></textarea><div class="actions"><button class="btn" onclick="importClipboard()">クリップボードから登録</button><button class="btn primary" onclick="importText()">抽出して登録</button></div></div></article>
        <article class="card"><div class="card-head"><div><h2>ファイル・フォルダーから抽出</h2><p>文書やOfficeファイル内のリンクを候補として確認できます。</p></div></div><div class="card-body"><label class="label" for="extractPath">対象</label><div class="form-row"><input id="extractPath" class="input" placeholder="ファイルまたはフォルダー"><button class="btn" onclick="chooseExtract('file')">ファイル</button><button class="btn" onclick="chooseExtract('folder')">フォルダー</button></div><div class="form-row" style="margin-top:12px;justify-content:space-between"><label class="toggle"><input id="extractRecursive" type="checkbox" checked>サブフォルダーも確認</label><label class="toggle">上限 <select id="extractMax" class="field-select"><option>200</option><option selected>500</option><option>1000</option></select> ファイル</label></div><div class="actions"><button class="btn primary" onclick="startExtract()">リンク候補を抽出</button></div></div></article>
      </div>
      <article id="candidateCard" class="card candidate-card"><div class="card-head"><div><h2>抽出した候補</h2><p id="candidateLead">候補はまだありません。</p></div></div><div class="candidate-toolbar"><label class="toggle"><input id="selectCandidates" type="checkbox">すべて選択</label><span id="candidateCount"></span><button class="btn small" onclick="clearCandidates()">候補を消去</button><button class="btn small primary" onclick="addCandidates()">選択を登録</button></div><div id="candidateList" class="candidate-list"></div></article>
    </div></div></section>

    <section class="view" id="view-manage"><div class="page"><div class="page-inner">
      <div class="page-head"><div><h1>管理</h1><p>普段は触らなくてよい点検・保存・出力をまとめています。</p></div><button class="btn" onclick="showView('links')">一覧へ戻る</button></div>
      <div class="manage-grid">
        <article class="card manage-card"><div class="card-head"><div><div class="manage-icon">QA</div><h2 style="margin-top:12px">リンク点検</h2><p>アクセス可否やファイルの存在をまとめて確認します。</p></div></div><div class="card-body"><div class="statline"><span>未確認・要確認</span><strong id="attentionStat">0件</strong></div><button class="btn primary" onclick="checkAttention()">要確認だけ点検</button><button class="btn" onclick="checkAll()">すべて点検</button></div></article>
        <article class="card manage-card"><div class="card-head"><div><div class="manage-icon">DB</div><h2 style="margin-top:12px">保存と復元</h2><p>変更内容は自動保存されます。JSONデータも読み込めます。</p></div></div><div class="card-body"><div id="dataPath" class="path"></div><div class="button-stack"><button class="btn" onclick="saveJson()">今すぐ保存</button><button class="btn" onclick="openSaveDir()">保存先を開く</button></div><button class="btn" onclick="document.getElementById('jsonFile').click()">JSONを追加読込</button><input id="jsonFile" type="file" accept=".json,.linkbook.json" hidden></div></article>
        <article class="card manage-card"><div class="card-head"><div><div class="manage-icon">EX</div><h2 style="margin-top:12px">出力と整理</h2><p>共有用ファイルの作成と重複データの整理を行います。</p></div></div><div class="card-body"><div class="button-stack"><button class="btn" onclick="exportData('xlsx')">Excel</button><button class="btn" onclick="exportData('csv')">CSV</button><button class="btn" onclick="exportData('html')">HTML</button><button class="btn danger" onclick="cleanupDuplicates()">重複を整理</button></div></div></article>
        <article class="card manage-card"><div class="card-head"><div><div class="manage-icon">KEY</div><h2 style="margin-top:12px">キーボード操作</h2><p>検索から起動までマウスなしで操作できます。</p></div></div><div class="card-body"><div class="shortcut-list"><span>検索へ移動</span><span><span class="kbd">Ctrl</span>＋<span class="kbd">K</span></span><span>次 / 前を選択</span><span><span class="kbd">下</span> <span class="kbd">上</span></span><span>選択中を開く</span><span><span class="kbd">Enter</span></span><span>URLをコピー</span><span><span class="kbd">Alt</span>＋<span class="kbd">Enter</span></span><span>編集</span><span><span class="kbd">F2</span></span><span>新規追加</span><span><span class="kbd">Ctrl</span>＋<span class="kbd">N</span></span></div></div></article>
      </div>
    </div></div></section>
  </main>

  <footer class="statusbar"><span id="statusDot" class="status-dot"></span><span id="statusMessage" class="status-message">準備完了</span><div id="progress" class="progress"><i id="progressBar"></i></div><button id="taskStop" class="btn link small task-stop" onclick="stopTask()">停止</button><span class="status-spacer"></span><span id="saveState" class="save-state">自動保存</span></footer>
</div>

<div id="linkModal" class="modal-layer" role="dialog" aria-modal="true" aria-labelledby="modalTitle"><div class="modal">
  <div class="modal-head"><h2 id="modalTitle">リンクを追加</h2><button class="close-btn" onclick="closeLinkModal()" aria-label="閉じる">×</button></div>
  <div class="modal-body"><input id="editId" type="hidden"><div class="modal-grid">
    <div class="span2"><label class="label" for="editUrl">URL またはファイルパス <span class="required">必須</span></label><input id="editUrl" class="input" placeholder="https://… または C:\…"></div>
    <div class="span2"><label class="label" for="editTitle">名前</label><input id="editTitle" class="input" placeholder="未入力ならURLから自動作成"></div>
    <div><label class="label" for="editTags">タグ</label><input id="editTags" class="input" placeholder="案件, 定例, 資料"></div>
    <div><label class="label" for="editOpenMode">開き方</label><select id="editOpenMode" class="input"><option value="">通常</option><option value="window">新しいウィンドウ</option><option value="private">InPrivate</option><option value="app">アプリ表示</option><option value="desktop">デスクトップOffice</option><option value="desktop_view">Officeで閲覧</option></select></div>
    <div><label class="label" for="editZone">所属ゾーン</label><select id="editZone" class="input"><option value="">ゾーン未設定</option></select></div>
    <div><span class="label">表示の優先</span><div class="form-row" style="height:40px"><label class="toggle"><input id="editPinned" type="checkbox">ピン留め</label><label class="toggle"><input id="editFavorite" type="checkbox">お気に入り</label></div></div>
    <div class="span2"><label class="label" for="editNote">メモ</label><textarea id="editNote" class="textarea" style="min-height:92px" placeholder="検索に使う補足など"></textarea></div>
  </div></div>
  <div class="modal-footer"><button id="deleteFromModal" class="btn danger" onclick="deleteFromModal()" style="margin-right:auto" hidden>このリンクを削除</button><button class="btn" onclick="closeLinkModal()">キャンセル</button><button class="btn" onclick="saveLink(true)">保存して開く</button><button class="btn primary" onclick="saveLink(false)">保存</button></div>
</div></div>
<div id="zoneModal" class="modal-layer" role="dialog" aria-modal="true" aria-labelledby="zoneModalTitle"><div class="modal zone-modal">
  <div class="modal-head"><h2 id="zoneModalTitle">ゾーンを管理</h2><button class="close-btn" onclick="closeZoneModal()" aria-label="閉じる">×</button></div>
  <div class="modal-body">
    <p class="zone-help">用途に合わせて自由に作成できます。最初から「部門予定表」などのゾーンは作成していません。</p>
    <div class="zone-create"><div><label class="label" for="newZoneName">新しいゾーン名</label><input id="newZoneName" class="input" maxlength="40" placeholder="例：部門予定表"></div><button class="btn primary" onclick="createZone()">作成</button></div>
    <div id="zoneManagerList" class="zone-manager-list"></div>
  </div>
  <div class="modal-footer"><button class="btn primary" onclick="closeZoneModal()">完了</button></div>
</div></div>
<div id="toastArea" class="toast-area" aria-live="polite"></div>
<div id="activeAnnounce" class="sr-only" aria-live="polite" aria-atomic="true"></div>

<script>
const API_TOKEN='__API_TOKEN__';
const CLIENT_ID=sessionStorage.getItem('linkManagerClientId')||((crypto.randomUUID&&crypto.randomUUID())||Math.random().toString(36).slice(2));
sessionStorage.setItem('linkManagerClientId',CLIENT_ID);
const PAGE_ID=(crypto.randomUUID&&crypto.randomUUID())||Math.random().toString(36).slice(2);
let STATE={links:[],zones:[],candidates:[],task:{},stats:{kinds:{},statuses:{}},revision:0};
let currentView='links',filterMode='all',activeId='',selected=new Set(),candidateSelected=new Set(),renderedIds=[],pollTimer=0,polling=false,modalReturnFocus=null,zoneReturnKey='',closingSent=false,bulkOpening=false;
const systemCollapsed={pinned:false,other:false};
const MAX_RENDERED=600,openingIds=new Set(),recentOpenAt=new Map();
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const attr=esc;
const norm=s=>String(s??'').normalize('NFKC').toLocaleLowerCase('ja-JP').replace(/\s+/g,' ').trim();
const ISSUE=new Set(['見つからない','確認できない','要確認','サインイン必要','未確認']);
function clientPayload(extra={}){return {clientId:CLIENT_ID,pageId:PAGE_ID,instanceId:STATE.instanceId||'',...extra}}
async function api(path,data={},timeout=15000){const ac=new AbortController(),timer=setTimeout(()=>ac.abort(),timeout);try{const res=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-LinkManager-Token':API_TOKEN},body:JSON.stringify(data||{}),signal:ac.signal,cache:'no-store'});let out={};try{out=await res.json()}catch(_){throw new Error('本体から正しい応答がありません。')}if(!res.ok||out.ok===false&&res.status>=400)throw new Error(out.message||`通信エラー (${res.status})`);return out}finally{clearTimeout(timer)}}
function toast(message,type=''){if(!message)return;const n=document.createElement('div');n.className='toast '+type;n.textContent=message;$('toastArea').append(n);setTimeout(()=>n.remove(),4200)}
function showView(name){currentView=name;document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id===`view-${name}`));document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.view===name));if(name==='links')setTimeout(()=>$('searchInput').focus(),30);if(name==='manage')renderManage()}
function focusSearch(){showView('links');$('searchInput').focus();$('searchInput').select()}
function clearSearch(){$('searchInput').value='';activeId='';selected.clear();renderLinks();$('searchInput').focus()}
function setFilter(mode){filterMode=mode;selected.clear();document.querySelectorAll('.seg').forEach(x=>{const active=x.dataset.filter===mode;x.classList.toggle('active',active);x.setAttribute('aria-pressed',String(active))});activeId='';renderLinks()}
function filterControlChanged(){selected.clear();activeId='';renderLinks()}
function zoneMap(){return new Map((STATE.zones||[]).map(x=>[x.id,x]))}
function zoneNameFor(id){return zoneMap().get(id)?.name||''}
function searchScore(x,q){if(!q)return 0;const words=q.split(' ').filter(Boolean),title=norm(x.title),url=norm(x.url),tags=norm((x.tags||[]).join(' ')),note=norm(x.note),kind=norm(x.kind),zone=norm(zoneNameFor(x.zoneId));if(!words.every(w=>title.includes(w)||url.includes(w)||tags.includes(w)||note.includes(w)||kind.includes(w)||zone.includes(w)))return -1;let s=0;if(title===q)s+=1000;if(title.startsWith(q))s+=500;if(title.includes(q))s+=260;if(zone===q)s+=220;if(tags.includes(q))s+=170;if(url.includes(q))s+=115;if(note.includes(q))s+=70;for(const w of words){if(title.startsWith(w))s+=35;if(tags.split(' ').includes(w))s+=28;if(zone.startsWith(w))s+=24}return s}
function timestamp(v){const t=Date.parse(String(v||'').replace(' ','T'));return Number.isFinite(t)?t:0}
function stableCompare(x,y){return String(x.title||'').localeCompare(String(y.title||''),'ja')||String(x.id||'').localeCompare(String(y.id||''))}
function smartCompare(x,y){return Number(!!y.pinned)-Number(!!x.pinned)||Number(!!y.favorite)-Number(!!x.favorite)||Math.max(0,Number(y.openCount)||0)-Math.max(0,Number(x.openCount)||0)||timestamp(y.openedAt)-timestamp(x.openedAt)||timestamp(y.updatedAt)-timestamp(x.updatedAt)||stableCompare(x,y)}
function visibleLinks(){const q=norm($('searchInput')?.value),kind=$('kindFilter')?.value||'',sort=$('sortSelect')?.value||'smart';let arr=(STATE.links||[]).map(x=>({x,score:searchScore(x,q)})).filter(o=>o.score>=0).filter(o=>!kind||o.x.kind===kind).filter(o=>filterMode==='all'||filterMode==='pinned'&&o.x.pinned||filterMode==='favorite'&&o.x.favorite||filterMode==='recent'&&o.x.openedAt||filterMode==='attention'&&ISSUE.has(o.x.status||'未確認'));
  arr.sort((a,b)=>{const x=a.x,y=b.x;if(sort==='smart'){if(q&&b.score!==a.score)return b.score-a.score;return smartCompare(x,y)}if(sort==='title')return stableCompare(x,y);if(sort==='updated')return timestamp(y.updatedAt)-timestamp(x.updatedAt)||stableCompare(x,y);if(sort==='recent')return timestamp(y.openedAt)-timestamp(x.openedAt)||Math.max(0,Number(y.openCount)||0)-Math.max(0,Number(x.openCount)||0)||stableCompare(x,y);return stableCompare(x,y)});return arr.map(o=>o.x)}
function shortDate(v){if(!v)return '未使用';const d=new Date(String(v).replace(' ','T'));if(Number.isNaN(d.getTime()))return v;const now=new Date(),same=d.toDateString()===now.toDateString();return same?d.toLocaleTimeString('ja-JP',{hour:'2-digit',minute:'2-digit'}):d.toLocaleDateString('ja-JP',{month:'numeric',day:'numeric'})}
function statusClass(s){return ['見つからない','確認できない'].includes(s)?'issue':['要確認','サインイン必要','未確認'].includes(s)?'warn':''}
function renderKinds(){const select=$('kindFilter'),current=select.value,kinds=Object.entries(STATE.stats?.kinds||{}).sort((a,b)=>a[0].localeCompare(b[0],'ja'));select.innerHTML='<option value="">すべての種類</option>'+kinds.map(([k,n])=>`<option value="${attr(k)}">${esc(k)} (${n})</option>`).join('');if(kinds.some(([k])=>k===current))select.value=current}
function displayedLinks(){const byId=new Map((STATE.links||[]).map(x=>[x.id,x]));return renderedIds.map(id=>byId.get(id)).filter(Boolean)}
function renderSelectionUi(arr=displayedLinks()){$('selectionbar').classList.toggle('show',selected.size>0);$('controlbar').classList.toggle('has-selection',selected.size>0);$('selectionCount').textContent=`${selected.size}件選択中`;const all=arr.length>0&&arr.every(x=>selected.has(x.id));$('selectVisible').checked=all;$('selectVisible').indeterminate=!all&&arr.some(x=>selected.has(x.id))}
function announceActive(){const x=(STATE.links||[]).find(v=>v.id===activeId);$('activeAnnounce').textContent=x?`${x.title||x.url}を選択。Enterキーで開きます。`:''}
function linkRowHtml(x){const label=x.title||x.url,tags=(x.tags||[]).slice(0,1).map(t=>`<span class="tag">${esc(t)}</span>`).join(''),status=x.status||'未確認',note=x.note?`<div class="note-line">${esc(x.note)}</div>`:'',zone=zoneNameFor(x.zoneId),zoneChip=zone?`<span class="zone-chip" title="${attr(zone)}">${esc(zone)}</span>`:'';return `<div class="link-row ${x.id===activeId?'active':''}" role="listitem" aria-current="${x.id===activeId?'true':'false'}" data-id="${attr(x.id)}"><input class="check row-check" type="checkbox" ${selected.has(x.id)?'checked':''} aria-label="${attr(label)}を選択"><button class="icon-btn pin ${x.pinned?'pinned':''}" aria-label="${attr(label)}をピン留め${x.pinned?'から外す':'する'}" aria-pressed="${!!x.pinned}" title="ピン留め"></button><button class="icon-btn star ${x.favorite?'favorite':''}" aria-label="${attr(label)}をお気に入り${x.favorite?'から外す':'に追加'}" aria-pressed="${!!x.favorite}" title="お気に入り"></button><button class="link-main open-title" aria-label="${attr(label)}を開く" title="${attr(x.url)}"><span class="link-title">${esc(label)}</span><span class="link-url">${esc(x.url)}</span></button><div class="meta"><div class="meta-top">${zoneChip}<span class="kind">${esc(x.kind||'未分類')}</span>${tags}</div>${note}</div><div class="last-col"><span class="status ${statusClass(status)}">${esc(status)}</span><span class="last-used">${esc(shortDate(x.openedAt))} · ${Math.max(0,Number(x.openCount)||0)}回</span></div><div class="row-actions"><button class="btn small primary open-btn" aria-label="${attr(label)}を開く">開く</button><button class="btn small copy-btn" aria-label="${attr(label)}のURLをコピー">コピー</button><button class="btn small edit-btn" aria-label="${attr(label)}を編集">編集</button></div></div>`}
function groupedViewEnabled(){return !norm($('searchInput')?.value)&&filterMode==='all'&&!($('kindFilter')?.value||'')&&($('sortSelect')?.value||'smart')==='smart'&&((STATE.zones||[]).length||(STATE.links||[]).some(x=>x.pinned))}
function buildDisplayGroups(arr){const zones=[...(STATE.zones||[])].sort((a,b)=>Number(a.order||0)-Number(b.order||0)),valid=new Set(zones.map(x=>x.id)),all=STATE.links||[],groups=[],limited=arr.length<all.length;const pinned=arr.filter(x=>x.pinned),pinnedCount=all.filter(x=>x.pinned).length;groups.push({key:'pinned',name:'ピン留め',items:pinned,collapsed:systemCollapsed.pinned,count:pinnedCount,kind:'pinned',empty:pinnedCount&&limited?'ピン留めリンクは表示上限の対象外です。検索で絞り込んでください。':'各リンクのピンボタンを押すと、ここからすぐ開けます。'});for(const z of zones){const assigned=all.filter(x=>x.zoneId===z.id),pinCount=assigned.filter(x=>x.pinned).length,normalCount=assigned.length-pinCount,items=arr.filter(x=>!x.pinned&&x.zoneId===z.id);groups.push({key:z.id,name:z.name,items,collapsed:!!z.collapsed,count:assigned.length,pinCount,kind:'custom',empty:normalCount&&limited?'このゾーンのリンクは表示上限の対象外です。検索でゾーン名を入力してください。':pinCount?'このゾーンのリンクはピン留め枠に表示されています。':'このゾーンにリンクはありません。'})}const otherCount=all.filter(x=>!x.pinned&&!valid.has(x.zoneId)).length,otherItems=arr.filter(x=>!x.pinned&&!valid.has(x.zoneId));groups.push({key:'other',name:'ゾーン未設定',items:otherItems,collapsed:systemCollapsed.other,count:otherCount,kind:'other',empty:otherCount&&limited?'ゾーン未設定リンクは表示上限の対象外です。検索で絞り込んでください。':'ゾーン未設定のリンクはありません。'});return groups}
function zoneSectionHtml(g){const collapsed=!!g.collapsed,note=g.pinCount?`うち${g.pinCount}件はピン留めへ表示`:g.kind==='pinned'?'すぐ開くリンク':'',labelId=`zone-label-${String(g.key).replace(/[^A-Za-z0-9_-]/g,'')}`;return `<section class="zone-section ${g.kind==='pinned'?'pinned-zone ':''}${collapsed?'collapsed':''}" data-zone="${attr(g.key)}" aria-labelledby="${attr(labelId)}"><div class="zone-head"><button class="zone-toggle" data-zone-toggle="${attr(g.key)}" aria-expanded="${!collapsed}" aria-label="${attr(g.name)}を${collapsed?'展開':'折りたたむ'}"></button><span id="${attr(labelId)}" class="zone-title">${esc(g.name)}</span><span class="zone-count">${g.count}件</span>${note?`<span class="zone-note">${esc(note)}</span>`:''}<span class="zone-spacer"></span>${g.kind==='custom'?`<button class="btn zone-edit" data-zone-edit="${attr(g.key)}" aria-label="${attr(g.name)}の名前変更と削除">名前・削除</button>`:''}</div><div class="zone-body">${g.items.length?g.items.map(linkRowHtml).join(''):`<div class="zone-empty">${esc(g.empty)}</div>`}</div></section>`}
function renderLinks(){const q=$('searchInput')?.value||'';$('searchClear').hidden=!q;const matches=visibleLinks(),arr=matches.slice(0,MAX_RENDERED),grouped=groupedViewEnabled(),groups=grouped?buildDisplayGroups(arr):[];renderedIds=grouped?groups.filter(g=>!g.collapsed).flatMap(g=>g.items.map(x=>x.id)):arr.map(x=>x.id);const allowed=new Set(renderedIds);for(const id of [...selected])if(!allowed.has(id))selected.delete(id);if(!activeId||!allowed.has(activeId))activeId=renderedIds[0]||'';const total=(STATE.links||[]).length;$('resultSummary').textContent=matches.length>MAX_RENDERED?`先頭${arr.length} / ${matches.length}件（全${total}件）`:grouped?`${total}件 · ${(STATE.zones||[]).length}ゾーン`:`${matches.length} / ${total}件`;renderSelectionUi();
  const list=$('linkList');if(!arr.length&&!grouped){$('activeAnnounce').textContent='';const hasLinks=total>0;list.innerHTML=`<div class="empty"><div class="empty-box"><div class="empty-icon">${hasLinks?'0':'L'}</div><h2>${hasLinks?'条件に合うリンクがありません':'最初のリンクを追加しましょう'}</h2><p>${hasLinks?'検索語や絞り込みを変えてください。':'追加後は起動時から検索欄へ入力し、Enterですぐ開けます。'}</p><div class="empty-actions">${hasLinks?'<button class="btn" onclick="resetFilters()">絞り込みを解除</button>':'<button class="btn primary" onclick="openLinkModal()">＋ リンク追加</button><button class="btn" onclick="showView(\'import\')">まとめて取り込む</button>'}</div></div></div>`;return}
  list.innerHTML=grouped?groups.map(zoneSectionHtml).join(''):arr.map(linkRowHtml).join('');if(matches.length>MAX_RENDERED)list.insertAdjacentHTML('beforeend',`<div style="padding:16px;text-align:center;color:#66758a">先頭${MAX_RENDERED}件だけを操作対象にしています。検索で絞り込んでください。</div>`);announceActive()}
function resetFilters(){$('searchInput').value='';$('kindFilter').value='';filterMode='all';$('sortSelect').value='smart';selected.clear();document.querySelectorAll('.seg').forEach(x=>{const active=x.dataset.filter==='all';x.classList.toggle('active',active);x.setAttribute('aria-pressed',String(active))});activeId='';renderLinks();focusSearch()}
function setActive(id,scroll=false){activeId=id;document.querySelectorAll('.link-row').forEach(r=>{const active=r.dataset.id===id;r.classList.toggle('active',active);r.setAttribute('aria-current',String(active))});announceActive();if(scroll)document.querySelector(`.link-row[data-id="${CSS.escape(id)}"]`)?.scrollIntoView({block:'nearest'})}
async function openOne(id){const now=Date.now();if(openingIds.has(id)||now-(recentOpenAt.get(id)||0)<900)return;openingIds.add(id);recentOpenAt.set(id,now);const row=document.querySelector(`.link-row[data-id="${CSS.escape(id)}"]`);row?.classList.add('opening');row?.querySelectorAll('button').forEach(b=>b.disabled=true);try{const res=await api('/api/links/open',{ids:[id]});toast(res.message||((res.opened||0)?'起動要求を送りました。':'リンクを開けませんでした。'),res.ok?'':'error');await refresh()}catch(e){toast(e.message,'error')}finally{openingIds.delete(id);row?.classList.remove('opening');$('searchInput').focus()}}
async function copyIds(ids){if(!ids.length)return toast('コピーするリンクを選んでください。','error');try{const r=await api('/api/links/copy',{ids});toast(r.ok?`${r.copied||0}件のURLをコピーしました。`:(r.message||'コピーできませんでした。'),r.ok?'':'error')}catch(e){toast(e.message,'error')}}
async function toggleFlag(id,field){const x=(STATE.links||[]).find(v=>v.id===id);if(!x)return;try{const r=await api('/api/links/flag',{id,field,value:!x[field]});if(!r.ok)throw new Error(r.message);await refresh();$('searchInput').focus()}catch(e){toast(e.message,'error')}}
function toggleFavorite(id){return toggleFlag(id,'favorite')}
function togglePinned(id){return toggleFlag(id,'pinned')}
function selectedIds(){return [...selected]}
async function openSelected(){if(bulkOpening)return;const ids=selectedIds().filter(id=>!openingIds.has(id));if(!ids.length)return toast('リンクを選択してください。','error');bulkOpening=true;const now=Date.now();ids.forEach(id=>{openingIds.add(id);recentOpenAt.set(id,now)});try{const r=await api('/api/links/open',{ids});toast(r.message||`${r.opened||0}件へ起動要求を送りました。`,r.ok?'':'error');selected.clear();await refresh();focusSearch()}catch(e){toast(e.message,'error')}finally{ids.forEach(id=>openingIds.delete(id));bulkOpening=false}}
function copySelected(){return copyIds(selectedIds())}
async function assignSelectedZone(zoneId){if(zoneId==='__choose__')return;const ids=selectedIds();if(!ids.length){$('selectionZone').value='__choose__';return toast('移動するリンクを選択してください。','error')}try{const r=await api('/api/links/zone',{ids,zoneId});if(!r.ok)throw new Error(r.message);const name=zoneId?zoneNameFor(zoneId):'ゾーン未設定';selected.clear();await refresh();$('selectionZone').value='__choose__';toast(`${r.updated||0}件を「${name}」へ移動しました。`);focusSearch()}catch(e){$('selectionZone').value='__choose__';toast(e.message,'error')}}
async function checkSelected(){const ids=selectedIds();if(!ids.length)return toast('点検するリンクを選択してください。','error');const r=await api('/api/check_start',{ids});toast(r.message||'点検を開始しました。');schedulePoll(300)}
async function deleteIds(ids){if(!ids.length)return;if(!confirm(`${ids.length}件のリンクを削除します。\nこの操作は元に戻せません。`))return;try{const r=await api('/api/links/delete',{ids});selected.clear();toast(`${r.deleted||0}件を削除しました。`);await refresh();focusSearch()}catch(e){toast(e.message,'error')}}
function deleteSelected(){return deleteIds(selectedIds())}
function renderZoneOptions(){const zones=[...(STATE.zones||[])].sort((a,b)=>Number(a.order||0)-Number(b.order||0)),edit=$('editZone'),selection=$('selectionZone'),editCurrent=edit?.value||'',selectionCurrent=selection?.value||'__choose__',options=zones.map(z=>`<option value="${attr(z.id)}">${esc(z.name)}</option>`).join('');if(edit){edit.innerHTML='<option value="">ゾーン未設定</option>'+options;edit.value=zones.some(z=>z.id===editCurrent)?editCurrent:''}if(selection){selection.innerHTML='<option value="__choose__">ゾーンへ移動</option><option value="">ゾーン未設定へ</option>'+options;selection.value=selectionCurrent==='__choose__'||selectionCurrent===''||zones.some(z=>z.id===selectionCurrent)?selectionCurrent:'__choose__'}}
function openLinkModal(id=''){modalReturnFocus=document.activeElement;renderZoneOptions();const x=id?(STATE.links||[]).find(v=>v.id===id):null;$('modalTitle').textContent=x?'リンクを編集':'リンクを追加';$('editId').value=x?.id||'';$('editUrl').value=x?.url||'';$('editTitle').value=x?.title||'';$('editTags').value=(x?.tags||[]).join(', ');$('editOpenMode').value=x?.openMode||'';$('editZone').value=x?.zoneId||'';$('editNote').value=x?.note||'';$('editPinned').checked=!!x?.pinned;$('editFavorite').checked=!!x?.favorite;$('deleteFromModal').hidden=!x;document.querySelector('.app').inert=true;$('linkModal').classList.add('open');setTimeout(()=>$(x?'editTitle':'editUrl').focus(),50)}
function closeLinkModal(){$('linkModal').classList.remove('open');document.querySelector('.app').inert=false;modalReturnFocus?.focus?.();modalReturnFocus=null}
async function saveLink(openAfter=false){const id=$('editId').value,item={id,url:$('editUrl').value,title:$('editTitle').value,tags:$('editTags').value,openMode:$('editOpenMode').value,zoneId:$('editZone').value,note:$('editNote').value,pinned:$('editPinned').checked,favorite:$('editFavorite').checked,source:'手入力'};if(!item.url.trim())return toast('URLまたはファイルパスを入力してください。','error'),$('editUrl').focus();try{const r=id?await api('/api/links/update',item):await api('/api/links/add',[item]);if(!r.ok)throw new Error(r.message||'保存できませんでした。');const savedId=id||(r.addedIds||[])[0]||(r.skippedIds||[])[0]||'';if(!id&&!r.added&&!savedId)throw new Error('登録できるURLまたはパスとして認識できませんでした。');closeLinkModal();await refresh();activeId=savedId||activeId;renderLinks();toast(id?'更新しました。':r.skipped?'同じリンクが登録済みです。':'登録しました。');if(openAfter&&savedId)await openOne(savedId)}catch(e){toast(e.message,'error')}}
async function deleteFromModal(){const id=$('editId').value;if(!id||!confirm('このリンクを削除します。\nこの操作は元に戻せません。'))return;try{const r=await api('/api/links/delete',{ids:[id]});closeLinkModal();toast(`${r.deleted||0}件を削除しました。`);await refresh();focusSearch()}catch(e){toast(e.message,'error')}}
function renderZoneManager(){const zones=[...(STATE.zones||[])].sort((a,b)=>Number(a.order||0)-Number(b.order||0));$('zoneManagerList').innerHTML=zones.length?zones.map(z=>{const count=(STATE.links||[]).filter(x=>x.zoneId===z.id).length;return `<div class="zone-manager-row" data-zone-row="${attr(z.id)}"><div><input class="input zone-name-input" maxlength="40" value="${attr(z.name)}" aria-label="${attr(z.name)}の名前"><span class="help">${count}件のリンク${z.collapsed?' · 折りたたみ中':''}</span></div><button class="btn small save-zone-name" data-id="${attr(z.id)}" aria-label="${attr(z.name)}の名前を保存">名前を保存</button><button class="btn small danger delete-zone" data-id="${attr(z.id)}" aria-label="${attr(z.name)}を削除">削除</button></div>`}).join(''):'<div class="zone-manager-empty">まだゾーンはありません。<br>予定表・申請・共有資料など、必要な名前で作成してください。</div>'}
function openZoneModal(zoneId=''){modalReturnFocus=document.activeElement;zoneReturnKey=zoneId;renderZoneManager();document.querySelector('.app').inert=true;$('zoneModal').classList.add('open');setTimeout(()=>{const input=zoneId?document.querySelector(`[data-zone-row="${CSS.escape(zoneId)}"] .zone-name-input`):$('newZoneName');input?.focus();input?.select?.()},50)}
function closeZoneModal(){$('zoneModal').classList.remove('open');document.querySelector('.app').inert=false;$('newZoneName').value='';const fallback=zoneReturnKey?document.querySelector(`[data-zone-edit="${CSS.escape(zoneReturnKey)}"]`):null,target=modalReturnFocus?.isConnected?modalReturnFocus:fallback||$('searchInput');target?.focus?.();modalReturnFocus=null;zoneReturnKey=''}
async function createZone(){const name=$('newZoneName').value.trim();if(!name)return toast('ゾーン名を入力してください。','error'),$('newZoneName').focus();try{const r=await api('/api/zones/add',{name});if(!r.ok)throw new Error(r.message);$('newZoneName').value='';await refresh();renderZoneManager();toast(`「${r.item.name}」を作成しました。`);$('newZoneName').focus()}catch(e){toast(e.message,'error')}}
async function saveZoneName(id){const input=document.querySelector(`[data-zone-row="${CSS.escape(id)}"] .zone-name-input`),name=input?.value.trim()||'';if(!name)return toast('ゾーン名を入力してください。','error'),input?.focus();try{const r=await api('/api/zones/update',{id,name});if(!r.ok)throw new Error(r.message);await refresh();renderZoneManager();toast('ゾーン名を更新しました。');document.querySelector(`[data-zone-row="${CSS.escape(id)}"] .zone-name-input`)?.focus()}catch(e){toast(e.message,'error')}}
async function removeZone(id){const z=(STATE.zones||[]).find(x=>x.id===id);if(!z||!confirm(`ゾーン「${z.name}」を削除します。\nリンク自体は削除せず、ゾーン未設定へ戻します。`))return;try{const r=await api('/api/zones/delete',{id});if(!r.ok)throw new Error(r.message);await refresh();renderZoneManager();toast(`ゾーンを削除し、${r.moved||0}件をゾーン未設定へ戻しました。`)}catch(e){toast(e.message,'error')}}
async function toggleZone(key){const scroll=$('linkList').scrollTop;if(key==='pinned'||key==='other'){systemCollapsed[key]=!systemCollapsed[key];renderLinks();$('linkList').scrollTop=scroll;document.querySelector(`[data-zone-toggle="${key}"]`)?.focus();return}const z=(STATE.zones||[]).find(x=>x.id===key);if(!z)return;const before=!!z.collapsed;z.collapsed=!before;renderLinks();$('linkList').scrollTop=scroll;try{const r=await api('/api/zones/update',{id:key,collapsed:!before});if(!r.ok)throw new Error(r.message);await refresh();$('linkList').scrollTop=scroll;document.querySelector(`[data-zone-toggle="${CSS.escape(key)}"]`)?.focus()}catch(e){z.collapsed=before;renderLinks();toast(e.message,'error')}}
async function importText(){const text=$('bulkText').value.trim();if(!text)return toast('取り込む文章を貼り付けてください。','error');try{const r=await api('/api/import_text',{text});if(!(r.added||r.skipped))throw new Error('登録できるURLまたはパスが見つかりませんでした。');$('bulkText').value='';toast(`${r.added||0}件を登録${r.skipped?`、${r.skipped}件は登録済み`:''}。`);await refresh();showView('links')}catch(e){toast(e.message,'error')}}
async function importClipboard(){try{const r=await api('/api/import_clipboard',{});if(!(r.added||r.skipped))throw new Error('クリップボードに登録できるリンクがありません。');toast(`${r.added||0}件を登録${r.skipped?`、${r.skipped}件は登録済み`:''}。`);await refresh();showView('links')}catch(e){toast(e.message,'error')}}
async function chooseExtract(kind){try{const r=await api('/api/choose_path',{kind});if(r.path)$('extractPath').value=r.path;else if(r.message)toast(r.message,'error')}catch(e){toast(e.message,'error')}}
async function startExtract(){const path=$('extractPath').value.trim();if(!path)return toast('対象を選択してください。','error');try{candidateSelected.clear();const r=await api('/api/extract_path_start',{path,recursive:$('extractRecursive').checked,maxFiles:Number($('extractMax').value)||500});toast(r.message||'抽出を開始しました。');schedulePoll(250)}catch(e){toast(e.message,'error')}}
function renderCandidates(){const arr=STATE.candidates||[];$('candidateLead').textContent=arr.length?`${arr.length}件の候補から登録するものを選んでください。`:'候補はまだありません。';$('candidateCount').textContent=`${candidateSelected.size} / ${arr.length}件選択`;$('selectCandidates').checked=arr.length>0&&arr.every(x=>candidateSelected.has(x.id));$('selectCandidates').indeterminate=arr.some(x=>candidateSelected.has(x.id))&&!arr.every(x=>candidateSelected.has(x.id));$('candidateList').innerHTML=arr.length?arr.map(x=>`<label class="candidate"><input class="check candidate-check" data-id="${attr(x.id)}" type="checkbox" ${candidateSelected.has(x.id)?'checked':''}><span><strong>${esc(x.title||x.url)}</strong><small>${esc(x.url)}</small></span><span class="kind">${esc(x.kind||'未分類')}</span></label>`).join(''):'<div style="padding:26px;text-align:center;color:#8490a0">ファイルを選んで「リンク候補を抽出」を押してください。</div>'}
async function addCandidates(){const ids=[...candidateSelected];if(!ids.length)return toast('登録する候補を選択してください。','error');try{const r=await api('/api/candidates/add',{ids});candidateSelected.clear();toast(`${r.added||0}件を登録しました。`);await refresh();showView('links')}catch(e){toast(e.message,'error')}}
async function clearCandidates(){if(!(STATE.candidates||[]).length)return;await api('/api/candidates/clear',{});candidateSelected.clear();await refresh()}
function attentionIds(){return (STATE.links||[]).filter(x=>ISSUE.has(x.status||'未確認')).map(x=>x.id)}
function renderManage(){$('attentionStat').textContent=`${attentionIds().length}件`;$('dataPath').textContent=STATE.autosavePath||STATE.currentJsonPath||'既定の保存先'}
async function startCheck(ids){if(!ids.length)return toast('点検するリンクはありません。');try{const r=await api('/api/check_start',{ids});toast(r.message||'点検を開始しました。');schedulePoll(250)}catch(e){toast(e.message,'error')}}
function checkAttention(){return startCheck(attentionIds())}function checkAll(){return startCheck((STATE.links||[]).map(x=>x.id))}
async function stopTask(){try{const r=await api('/api/stop',{});toast(r.message);schedulePoll(200)}catch(e){toast(e.message,'error')}}
async function saveJson(){try{const r=await api('/api/save_json',{});toast(r.ok?'保存しました。':r.message,r.ok?'':'error');await refresh()}catch(e){toast(e.message,'error')}}
async function openSaveDir(){try{await api('/api/open_save_dir',{});toast('保存フォルダーへ起動要求を送りました。')}catch(e){toast(e.message,'error')}}
async function exportData(type){try{const r=await api(`/api/export_${type}`,{});toast(r.ok?`${type.toUpperCase()}を作成しました。`:(r.message||'出力できませんでした。'),r.ok?'':'error')}catch(e){toast(e.message,'error')}}
async function cleanupDuplicates(){if(!confirm('重複しているリンクを整理します。よろしいですか？'))return;try{const r=await api('/api/links/cleanup',{});toast(`${r.removed||0}件の重複を整理しました。`);await refresh()}catch(e){toast(e.message,'error')}}
async function loadJsonFile(file){if(!file)return;try{const data=JSON.parse(await file.text()),r=await api('/api/load_json',{data,replace:false});if(!r.ok)throw new Error(r.message);toast(r.message||`${r.added||0}件を読み込みました。`);await refresh()}catch(e){toast(e.message||'JSONを読み込めませんでした。','error')}finally{$('jsonFile').value=''}}
function renderTask(){const t=STATE.task||{},running=!!t.running,dot=$('statusDot');dot.className='status-dot'+(running?' busy':STATE.lastSaveError?' error':'');$('statusMessage').textContent=running?(t.message||'処理中…'):(STATE.lastSaveError||'準備完了');$('progress').classList.toggle('show',running);$('taskStop').classList.toggle('show',running);const total=Number(t.total)||0,done=Number(t.progress)||0;$('progressBar').style.width=total?`${Math.min(100,done/total*100)}%`:'18%';$('saveState').textContent=STATE.lastSaveError?'保存状態を確認してください':`自動保存 · ${(STATE.links||[]).length}件`}
function renderAll(){renderKinds();renderZoneOptions();renderLinks();renderCandidates();renderManage();renderTask();if($('zoneModal').classList.contains('open'))renderZoneManager()}
async function refresh(){const s=await api('/api/state',clientPayload(),10000);STATE=s;renderAll();return s}
function schedulePoll(ms=4000){clearTimeout(pollTimer);pollTimer=setTimeout(poll,ms)}
async function poll(){if(polling)return schedulePoll(2000);polling=true;try{const p=await api('/api/ping',clientPayload(),7000);if(STATE.instanceId&&p.instanceId!==STATE.instanceId)return location.reload();STATE.task=p.task||STATE.task;STATE.lastSaveError=p.lastSaveError||'';renderTask();if(Number(p.revision)!==Number(STATE.revision))await refresh()}catch(e){$('statusDot').className='status-dot error';$('statusMessage').textContent='本体に再接続しています…'}finally{polling=false;schedulePoll(document.hidden?12000:4000)}}
async function announceOpen(){closingSent=false;try{await api('/api/client/open',clientPayload(),5000)}catch(_){}}
function announceClosing(){if(closingSent)return;closingSent=true;const payload=clientPayload({apiToken:API_TOKEN}),body=JSON.stringify(payload);try{fetch('/api/client/closing',{method:'POST',headers:{'Content-Type':'application/json','X-LinkManager-Token':API_TOKEN},body,keepalive:true,cache:'no-store'}).catch(()=>{try{navigator.sendBeacon('/api/client/closing',new Blob([body],{type:'text/plain'}))}catch(_){}})}catch(_){try{navigator.sendBeacon('/api/client/closing',new Blob([body],{type:'text/plain'}))}catch(__){}}}
function moveActive(delta){const arr=displayedLinks();if(!arr.length)return;let i=arr.findIndex(x=>x.id===activeId);i=i<0?0:Math.max(0,Math.min(arr.length-1,i+delta));setActive(arr[i].id,true)}
function rowHasTextSelection(row){const selection=window.getSelection?.();if(!selection||selection.isCollapsed||!selection.toString().trim())return false;return row.contains(selection.anchorNode)||row.contains(selection.focusNode)}
$('searchInput').addEventListener('input',()=>{activeId='';selected.clear();renderLinks()});$('searchInput').addEventListener('keydown',e=>{if(e.altKey&&e.key==='Enter'&&activeId){e.preventDefault();copyIds([activeId])}else if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();moveActive(e.key==='ArrowDown'?1:-1)}else if(e.key==='Enter'&&activeId){e.preventDefault();openOne(activeId)}else if(e.key==='F2'&&activeId){e.preventDefault();openLinkModal(activeId)}});
$('linkList').addEventListener('click',e=>{const zoneToggle=e.target.closest('[data-zone-toggle]');if(zoneToggle)return toggleZone(zoneToggle.dataset.zoneToggle);const zoneEdit=e.target.closest('[data-zone-edit]');if(zoneEdit)return openZoneModal(zoneEdit.dataset.zoneEdit);const row=e.target.closest('.link-row');if(!row)return;const id=row.dataset.id;setActive(id);if(e.target.closest('.row-check')){e.target.checked?selected.add(id):selected.delete(id);renderSelectionUi()}else if(e.target.closest('.pin'))togglePinned(id);else if(e.target.closest('.star'))toggleFavorite(id);else if(e.target.closest('.copy-btn'))copyIds([id]);else if(e.target.closest('.edit-btn'))openLinkModal(id);else if(e.target.closest('.open-btn'))openOne(id);else if(e.target.closest('.open-title')){if(e.detail===0||!rowHasTextSelection(row))openOne(id)}else if(e.target.closest('button,input,select,textarea,a,label'))return;else if(!rowHasTextSelection(row))openOne(id)});
$('selectVisible').addEventListener('change',e=>{displayedLinks().forEach(x=>e.target.checked?selected.add(x.id):selected.delete(x.id));renderLinks()});$('selectCandidates').addEventListener('change',e=>{(STATE.candidates||[]).forEach(x=>e.target.checked?candidateSelected.add(x.id):candidateSelected.delete(x.id));renderCandidates()});$('candidateList').addEventListener('change',e=>{if(!e.target.matches('.candidate-check'))return;e.target.checked?candidateSelected.add(e.target.dataset.id):candidateSelected.delete(e.target.dataset.id);renderCandidates()});$('jsonFile').addEventListener('change',e=>loadJsonFile(e.target.files?.[0]));
$('zoneManagerList').addEventListener('click',e=>{const save=e.target.closest('.save-zone-name'),remove=e.target.closest('.delete-zone');if(save)saveZoneName(save.dataset.id);else if(remove)removeZone(remove.dataset.id)});$('zoneManagerList').addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.matches('.zone-name-input')){e.preventDefault();saveZoneName(e.target.closest('[data-zone-row]').dataset.zoneRow)}});$('newZoneName').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();createZone()}});
document.addEventListener('keydown',e=>{const modal=document.querySelector('.modal-layer.open'),typing=['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName);if(modal){if(e.key==='Escape'){e.preventDefault();modal.id==='linkModal'?closeLinkModal():closeZoneModal();return}if(e.key==='Tab'){const items=[...modal.querySelectorAll('button:not([disabled]),input:not([disabled]):not([type="hidden"]),textarea:not([disabled]),select:not([disabled])')].filter(x=>!x.hidden&&x.offsetParent!==null);if(items.length){const first=items[0],last=items[items.length-1],inside=modal.contains(document.activeElement);if(e.shiftKey&&(!inside||document.activeElement===first)){e.preventDefault();last.focus()}else if(!e.shiftKey&&(!inside||document.activeElement===last)){e.preventDefault();first.focus()}}}return}const k=e.key.toLowerCase();if((e.ctrlKey||e.metaKey)&&(k==='k'||k==='f')){e.preventDefault();focusSearch()}else if((e.ctrlKey||e.metaKey)&&k==='n'){e.preventDefault();openLinkModal()}else if(!typing&&e.key==='/'){e.preventDefault();focusSearch()}else if(!typing&&(e.key==='ArrowDown'||e.key==='ArrowUp')){e.preventDefault();moveActive(e.key==='ArrowDown'?1:-1)}else if(!typing&&e.altKey&&e.key==='Enter'&&activeId){e.preventDefault();copyIds([activeId])}else if(!typing&&e.key==='Enter'&&activeId){e.preventDefault();openOne(activeId)}else if(!typing&&e.key==='F2'&&activeId){e.preventDefault();openLinkModal(activeId)}else if(e.key==='Escape'){if($('searchInput').value)clearSearch();else if(selected.size){selected.clear();renderLinks()}}});
window.addEventListener('pagehide',announceClosing);window.addEventListener('pageshow',()=>{announceOpen();schedulePoll(100)});window.addEventListener('focus',()=>schedulePoll(100));document.addEventListener('visibilitychange',()=>{if(!document.hidden)schedulePoll(100)});
(async()=>{try{await announceOpen();await refresh();setTimeout(()=>$('searchInput').focus(),70);schedulePoll(4000)}catch(e){$('statusDot').className='status-dot error';$('statusMessage').textContent='本体へ接続できません。もう一度起動してください。';toast(e.message,'error');schedulePoll(3000)}})();
</script>
</body>
</html>
'''

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return

    def send_json(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def send_html(self, text):
        text = (text
                .replace('__API_TOKEN__', getattr(APP, 'api_token', ''))
                .replace('__WINDOW_MARKER__', getattr(APP, 'window_marker', '')))
        data = text.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def read_json(self):
        raw_length = self.headers.get('Content-Length', '0') or '0'
        try:
            n = int(raw_length)
        except Exception as e:
            raise ValueError('Content-Lengthが不正です。') from e
        if n < 0 or n > 16 * 1024 * 1024:
            raise ValueError('送信データが大きすぎるか、長さが不正です。')
        if not n:
            return {}
        data = self.rfile.read(n).decode('utf-8', errors='strict')
        try:
            value = json.loads(data) if data.strip() else {}
        except Exception as e:
            raise ValueError('JSONデータを読み取れません。') from e
        if not isinstance(value, (dict, list)):
            raise ValueError('JSONの形式が不正です。')
        return value

    def api_authorized(self, data=None):
        data = data if isinstance(data, dict) else {}
        origin = self.headers.get('Origin', '')
        if origin:
            allowed = {f'http://{HOST}:{APP.port}', f'http://localhost:{APP.port}'}
            if origin not in allowed:
                return False
        token = self.headers.get('X-LinkManager-Token', '') or clean_text(data.get('apiToken'))
        return bool(token) and hmac.compare_digest(token, getattr(APP, 'api_token', ''))

    def do_GET(self):
        if self.path == '/health':
            self.send_json({'ok': True, 'instanceId': APP.instance_id}); return
        if self.path == '/' or self.path.startswith('/?'):
            self.send_html(HTML_PAGE); return
        if self.path.startswith('/api/state'):
            if not self.api_authorized({}):
                self.send_json({'ok': False, 'message': 'APIトークンが不正です。'}, code=403); return
            self.send_json(APP.state()); return
        self.send_response(404); self.end_headers()

    def do_POST(self):
        path = self.path.split('?',1)[0]
        try:
            data = self.read_json()
        except ValueError as e:
            self.send_json({'ok': False, 'message': str(e)}, code=413); return
        if path.startswith('/api/') and not self.api_authorized(data):
            self.send_json({'ok': False, 'message': 'APIトークンが不正です。'}, code=403); return
        try:
            if path == '/api/client/open': self.send_json(APP.client_open(data.get('clientId',''), data.get('pageId',''), data.get('instanceId',''))); return
            if path == '/api/ping': self.send_json(APP.client_ping(data.get('clientId',''), data.get('pageId',''), data.get('instanceId',''))); return
            if path == '/api/client/closing': self.send_json(APP.client_closing(data.get('clientId',''), data.get('pageId',''), data.get('instanceId',''))); return
            if path == '/api/state': self.send_json(APP.state()); return
            if path == '/api/stop': self.send_json(APP.stop()); return
            if path == '/api/candidates/add': self.send_json(APP.add_candidates(data.get('ids', []))); return
            if path == '/api/candidates/clear': self.send_json(APP.clear_candidates()); return
            if path == '/api/links/add': self.send_json(APP.add_links(data)); return
            if path == '/api/links/update': self.send_json(APP.update_link(data)); return
            if path == '/api/links/flag': self.send_json(APP.set_link_flag(data.get('id',''), data.get('field',''), data.get('value'))); return
            if path == '/api/links/zone': self.send_json(APP.assign_links_zone(data.get('ids', []), data.get('zoneId',''))); return
            if path == '/api/links/delete': self.send_json(APP.delete_links(data.get('ids', []))); return
            if path == '/api/links/cleanup': self.send_json(APP.duplicate_cleanup()); return
            if path == '/api/links/open': self.send_json(APP.open_selected(data.get('ids', []))); return
            if path == '/api/links/copy': self.send_json(APP.copy_selected_to_clipboard(data.get('ids', []))); return
            if path == '/api/zones/add': self.send_json(APP.add_zone(data.get('name',''))); return
            if path == '/api/zones/update': self.send_json(APP.update_zone(data)); return
            if path == '/api/zones/delete': self.send_json(APP.delete_zone(data.get('id',''))); return
            if path == '/api/choose_path': self.send_json(APP.choose_path(data.get('kind','file'))); return
            if path == '/api/extract_path_start': self.send_json(APP.extract_path_start(data.get('path',''), data.get('recursive', True), data.get('maxFiles', 500))); return
            if path == '/api/import_text': self.send_json(APP.import_text(data.get('text',''))); return
            if path == '/api/import_clipboard': self.send_json(APP.import_text(APP.read_clipboard_text(), 'クリップボード')); return
            if path == '/api/check_start': self.send_json(APP.check_start(data.get('ids', []))); return
            if path == '/api/save_json': self.send_json(APP.save_json(data.get('path',''))); return
            if path == '/api/load_json': self.send_json(APP.load_json_data(data.get('data'), data.get('replace') is True)); return
            if path == '/api/export_csv': self.send_json(APP.export_csv()); return
            if path == '/api/export_html': self.send_json(APP.export_html()); return
            if path == '/api/export_xlsx': self.send_json(APP.export_xlsx()); return
            if path == '/api/open_save_dir': self.send_json(APP.open_save_dir()); return
        except Exception as e:
            self.send_json({'ok': False, 'message': str(e)}, code=500); return
        self.send_response(404); self.end_headers()


_INSTANCE_MUTEX = None


class LocalHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 32


def runtime_info_path():
    if os.name == 'nt' and os.environ.get('LOCALAPPDATA'):
        base = pathlib.Path(os.environ['LOCALAPPDATA'])
    else:
        base = pathlib.Path(os.environ.get('TMPDIR') or '/tmp')
    return base / 'LinkManager' / 'runtime.json'


def find_running_instance():
    p = runtime_info_path()
    try:
        info = json.loads(p.read_text(encoding='utf-8'))
        port = int(info.get('port') or 0)
        expected = clean_text(info.get('instanceId'))
        if not (1 <= port <= 65535) or not expected:
            return None
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(f'http://{HOST}:{port}/health', timeout=0.45) as res:
            health = json.loads(res.read(65536).decode('utf-8'))
        if health.get('ok') and hmac.compare_digest(clean_text(health.get('instanceId')), expected):
            marker = clean_text(info.get('windowMarker'))
            if not re.fullmatch(r'LM-[a-f0-9]{12}', marker):
                marker = ''
            return {
                'url': f'http://{HOST}:{port}/',
                'port': port,
                'instanceId': expected,
                'windowMarker': marker,
            }
    except Exception:
        return None
    return None


def write_runtime_info(port):
    p = runtime_info_path()
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(p.name + '.tmp')
        tmp.write_text(json.dumps({
            'port': int(port),
            'pid': os.getpid(),
            'instanceId': APP.instance_id,
            'windowMarker': APP.window_marker,
        }, ensure_ascii=False), encoding='utf-8')
        tmp.replace(p)
    except Exception:
        pass


def clear_runtime_info(instance_id=''):
    p = runtime_info_path()
    try:
        info = json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
        if not instance_id or hmac.compare_digest(clean_text(info.get('instanceId')), clean_text(instance_id)):
            p.unlink(missing_ok=True)
    except Exception:
        pass


def find_window_by_marker(marker):
    """Return the top-level Edge app HWND carrying this instance marker."""
    marker = clean_text(marker)
    if os.name != 'nt' or not marker:
        return 0
    found = []
    try:
        user32 = ctypes.windll.user32
        callback_type = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p)

        def visit(hwnd, _):
            try:
                if not user32.IsWindowVisible(hwnd):
                    return 1
                size = int(user32.GetWindowTextLengthW(hwnd))
                if size <= 0:
                    return 1
                buf = ctypes.create_unicode_buffer(size + 1)
                user32.GetWindowTextW(hwnd, buf, size + 1)
                if marker in buf.value:
                    found.append(int(hwnd))
            except Exception:
                pass
            return 1

        callback = callback_type(visit)
        user32.EnumWindows(callback, 0)
    except Exception:
        return 0
    return found[0] if found else 0


def activate_app_window(marker):
    hwnd = find_window_by_marker(marker)
    if not hwnd:
        return False
    try:
        user32 = ctypes.windll.user32
        user32.ShowWindow(ctypes.c_void_p(hwnd), 9)  # SW_RESTORE
        user32.SetForegroundWindow(ctypes.c_void_p(hwnd))
        return True
    except Exception:
        return False


def release_instance_mutex():
    global _INSTANCE_MUTEX
    handle = _INSTANCE_MUTEX
    _INSTANCE_MUTEX = None
    if os.name == 'nt' and handle:
        try:
            ctypes.windll.kernel32.CloseHandle(ctypes.c_void_p(handle))
        except Exception:
            pass


def acquire_or_reopen_instance():
    global _INSTANCE_MUTEX
    running = find_running_instance()
    if running:
        marker = running.get('windowMarker', '')
        if not activate_app_window(marker):
            open_app_window(running.get('url', ''))
        return False
    if os.name != 'nt':
        return True
    try:
        kernel = ctypes.windll.kernel32
        create = kernel.CreateMutexW
        create.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
        create.restype = ctypes.c_void_p
        kernel.SetLastError(0)
        handle = create(None, 0, 'Local\\OpenAI.LinkManager.Singleton')
        err = int(kernel.GetLastError())
        if not handle:
            return True
        if err == 183:  # ERROR_ALREADY_EXISTS
            try:
                kernel.CloseHandle(ctypes.c_void_p(handle))
            except Exception:
                pass
            for _ in range(20):
                running = find_running_instance()
                if running:
                    marker = running.get('windowMarker', '')
                    if not activate_app_window(marker):
                        open_app_window(running.get('url', ''))
                    return False
                time.sleep(0.1)
            try:
                ctypes.windll.user32.MessageBoxW(None, 'リンク管理はすでに起動していますが、画面へ接続できません。少し待ってからもう一度起動してください。', APP_TITLE, 0x30)
            except Exception:
                pass
            return False
        _INSTANCE_MUTEX = handle
        return True
    except Exception:
        return True


def open_app_window(url):
    """Open the local UI and return ``edge``/``browser`` or an empty string."""
    if not clean_text(url):
        return ''
    if os.name == 'nt':
        candidates = []
        pf = os.environ.get('ProgramFiles','')
        pfx = os.environ.get('ProgramFiles(x86)','')
        local = os.environ.get('LOCALAPPDATA','')
        for base in [pf, pfx, local]:
            if base:
                candidates.append(os.path.join(base, 'Microsoft', 'Edge', 'Application', 'msedge.exe'))
        exe = next((p for p in candidates if os.path.exists(p)), None) or shutil.which('msedge.exe') or shutil.which('msedge')
        if exe:
            try:
                subprocess.Popen([exe, f'--app={url}', '--new-window'], creationflags=CREATE_NO_WINDOW)
                return 'edge'
            except Exception:
                pass
    try:
        return 'browser' if webbrowser.open(url, new=1) else ''
    except Exception:
        return ''


def monitor_app_window(marker):
    """Track the native app window, independent of page reload/unload events."""
    if os.name != 'nt' or not marker:
        return
    deadline = time.monotonic() + 20.0
    hwnd = 0
    while not APP.shutdown_started and time.monotonic() < deadline:
        hwnd = find_window_by_marker(marker)
        if hwnd:
            break
        time.sleep(0.2)
    if not hwnd or APP.shutdown_started:
        # Edgeアプリ窓を捕捉できない環境ではclient close APIが担当する。
        return
    with APP.lock:
        APP.window_hwnd = hwnd
        APP.window_attached = True
    missing_since = None
    while not APP.shutdown_started:
        try:
            alive = bool(ctypes.windll.user32.IsWindow(ctypes.c_void_p(hwnd)))
        except Exception:
            alive = True
        if alive:
            missing_since = None
            time.sleep(0.25)
            continue
        replacement = find_window_by_marker(marker)
        if replacement:
            hwnd = replacement
            with APP.lock:
                APP.window_hwnd = hwnd
            missing_since = None
        elif missing_since is None:
            missing_since = time.monotonic()
        elif time.monotonic() - missing_since >= 2.5:
            APP.shutdown('window-frame-closed')
            return
        time.sleep(0.25)


def main():
    if not acquire_or_reopen_instance():
        return
    try:
        server = LocalHTTPServer((HOST, 0), Handler)
    except Exception:
        release_instance_mutex()
        return
    port = int(server.server_address[1])
    APP.server = server
    APP.port = port
    threading.Thread(target=server.serve_forever, daemon=True).start()
    write_runtime_info(port)
    url = f'http://{HOST}:{port}/'
    launch_method = open_app_window(url)
    if launch_method == 'edge':
        threading.Thread(target=monitor_app_window, args=(APP.window_marker,), daemon=True).start()
    elif not launch_method:
        APP.shutdown('window-launch-failed')
    try:
        APP.closed_event.wait()
    except KeyboardInterrupt:
        APP.shutdown('keyboard')
        APP.closed_event.wait(5)

if __name__ == '__main__':
    main()

Attribute VB_Name = "modMarriageHistory"
Option Explicit

'�����E�����͐l���\/�֌W�\�̕������ł͂Ȃ��A�����𐳂Ƃ���B
'���Ō݊��̂��ߐl���\�E�֌W�\�̓��t�͓ǂݎ���p�̈ڍs���Ƃ��Ĉ����A
'�Z�b�g�A�b�v��o�͎��ɔ�j��� W_�������� �֋z���グ��B

Public Sub EnsureMarriageHistoryWorkSheet(Optional ByVal resetData As Boolean = False)
    Dim ws As Worksheet, headers As Variant, i As Long
    Set ws = EnsureSheet(SH_W_MARRIAGE_HIST, xlSheetVeryHidden)
    If resetData Then ws.Cells.Clear
    headers = Array("��������ID", "�l��ID", "����l��ID", "���薼", "������", "������", _
        "�������", "����", "���l", "�����쐬�敪", "�\��", "�f�[�^���", _
        "�쐬����", "�X�V����", "���f�[�^ID")
    For i = LBound(headers) To UBound(headers)
        ws.Cells(1, i + 1).Value = headers(i)
    Next i
    ws.Rows(1).Font.Bold = True
    SetSheetVisibilitySafe ws, xlSheetVeryHidden
End Sub

Public Sub UpsertMarriageHistory(ByVal personId As String, _
        ByVal counterpartId As String, _
        ByVal counterpartName As String, _
        ByVal marriageDate As Variant, _
        ByVal divorceDate As Variant, _
        ByVal sourceText As String, _
        Optional ByVal sourceId As String = "", _
        Optional ByVal noteText As String = "")

    Dim ws As Worksheet, r As Long, stateText As String
    personId = CleanText(personId)
    counterpartId = CleanText(counterpartId)
    counterpartName = CleanText(counterpartName)
    If Len(personId) = 0 Then Exit Sub
    If Not IsDate(marriageDate) And Not IsDate(divorceDate) Then Exit Sub

    EnsureMarriageHistoryWorkSheet
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)

    r = FindMarriageHistoryRow(personId, counterpartId, counterpartName, marriageDate, divorceDate)
    If r = 0 Then
        r = NextBlankRow(ws, 1)
        ws.Cells(r, MH_ID).Value = NextId("��������")
        ws.Cells(r, MH_CREATED).Value = Now
    End If

    If Len(counterpartName) = 0 And Len(counterpartId) > 0 Then counterpartName = GetPersonValue(counterpartId, P_DISPLAY)
    If IsDate(divorceDate) Then
        stateText = "����"
    ElseIf IsDate(marriageDate) Then
        stateText = "����"
    Else
        stateText = "���t�v�m�F"
    End If

    ws.Cells(r, MH_PERSON_ID).Value = personId
    ws.Cells(r, MH_COUNTERPART_ID).Value = counterpartId
    ws.Cells(r, MH_COUNTERPART_NAME).Value = counterpartName
    ws.Cells(r, MH_MARRIAGE).Value = SameDateOrBlank(marriageDate)
    ws.Cells(r, MH_DIVORCE).Value = SameDateOrBlank(divorceDate)
    ws.Cells(r, MH_STATE).Value = stateText
    ws.Cells(r, MH_SOURCE).Value = sourceText
    ws.Cells(r, MH_NOTE).Value = noteText
    If sourceText = "�����������" Then
        ws.Cells(r, MH_AUTO).Value = "�����"
    ElseIf InStr(1, sourceText, "�ڍs", vbTextCompare) > 0 Then
        ws.Cells(r, MH_AUTO).Value = "�ڍs"
    Else
        ws.Cells(r, MH_AUTO).Value = "����"
    End If
    ws.Cells(r, MH_SHOW).Value = SHOW_YES
    ws.Cells(r, MH_STATUS).Value = STATUS_ACTIVE
    ws.Cells(r, MH_UPDATED).Value = Now
    ws.Cells(r, MH_SOURCE_ID).Value = sourceId
    SetSheetVisibilitySafe ws, xlSheetVeryHidden
    On Error Resume Next
    DiagramGraphReset
    On Error GoTo 0
End Sub

Public Sub BackfillMarriageHistoryFromLegacyFacts()
    '���Ńf�[�^�� P_MARRIAGE/P_DIVORCE �� R_MARRIAGE/R_DIVORCE ���A���������֔�j��ňڍs����B
    '����͏����Ȃ��B���n��E03���́E���ʕۑ��� W_��������/T_�������� ��D�悷��B
    Dim wp As Worksheet, wr As Worksheet
    Dim r As Long, lastR As Long
    Dim pid As String, otherId As String, relType As String, srcId As String, cpName As String

    If Not SheetExists(SH_W_PERSON, ThisWorkbook) Then Exit Sub
    EnsureMarriageHistoryWorkSheet

    Set wp = ThisWorkbook.Worksheets(SH_W_PERSON)
    lastR = LastRow(wp, 1)
    For r = 2 To lastR
        If CStr(wp.Cells(r, P_STATUS).Value) <> STATUS_CANCEL Then
            pid = CleanText(wp.Cells(r, P_ID).Value)
            If Len(pid) > 0 Then
                If IsDate(wp.Cells(r, P_MARRIAGE).Value) Or IsDate(wp.Cells(r, P_DIVORCE).Value) Then
                    srcId = "P|" & pid & "|" & CStr(r)
                    UpsertMarriageHistory pid, "", "", wp.Cells(r, P_MARRIAGE).Value, wp.Cells(r, P_DIVORCE).Value, "�l���\�������t�ڍs", srcId, "���`���̖{�l������/�{�l����������ڍs"
                End If
            End If
        End If
    Next r

    If Not SheetExists(SH_W_REL, ThisWorkbook) Then Exit Sub
    Set wr = ThisWorkbook.Worksheets(SH_W_REL)
    lastR = LastRow(wr, 1)
    For r = 2 To lastR
        If CStr(wr.Cells(r, R_STATUS).Value) <> STATUS_CANCEL Then
            relType = CleanText(wr.Cells(r, R_TYPE).Value)
            If relType = MODE_SPOUSE Or relType = "�z���" Then
                pid = CleanText(wr.Cells(r, R_BASE_ID).Value)
                otherId = CleanText(wr.Cells(r, R_OTHER_ID).Value)
                If Len(pid) > 0 Then
                    If IsDate(wr.Cells(r, R_MARRIAGE).Value) Or IsDate(wr.Cells(r, R_DIVORCE).Value) Then
                        cpName = ""
                        If Len(otherId) > 0 Then cpName = GetPersonValue(otherId, P_DISPLAY)
                        srcId = "R|" & CleanText(wr.Cells(r, R_ID).Value)
                        UpsertMarriageHistory pid, otherId, cpName, wr.Cells(r, R_MARRIAGE).Value, wr.Cells(r, R_DIVORCE).Value, "�֌W�\�������t�ڍs", srcId, "���`���̔z��Ҋ֌W���t����ڍs"
                    End If
                End If
            End If
        End If
    Next r

    ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST).Visible = xlSheetVeryHidden
End Sub

Private Function FindMarriageHistoryRow(ByVal personId As String, _
        ByVal counterpartId As String, _
        ByVal counterpartName As String, _
        ByVal marriageDate As Variant, _
        ByVal divorceDate As Variant) As Long

    Dim ws As Worksheet, r As Long, lastR As Long
    Dim existingCpId As String, existingCpName As String
    personId = CleanText(personId)
    counterpartId = CleanText(counterpartId)
    counterpartName = CleanText(counterpartName)
    If Len(personId) = 0 Then Exit Function
    EnsureMarriageHistoryWorkSheet
    Set ws = ThisWorkbook.Worksheets(SH_W_MARRIAGE_HIST)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CStr(ws.Cells(r, MH_STATUS).Value) <> STATUS_CANCEL Then
            If CleanText(ws.Cells(r, MH_PERSON_ID).Value) = personId Then
                If MarriageSameDateValueOrBlank(ws.Cells(r, MH_MARRIAGE).Value, marriageDate) Then
                    If MarriageSameDateValueOrBlank(ws.Cells(r, MH_DIVORCE).Value, divorceDate) Then
                        existingCpId = CleanText(ws.Cells(r, MH_COUNTERPART_ID).Value)
                        existingCpName = CleanText(ws.Cells(r, MH_COUNTERPART_NAME).Value)
                        If Len(counterpartId) > 0 Then
                            If existingCpId = counterpartId Then FindMarriageHistoryRow = r: Exit Function
                        ElseIf Len(existingCpId) = 0 Then
                            If Len(counterpartName) = 0 Or Len(existingCpName) = 0 Or StrComp(existingCpName, counterpartName, vbTextCompare) = 0 Then
                                FindMarriageHistoryRow = r
                                Exit Function
                            End If
                        End If
                    End If
                End If
            End If
        End If
    Next r
End Function

Private Function MarriageSameDateValueOrBlank(ByVal a As Variant, ByVal b As Variant) As Boolean
    If IsDate(a) Or IsDate(b) Then
        If IsDate(a) Then
            If IsDate(b) Then MarriageSameDateValueOrBlank = (CLng(CDate(a)) = CLng(CDate(b)))
        End If
    Else
        If Len(CleanText(a)) = 0 Then
            If Len(CleanText(b)) = 0 Then MarriageSameDateValueOrBlank = True
        End If
    End If
End Function


Public Sub ShowMarriageHistoryEditor()
    '����݊��̓����B�����\ W_�������� �͒��ڌ������A�m�F�p�̔�����ʂ֗U������B
    ShowMarriageHistoryReviewSheet
End Sub

Public Sub ApplyMarriageHistoryEditorChanges()
    ApplyMarriageHistoryReviewEdits
End Sub

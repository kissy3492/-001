# 01 人物情報 関数監査レポート

## 監査対象

- modRelationshipGraph.bas
- modOutputs.bas
- modWorkflow.bas ほか 01 同梱モジュール

## 重点確認

- 孫の配偶者の子が婚姻期間内出生の場合、血族側の孫へ親を強制確定する経路を追加。
- P_TYPE=配偶者による配偶者復元を追加。
- 旧 `NormalizePersonRelationLabels` 系は残存なし。
- TextFrame2依存なし。
- カード高さ計算を過大化しにくい形へ変更。

## 静的結果

`01_STATIC_CHECK.json` を参照。

## 未実施

実機VBEコンパイルおよび印刷プレビューは未実施。

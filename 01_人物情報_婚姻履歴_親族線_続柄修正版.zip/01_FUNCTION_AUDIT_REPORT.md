# 01 人物情報 関数監査レポート

## 重点監査対象

- `RegisterMarriageFactForBasePerson`
- `PendingMarriageKeyForInput`
- `FlushPendingMarriageHistoryToPerson`
- `GetChildRowsForParent`
- `InferredDiagramParentIdForChildRow`
- `DiagramNormalizeParentCandidateByMarriage`
- `DiagramPersonRowIsPureSpouse`
- `ChildRowCanAppearUnderParent`
- `ChildLinkOriginForDiagram`
- `DiagramRelationDisplayTextForPersonRow`
- `DiagramCardBodyText`
- `CardFontSizeForShape`

## 監査結果

- 入力中人物の婚姻履歴を、本人登録前に仮IDで保持する経路を追加。
- 配偶者カードを続柄文字列だけで判定せず、`P_SUR_SRC` と `W_関係` の配偶者行から復元するよう変更。
- 子カードは確定した図上親IDの下だけに描くよう変更。
- 孫の配偶者を基準に登録した子は、婚姻期間と出生年月日で血族側の孫の子として戻す。
- 続柄だけの救済判定を描画入口から外し、親カード起点線と夫婦中央線の二重出力を抑止。
- カード内年齢の二重表記と行高不足を点検。

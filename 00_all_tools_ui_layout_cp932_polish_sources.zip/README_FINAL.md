# 相続税調査支援4ツール 最終軽微チェック反映版

このパッケージは、White Studio v3 Locked をベースに、機能面・軽微箇所まで横断チェックした反映版です。

含まれるもの:

- `01_person_v8` 人物住所時系列ツール
- `02_cash_v10` 資金操作表・残高推移表作成補助ツール
- `03_analysis_v11` 資金移動分析ツール
- `04_voucher_v5` 伝票依頼表作成ツール
- `00_common_data_schema_final_v1_1.md` 共通データ最終スキーマ
- `MINOR_FINAL_ALL_CHECK_REPORT.md` 最終軽微チェック報告
- `MINOR_FINAL_ALL_CHECK.json` 静的チェック結果
- `minor_final_micro_polish_patch.diff` 今回差分

実機では、各ブックへインポート後、必ず `Debug > Compile VBAProject` を実行してください。

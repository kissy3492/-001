Attribute VB_Name = "modRender"
Option Explicit

Public Sub RenderDestinationSetSheets()
    DeleteGeneratedVoucherSetSheets
    AssignDestinationSetSheetNames

    Dim dest As Worksheet, dr As Long
    Set dest = Ws(SH_W_DEST)
    For dr = 2 To LastRow(dest, DS_ID)
        If dest.Cells(dr, DS_TARGET).Value = "�쐬" Then
            Dim req As Worksheet, ctl As Worksheet
            Set req = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
            req.Name = dest.Cells(dr, DS_REQ_SHEET).Value
            RenderRequestSheetForDestInTool req, dr

            Set ctl = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
            ctl.Name = dest.Cells(dr, DS_CTL_SHEET).Value
            RenderControlSheetForDestInTool ctl, dr
        End If
    Next dr
End Sub

Private Sub DeleteGeneratedVoucherSetSheets()
    Dim sh As Worksheet, targets As Collection, nm As Variant
    Set targets = New Collection
    For Each sh In ThisWorkbook.Worksheets
        If IsVoucherSetSheetName(sh.Name) Then targets.Add sh.Name
    Next sh
    If targets.Count = 0 Then Exit Sub
    Dim oldAlerts As Boolean
    oldAlerts = Application.DisplayAlerts
    Application.DisplayAlerts = False
    For Each nm In targets
        ThisWorkbook.Worksheets(CStr(nm)).Delete
    Next nm
    Application.DisplayAlerts = oldAlerts
End Sub

Private Sub AssignDestinationSetSheetNames()
    Dim dest As Worksheet, dr As Long, used As Object, baseReq As String, baseCtl As String
    Set dest = Ws(SH_W_DEST)
    Set used = CreateObject("Scripting.Dictionary")
    For dr = 2 To LastRow(dest, DS_ID)
        baseReq = SafeSheetName(dest.Cells(dr, DS_ID).Value & "_" & dest.Cells(dr, DS_BANK).Value & "_" & dest.Cells(dr, DS_SHOP).Value, "�˗�_")
        baseCtl = SafeSheetName(dest.Cells(dr, DS_ID).Value & "_" & dest.Cells(dr, DS_BANK).Value & "_" & dest.Cells(dr, DS_SHOP).Value, "�T��_")
        dest.Cells(dr, DS_REQ_SHEET).Value = UniqueNameInDict(used, baseReq)
        dest.Cells(dr, DS_CTL_SHEET).Value = UniqueNameInDict(used, baseCtl)
    Next dr
End Sub

Private Function UniqueNameInDict(ByVal used As Object, ByVal baseName As String) As String
    Dim s As String, i As Long
    s = Left$(baseName, 31)
    i = 1
    Do While used.Exists(s) Or SheetExists(s)
        i = i + 1
        s = Left$(baseName, 28) & "_" & i
    Loop
    used(s) = 1
    UniqueNameInDict = s
End Function

Public Sub RenderRequestPreview()
    Dim sh As Worksheet
    Set sh = Ws(SH_REQUEST)
    ClearSheetSafe sh
    BuildSetIndexSheet sh, "�˗��p�Z�b�g�ꗗ", "�˗����͊e�˗����p�̈˗��p�V�[�g�����ɕ\�����܂��B���̈ꗗ�ɂ͕����˗���̈˗��������݂����܂���B", True
End Sub

Public Sub RenderControlPreview()
    Dim sh As Worksheet
    Set sh = Ws(SH_CONTROL)
    ClearSheetSafe sh
    BuildSetIndexSheet sh, "�T���p�Z�b�g�ꗗ", "�T�����ׂ͊e�˗����p�̍T���p�V�[�g�����ɕ\�����܂��B���̈ꗗ�ɂ͕����˗���̖��ׂ����݂����܂���B", False
End Sub

Private Sub BuildSetIndexSheet(ByVal sh As Worksheet, ByVal titleText As String, ByVal guideText As String, ByVal requestMode As Boolean)
    Dim dest As Worksheet, r As Long, outR As Long
    Set dest = Ws(SH_W_DEST)
    sh.Cells.Font.Name = "Meiryo UI"
    sh.Cells.Font.Size = 10
    sh.Columns("A").ColumnWidth = 2
    sh.Columns("B").ColumnWidth = 12
    sh.Columns("C").ColumnWidth = 22
    sh.Columns("D").ColumnWidth = 24
    sh.Columns("E").ColumnWidth = 12
    sh.Columns("F").ColumnWidth = 12
    sh.Columns("G").ColumnWidth = 28
    sh.Columns("H").ColumnWidth = 28
    sh.Rows.RowHeight = 21

    sh.Range("B2:H3").Merge
    With sh.Range("B2")
        .Value = titleText
        .Interior.Color = C_DARK
        .Font.Color = vbWhite
        .Font.Bold = True
        .Font.Size = 17
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With
    sh.Range("B5:H6").Merge
    With sh.Range("B5")
        .Value = guideText & vbCrLf & "�Œ胋�[��: ��s���{�戵�X = 1�˗���B1�˗���ɂ��˗��p�E�T���p��1�Z�b�g�ō쐬�B"
        .Interior.Color = C_LIGHT_BLUE
        .Font.Color = C_DARK
        .Font.Bold = True
        .WrapText = True
        .VerticalAlignment = xlCenter
    End With
    sh.Range("B8:H8").Value = Array("�˗���ID", "��s��", "�戵�X", "�Ώێ��", "�˗���", "�˗��p�V�[�g", "�T���p�V�[�g")
    With sh.Range("B8:H8")
        .Interior.Color = C_NAVY
        .Font.Color = vbWhite
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
    outR = 9
    For r = 2 To LastRow(dest, DS_ID)
        If dest.Cells(r, DS_TARGET).Value = "�쐬" Then
            sh.Cells(outR, 2).Value = dest.Cells(r, DS_ID).Value
            sh.Cells(outR, 3).Value = dest.Cells(r, DS_BANK).Value
            sh.Cells(outR, 4).Value = dest.Cells(r, DS_SHOP).Value
            sh.Cells(outR, 5).Value = dest.Cells(r, DS_TX_COUNT).Value
            sh.Cells(outR, 6).Value = dest.Cells(r, DS_REQUEST_DATE_COUNT).Value
            sh.Cells(outR, 7).Value = dest.Cells(r, DS_REQ_SHEET).Value
            sh.Cells(outR, 8).Value = dest.Cells(r, DS_CTL_SHEET).Value
            If outR Mod 2 = 0 Then sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 8)).Interior.Color = ThemeColor("canvas")
            outR = outR + 1
        End If
    Next r
    If outR = 9 Then sh.Range("B9").Value = "�쐬�Ώۂ̈˗��悪����܂���B"
    With sh.Range("B8:H" & Application.Max(outR - 1, 9))
        .Borders.LineStyle = xlContinuous
        .Borders.Color = C_BORDER
        .Borders.Weight = xlThin
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    AddButton sh, "���͉�ʂ�", "ShowNormalMode", 20, 20, 110, 30, ThemeColor("muted")
    AddButton sh, "�˗���m�F", "ShowDestinationList", 145, 20, 110, 30, C_PURPLE
    AddButton sh, "�ŏI�o��", "ExportVoucherWorkbooks", 270, 20, 110, 30, C_GREEN
    ThemeApplyPrintTable sh.Range("B8:H" & CStr(Application.Max(outR - 1, 9))), 1
    ThemeApplyMonochromePrint sh, sh.Range("B2:H" & CStr(Application.Max(outR - 1, 9))).Address, True, "$8:$8", 1, 0
    ActiveWindow.DisplayGridlines = False
End Sub

Private Sub RenderRequestSheetForDestInTool(ByVal sh As Worksheet, ByVal destRow As Long)
    ClearSheetSafe sh
    SetupRequestSheetBase sh
    Dim rowTop As Long
    rowTop = 2
    rowTop = RenderRequestPages(sh, destRow, rowTop)
    PolishVoucherRequestSheet sh, rowTop
    ActiveWindow.DisplayGridlines = False
End Sub

Private Sub SetupRequestSheetBase(ByVal sh As Worksheet)
    sh.Cells.Font.Name = "Meiryo UI"
    sh.Cells.Font.Size = 10
    sh.Columns("A").ColumnWidth = 2
    sh.Columns("B").ColumnWidth = 16
    sh.Columns("C").ColumnWidth = 18
    sh.Columns("D").ColumnWidth = 18
    sh.Columns("E").ColumnWidth = 18
    sh.Columns("F").ColumnWidth = 18
    sh.Rows.RowHeight = 21
End Sub

Private Function RenderRequestPages(ByVal sh As Worksheet, ByVal destRow As Long, ByVal rowTop As Long) As Long
    Dim dates As Worksheet, dest As Worksheet
    Set dates = Ws(SH_W_DATES)
    Set dest = Ws(SH_W_DEST)
    Dim allDates As Collection, r As Long
    Set allDates = New Collection
    For r = 2 To LastRow(dates, RD_ID)
        If dates.Cells(r, RD_DEST_ID).Value = dest.Cells(destRow, DS_ID).Value Then allDates.Add CDate(dates.Cells(r, RD_REQUEST_DATE).Value)
    Next r
    Dim perPage As Long, idx As Long, startIdx As Long, endIdx As Long, pageNo As Long, row As Long
    perPage = SettingLong("�˗��p1�y�[�W�ő����", 60)
    If perPage <= 0 Or perPage > 60 Then perPage = 60
    idx = 1
    pageNo = 1
    Do While idx <= allDates.Count Or (allDates.Count = 0 And pageNo = 1)
        startIdx = idx
        endIdx = WorksheetFunction.Min(idx + perPage - 1, allDates.Count)
        sh.Range(sh.Cells(rowTop, 2), sh.Cells(rowTop, 6)).Merge
        With sh.Cells(rowTop, 2)
            .Value = "�`�[�˗��\�i�˗��p�j"
            .Interior.Color = C_DARK
            .Font.Color = vbWhite
            .Font.Bold = True
            .Font.Size = 16
            .HorizontalAlignment = xlCenter
            .VerticalAlignment = xlCenter
        End With
        sh.Rows(rowTop).RowHeight = 30
        sh.Cells(rowTop + 2, 2).Value = "��s��"
        sh.Cells(rowTop + 2, 3).Value = dest.Cells(destRow, DS_BANK).Value
        sh.Cells(rowTop + 3, 2).Value = "�x�X��"
        sh.Cells(rowTop + 3, 3).Value = dest.Cells(destRow, DS_SHOP).Value
        sh.Cells(rowTop + 2, 5).Value = "�˗���ID"
        sh.Cells(rowTop + 2, 6).Value = dest.Cells(destRow, DS_ID).Value
        sh.Cells(rowTop + 3, 5).Value = "�y�[�W"
        sh.Cells(rowTop + 3, 6).Value = pageNo
        sh.Cells(rowTop + 4, 2).Value = "�˗�����"
        sh.Cells(rowTop + 4, 3).Value = IIf(allDates.Count = 0, 0, endIdx - startIdx + 1)
        With sh.Range(sh.Cells(rowTop + 2, 2), sh.Cells(rowTop + 4, 6)).Borders
            .LineStyle = xlContinuous
            .Color = C_BORDER
            .Weight = xlThin
        End With
        sh.Range(sh.Cells(rowTop + 2, 2), sh.Cells(rowTop + 4, 2)).Interior.Color = C_LIGHT_GRAY
        sh.Range(sh.Cells(rowTop + 2, 5), sh.Cells(rowTop + 4, 5)).Interior.Color = C_LIGHT_GRAY
        sh.Range(sh.Cells(rowTop + 6, 2), sh.Cells(rowTop + 6, 6)).Merge
        With sh.Cells(rowTop + 6, 2)
            .Value = "�˗���"
            .Interior.Color = C_NAVY
            .Font.Color = vbWhite
            .Font.Bold = True
            .Font.Size = 12
            .HorizontalAlignment = xlCenter
        End With
        row = rowTop + 7
        If allDates.Count = 0 Then
            sh.Range(sh.Cells(row, 2), sh.Cells(row, 6)).Merge
            sh.Cells(row, 2).Value = "�Ώۓ��Ȃ�"
            sh.Cells(row, 2).HorizontalAlignment = xlCenter
            row = row + 1
        Else
            For idx = startIdx To endIdx
                sh.Range(sh.Cells(row, 2), sh.Cells(row, 6)).Merge
                sh.Cells(row, 2).Value = FormatRequestDate(allDates(idx))
                sh.Cells(row, 2).HorizontalAlignment = xlCenter
                sh.Cells(row, 2).Font.Size = 12
                If row Mod 2 = 0 Then sh.Range(sh.Cells(row, 2), sh.Cells(row, 6)).Interior.Color = ThemeColor("canvas")
                row = row + 1
            Next idx
        End If
        With sh.Range(sh.Cells(rowTop + 6, 2), sh.Cells(row - 1, 6))
            .Borders.LineStyle = xlContinuous
            .Borders.Color = C_BORDER
            .Borders.Weight = xlThin
            .VerticalAlignment = xlCenter
        End With
        rowTop = rowTop + 70
        If idx > allDates.Count Then Exit Do
        sh.HPageBreaks.Add Before:=sh.Cells(rowTop, 1)
        pageNo = pageNo + 1
    Loop
    RenderRequestPages = rowTop
End Function

Private Sub RenderControlSheetForDestInTool(ByVal sh As Worksheet, ByVal destRow As Long)
    ClearSheetSafe sh
    Dim src As Worksheet, dest As Worksheet, r As Long, outR As Long, lr As Long, curDate As Variant, d As Date
    Set src = Ws(SH_W_CONTROL)
    Set dest = Ws(SH_W_DEST)
    sh.Cells.Font.Name = "Meiryo UI"
    sh.Cells.Font.Size = 9
    sh.Columns("A").ColumnWidth = 2
    sh.Columns("B").ColumnWidth = 14
    sh.Columns("C").ColumnWidth = 16
    sh.Columns("D").ColumnWidth = 10
    sh.Columns("E").ColumnWidth = 12
    sh.Columns("F").ColumnWidth = 12
    sh.Columns("G").ColumnWidth = 18
    sh.Columns("H").ColumnWidth = 16
    sh.Columns("I").ColumnWidth = 42
    sh.Columns("J").ColumnWidth = 14
    sh.Rows.RowHeight = 20
    sh.Range("B2:J3").Merge
    With sh.Range("B2")
        .Value = "�`�[�˗��\�i�T���p�j�@" & dest.Cells(destRow, DS_BANK).Value & "�@" & dest.Cells(destRow, DS_SHOP).Value
        .Interior.Color = C_DARK
        .Font.Color = vbWhite
        .Font.Bold = True
        .Font.Size = 15
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With
    sh.Range("B5:J5").Merge
    sh.Range("B5").Value = "�T���p�́A����������Ƃ̌��o���̉��Ɉ˗��Ώێ����\�����܂��B�O���s�c�Ɠ��͊܂߂܂���B"
    sh.Range("B5").Interior.Color = C_LIGHT_BLUE
    sh.Range("B5").WrapText = True
    outR = 7
    lr = LastRow(src, CD_DEST_ID)
    curDate = Empty
    For r = 2 To lr
        If src.Cells(r, CD_DEST_ID).Value = dest.Cells(destRow, DS_ID).Value Then
            If IsDate(src.Cells(r, CD_TX_DATE).Value) Then
                d = CDate(src.Cells(r, CD_TX_DATE).Value)
                If IsEmpty(curDate) Or CLng(curDate) <> CLng(d) Then
                    If Not IsEmpty(curDate) Then outR = outR + 1
                    curDate = d
                    sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Merge
                    sh.Cells(outR, 2).Value = "�˗��Ώۓ��i��������j�F" & FormatJPDate(d, True) & "�@�Ώێ�� " & src.Cells(r, CD_DATE_COUNT).Value & "��"
                    sh.Cells(outR, 2).Interior.Color = C_NAVY
                    sh.Cells(outR, 2).Font.Color = vbWhite
                    sh.Cells(outR, 2).Font.Bold = True
                    outR = outR + 1
                    sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Value = Array("�敪", "�l��", "����", "�o��", "����", "���͌��ID", "���ID", "�E�v�E����", "�m�F")
                    sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Interior.Color = ThemeColor("section")
                    sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Font.Bold = True
                    outR = outR + 1
                End If
            End If
            sh.Cells(outR, 2).Value = src.Cells(r, CD_KIND).Value
            sh.Cells(outR, 3).Value = src.Cells(r, CD_PERSON).Value
            sh.Cells(outR, 4).Value = src.Cells(r, CD_RELATION).Value
            sh.Cells(outR, 5).Value = src.Cells(r, CD_OUT).Value
            sh.Cells(outR, 6).Value = src.Cells(r, CD_IN).Value
            sh.Cells(outR, 7).Value = src.Cells(r, CD_ANALYSIS_ID).Value
            sh.Cells(outR, 8).Value = src.Cells(r, CD_TX_ID).Value
            If IsSettingYes("�T���p�E�v�\��", True) Then sh.Cells(outR, 9).Value = JoinNonEmpty(src.Cells(r, CD_SUMMARY).Value, src.Cells(r, CD_MEMO).Value, " / ")
            If outR Mod 2 = 0 Then sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Interior.Color = ThemeColor("canvas")
            outR = outR + 1
        End If
    Next r
    If outR = 7 Then sh.Cells(7, 2).Value = "�Ώۖ��ׂȂ�"
    With sh.Range("B7:J" & Application.Max(outR - 1, 7))
        .Borders.LineStyle = xlContinuous
        .Borders.Color = C_BORDER
        .Borders.Weight = xlThin
        .WrapText = True
        .VerticalAlignment = xlTop
    End With
    sh.Columns("E:F").NumberFormat = "#,##0"
    PolishVoucherControlSheet sh, Application.Max(outR - 1, 7)
    ActiveWindow.DisplayGridlines = False
End Sub


Private Sub PolishVoucherRequestSheet(ByVal sh As Worksheet, ByVal lastRowTop As Long)
    Dim lastR As Long
    If sh Is Nothing Then Exit Sub
    lastR = Application.Max(12, lastRowTop - 1)
    On Error Resume Next
    ThemeApplyPrintTable sh.Range("B2:F" & CStr(lastR)), 0
    ThemeCapRowHeights sh.Range("B2:F" & CStr(lastR)), 18, 42
    ThemeApplyMonochromePrint sh, sh.Range("B2:F" & CStr(lastR)).Address, False, "", 1, 0
    On Error GoTo 0
End Sub

Private Sub PolishVoucherControlSheet(ByVal sh As Worksheet, ByVal lastR As Long)
    If sh Is Nothing Then Exit Sub
    If lastR < 7 Then lastR = 7
    On Error Resume Next
    ThemeApplyPrintTable sh.Range("B7:J" & CStr(lastR)), 1
    ThemeCapRowHeights sh.Range("B7:J" & CStr(lastR)), 18, 72
    ThemeApplyMonochromePrint sh, sh.Range("B2:J" & CStr(lastR)).Address, True, "$7:$7", 1, 0
    On Error GoTo 0
End Sub

Private Function FormatRequestDate(ByVal d As Date) As String
    Select Case SettingText("�˗����\��", "�a��j��")
        Case "����"
            FormatRequestDate = Format$(d, "yyyy�Nm��d��") & "�i" & WeekdayNameJP(Weekday(d, vbSunday)) & "�j"
        Case "�a��"
            FormatRequestDate = FormatJPDate(d, False)
        Case Else
            FormatRequestDate = FormatJPDate(d, True)
    End Select
End Function

Public Function JoinNonEmpty(ByVal a As String, ByVal b As String, Optional ByVal sep As String = " ") As String
    If Len(Nz(a)) > 0 And Len(Nz(b)) > 0 Then
        JoinNonEmpty = a & sep & b
    ElseIf Len(Nz(a)) > 0 Then
        JoinNonEmpty = a
    Else
        JoinNonEmpty = b
    End If
End Function

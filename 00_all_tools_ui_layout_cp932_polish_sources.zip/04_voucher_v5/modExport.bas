Attribute VB_Name = "modExport"
Option Explicit

Public Sub SaveVoucherCommonData()
    On Error GoTo EH
    AppBegin "�`�[�˗��f�[�^�����ʕۑ���..."
    If LastRow(Ws(SH_W_DATES), 1) <= 1 Then BuildVoucherSheets
    Dim p As String
    p = CommonDataPath()
    If Dir(p) = vbNullString Then Err.Raise vbObjectError + 501, , COMMON_DATA_FILE & " ��������܂���B"
    Dim wb As Workbook
    BackupCommonDataBeforeUpdate p
    Set wb = Workbooks.Open(Filename:=p, ReadOnly:=False, UpdateLinks:=False, IgnoreReadOnlyRecommended:=True, Notify:=False, AddToMru:=False)
    WriteSettingTable wb
    CopyTableToCommon wb, SH_W_DEST, OUT_DEST
    CopyTableToCommon wb, SH_W_DATES, OUT_DATES
    CopyTableToCommon wb, SH_W_CONTROL, OUT_DETAIL
    wb.Save
    wb.Close SaveChanges:=False
    WriteLog "�`�[�˗��f�[�^�����ʕۑ�"
    AppEnd ""
    MsgBox "���ʃf�[�^�֕ۑ����܂����B", vbInformation
    Exit Sub
EH:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    AppEnd ""
    MsgBox "���ʕۑ��ŃG���[: " & Err.Description, vbExclamation
End Sub

Private Sub WriteSettingTable(ByVal wb As Workbook)
    Dim sh As Worksheet
    Set sh = ResetCommonSheet(wb, OUT_SETTING)
    sh.Range("A1:B1").Value = Array("����", "�l")
    Dim data As Variant, i As Long
    data = Array( _
        Array("schema", TOOL_SCHEMA), _
        Array("created_at", Now), _
        Array("source_tool", ThisWorkbook.Name), _
        Array("�O���s�c�Ɠ����܂߂�", SettingText("�O���s�c�Ɠ����܂߂�", "����")), _
        Array("�O�����", SettingLong("�O�����", 1)), _
        Array("�˗��p1�y�[�W�ő����", SettingLong("�˗��p1�y�[�W�ő����", 60)), _
        Array("�˗���ʃZ�b�g�o��", SettingText("�˗���ʃZ�b�g�o��", "����")), _
        Array("�˗��搔", Application.Max(LastRow(Ws(SH_W_DEST), 1) - 1, 0)))
    For i = 0 To UBound(data)
        sh.Cells(i + 2, 1).Value = data(i)(0)
        sh.Cells(i + 2, 2).Value = data(i)(1)
    Next i
    FormatCommonHeader sh

    UpdateCommonLinkControlSheet wb, "�`�[�˗��X�L�[�}�o�[�W����", TOOL_SCHEMA, "04���̏o�͎d�l"
    UpdateCommonLinkControlSheet wb, "�ۑ�����", Now, "���ʃf�[�^���Ō�ɍX�V��������"
End Sub

Private Sub UpdateCommonLinkControlSheet(ByVal wb As Workbook, ByVal keyText As String, ByVal valueText As Variant, ByVal descText As String)
    Dim ws As Worksheet, r As Long, lastR As Long
    On Error Resume Next
    Set ws = wb.Worksheets("T_�A�g�ݒ�")
    On Error GoTo 0
    If ws Is Nothing Then
        Set ws = wb.Worksheets.Add(Before:=wb.Worksheets(1))
        ws.Name = "T_�A�g�ݒ�"
        ws.Range("A1:C1").Value = Array("�L�[", "�l", "����")
    End If
    If Len(Nz(ws.Cells(1, 1).Value)) = 0 Then ws.Range("A1:C1").Value = Array("�L�[", "�l", "����")

    lastR = LastRow(ws, 1)
    If lastR < 1 Then lastR = 1
    For r = 2 To lastR
        If Nz(ws.Cells(r, 1).Value) = keyText Then
            ws.Cells(r, 2).Value = valueText
            ws.Cells(r, 3).Value = descText
            Exit Sub
        End If
    Next r

    ws.Cells(lastR + 1, 1).Value = keyText
    ws.Cells(lastR + 1, 2).Value = valueText
    ws.Cells(lastR + 1, 3).Value = descText
    ws.Columns("A:C").AutoFit
End Sub

Private Sub CopyTableToCommon(ByVal wb As Workbook, ByVal srcSheetName As String, ByVal dstSheetName As String)
    Dim src As Worksheet, dst As Worksheet, lr As Long, lc As Long
    Set src = Ws(srcSheetName)
    Set dst = ResetCommonSheet(wb, dstSheetName)
    lr = LastRow(src, 1)
    lc = LastCol(src, 1)
    dst.Range(dst.Cells(1, 1), dst.Cells(lr, lc)).Value = src.Range(src.Cells(1, 1), src.Cells(lr, lc)).Value
    FormatCommonHeader dst
    dst.Columns.AutoFit
End Sub

Private Function ResetCommonSheet(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    Dim sh As Worksheet, lo As ListObject
    If SheetExists(sheetName, wb) Then
        Set sh = wb.Worksheets(sheetName)
    Else
        Set sh = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
        sh.Name = sheetName
    End If
    On Error Resume Next
    sh.Unprotect
    If sh.AutoFilterMode Then sh.AutoFilterMode = False
    For Each lo In sh.ListObjects
        lo.Unlist
    Next lo
    sh.Cells.Clear
    On Error GoTo 0
    Set ResetCommonSheet = sh
End Function

Private Sub FormatCommonHeader(ByVal sh As Worksheet)
    With sh.Rows(1)
        .Interior.Color = C_NAVY
        .Font.Color = vbWhite
        .Font.Bold = True
    End With
    sh.Cells.Font.Name = "Meiryo UI"
    sh.Cells.Font.Size = 10
End Sub

Public Sub ExportVoucherWorkbooks()
    On Error GoTo EH
    AppBegin "�`�[�˗��\���o�͒�..."
    If IsSettingYes("�ŏI�o�͑O�`�F�b�N", True) Then
        RunVoucherCheck
        If HasVoucherCheckError() Then Err.Raise vbObjectError + 502, , "�����`�F�b�N�ɃG���[������܂��BC_�`�F�b�N���m�F���Ă��������B"
    End If
    If LastRow(Ws(SH_W_DATES), 1) <= 1 Then BuildVoucherSheets

    Dim outFolder As String
    outFolder = OutputPath()
    If Not ConfirmVoucherOverwrite(outFolder) Then
        AppEnd ""
        Exit Sub
    End If
    ExportRequestBook outFolder & Application.PathSeparator & "11_�`�[�˗��\_�˗��p.xlsx"
    ExportControlBook outFolder & Application.PathSeparator & "12_�`�[�˗��\_�T���p.xlsx"
    If IsSettingYes("�˗���ʃZ�b�g�o��", True) Then ExportDestinationSetBooks outFolder
    AppEnd ""
    MsgBox "�`�[�˗��\���o�͂��܂����B" & vbCrLf & _
           "11_�`�[�˗��\_�˗��p.xlsx" & vbCrLf & _
           "12_�`�[�˗��\_�T���p.xlsx" & vbCrLf & _
           IIf(IsSettingYes("�˗���ʃZ�b�g�o��", True), "13_�`�[�˗��\_�˗���ʃZ�b�g", ""), vbInformation
    Exit Sub
EH:
    AppEnd ""
    MsgBox "�ŏI�o�͂ŃG���[: " & Err.Description, vbExclamation
End Sub

Private Sub ExportRequestBook(ByVal filePath As String)
    Dim wb As Workbook, dest As Worksheet, dr As Long
    Set wb = Workbooks.Add(xlWBATWorksheet)
    Application.DisplayAlerts = False
    Do While wb.Worksheets.Count > 1
        wb.Worksheets(wb.Worksheets.Count).Delete
    Loop
    Application.DisplayAlerts = True
    Set dest = Ws(SH_W_DEST)
    For dr = 2 To LastRow(dest, DS_ID)
        If dest.Cells(dr, DS_TARGET).Value = "�쐬" Then
            Dim sh As Worksheet
            If wb.Worksheets.Count = 1 And wb.Worksheets(1).UsedRange.Count = 1 And wb.Worksheets(1).Range("A1").Value = "" Then
                Set sh = wb.Worksheets(1)
            Else
                Set sh = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
            End If
            sh.Name = UniqueSheetName(wb, SafeSheetName(dest.Cells(dr, DS_BANK).Value & "_" & dest.Cells(dr, DS_SHOP).Value, "�˗�_"))
            RenderRequestSheetForDest wb, sh, dr
        End If
    Next dr
    PrepareOutputPathWithBackup filePath
    wb.SaveAs Filename:=filePath, FileFormat:=xlOpenXMLWorkbook
    wb.Close SaveChanges:=False
End Sub

Private Sub ExportControlBook(ByVal filePath As String)
    Dim wb As Workbook, dest As Worksheet, dr As Long
    Set wb = Workbooks.Add(xlWBATWorksheet)
    Set dest = Ws(SH_W_DEST)
    For dr = 2 To LastRow(dest, DS_ID)
        If dest.Cells(dr, DS_TARGET).Value = "�쐬" Then
            Dim sh As Worksheet
            If wb.Worksheets.Count = 1 And wb.Worksheets(1).UsedRange.Count = 1 And wb.Worksheets(1).Range("A1").Value = "" Then
                Set sh = wb.Worksheets(1)
            Else
                Set sh = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
            End If
            sh.Name = UniqueSheetName(wb, SafeSheetName(dest.Cells(dr, DS_BANK).Value & "_" & dest.Cells(dr, DS_SHOP).Value, "�T��_"))
            RenderControlSheetForDest wb, sh, dr
        End If
    Next dr
    PrepareOutputPathWithBackup filePath
    wb.SaveAs Filename:=filePath, FileFormat:=xlOpenXMLWorkbook
    wb.Close SaveChanges:=False
End Sub

Private Sub ExportDestinationSetBooks(ByVal outFolder As String)
    Dim setFolder As String
    setFolder = outFolder & Application.PathSeparator & "13_�`�[�˗��\_�˗���ʃZ�b�g"
    If Dir(setFolder, vbDirectory) = vbNullString Then MkDir setFolder

    Dim dest As Worksheet, dr As Long, fileName As String, wb As Workbook, req As Worksheet, ctl As Worksheet
    Set dest = Ws(SH_W_DEST)
    For dr = 2 To LastRow(dest, DS_ID)
        If dest.Cells(dr, DS_TARGET).Value = "�쐬" Then
            Set wb = Workbooks.Add(xlWBATWorksheet)
            Set req = wb.Worksheets(1)
            req.Name = "�˗��p"
            RenderRequestSheetForDest wb, req, dr
            Set ctl = wb.Worksheets.Add(After:=req)
            ctl.Name = "�T���p"
            RenderControlSheetForDest wb, ctl, dr
            fileName = "�`�[�˗��\_" & SafeFileName(dest.Cells(dr, DS_ID).Value & "_" & dest.Cells(dr, DS_BANK).Value & "_" & dest.Cells(dr, DS_SHOP).Value) & ".xlsx"
            PrepareOutputPathWithBackup setFolder & Application.PathSeparator & fileName
            wb.SaveAs Filename:=setFolder & Application.PathSeparator & fileName, FileFormat:=xlOpenXMLWorkbook
            wb.Close SaveChanges:=False
        End If
    Next dr
End Sub

Private Function UniqueSheetName(ByVal wb As Workbook, ByVal baseName As String) As String
    Dim s As String, i As Long
    s = Left$(baseName, 31)
    i = 1
    Do While SheetExists(s, wb)
        i = i + 1
        s = Left$(baseName, 28) & "_" & i
    Loop
    UniqueSheetName = s
End Function

Private Sub RenderRequestSheetForDest(ByVal wb As Workbook, ByVal sh As Worksheet, ByVal destRow As Long)
    Dim tmp As Worksheet, dates As Worksheet, dest As Worksheet
    Set dates = Ws(SH_W_DATES)
    Set dest = Ws(SH_W_DEST)
    sh.Cells.Font.Name = "Meiryo UI"
    sh.Cells.Font.Size = 10
    sh.Columns("A").ColumnWidth = 2
    sh.Columns("B:F").ColumnWidth = 18
    Dim rowTop As Long, dummy As Long
    rowTop = 2
    dummy = RenderRequestSectionExternal(sh, dates, dest, destRow, rowTop)
    PolishExportRequestSheet sh, dummy
End Sub


Private Sub PolishExportRequestSheet(ByVal sh As Worksheet, ByVal lastRowTop As Long)
    Dim lastR As Long
    If sh Is Nothing Then Exit Sub
    lastR = Application.Max(12, lastRowTop - 1)
    On Error Resume Next
    ThemeApplyPrintTable sh.Range("B2:F" & CStr(lastR)), 0
    ThemeCapRowHeights sh.Range("B2:F" & CStr(lastR)), 18, 42
    ThemeApplyMonochromePrint sh, sh.Range("B2:F" & CStr(lastR)).Address, False, "", 1, 0
    On Error GoTo 0
End Sub

Private Sub PolishExportControlSheet(ByVal sh As Worksheet, ByVal lastR As Long)
    If sh Is Nothing Then Exit Sub
    If lastR < 6 Then lastR = 6
    On Error Resume Next
    ThemeApplyPrintTable sh.Range("B6:J" & CStr(lastR)), 1
    ThemeCapRowHeights sh.Range("B6:J" & CStr(lastR)), 18, 72
    ThemeApplyMonochromePrint sh, sh.Range("B1:J" & CStr(lastR)).Address, True, "$6:$6", 1, 0
    On Error GoTo 0
End Sub

Private Function RenderRequestSectionExternal(ByVal sh As Worksheet, ByVal dates As Worksheet, ByVal dest As Worksheet, ByVal destRow As Long, ByVal rowTop As Long) As Long
    Dim allDates As Collection, r As Long
    Set allDates = New Collection
    For r = 2 To LastRow(dates, RD_ID)
        If dates.Cells(r, RD_DEST_ID).Value = dest.Cells(destRow, DS_ID).Value Then allDates.Add CDate(dates.Cells(r, RD_REQUEST_DATE).Value)
    Next r
    Dim perPage As Long, idx As Long, startIdx As Long, endIdx As Long, pageNo As Long, row As Long
    perPage = SettingLong("�˗��p1�y�[�W�ő����", 60)
    If perPage <= 0 Or perPage > 60 Then perPage = 60
    idx = 1: pageNo = 1
    Do While idx <= allDates.Count Or (allDates.Count = 0 And pageNo = 1)
        startIdx = idx
        endIdx = WorksheetFunction.Min(idx + perPage - 1, allDates.Count)
        sh.Range(sh.Cells(rowTop, 2), sh.Cells(rowTop, 6)).Merge
        sh.Cells(rowTop, 2).Value = "�`�[�˗��\"
        sh.Cells(rowTop, 2).Interior.Color = C_DARK
        sh.Cells(rowTop, 2).Font.Color = vbWhite
        sh.Cells(rowTop, 2).Font.Bold = True
        sh.Cells(rowTop, 2).Font.Size = 16
        sh.Cells(rowTop, 2).HorizontalAlignment = xlCenter
        sh.Cells(rowTop + 2, 2).Value = "��s��": sh.Cells(rowTop + 2, 3).Value = dest.Cells(destRow, DS_BANK).Value
        sh.Cells(rowTop + 3, 2).Value = "�x�X��": sh.Cells(rowTop + 3, 3).Value = dest.Cells(destRow, DS_SHOP).Value
        sh.Cells(rowTop + 2, 5).Value = "�y�[�W": sh.Cells(rowTop + 2, 6).Value = pageNo
        sh.Cells(rowTop + 3, 5).Value = "�˗�����": sh.Cells(rowTop + 3, 6).Value = IIf(allDates.Count = 0, 0, endIdx - startIdx + 1)
        With sh.Range(sh.Cells(rowTop + 2, 2), sh.Cells(rowTop + 3, 6)).Borders
            .LineStyle = xlContinuous
            .Color = C_BORDER
            .Weight = xlThin
        End With
        sh.Range(sh.Cells(rowTop + 5, 2), sh.Cells(rowTop + 5, 6)).Merge
        sh.Cells(rowTop + 5, 2).Value = "�˗���"
        sh.Cells(rowTop + 5, 2).Interior.Color = C_NAVY
        sh.Cells(rowTop + 5, 2).Font.Color = vbWhite
        sh.Cells(rowTop + 5, 2).Font.Bold = True
        sh.Cells(rowTop + 5, 2).HorizontalAlignment = xlCenter
        row = rowTop + 6
        If allDates.Count = 0 Then
            sh.Cells(row, 2).Value = "�Ώۓ��Ȃ�"
            row = row + 1
        Else
            For idx = startIdx To endIdx
                sh.Range(sh.Cells(row, 2), sh.Cells(row, 6)).Merge
                sh.Cells(row, 2).Value = FormatJPDate(allDates(idx), True)
                sh.Cells(row, 2).HorizontalAlignment = xlCenter
                row = row + 1
            Next idx
        End If
        With sh.Range(sh.Cells(rowTop + 5, 2), sh.Cells(row - 1, 6)).Borders
            .LineStyle = xlContinuous
            .Color = C_BORDER
            .Weight = xlThin
        End With
        rowTop = rowTop + 70
        If idx > allDates.Count Then Exit Do
        sh.HPageBreaks.Add Before:=sh.Cells(rowTop, 1)
        pageNo = pageNo + 1
    Loop
    RenderRequestSectionExternal = rowTop
End Function

Private Sub RenderControlSheetForDest(ByVal wb As Workbook, ByVal sh As Worksheet, ByVal destRow As Long)
    Dim src As Worksheet, dest As Worksheet, r As Long, outR As Long, curDate As Variant, d As Date
    Set src = Ws(SH_W_CONTROL)
    Set dest = Ws(SH_W_DEST)
    sh.Cells.Font.Name = "Meiryo UI"
    sh.Cells.Font.Size = 9
    sh.Columns("A").ColumnWidth = 2
    sh.Columns("B").ColumnWidth = 14
    sh.Columns("C").ColumnWidth = 16
    sh.Columns("D").ColumnWidth = 10
    sh.Columns("E").ColumnWidth = 12
    sh.Columns("F").ColumnWidth = 12
    sh.Columns("G").ColumnWidth = 18
    sh.Columns("H").ColumnWidth = 16
    sh.Columns("I").ColumnWidth = 42
    sh.Columns("J").ColumnWidth = 14
    sh.Range("B1:J2").Merge
    sh.Range("B1").Value = "�`�[�˗��T���@" & dest.Cells(destRow, DS_BANK).Value & "�@" & dest.Cells(destRow, DS_SHOP).Value
    sh.Range("B1").Interior.Color = C_DARK
    sh.Range("B1").Font.Color = vbWhite
    sh.Range("B1").Font.Bold = True
    sh.Range("B1").Font.Size = 14
    sh.Range("B1").HorizontalAlignment = xlCenter
    sh.Range("B4:J4").Merge
    sh.Range("B4").Value = "�T���p�́A����������Ƃ̌��o���̉��Ɉ˗��Ώێ����\�����܂��B�O���s�c�Ɠ��͊܂߂܂���B"
    sh.Range("B4").Interior.Color = C_LIGHT_BLUE
    sh.Range("B4").WrapText = True
    outR = 6
    curDate = Empty
    For r = 2 To LastRow(src, CD_DEST_ID)
        If src.Cells(r, CD_DEST_ID).Value = dest.Cells(destRow, DS_ID).Value Then
            If IsDate(src.Cells(r, CD_TX_DATE).Value) Then
                d = CDate(src.Cells(r, CD_TX_DATE).Value)
                If IsEmpty(curDate) Or CLng(curDate) <> CLng(d) Then
                    If Not IsEmpty(curDate) Then outR = outR + 1
                    curDate = d
                    sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Merge
                    sh.Cells(outR, 2).Value = "�˗��Ώۓ��i��������j�F" & FormatJPDate(d, True) & "�@�Ώێ�� " & src.Cells(r, CD_DATE_COUNT).Value & "��"
                    sh.Cells(outR, 2).Interior.Color = C_NAVY
                    sh.Cells(outR, 2).Font.Color = vbWhite
                    sh.Cells(outR, 2).Font.Bold = True
                    outR = outR + 1
                    sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Value = Array("�敪", "�l��", "����", "�o��", "����", "���͌��ID", "���ID", "�E�v�E����", "�m�F")
                    sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Interior.Color = ThemeColor("section")
                    sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Font.Bold = True
                    outR = outR + 1
                End If
            End If
            sh.Cells(outR, 2).Value = src.Cells(r, CD_KIND).Value
            sh.Cells(outR, 3).Value = src.Cells(r, CD_PERSON).Value
            sh.Cells(outR, 4).Value = src.Cells(r, CD_RELATION).Value
            sh.Cells(outR, 5).Value = src.Cells(r, CD_OUT).Value
            sh.Cells(outR, 6).Value = src.Cells(r, CD_IN).Value
            sh.Cells(outR, 7).Value = src.Cells(r, CD_ANALYSIS_ID).Value
            sh.Cells(outR, 8).Value = src.Cells(r, CD_TX_ID).Value
            If IsSettingYes("�T���p�E�v�\��", True) Then sh.Cells(outR, 9).Value = JoinNonEmpty(src.Cells(r, CD_SUMMARY).Value, src.Cells(r, CD_MEMO).Value, " / ")
            If outR Mod 2 = 0 Then sh.Range(sh.Cells(outR, 2), sh.Cells(outR, 10)).Interior.Color = ThemeColor("canvas")
            outR = outR + 1
        End If
    Next r
    If outR = 6 Then sh.Cells(6, 2).Value = "�Ώۖ��ׂȂ�"
    With sh.Range("B6:J" & Application.Max(outR - 1, 6))
        .Borders.LineStyle = xlContinuous
        .Borders.Color = C_BORDER
        .Borders.Weight = xlThin
        .WrapText = True
        .VerticalAlignment = xlTop
    End With
    sh.Columns("E:F").NumberFormat = "#,##0"
    PolishExportControlSheet sh, Application.Max(outR - 1, 6)
End Sub

Private Function ConfirmVoucherOverwrite(ByVal outFolder As String) As Boolean
    Dim msg As String, p1 As String, p2 As String
    p1 = outFolder & Application.PathSeparator & "11_�`�[�˗��\_�˗��p.xlsx"
    p2 = outFolder & Application.PathSeparator & "12_�`�[�˗��\_�T���p.xlsx"
    If Len(Dir$(p1)) > 0 Then msg = msg & "�E" & p1 & vbCrLf
    If Len(Dir$(p2)) > 0 Then msg = msg & "�E" & p2 & vbCrLf
    If Len(msg) = 0 Then
        ConfirmVoucherOverwrite = True
    Else
        ConfirmVoucherOverwrite = (MsgBox("�ȉ��̓`�[�˗��\�͊��ɑ��݂��܂��B�o�b�N�A�b�v���쐬���ď㏑�����܂����H" & vbCrLf & vbCrLf & msg, vbQuestion + vbYesNo, "�㏑���m�F") = vbYes)
    End If
End Function

Private Sub PrepareOutputPathWithBackup(ByVal filePath As String)
    Dim backupPath As String
    If Len(filePath) = 0 Then Exit Sub
    If Len(Dir$(filePath)) = 0 Then Exit Sub
    backupPath = filePath & ".bak_" & Format$(Now, "yyyymmdd_hhnnss")
    FileCopy filePath, backupPath
    Kill filePath
    WriteLog "�����o�̓o�b�N�A�b�v: " & backupPath
End Sub

Private Sub BackupCommonDataBeforeUpdate(ByVal filePath As String)
    Dim backupPath As String
    If Len(filePath) = 0 Then Exit Sub
    If Len(Dir$(filePath)) = 0 Then Exit Sub
    backupPath = filePath & ".bak_" & Format$(Now, "yyyymmdd_hhnnss")
    FileCopy filePath, backupPath
    WriteLog "���ʃf�[�^�X�V�O�o�b�N�A�b�v: " & backupPath
End Sub

Attribute VB_Name = "modHoliday"
Option Explicit

' �j���f�[�^�́A�`�[�˗���₩����ۂɕK�v�ɂȂ�˗����͈͂����� W_�j�� �ɕێ�����B
' ���f�[�^�͓��t�{CSV���g�p���邪�A�V�[�g�ɂ͍ŌÈ˗����`�ŐV�˗����͈͓̔��������������ށB

Private mHolidayCache As Object
Private mHolidayNameCache As Object
Private mHolidayCacheLastRow As Long


Public Sub ImportHolidayCsv()
    On Error GoTo EH
    Dim fd As FileDialog
    Set fd = Application.FileDialog(msoFileDialogFilePicker)
    With fd
        .Title = "�j��CSV��I�����Ă�������"
        .Filters.Clear
        .Filters.Add "CSV", "*.csv"
        .AllowMultiSelect = False
        If .Show <> -1 Then Exit Sub
        ImportHolidayCsvFile .SelectedItems(1), True
    End With
    MsgBox "�j���f�[�^��K�v�͈͂�����荞�݂܂����B" & vbCrLf & HolidayCoverageStatusText(), vbInformation
    Exit Sub
EH:
    MsgBox "�j��CSV�捞�ŃG���[: " & Err.Description, vbExclamation
End Sub

Public Sub DownloadHolidayCsv()
    If EnsureHolidayCoverageForVoucherDates(True, True) Then Exit Sub
    MsgBox "�j���f�[�^���擾�ł��܂���ł����B������E�˗���ݒ�E�ʐM�����m�F���Ă��������B", vbExclamation
End Sub

Public Function EnsureHolidayCoverageForVoucherDates(Optional ByVal forceRefresh As Boolean = False, Optional ByVal notify As Boolean = False) As Boolean
    On Error GoTo EH
    EnsureHolidayCoverageForVoucherDates = False

    If Not IsSettingYes("�O���s�c�Ɠ����܂߂�", True) Then
        EnsureHolidayCoverageForVoucherDates = True
        Exit Function
    End If

    Dim baseMin As Date, baseMax As Date
    If Not GetVoucherCandidateDateRange(baseMin, baseMax) Then
        EnsureHolidayCoverageForVoucherDates = True
        If notify Then MsgBox "�j���擾���K�v�Ȉ˗��Ώۓ�������܂���B", vbInformation
        Exit Function
    End If

    Dim reqMin As Date, reqMax As Date
    If Not forceRefresh Then
        If ComputeRequiredDateRangeFromSheet(reqMin, reqMax) Then
            If HasHolidayCoverageForRange(reqMin, reqMax) Then
                EnsureHolidayCoverageForVoucherDates = True
                If notify Then MsgBox "�j���f�[�^�͊��ɕK�v�͈͂𖞂����Ă��܂��B" & vbCrLf & HolidayCoverageStatusText(), vbInformation
                Exit Function
            End If
        End If
    End If

    Dim begun As Boolean, url As String, tmp As String
    Dim wb As Workbook, src As Worksheet, holidays As Object
    Dim srcMin As Date, srcMax As Date

    AppBegin "�K�v�͈͂̏j���f�[�^���擾��..."
    begun = True

    url = SettingText("�j��URL", HOLIDAY_URL)
    tmp = DownloadHolidayCsvToTemp(url)

    Set wb = OpenHolidayCsvWorkbook(tmp)
    Set src = wb.Worksheets(1)
    Set holidays = HolidayDictionaryFromWorksheet(src, srcMin, srcMax)
    If holidays.Count = 0 Then Err.Raise vbObjectError + 331, , "�擾�����j��CSV�ɗL���ȓ��t������܂���B"
    If StripTime(srcMin) > StripTime(baseMin) Or StripTime(srcMax) < StripTime(baseMax) Then
        Err.Raise vbObjectError + 332, , "�擾�����j��CSV�̎��^�͈͂��˗��Ώۓ����܂�ł��܂���BCSV�͈�: " & _
                                      Format$(srcMin, "yyyy/m/d") & "�`" & Format$(srcMax, "yyyy/m/d")
    End If

    If Not ComputeRequiredDateRangeFromDict(holidays, reqMin, reqMax) Then
        Err.Raise vbObjectError + 333, , "�˗����͈͂��v�Z�ł��܂���ł����B"
    End If
    If StripTime(srcMin) > StripTime(reqMin) Or StripTime(srcMax) < StripTime(reqMax) Then
        Err.Raise vbObjectError + 334, , "�擾�����j��CSV�̎��^�͈͂��O���s�c�Ɠ����܂ވ˗����͈͂𖞂����Ă��܂���B�K�v�͈�: " & _
                                      Format$(reqMin, "yyyy/m/d") & "�`" & Format$(reqMax, "yyyy/m/d")
    End If

    WriteHolidayRowsFromWorksheet src, reqMin, reqMax, "�����擾", url
    InvalidateHolidayCache

    wb.Close SaveChanges:=False
    Set wb = Nothing
    On Error Resume Next
    Kill tmp
    On Error GoTo EH

    UpdateMainStatus
    WriteLog "�j���f�[�^�����擾: " & Format$(reqMin, "yyyy/m/d") & "�`" & Format$(reqMax, "yyyy/m/d")
    If begun Then AppEnd ""
    If notify Then MsgBox "�j���f�[�^��K�v�͈͂��������擾���܂����B" & vbCrLf & HolidayCoverageStatusText(), vbInformation
    EnsureHolidayCoverageForVoucherDates = True
    Exit Function
EH:
    Dim errMsg As String
    errMsg = Err.Description
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    If Len(tmp) > 0 Then Kill tmp
    If begun Then AppEnd ""
    WriteLog "�j���f�[�^�����擾���s: " & errMsg, "ERROR"
    If notify Then MsgBox "�j�������擾�ŃG���[: " & errMsg, vbExclamation
End Function

Private Sub ImportHolidayCsvFile(ByVal filePath As String, Optional ByVal fitVoucherRange As Boolean = True)
    On Error GoTo EH
    Dim begun As Boolean
    Dim wb As Workbook, src As Worksheet, holidays As Object
    Dim reqMin As Date, reqMax As Date, srcMin As Date, srcMax As Date

    AppBegin "�j��CSV���捞��..."
    begun = True
    Set wb = OpenHolidayCsvWorkbook(filePath)
    Set src = wb.Worksheets(1)
    Set holidays = HolidayDictionaryFromWorksheet(src, srcMin, srcMax)
    If holidays.Count = 0 Then Err.Raise vbObjectError + 335, , "�j��CSV�ɗL���ȓ��t������܂���B"

    If fitVoucherRange And ComputeRequiredDateRangeFromDict(holidays, reqMin, reqMax) Then
        WriteHolidayRowsFromWorksheet src, reqMin, reqMax, "CSV�捞", filePath
        InvalidateHolidayCache
    ElseIf fitVoucherRange Then
        Err.Raise vbObjectError + 336, , "�˗��Ώۓ����Ȃ����߁A�K�v�͈͂�����ł��܂���B��ɋ��ʃf�[�^�Ǎ������s���Ă��������B"
    Else
        WriteHolidayRowsFromWorksheet src, srcMin, srcMax, "CSV�捞", filePath
        InvalidateHolidayCache
    End If

    wb.Close SaveChanges:=False
    Set wb = Nothing
    UpdateMainStatus
    WriteLog "�j���f�[�^�捞: " & HolidayCoverageStatusText()
    If begun Then AppEnd ""
    Exit Sub
EH:
    Dim errNo As Long, errSource As String, errMsg As String
    errNo = Err.Number
    errSource = Err.Source
    errMsg = Err.Description
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    If begun Then AppEnd ""
    Err.Raise errNo, errSource, errMsg
End Sub

Private Function DownloadHolidayCsvToTemp(ByVal url As String) As String
    Dim tmp As String
    tmp = Environ$("TEMP") & Application.PathSeparator & "syukujitsu_" & Format$(Now, "yyyymmddhhmmss") & ".csv"

    Dim http As Object, stm As Object
    On Error Resume Next
    Set http = CreateObject("MSXML2.XMLHTTP.6.0")
    If http Is Nothing Then Set http = CreateObject("MSXML2.XMLHTTP")
    On Error GoTo 0
    If http Is Nothing Then Err.Raise vbObjectError + 337, , "MSXML HTTP �𗘗p�ł��܂���B"

    http.Open "GET", url, False
    On Error Resume Next
    http.setRequestHeader "Cache-Control", "no-cache"
    On Error GoTo 0
    http.send
    If http.Status <> 200 Then Err.Raise vbObjectError + 338, , "HTTP " & http.Status & " �Ŏ擾�ł��܂���ł����BURL���m�F���Ă��������B"

    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 1
    stm.Open
    stm.Write http.responseBody
    stm.SaveToFile tmp, 2
    stm.Close
    DownloadHolidayCsvToTemp = tmp
End Function

Private Function OpenHolidayCsvWorkbook(ByVal filePath As String) As Workbook
    Workbooks.OpenText Filename:=filePath, Origin:=932, DataType:=xlDelimited, Comma:=True, Local:=True
    Set OpenHolidayCsvWorkbook = ActiveWorkbook
End Function

Private Function HolidayDictionaryFromWorksheet(ByVal src As Worksheet, ByRef minD As Date, ByRef maxD As Date) As Object
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")
    Dim lr As Long, r As Long, d As Date, got As Boolean
    lr = LastRow(src, 1)
    For r = 2 To lr
        If IsDate(src.Cells(r, 1).Value) Then
            d = StripTime(CDate(src.Cells(r, 1).Value))
            dict(CStr(CLng(d))) = Nz(src.Cells(r, 2).Value)
            If Not got Then
                minD = d
                maxD = d
                got = True
            Else
                If d < minD Then minD = d
                If d > maxD Then maxD = d
            End If
        End If
    Next r
    Set HolidayDictionaryFromWorksheet = dict
End Function

Private Sub WriteHolidayRowsFromWorksheet(ByVal src As Worksheet, ByVal rangeStart As Date, ByVal rangeEnd As Date, ByVal sourceText As String, ByVal sourceUrl As String)
    Dim dst As Worksheet
    Set dst = Ws(SH_W_HOLIDAY)
    EnsureHolidayHeaders dst
    ClearHolidayData dst

    Dim lr As Long, r As Long, outR As Long, d As Date
    lr = LastRow(src, 1)
    outR = 2
    For r = 2 To lr
        If IsDate(src.Cells(r, 1).Value) Then
            d = StripTime(CDate(src.Cells(r, 1).Value))
            If d >= StripTime(rangeStart) And d <= StripTime(rangeEnd) Then
                dst.Cells(outR, 1).Value = d
                dst.Cells(outR, 2).Value = Nz(src.Cells(r, 2).Value)
                dst.Cells(outR, 3).Value = sourceText
                dst.Cells(outR, 4).Value = Now
                outR = outR + 1
            End If
        End If
    Next r

    dst.Cells(2, 5).Value = StripTime(rangeStart)
    dst.Cells(2, 6).Value = StripTime(rangeEnd)
    dst.Cells(2, 7).Value = sourceUrl
    dst.Columns(1).NumberFormatLocal = "yyyy/m/d"
    dst.Columns(4).NumberFormatLocal = "yyyy/m/d h:mm"
    dst.Columns(5).NumberFormatLocal = "yyyy/m/d"
    dst.Columns(6).NumberFormatLocal = "yyyy/m/d"
    dst.Columns("A:G").AutoFit
End Sub

Private Sub EnsureHolidayHeaders(ByVal sh As Worksheet)
    sh.Range("A1:G1").Value = Array("���t", "����", "�\�[�X", "�X�V����", "�擾�͈͊J�n", "�擾�͈͏I��", "�擾��URL")
    With sh.Range("A1:G1")
        .Interior.Color = C_NAVY
        .Font.Color = vbWhite
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
End Sub

Private Sub ClearHolidayData(ByVal sh As Worksheet)
    On Error Resume Next
    sh.Unprotect Password:=TOOL_PASSWORD
    If sh.AutoFilterMode Then sh.AutoFilterMode = False
    On Error GoTo 0
    Dim lr As Long
    lr = Application.Max(LastRow(sh, 1), LastRow(sh, 5), 2)
    sh.Range("A2:G" & CStr(lr)).ClearContents
End Sub

Private Function GetVoucherCandidateDateRange(ByRef minD As Date, ByRef maxD As Date) As Boolean
    Dim sh As Worksheet, r As Long, lr As Long, d As Date, got As Boolean
    Dim destKeys As Object, hasDestRows As Boolean, key As String
    If Not SheetExists(SH_W_CAND) Then Exit Function
    Set sh = Ws(SH_W_CAND)
    lr = LastRow(sh, VC_ID)
    If lr <= 1 Then Exit Function

    Set destKeys = IncludedDestinationKeys(hasDestRows)
    If hasDestRows And destKeys.Count = 0 Then Exit Function

    For r = 2 To lr
        If Nz(sh.Cells(r, VC_TARGET).Value) = "�v" And IsDate(sh.Cells(r, VC_TX_DATE).Value) Then
            key = Nz(sh.Cells(r, VC_DEST_KEY).Value)
            If (Not hasDestRows) Or destKeys.Exists(key) Then
                d = StripTime(CDate(sh.Cells(r, VC_TX_DATE).Value))
                If Not got Then
                    minD = d
                    maxD = d
                    got = True
                Else
                    If d < minD Then minD = d
                    If d > maxD Then maxD = d
                End If
            End If
        End If
    Next r
    GetVoucherCandidateDateRange = got
End Function

Private Function IncludedDestinationKeys(ByRef hasDestRows As Boolean) As Object
    Dim dict As Object, sh As Worksheet, r As Long, lr As Long
    Set dict = CreateObject("Scripting.Dictionary")
    hasDestRows = False
    If Not SheetExists(SH_W_DEST) Then
        Set IncludedDestinationKeys = dict
        Exit Function
    End If
    Set sh = Ws(SH_W_DEST)
    lr = LastRow(sh, DS_ID)
    If lr <= 1 Then
        Set IncludedDestinationKeys = dict
        Exit Function
    End If
    hasDestRows = True
    For r = 2 To lr
        If Nz(sh.Cells(r, DS_TARGET).Value, "�쐬") = "�쐬" Then
            If Len(Nz(sh.Cells(r, DS_KEY).Value)) > 0 Then dict(Nz(sh.Cells(r, DS_KEY).Value)) = 1
        End If
    Next r
    Set IncludedDestinationKeys = dict
End Function

Private Function ComputeRequiredDateRangeFromSheet(ByRef reqMin As Date, ByRef reqMax As Date) As Boolean
    Dim sh As Worksheet, r As Long, lr As Long, d As Date
    Dim destKeys As Object, hasDestRows As Boolean, key As String
    Dim n As Long, i As Long, prevD As Date, nextD As Date, got As Boolean
    If Not SheetExists(SH_W_CAND) Then Exit Function
    Set sh = Ws(SH_W_CAND)
    lr = LastRow(sh, VC_ID)
    If lr <= 1 Then Exit Function
    n = NormalizedBeforeAfterCount()
    Set destKeys = IncludedDestinationKeys(hasDestRows)
    If hasDestRows And destKeys.Count = 0 Then Exit Function

    For r = 2 To lr
        If Nz(sh.Cells(r, VC_TARGET).Value) = "�v" And IsDate(sh.Cells(r, VC_TX_DATE).Value) Then
            key = Nz(sh.Cells(r, VC_DEST_KEY).Value)
            If (Not hasDestRows) Or destKeys.Exists(key) Then
                d = StripTime(CDate(sh.Cells(r, VC_TX_DATE).Value))
                AddDateToRange reqMin, reqMax, got, d
                If IsSettingYes("�O���s�c�Ɠ����܂߂�", True) Then
                    prevD = d
                    nextD = d
                    For i = 1 To n
                        prevD = PreviousBankBusinessDay(prevD)
                        nextD = NextBankBusinessDay(nextD)
                        AddDateToRange reqMin, reqMax, got, prevD
                        AddDateToRange reqMin, reqMax, got, nextD
                    Next i
                End If
            End If
        End If
    Next r
    ComputeRequiredDateRangeFromSheet = got
End Function

Private Function ComputeRequiredDateRangeFromDict(ByVal holidays As Object, ByRef reqMin As Date, ByRef reqMax As Date) As Boolean
    Dim sh As Worksheet, r As Long, lr As Long, d As Date
    Dim destKeys As Object, hasDestRows As Boolean, key As String
    Dim n As Long, i As Long, prevD As Date, nextD As Date, got As Boolean
    If holidays Is Nothing Then Exit Function
    If Not SheetExists(SH_W_CAND) Then Exit Function
    Set sh = Ws(SH_W_CAND)
    lr = LastRow(sh, VC_ID)
    If lr <= 1 Then Exit Function
    n = NormalizedBeforeAfterCount()
    Set destKeys = IncludedDestinationKeys(hasDestRows)
    If hasDestRows And destKeys.Count = 0 Then Exit Function

    For r = 2 To lr
        If Nz(sh.Cells(r, VC_TARGET).Value) = "�v" And IsDate(sh.Cells(r, VC_TX_DATE).Value) Then
            key = Nz(sh.Cells(r, VC_DEST_KEY).Value)
            If (Not hasDestRows) Or destKeys.Exists(key) Then
                d = StripTime(CDate(sh.Cells(r, VC_TX_DATE).Value))
                AddDateToRange reqMin, reqMax, got, d
                If IsSettingYes("�O���s�c�Ɠ����܂߂�", True) Then
                    prevD = d
                    nextD = d
                    For i = 1 To n
                        prevD = PreviousBankBusinessDayFromDict(prevD, holidays)
                        nextD = NextBankBusinessDayFromDict(nextD, holidays)
                        AddDateToRange reqMin, reqMax, got, prevD
                        AddDateToRange reqMin, reqMax, got, nextD
                    Next i
                End If
            End If
        End If
    Next r
    ComputeRequiredDateRangeFromDict = got
End Function

Private Sub AddDateToRange(ByRef minD As Date, ByRef maxD As Date, ByRef hasValue As Boolean, ByVal d As Date)
    d = StripTime(d)
    If Not hasValue Then
        minD = d
        maxD = d
        hasValue = True
    Else
        If d < minD Then minD = d
        If d > maxD Then maxD = d
    End If
End Sub

Private Function NormalizedBeforeAfterCount() As Long
    NormalizedBeforeAfterCount = SettingLong("�O�����", 1)
    If NormalizedBeforeAfterCount < 0 Then NormalizedBeforeAfterCount = 0
    If NormalizedBeforeAfterCount > 5 Then NormalizedBeforeAfterCount = 5
End Function

Private Function PreviousBankBusinessDayFromDict(ByVal d As Date, ByVal holidays As Object) As Date
    Dim x As Date, guard As Long
    x = DateAdd("d", -1, StripTime(d))
    Do While Not IsBankBusinessDayFromDict(x, holidays)
        x = DateAdd("d", -1, x)
        guard = guard + 1
        If guard > 370 Then Err.Raise vbObjectError + 339, , "�O��s�c�Ɠ��̒T���Ɏ��s���܂����B�j���f�[�^���m�F���Ă��������B"
    Loop
    PreviousBankBusinessDayFromDict = x
End Function

Private Function NextBankBusinessDayFromDict(ByVal d As Date, ByVal holidays As Object) As Date
    Dim x As Date, guard As Long
    x = DateAdd("d", 1, StripTime(d))
    Do While Not IsBankBusinessDayFromDict(x, holidays)
        x = DateAdd("d", 1, x)
        guard = guard + 1
        If guard > 370 Then Err.Raise vbObjectError + 340, , "����s�c�Ɠ��̒T���Ɏ��s���܂����B�j���f�[�^���m�F���Ă��������B"
    Loop
    NextBankBusinessDayFromDict = x
End Function

Private Function IsBankBusinessDayFromDict(ByVal d As Date, ByVal holidays As Object) As Boolean
    Dim wd As Long
    d = StripTime(d)
    wd = Weekday(d, vbMonday)
    IsBankBusinessDayFromDict = (wd <= 5 And Not holidays.Exists(CStr(CLng(d))) And Not IsBankYearEndHoliday(d))
End Function

Public Function HasHolidayCoverageForRange(ByVal rangeStart As Date, ByVal rangeEnd As Date) As Boolean
    Dim storedStart As Date, storedEnd As Date
    If Not HolidayCoverageBounds(storedStart, storedEnd) Then Exit Function
    HasHolidayCoverageForRange = (StripTime(storedStart) <= StripTime(rangeStart) And StripTime(storedEnd) >= StripTime(rangeEnd))
End Function

Private Function HolidayCoverageBounds(ByRef storedStart As Date, ByRef storedEnd As Date) As Boolean
    Dim sh As Worksheet, r As Long, lr As Long, d As Date
    If Not SheetExists(SH_W_HOLIDAY) Then Exit Function
    Set sh = Ws(SH_W_HOLIDAY)

    If IsDate(sh.Cells(2, 5).Value) And IsDate(sh.Cells(2, 6).Value) Then
        storedStart = StripTime(CDate(sh.Cells(2, 5).Value))
        storedEnd = StripTime(CDate(sh.Cells(2, 6).Value))
        HolidayCoverageBounds = True
        Exit Function
    End If

    lr = LastRow(sh, 1)
    If lr <= 1 Then Exit Function
    For r = 2 To lr
        If IsDate(sh.Cells(r, 1).Value) Then
            d = StripTime(CDate(sh.Cells(r, 1).Value))
            If Not HolidayCoverageBounds Then
                storedStart = d
                storedEnd = d
                HolidayCoverageBounds = True
            Else
                If d < storedStart Then storedStart = d
                If d > storedEnd Then storedEnd = d
            End If
        End If
    Next r
End Function

Public Function HolidayCoverageStatusText() As String
    Dim s As Date, e As Date
    If HolidayCoverageBounds(s, e) Then
        HolidayCoverageStatusText = "�擾�� " & Format$(s, "yyyy/m/d") & "�`" & Format$(e, "yyyy/m/d")
    Else
        HolidayCoverageStatusText = "���擾"
    End If
End Function

Public Function RequiredHolidayRangeText() As String
    Dim reqMin As Date, reqMax As Date
    If ComputeRequiredDateRangeFromSheet(reqMin, reqMax) Then
        RequiredHolidayRangeText = Format$(reqMin, "yyyy/m/d") & "�`" & Format$(reqMax, "yyyy/m/d")
    Else
        RequiredHolidayRangeText = "�ΏۂȂ�"
    End If
End Function

Private Function StripTime(ByVal d As Date) As Date
    StripTime = DateSerial(Year(d), Month(d), Day(d))
End Function

Public Function IsHoliday(ByVal d As Date) As Boolean
    EnsureHolidayCacheLoaded
    If mHolidayCache Is Nothing Then
        IsHoliday = False
    Else
        IsHoliday = mHolidayCache.Exists(CStr(CLng(StripTime(d))))
    End If
End Function

Public Function HolidayName(ByVal d As Date) As String
    EnsureHolidayCacheLoaded
    If Not mHolidayNameCache Is Nothing Then
        If mHolidayNameCache.Exists(CStr(CLng(StripTime(d)))) Then HolidayName = CStr(mHolidayNameCache(CStr(CLng(StripTime(d)))))
    End If
End Function

Public Sub EnsureHolidayCacheLoaded(Optional ByVal forceRefresh As Boolean = False)
    Dim sh As Worksheet, lr As Long, data As Variant, r As Long, d As Date, key As String
    If Not SheetExists(SH_W_HOLIDAY) Then Exit Sub
    Set sh = Ws(SH_W_HOLIDAY)
    lr = LastRow(sh, 1)
    If Not forceRefresh Then
        If Not mHolidayCache Is Nothing Then
            If mHolidayCacheLastRow = lr Then Exit Sub
        End If
    End If
    Set mHolidayCache = CreateObject("Scripting.Dictionary")
    Set mHolidayNameCache = CreateObject("Scripting.Dictionary")
    mHolidayCacheLastRow = lr
    If lr <= 1 Then Exit Sub
    data = sh.Range(sh.Cells(2, 1), sh.Cells(lr, 2)).Value
    For r = 1 To UBound(data, 1)
        If IsDate(data(r, 1)) Then
            d = StripTime(CDate(data(r, 1)))
            key = CStr(CLng(d))
            mHolidayCache(key) = True
            mHolidayNameCache(key) = Nz(data(r, 2))
        End If
    Next r
End Sub

Public Sub InvalidateHolidayCache()
    Set mHolidayCache = Nothing
    Set mHolidayNameCache = Nothing
    mHolidayCacheLastRow = 0
End Sub

Public Function IsBankYearEndHoliday(ByVal d As Date) As Boolean
    Dim m As Long, dd As Long
    d = StripTime(d)
    m = Month(d)
    dd = Day(d)
    IsBankYearEndHoliday = ((m = 12 And dd = 31) Or (m = 1 And dd >= 1 And dd <= 3))
End Function

Public Function BankHolidayName(ByVal d As Date) As String
    Dim nm As String
    If Weekday(d, vbMonday) >= 6 Then
        BankHolidayName = "�y��"
    Else
        nm = HolidayName(d)
        If Len(nm) > 0 Then
            BankHolidayName = nm
        ElseIf IsBankYearEndHoliday(d) Then
            BankHolidayName = "��s�x�Ɠ��i�N���N�n�j"
        Else
            BankHolidayName = ""
        End If
    End If
End Function

Public Function IsBankBusinessDay(ByVal d As Date) As Boolean
    Dim wd As Long
    d = StripTime(d)
    wd = Weekday(d, vbMonday)
    IsBankBusinessDay = (wd <= 5 And Not IsHoliday(d) And Not IsBankYearEndHoliday(d))
End Function

Public Function PreviousBankBusinessDay(ByVal d As Date) As Date
    Dim x As Date, guard As Long
    x = DateAdd("d", -1, StripTime(d))
    Do While Not IsBankBusinessDay(x)
        x = DateAdd("d", -1, x)
        guard = guard + 1
        If guard > 370 Then Err.Raise vbObjectError + 321, , "�O��s�c�Ɠ��̒T���Ɏ��s���܂����B�j���f�[�^���m�F���Ă��������B"
    Loop
    PreviousBankBusinessDay = x
End Function

Public Function NextBankBusinessDay(ByVal d As Date) As Date
    Dim x As Date, guard As Long
    x = DateAdd("d", 1, StripTime(d))
    Do While Not IsBankBusinessDay(x)
        x = DateAdd("d", 1, x)
        guard = guard + 1
        If guard > 370 Then Err.Raise vbObjectError + 322, , "����s�c�Ɠ��̒T���Ɏ��s���܂����B�j���f�[�^���m�F���Ă��������B"
    Loop
    NextBankBusinessDay = x
End Function

' ���Ō݊�: �u�c�Ɠ��v�ƌĂ�ł����֐����Av2�ȍ~�͋�s�c�Ɠ��Ƃ��Ĉ����B
Public Function IsBusinessDay(ByVal d As Date) As Boolean
    IsBusinessDay = IsBankBusinessDay(d)
End Function

Public Function PreviousBusinessDay(ByVal d As Date) As Date
    PreviousBusinessDay = PreviousBankBusinessDay(d)
End Function

Public Function NextBusinessDay(ByVal d As Date) As Date
    NextBusinessDay = NextBankBusinessDay(d)
End Function

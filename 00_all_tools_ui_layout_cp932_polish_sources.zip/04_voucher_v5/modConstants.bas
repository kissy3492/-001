Attribute VB_Name = "modConstants"
Option Explicit

Public Const TOOL_SCHEMA As String = "voucher-link-v5"
Public Const TOOL_PASSWORD As String = "voucherlink"
Public Const COMMON_DATA_FILE As String = "00_���ʃf�[�^.xlsx"
Public Const OUTPUT_FOLDER As String = "�o��"
Public Const HOLIDAY_URL As String = "https://www8.cao.go.jp/chosei/shukujitsu/syukujitsu.csv"

Public Const SH_MAIN As String = "�`�[�˗�����"
Public Const SH_SETTINGS As String = "�ݒ�"
Public Const SH_DEST_LIST As String = "�˗���ꗗ"
Public Const SH_REQUEST As String = "�`�[�˗��\_�˗��p"
Public Const SH_CONTROL As String = "�`�[�˗��\_�T���p"
Public Const SH_CHECK As String = "C_�`�F�b�N"
Public Const SH_W_CAND As String = "W_�`�[���"
Public Const SH_W_DEST As String = "W_�˗���"
Public Const SH_W_DATES As String = "W_�˗���"
Public Const SH_W_CONTROL As String = "W_�T������"
Public Const SH_W_HOLIDAY As String = "W_�j��"
Public Const SH_W_LOG As String = "W_�A�g���O"
Public Const SH_W_ID As String = "W_ID�Ǘ�"

Public Const SRC_VOUCHER As String = "T_�`�[�˗����"
Public Const SRC_ANALYSIS As String = "T_���͌���"
Public Const SRC_DETAIL As String = "T_���͖���"
Public Const SRC_SETTING As String = "T_���͘A�g�ݒ�"

Public Const OUT_SETTING As String = "T_�`�[�˗��A�g�ݒ�"
Public Const OUT_DATES As String = "T_�`�[�˗���"
Public Const OUT_DETAIL As String = "T_�`�[�˗�����"
Public Const OUT_DEST As String = "T_�`�[�˗���"

' W_�`�[��� columns
Public Const VC_ID As Long = 1
Public Const VC_ANALYSIS_ID As Long = 2
Public Const VC_DETAIL_ID As Long = 3
Public Const VC_TX_ID As Long = 4
Public Const VC_TX_DATE As Long = 5
Public Const VC_BANK As Long = 6
Public Const VC_BRANCH As Long = 7
Public Const VC_SHOP As Long = 8
Public Const VC_PERSON_ID As Long = 9
Public Const VC_PERSON_NAME As Long = 10
Public Const VC_RELATION As Long = 11
Public Const VC_KIND As Long = 12
Public Const VC_OUT As Long = 13
Public Const VC_IN As Long = 14
Public Const VC_SUMMARY As Long = 15
Public Const VC_VOUCHER As Long = 16
Public Const VC_ADOPT As Long = 17
Public Const VC_TARGET As Long = 18
Public Const VC_MEMO As Long = 19
Public Const VC_DEST_KEY As Long = 20
Public Const VC_STATUS As Long = 21
Public Const VC_COLS As Long = 21

' W_�˗��� columns
Public Const DS_ID As Long = 1
Public Const DS_KEY As Long = 2
Public Const DS_BANK As Long = 3
Public Const DS_SHOP As Long = 4
Public Const DS_TX_DATE_COUNT As Long = 5
Public Const DS_REQUEST_DATE_COUNT As Long = 6
Public Const DS_TX_COUNT As Long = 7
Public Const DS_TARGET As Long = 8
Public Const DS_REQ_SHEET As Long = 9
Public Const DS_CTL_SHEET As Long = 10
Public Const DS_MEMO As Long = 11
Public Const DS_COLS As Long = 11

' W_�˗��� columns
Public Const RD_ID As Long = 1
Public Const RD_DEST_ID As Long = 2
Public Const RD_DEST_KEY As Long = 3
Public Const RD_BANK As Long = 4
Public Const RD_SHOP As Long = 5
Public Const RD_SOURCE_DATE As Long = 6
Public Const RD_REQUEST_DATE As Long = 7
Public Const RD_DATE_KIND As Long = 8
Public Const RD_WEEKDAY As Long = 9
Public Const RD_HOLIDAY As Long = 10
Public Const RD_SOURCE_COUNT As Long = 11
Public Const RD_SOURCE_IDS As Long = 12
Public Const RD_COLS As Long = 12

' W_�T������ columns
Public Const CD_DEST_ID As Long = 1
Public Const CD_DEST_KEY As Long = 2
Public Const CD_BANK As Long = 3
Public Const CD_SHOP As Long = 4
Public Const CD_TX_DATE As Long = 5
Public Const CD_DATE_COUNT As Long = 6
Public Const CD_ANALYSIS_ID As Long = 7
Public Const CD_TX_ID As Long = 8
Public Const CD_KIND As Long = 9
Public Const CD_PERSON As Long = 10
Public Const CD_RELATION As Long = 11
Public Const CD_OUT As Long = 12
Public Const CD_IN As Long = 13
Public Const CD_SUMMARY As Long = 14
Public Const CD_MEMO As Long = 15
Public Const CD_COLS As Long = 15

Public Const C_DARK As Long = &H2A1F18      ' #181F2A
Public Const C_NAVY As Long = &H37291F      ' #1F2937
Public Const C_BLUE As Long = &HEB6325      ' #2563EB
Public Const C_TEAL As Long = &H88940D      ' #0D9488
Public Const C_GREEN As Long = &H4AA316      ' #16A34A
Public Const C_ORANGE As Long = &HC58EA     ' #EA580C
Public Const C_PURPLE As Long = &HED3A7C     ' #7C3AED
Public Const C_RED As Long = &H2626DC        ' #DC2626
Public Const C_LIGHT_BLUE As Long = &HFCFAF8 ' #F8FAFC
Public Const C_LIGHT_GREEN As Long = &HF5FDEC
Public Const C_LIGHT_YELLOW As Long = &HEBFBFF
Public Const C_LIGHT_RED As Long = &HF2F2FE
Public Const C_LIGHT_GRAY As Long = &HF9F5F1
Public Const C_BORDER As Long = &HF0E8E2

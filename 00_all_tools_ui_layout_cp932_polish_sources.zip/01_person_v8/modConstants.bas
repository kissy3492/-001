Attribute VB_Name = "modConstants"
Option Explicit

Public Const TOOL_PASSWORD As String = "personinfo"

Public Const SH_MENU As String = "���j���["
Public Const SH_CONFIG As String = "�ݒ�"
Public Const SH_INPUT As String = "�l������"
Public Const SH_CONFIRM As String = "�m�F�ꗗ"
Public Const SH_CHECK As String = "C_�`�F�b�N"
Public Const SH_DIAGRAM As String = "�����֌W�����}"
Public Const SH_ADDR_TABLE As String = "�Z���ړ]�����\"
Public Const SH_COHAB As String = "��������\"
Public Const SH_TIMELINE As String = "���n��\"
Public Const SH_PERSON_LIST As String = "�l���ꗗ"

Public Const SH_W_PERSON As String = "W_�l��"
Public Const SH_W_REL As String = "W_�֌W"
Public Const SH_W_ADDR_CAND As String = "W_�Z�����"
Public Const SH_W_ADDR_HIST As String = "W_�Z������"
Public Const SH_W_EVENT As String = "W_�C�x���g"
Public Const SH_W_CAND As String = "W_���"
Public Const SH_W_ID As String = "W_ID�Ǘ�"
Public Const SH_W_LOG As String = "W_�A�g���O"

Public Const MODE_DECEDENT As String = "�푊���l"
Public Const MODE_SPOUSE As String = "�z���"
Public Const MODE_FATHER As String = "��"
Public Const MODE_MOTHER As String = "��"
Public Const MODE_CHILD As String = "�q"
Public Const MODE_SIBLING As String = "�Z��o��"
Public Const MODE_GRANDCHILD As String = "��"
Public Const MODE_OTHER As String = "���̑��֌W��"

Public Const STATUS_ACTIVE As String = "�L��"
Public Const STATUS_CANCEL As String = "���"

Public Const SHOW_YES As String = "�\��"
Public Const SHOW_NO As String = "��\��"

'�l�����̓Z��
Public Const CELL_BASE_SELECT As String = "C6"
Public Const CELL_BASE_ID As String = "C7"
Public Const CELL_BASE_NAME As String = "C8"
Public Const CELL_BASE_REL As String = "C9"
Public Const CELL_BASE_ADDRESS As String = "C10"

Public Const CELL_PERSON_ID As String = "C17"
Public Const CELL_MODE As String = "C18"
Public Const CELL_AUTO_SURNAME As String = "C20"
Public Const CELL_SURNAME As String = "C21"
Public Const CELL_GIVEN_NAME As String = "C22"
Public Const CELL_FORMER_SURNAME As String = "C23"
Public Const CELL_GENDER As String = "C24"
Public Const CELL_REL_TO_DECEDENT As String = "C25"
Public Const CELL_BIRTH As String = "C26"
Public Const CELL_DEATH As String = "C27"
Public Const CELL_OCCUPATION As String = "C28"
Public Const CELL_MARRIAGE As String = "C29"
Public Const CELL_DIVORCE As String = "C30"
Public Const CELL_NOTE As String = "C31"
Public Const CELL_SHOW_DIAGRAM As String = "C32"

Public Const CELL_ADDR_CAND As String = "F17"
Public Const CELL_ADDR_TEXT As String = "F18"
Public Const CELL_ADDR_KEY As String = "F19"
Public Const CELL_ADDR_TYPE As String = "F20"
Public Const CELL_ADDR_START As String = "F21"
Public Const CELL_ADDR_END As String = "F22"
Public Const CELL_ADDR_SOURCE As String = "F23"
Public Const CELL_ADDR_NOTE As String = "F24"

Public Const CELL_CONFIG_BASE_DATE As String = "C4"
Public Const CELL_CONFIG_INHERIT_DATE As String = "C5"
Public Const CELL_CONFIG_OUTPUT_MODE As String = "C6"

'W_�l�� columns
Public Const P_ID As Long = 1
Public Const P_ORDER As Long = 2
Public Const P_TYPE As Long = 3
Public Const P_SURNAME As Long = 4
Public Const P_GIVEN As Long = 5
Public Const P_FORMER As Long = 6
Public Const P_DISPLAY As Long = 7
Public Const P_SUR_MODE As Long = 8
Public Const P_SUR_SRC As Long = 9
Public Const P_REL_DEC As Long = 10
Public Const P_REL_DISP As Long = 11
Public Const P_GENDER As Long = 12
Public Const P_BIRTH As Long = 13
Public Const P_DEATH As Long = 14
Public Const P_OCC As Long = 15
Public Const P_REP_ADDR_ID As Long = 16
Public Const P_SHOW As Long = 17
Public Const P_NOTE As Long = 18
Public Const P_STATUS As Long = 19
Public Const P_CREATED As Long = 20
Public Const P_UPDATED As Long = 21

'W_�֌W columns
Public Const R_ID As Long = 1
Public Const R_BASE_ID As Long = 2
Public Const R_OTHER_ID As Long = 3
Public Const R_TYPE As Long = 4
Public Const R_DISPLAY As Long = 5
Public Const R_MARRIAGE As Long = 6
Public Const R_DIVORCE As Long = 7
Public Const R_AUTO As Long = 8
Public Const R_NOTE As Long = 9
Public Const R_STATUS As Long = 10
Public Const R_CREATED As Long = 11
Public Const R_UPDATED As Long = 12

'W_�Z����� columns
Public Const AC_ID As Long = 1
Public Const AC_TEXT As Long = 2
Public Const AC_KEY As Long = 3
Public Const AC_BUILDING As Long = 4
Public Const AC_FIRST_PERSON As Long = 5
Public Const AC_LAST_PERSON As Long = 6
Public Const AC_USE_COUNT As Long = 7
Public Const AC_LAST_USED As Long = 8
Public Const AC_NOTE As Long = 9

'W_�Z������ columns
Public Const A_ID As Long = 1
Public Const A_PERSON_ID As Long = 2
Public Const A_CAND_ID As Long = 3
Public Const A_TYPE As Long = 4
Public Const A_START As Long = 5
Public Const A_END As Long = 6
Public Const A_TEXT As Long = 7
Public Const A_KEY As Long = 8
Public Const A_SOURCE As Long = 9
Public Const A_COPY_PERSON_ID As Long = 10
Public Const A_COPY_ADDR_ID As Long = 11
Public Const A_NOTE As Long = 12
Public Const A_STATUS As Long = 13
Public Const A_CREATED As Long = 14
Public Const A_UPDATED As Long = 15

'W_�C�x���g columns
Public Const E_ID As Long = 1
Public Const E_PERSON_ID As Long = 2
Public Const E_DATE As Long = 3
Public Const E_YEAR As Long = 4
Public Const E_TYPE As Long = 5
Public Const E_CONTENT As Long = 6
Public Const E_AUTO As Long = 7
Public Const E_SOURCE_TYPE As Long = 8
Public Const E_SOURCE_ID As Long = 9
Public Const E_SHOW As Long = 10
Public Const E_NOTE As Long = 11
Public Const E_STATUS As Long = 12

# v10 CHECK NOTES

- Schema: analysis-link-v10
- 候補漏れ対策: ShouldSkipShiftRecord は取引単位の手動除外だけを見る。mMatched による先着候補の自動除外はしない。
- 重複表示対策: mSuppressDuplicateShift は候補生成ではなく、不明入出金の重複表示抑制に限定。
- 高度化: T_住所履歴、年齢、同居推定、相続開始前重点年数、同一住所を分析補助へ追加。
- 重さ対策: 最大組合せ10件、片側候補上限、組合せ生成上限、複数対複数照合上限、最大出力件数を維持。
- 未定義関数: JoinNonBlank / ClipText を追加。

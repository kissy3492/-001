Attribute VB_Name = "modIds"
Option Explicit

Public Function NextId(ByVal kindText As String) As String
    Dim ws As Worksheet, lastR As Long, r As Long
    Dim prefixText As String, num As Long, digits As Long
    Set ws = GetSheet(SH_WORK_ID)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = kindText Then
            prefixText = CellText(ws.Cells(r, 2).Value)
            num = CLng(ws.Cells(r, 3).Value)
            digits = CLng(ws.Cells(r, 4).Value)
            NextId = prefixText & Format$(num, String$(digits, "0"))
            ws.Cells(r, 3).Value = num + 1
            ws.Cells(r, 5).Value = Now
            Exit Function
        End If
    Next r
    Err.Raise vbObjectError + 9401, "NextId", "ID��ʂ�����܂���: " & kindText
End Function

Public Sub ResetAnalysisIds()
    Dim ws As Worksheet
    Set ws = GetSheet(SH_WORK_ID)
    ws.Cells.Clear
    SetRowValues ws.Range("A1"), Array("���", "�ړ���", "���ԍ�", "����", "�ŏI�̔ԓ���")
    FormatHeader ws.Range("A1:E1")
    SetRowValues ws.Range("A2"), Array("���͌��", "AN", 1, 6, "")
    SetRowValues ws.Range("A3"), Array("���͖���", "AD", 1, 6, "")
    SetRowValues ws.Range("A4"), Array("�`�[���", "VR", 1, 6, "")
End Sub

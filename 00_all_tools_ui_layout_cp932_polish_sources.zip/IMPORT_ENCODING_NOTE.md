# VBAインポート時の文字化け対策

このZIP内の `.bas`、`ThisWorkbook_code.txt`、`Sheet_*_code.txt`、`.txt` は、日本語版Excel/VBEへ直接インポートしやすいように CP932（Shift_JIS / Windows-31J）で保存しています。

日本語を削ったわけではありません。MsgBox、コメント、シート名、ボタン名などの日本語は残しています。

PowerShellや一部エディタでUTF-8として開くと文字化けして見える場合がありますが、VBEインポート向けにはCP932が優先です。内容確認だけをする場合は、CP932指定で開いてください。

Attribute VB_Name = "modFinanceIds"
Option Explicit

Public Sub EnsureFinanceLinkSheets()
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = GetOrCreateSheet(SH_WORK_PERSON_REF, False)
    If Len(CellText(ws.Range("A1").Value)) = 0 Then
        SetRowValues ws.Range("A1"), Array("�l��ID", "�����\��", "����", "�l���敪", "���N����", "���S��", "����", "���f�[�^�s")
        FormatOutputHeader ws.Range("A1:H1")
        ws.Columns("A:H").ColumnWidth = 16
        ws.Columns("E:F").NumberFormatLocal = "yyyy/m/d"
    End If

    Set ws = GetOrCreateSheet(SH_WORK_ACCOUNT, False)
    If Len(CellText(ws.Range("A1").Value)) = 0 Then
        SetRowValues ws.Range("A1"), Array("����ID", "�l��ID", "����", "����", "��s��", "�x�X��", "�Ȗ�", "�����ԍ�", "�����ԍ����K��", "�����J�ݓ�", "��������", "�f�[�^���", "�쐬����", "�X�V����")
        FormatOutputHeader ws.Range("A1:N1")
        ws.Columns("A:N").ColumnWidth = 16
        ws.Columns("J:K").NumberFormatLocal = "yyyy/m/d"
        ws.Columns("M:N").NumberFormatLocal = "yyyy/m/d h:mm"
    End If

    Set ws = GetOrCreateSheet(SH_WORK_ID, False)
    If Len(CellText(ws.Range("A1").Value)) = 0 Then
        SetRowValues ws.Range("A1"), Array("���", "�ړ���", "���ԍ�", "����", "�ŏI�̔ԓ���")
        FormatOutputHeader ws.Range("A1:E1")
        SetRowValues ws.Range("A2"), Array("����", "AC", 1, 4, "")
        SetRowValues ws.Range("A3"), Array("���", "TX", 1, 6, "")
        SetRowValues ws.Range("A4"), Array("�c��", "BL", 1, 6, "")
        SetRowValues ws.Range("A5"), Array("�]�L��", "TR", 1, 5, "")
        ws.Columns("A:E").ColumnWidth = 16
        ws.Columns("E:E").NumberFormatLocal = "yyyy/m/d h:mm"
    End If

    Set ws = GetOrCreateSheet(SH_LINK_LOG, False)
    If Len(CellText(ws.Range("A1").Value)) = 0 Then
        SetRowValues ws.Range("A1"), Array("����", "����", "����", "���e")
        FormatOutputHeader ws.Range("A1:D1")
        ws.Columns("A:A").ColumnWidth = 18
        ws.Columns("B:C").ColumnWidth = 16
        ws.Columns("D:D").ColumnWidth = 80
        ws.Columns("A:A").NumberFormatLocal = "yyyy/m/d h:mm"
    End If
    On Error GoTo 0
End Sub


Public Sub ResetFinanceLinkData()
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = GetOrCreateSheet(SH_WORK_ACCOUNT, True)
    SetRowValues ws.Range("A1"), Array("����ID", "�l��ID", "����", "����", "��s��", "�x�X��", "�Ȗ�", "�����ԍ�", "�����ԍ����K��", "�����J�ݓ�", "��������", "�f�[�^���", "�쐬����", "�X�V����")
    FormatOutputHeader ws.Range("A1:N1")
    Set ws = GetOrCreateSheet(SH_WORK_ID, True)
    SetRowValues ws.Range("A1"), Array("���", "�ړ���", "���ԍ�", "����", "�ŏI�̔ԓ���")
    FormatOutputHeader ws.Range("A1:E1")
    SetRowValues ws.Range("A2"), Array("����", "AC", 1, 4, "")
    SetRowValues ws.Range("A3"), Array("���", "TX", 1, 6, "")
    SetRowValues ws.Range("A4"), Array("�c��", "BL", 1, 6, "")
    SetRowValues ws.Range("A5"), Array("�]�L��", "TR", 1, 5, "")
    Set ws = GetOrCreateSheet(SH_LINK_LOG, True)
    SetRowValues ws.Range("A1"), Array("����", "����", "����", "���e")
    FormatOutputHeader ws.Range("A1:D1")
    EnsureFinanceLinkSheets
    On Error GoTo 0
End Sub

Public Function NextManagedId(ByVal typeName As String) As String
    Dim ws As Worksheet, r As Long, lastR As Long
    Dim prefixText As String, nextNo As Long, digits As Long
    EnsureFinanceLinkSheets
    Set ws = GetSheet(SH_WORK_ID)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CellText(ws.Cells(r, 1).Value) = typeName Then
            prefixText = CellText(ws.Cells(r, 2).Value)
            nextNo = CLng(Val(ws.Cells(r, 3).Value))
            digits = CLng(Val(ws.Cells(r, 4).Value))
            If digits <= 0 Then digits = 4
            NextManagedId = prefixText & Format$(nextNo, String$(digits, "0"))
            ws.Cells(r, 3).Value = nextNo + 1
            ws.Cells(r, 5).Value = Now
            Exit Function
        End If
    Next r
    Err.Raise vbObjectError + 8101, "NextManagedId", "ID��ʂ�������܂���: " & typeName
End Function

Public Function NextAccountId() As String
    NextAccountId = NextManagedId("����")
End Function

Public Function NextTransactionId() As String
    NextTransactionId = NextManagedId("���")
End Function

Public Function NextBalanceId() As String
    NextBalanceId = NextManagedId("�c��")
End Function

Public Function NextTransferId() As String
    NextTransferId = NextManagedId("�]�L��")
End Function

Public Function GetOrCreateWorkAccountId(ByVal personId As String, ByVal personName As String, ByVal relationName As String, _
                                         ByVal bankName As String, ByVal branchName As String, ByVal accType As String, _
                                         ByVal accNo As String, ByVal openDate As Variant, ByVal closeDate As Variant) As String
    Dim ws As Worksheet, lastR As Long, r As Long, nr As Long
    Dim normAccNo As String
    EnsureFinanceLinkSheets
    normAccNo = NormalizeAccountHyphen(accNo)
    Set ws = GetSheet(SH_WORK_ACCOUNT)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If CellText(ws.Cells(r, 2).Value) = CellText(personId) And _
           CellText(ws.Cells(r, 5).Value) = CellText(bankName) And _
           CellText(ws.Cells(r, 6).Value) = CellText(branchName) And _
           CellText(ws.Cells(r, 7).Value) = CellText(accType) And _
           CellText(ws.Cells(r, 9).Value) = normAccNo And _
           CellText(ws.Cells(r, 12).Value) <> DATA_STATUS_CANCELLED Then
            GetOrCreateWorkAccountId = CellText(ws.Cells(r, 1).Value)
            ws.Cells(r, 3).Value = personName
            ws.Cells(r, 4).Value = relationName
            ws.Cells(r, 10).ClearContents
            ws.Cells(r, 11).ClearContents
            If IsDate(openDate) Then ws.Cells(r, 10).Value = CDate(openDate)
            If IsDate(closeDate) Then ws.Cells(r, 11).Value = CDate(closeDate)
            ws.Cells(r, 14).Value = Now
            Exit Function
        End If
    Next r

    nr = lastR + 1
    If nr < 2 Then nr = 2
    GetOrCreateWorkAccountId = NextAccountId()
    ws.Cells(nr, 1).Value = GetOrCreateWorkAccountId
    ws.Cells(nr, 2).Value = personId
    ws.Cells(nr, 3).Value = personName
    ws.Cells(nr, 4).Value = relationName
    ws.Cells(nr, 5).Value = bankName
    ws.Cells(nr, 6).Value = branchName
    ws.Cells(nr, 7).Value = accType
    ws.Cells(nr, 8).Value = accNo
    ws.Cells(nr, 9).Value = normAccNo
    If IsDate(openDate) Then ws.Cells(nr, 10).Value = CDate(openDate)
    If IsDate(closeDate) Then ws.Cells(nr, 11).Value = CDate(closeDate)
    ws.Cells(nr, 12).Value = DATA_STATUS_ACTIVE
    ws.Cells(nr, 13).Value = Now
    ws.Cells(nr, 14).Value = Now
End Function

Public Sub RegisterWorkTxMeta(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal personId As String, ByVal accountId As String, _
                              ByVal transactionId As String, ByVal rowKind As String, ByVal transferId As String, _
                              ByVal sourceRow As Long, ByVal inputOrder As Long, ByVal shopFinal As String)
    If ws Is Nothing Or rowNo <= 0 Then Exit Sub
    ws.Cells(rowNo, WORK_TX_COL_PERSON_ID).Value = personId
    ws.Cells(rowNo, WORK_TX_COL_ACCOUNT_ID).Value = accountId
    ws.Cells(rowNo, WORK_TX_COL_TRANSACTION_ID).Value = transactionId
    ws.Cells(rowNo, WORK_TX_COL_ROW_KIND).Value = rowKind
    ws.Cells(rowNo, WORK_TX_COL_TRANSFER_ID).Value = transferId
    If sourceRow > 0 Then ws.Cells(rowNo, WORK_TX_COL_SOURCE_ROW).Value = sourceRow
    If inputOrder > 0 Then ws.Cells(rowNo, WORK_TX_COL_INPUT_ORDER).Value = inputOrder
    ws.Cells(rowNo, WORK_TX_COL_SHOP_FINAL).Value = shopFinal
    ws.Cells(rowNo, WORK_TX_COL_DATA_STATUS).Value = DATA_STATUS_ACTIVE
    ws.Cells(rowNo, WORK_TX_COL_TRANSFERRED_AT).Value = Now
End Sub

Public Sub RegisterWorkBalMeta(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal personId As String, ByVal accountId As String, _
                               ByVal balanceId As String, ByVal transferId As String)
    If ws Is Nothing Or rowNo <= 0 Then Exit Sub
    ws.Cells(rowNo, WORK_BAL_COL_PERSON_ID).Value = personId
    ws.Cells(rowNo, WORK_BAL_COL_ACCOUNT_ID).Value = accountId
    ws.Cells(rowNo, WORK_BAL_COL_BALANCE_ID).Value = balanceId
    ws.Cells(rowNo, WORK_BAL_COL_TRANSFER_ID).Value = transferId
    ws.Cells(rowNo, WORK_BAL_COL_DATA_STATUS).Value = DATA_STATUS_ACTIVE
    ws.Cells(rowNo, WORK_BAL_COL_TRANSFERRED_AT).Value = Now
End Sub

Public Sub AppendLinkLog(ByVal processName As String, ByVal resultText As String, ByVal detailText As String)
    Dim ws As Worksheet, nr As Long
    On Error Resume Next
    EnsureFinanceLinkSheets
    Set ws = GetSheet(SH_LINK_LOG)
    nr = LastRow(ws, 1) + 1
    If nr < 2 Then nr = 2
    ws.Cells(nr, 1).Value = Now
    ws.Cells(nr, 2).Value = processName
    ws.Cells(nr, 3).Value = resultText
    ws.Cells(nr, 4).Value = detailText
    On Error GoTo 0
End Sub

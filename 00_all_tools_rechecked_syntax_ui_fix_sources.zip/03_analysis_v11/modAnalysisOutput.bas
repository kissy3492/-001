Attribute VB_Name = "modAnalysisOutput"
Option Explicit

' v8: �l�Ԃ��둀�삵�Ȃ����͌��ʉ�ʁB�_�u���N���b�N�ؑցE�����ҏW�E�ĕ��͂����S������B
' �\����� A:M �ɏW�񂵁A�A�g�E�ĕ��͂ɕK�v�Ȑ��f�[�^�� AA:AV �ɔ�\���ێ�����B
Private Const VIEW_HEADER_ROW As Long = 7
Private Const VIEW_FIRST_DATA_ROW As Long = 8
Private Const VIEW_COL_ID As Long = 1
Private Const VIEW_COL_KIND As Long = 2
Private Const VIEW_COL_VOUCHER As Long = 3
Private Const VIEW_COL_DECISION As Long = 4
Private Const VIEW_COL_PATTERN As Long = 5
Private Const VIEW_COL_AMOUNT As Long = 6
Private Const VIEW_COL_DIFF As Long = 7
Private Const VIEW_COL_DATES As Long = 8
Private Const VIEW_COL_OUT_PERSON As Long = 9
Private Const VIEW_COL_IN_PERSON As Long = 10
Private Const VIEW_COL_RELATION As Long = 11
Private Const VIEW_COL_SUMMARY As Long = 12
Private Const VIEW_COL_MEMO As Long = 13
Private Const VIEW_LAST_COL As Long = 13
Private Const RAW_START_COL As Long = 27 ' AA

Public Sub BuildAnalysisResultSheet()
    Dim src As Worksheet, dst As Worksheet
    Dim lastR As Long, viewLastR As Long, r As Long, outR As Long
    Set src = GetSheet(SH_WORK_RESULT)
    Set dst = GetSheet(SH_RESULT)

    On Error Resume Next
    dst.Unprotect Password:=TOOL_PASSWORD
    dst.ScrollArea = ""
    dst.Cells.EntireColumn.Hidden = False
    dst.Cells.UnMerge
    dst.Cells.Clear
    DeleteAllShapes dst
    On Error GoTo 0

    lastR = LastRow(src, 1)
    If lastR < 1 Then lastR = 1
    viewLastR = VIEW_HEADER_ROW + lastR - 1

    BuildResultTopArea dst
    BuildCompactHeaders dst

    ' ���f�[�^�͔�\����ɕێ��B�A�g�ۑ��E�蓮���O�E�ĕ��͂Ŏg���B
    dst.Range(dst.Cells(VIEW_HEADER_ROW, RAW_START_COL), dst.Cells(viewLastR, RAW_START_COL + RES_LAST_COL - 1)).Value = _
        src.Range(src.Cells(1, 1), src.Cells(lastR, RES_LAST_COL)).Value

    If lastR >= 2 Then
        For r = 2 To lastR
            outR = VIEW_HEADER_ROW + r - 1
            WriteCompactResultRow dst, src, r, outR
        Next r
        FormatBody dst.Range(dst.Cells(VIEW_FIRST_DATA_ROW, 1), dst.Cells(viewLastR, VIEW_LAST_COL))
        dst.Range(dst.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_DIFF), dst.Cells(viewLastR, VIEW_COL_DIFF)).NumberFormatLocal = "#,##0"
        ColorResultRows dst, viewLastR
        PrepareManualEditing dst, viewLastR
        BuildResultSummaryCards dst, viewLastR
    Else
        BuildResultSummaryCards dst, VIEW_HEADER_ROW
    End If

    dst.Range(dst.Cells(VIEW_HEADER_ROW, 1), dst.Cells(viewLastR, VIEW_LAST_COL)).AutoFilter
    ApplyCompactResultLayout dst, viewLastR
    ThemeApplyPrintTable dst.Range(dst.Cells(VIEW_HEADER_ROW, 1), dst.Cells(viewLastR, VIEW_LAST_COL)), 1
    ThemeCapRowHeights dst.Range(dst.Cells(VIEW_FIRST_DATA_ROW, 1), dst.Cells(viewLastR, VIEW_LAST_COL)), 24, 84
    ThemeApplyMonochromePrint dst, dst.Range(dst.Cells(1, 1), dst.Cells(viewLastR, VIEW_LAST_COL)).Address, True, "$7:$7", 1, 0
    AddResultSheetControls dst
    ThemeMarkMacroButtonsNonPrintable dst

    dst.Activate
    ActiveWindow.FreezePanes = False
    dst.Range("A" & CStr(VIEW_FIRST_DATA_ROW)).Select
    ActiveWindow.FreezePanes = True
    ActiveWindow.Zoom = 90

    ProtectOutputSheet dst
End Sub

Private Sub BuildResultTopArea(ByVal ws As Worksheet)
    ws.Range("A1:O1").Merge
    ws.Range("A1").Value = "03_�����ړ����̓c�[���b���͌���"
    With ws.Range("A1")
        .Interior.Color = ThemeColor("title")
        .Font.Color = vbWhite
        .Font.Bold = True
        .Font.Size = 17
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With
    ws.Rows(1).RowHeight = 34

    ws.Range("A2:G4").Merge
    ws.Range("A2").Value = "���͌��ʂ͔��f�ɕK�v�ȍ��ڂ����������ɏW�񂵂Ă��܂��B" & vbCrLf & _
                           "C��̓_�u���N���b�N�œ`�[�v�ۂ�ؑցBD��͍̗p����⏜�O��������O���z�A�܂��̓h���b�v�_�E���ŕύX�ł��܂��BM�񃁃��͒��ړ��͉B�ĕ��͌���������L�[�Ȃ�蓮���f���ێ����܂��B"
    With ws.Range("A2")
        .Interior.Color = ThemeColor("section")
        .Font.Color = ThemeColor("header")
        .Font.Bold = True
        .WrapText = True
        .VerticalAlignment = xlCenter
    End With

    ws.Range("H2:I4").Merge
    ws.Range("J2:K4").Merge
    ws.Range("L2:M4").Merge
    FormatMiniCard ws.Range("H2"), "�`�[�˗� �v", ThemeColor("red")
    FormatMiniCard ws.Range("J2"), "���O�w��", ThemeColor("muted")
    FormatMiniCard ws.Range("L2"), "��␔", ThemeColor("header")
    ws.Rows("2:4").RowHeight = 22
End Sub

Private Sub FormatMiniCard(ByVal cell As Range, ByVal titleText As String, ByVal fillColor As Long)
    cell.Value = titleText & vbCrLf & "-"
    With cell
        .Interior.Color = fillColor
        .Font.Color = vbWhite
        .Font.Bold = True
        .Font.Size = 11
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
End Sub

Private Sub BuildResultSummaryCards(ByVal ws As Worksheet, ByVal viewLastR As Long)
    Dim nTotal As Long, nVoucher As Long, nExclude As Long
    If viewLastR >= VIEW_FIRST_DATA_ROW Then
        nTotal = Application.WorksheetFunction.CountA(ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_ID), ws.Cells(viewLastR, VIEW_COL_ID)))
        nVoucher = Application.WorksheetFunction.CountIf(ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_VOUCHER), ws.Cells(viewLastR, VIEW_COL_VOUCHER)), VOUCHER_YES)
        Dim rr As Long
        For rr = VIEW_FIRST_DATA_ROW To viewLastR
            If IsExcludeDecision(CellText(ws.Cells(rr, VIEW_COL_DECISION).Value)) Then nExclude = nExclude + 1
        Next rr
    End If
    ws.Range("H2").Value = "�`�[�˗� �v" & vbCrLf & CStr(nVoucher)
    ws.Range("J2").Value = "���O�w��" & vbCrLf & CStr(nExclude)
    ws.Range("L2").Value = "��␔" & vbCrLf & CStr(nTotal)
End Sub

Private Sub BuildCompactHeaders(ByVal ws As Worksheet)
    SetRowValues ws.Cells(VIEW_HEADER_ROW, 1), Array("���ID", "�敪", "�`�[", "���f", "�g����/�M���x", "���z", "���z", "���t", "�o����", "������", "�֌W/�N��", "�v�_/�Z��", "����")
    FormatHeader ws.Range(ws.Cells(VIEW_HEADER_ROW, 1), ws.Cells(VIEW_HEADER_ROW, VIEW_LAST_COL)), ThemeColor("header")
    ws.Rows(VIEW_HEADER_ROW).RowHeight = 27
End Sub

Private Sub WriteCompactResultRow(ByVal dst As Worksheet, ByVal src As Worksheet, ByVal srcRow As Long, ByVal outR As Long)
    Dim outAmt As Variant, inAmt As Variant, diffVal As Variant, relationText As String
    outAmt = src.Cells(srcRow, RES_COL_OUT_AMOUNT).Value
    inAmt = src.Cells(srcRow, RES_COL_IN_AMOUNT).Value
    diffVal = src.Cells(srcRow, RES_COL_DIFF).Value
    relationText = JoinNonBlank(CellText(src.Cells(srcRow, RES_COL_NAME_REL).Value), CellText(src.Cells(srcRow, RES_COL_INH_TIMING).Value), vbLf)
    If Len(CellText(src.Cells(srcRow, RES_COL_COHAB).Value)) > 0 Then relationText = JoinNonBlank(relationText, CellText(src.Cells(srcRow, RES_COL_COHAB).Value), vbLf)
    If Len(CellText(src.Cells(srcRow, RES_COL_AGE_HINT).Value)) > 0 Then relationText = JoinNonBlank(relationText, CellText(src.Cells(srcRow, RES_COL_AGE_HINT).Value), vbLf)

    dst.Cells(outR, VIEW_COL_ID).Value = src.Cells(srcRow, RES_COL_ID).Value
    dst.Cells(outR, VIEW_COL_KIND).Value = src.Cells(srcRow, RES_COL_KIND).Value
    dst.Cells(outR, VIEW_COL_VOUCHER).Value = src.Cells(srcRow, RES_COL_VOUCHER).Value
    dst.Cells(outR, VIEW_COL_DECISION).Value = src.Cells(srcRow, RES_COL_SHIFT_DECISION).Value
    dst.Cells(outR, VIEW_COL_PATTERN).Value = CellText(src.Cells(srcRow, RES_COL_PATTERN).Value) & vbLf & "�M���x " & CellText(src.Cells(srcRow, RES_COL_SCORE).Value) & "�_"
    dst.Cells(outR, VIEW_COL_AMOUNT).Value = "�o " & FormatNumberText(outAmt) & vbCrLf & "�� " & FormatNumberText(inAmt)
    dst.Cells(outR, VIEW_COL_DIFF).Value = diffVal
    dst.Cells(outR, VIEW_COL_DATES).Value = "�o " & CellText(src.Cells(srcRow, RES_COL_OUT_DATE).Value) & vbCrLf & "�� " & CellText(src.Cells(srcRow, RES_COL_IN_DATE).Value)
    dst.Cells(outR, VIEW_COL_OUT_PERSON).Value = CellText(src.Cells(srcRow, RES_COL_OUT_PERSON).Value)
    dst.Cells(outR, VIEW_COL_IN_PERSON).Value = CellText(src.Cells(srcRow, RES_COL_IN_PERSON).Value)
    dst.Cells(outR, VIEW_COL_RELATION).Value = relationText
    dst.Cells(outR, VIEW_COL_SUMMARY).Value = JoinNonBlank( _
        CellText(src.Cells(srcRow, RES_COL_SHOPS).Value), _
        CellText(src.Cells(srcRow, RES_COL_SUMMARY).Value), vbLf)
    If Len(CellText(src.Cells(srcRow, RES_COL_ADDRESS_HINT).Value)) > 0 Then
        dst.Cells(outR, VIEW_COL_SUMMARY).Value = JoinNonBlank( _
            CellText(dst.Cells(outR, VIEW_COL_SUMMARY).Value), _
            CellText(src.Cells(srcRow, RES_COL_ADDRESS_HINT).Value), vbLf)
    End If
    dst.Cells(outR, VIEW_COL_MEMO).Value = src.Cells(srcRow, RES_COL_OPERATION_MEMO).Value
End Sub

Private Function FormatNumberText(ByVal v As Variant) As String
    If IsNumeric(v) Then
        FormatNumberText = Format$(CDbl(v), "#,##0")
    Else
        FormatNumberText = CellText(v)
    End If
End Function

Private Sub ApplyCompactResultLayout(ByVal ws As Worksheet, ByVal viewLastR As Long)
    ws.Columns("A:A").ColumnWidth = 10
    ws.Columns("B:B").ColumnWidth = 13
    ws.Columns("C:D").ColumnWidth = 8
    ws.Columns("E:E").ColumnWidth = 9
    ws.Columns("F:F").ColumnWidth = 14
    ws.Columns("G:G").ColumnWidth = 10
    ws.Columns("H:H").ColumnWidth = 15
    ws.Columns("I:J").ColumnWidth = 15
    ws.Columns("K:K").ColumnWidth = 15
    ws.Columns("L:L").ColumnWidth = 29
    ws.Columns("M:M").ColumnWidth = 17
    ws.Range(ws.Cells(1, 1), ws.Cells(Application.Max(viewLastR, VIEW_FIRST_DATA_ROW), VIEW_LAST_COL)).WrapText = True
    ws.Range(ws.Cells(1, 1), ws.Cells(Application.Max(viewLastR, VIEW_FIRST_DATA_ROW), VIEW_LAST_COL)).VerticalAlignment = xlCenter
    If viewLastR >= VIEW_FIRST_DATA_ROW Then ws.Rows(CStr(VIEW_FIRST_DATA_ROW) & ":" & CStr(viewLastR)).RowHeight = 46
    ws.Columns("N:XFD").Hidden = True
    ws.ScrollArea = "A1:M" & CStr(Application.Max(200, viewLastR + 20))
End Sub

Private Sub AddResultSheetControls(ByVal ws As Worksheet)
    AddResultButton ws, "�ĕ���", "ReAnalyzeFromResultSheet", ws.Range("A5"), ThemeColor("orange")
    AddResultButton ws, "�ύX���f", "ApplyManualEditsFromResultSheet", ws.Range("C5"), ThemeColor("red")
    AddResultButton ws, "���ʕۑ�", "SaveAnalysisToCommonData", ws.Range("E5"), ThemeColor("teal")
    AddResultButton ws, "���O����", "ClearManualExclusions", ws.Range("G5"), ThemeColor("muted")
    AddResultButton ws, "������", "ShowMainSheet", ws.Range("I5"), ThemeColor("header")
    AddResultButton ws, "�ŏI�o��", "ExportAnalysisWorkbook", ws.Range("K5"), ThemeColor("purple")
    AddResultButton ws, "�s���o���ǐ�", "TraceSelectedUnknownOutToLaterUnknownIns", ws.Range("M5"), ThemeColor("purple")
End Sub

Private Sub AddResultButton(ByVal ws As Worksheet, ByVal caption As String, ByVal macroName As String, ByVal anchor As Range, ByVal fillColor As Long)
    Dim shp As Shape
    Dim target As Range
    Const M As Double = 2
    Set target = ws.Range(anchor, anchor.Offset(0, 1))
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, target.Left + M, target.Top + M, target.Width - M * 2, Application.Max(22, target.Height - M * 2))
    shp.Name = "btn_result_" & macroName
    ThemeStyleButtonShapeWithColor shp, caption, fillColor, fillColor, ThemeReadableFontColor(fillColor), macroName
End Sub

Private Sub PrepareManualEditing(ByVal ws As Worksheet, ByVal viewLastR As Long)
    On Error Resume Next
    ws.Cells.Locked = True
    With ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_VOUCHER), ws.Cells(viewLastR, VIEW_COL_VOUCHER))
        .Locked = False
        .Interior.Color = ThemeColor("warning-soft")
        .Validation.Delete
        .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:=VOUCHER_YES & "," & VOUCHER_NO
        .Validation.IgnoreBlank = True
        .Validation.InCellDropdown = True
    End With
    With ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_DECISION), ws.Cells(viewLastR, VIEW_COL_DECISION))
        .Locked = False
        .Interior.Color = ThemeColor("success-bg")
        .Validation.Delete
        .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:=DECISION_USE & "," & DECISION_EXCLUDE & "," & DECISION_TX_EXCLUDE
        .Validation.IgnoreBlank = True
        .Validation.InCellDropdown = True
    End With
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_VOUCHER).Interior.Color = ThemeColor("red")
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_VOUCHER).Font.Color = vbWhite
    With ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_MEMO), ws.Cells(viewLastR, VIEW_COL_MEMO))
        .Locked = False
        .Interior.Color = vbWhite
        .Validation.Delete
    End With
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_DECISION).Interior.Color = ThemeColor("green")
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_DECISION).Font.Color = vbWhite
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_MEMO).Interior.Color = ThemeColor("muted-strong")
    ws.Cells(VIEW_HEADER_ROW, VIEW_COL_MEMO).Font.Color = vbWhite
    On Error GoTo 0
End Sub

Public Sub HandleAnalysisResultSelectionChange(ByVal Target As Range)
    Dim ws As Worksheet, msg As String, r As Long
    If Target Is Nothing Then Exit Sub
    If Target.Worksheet.Name <> SH_RESULT Then Exit Sub
    If Target.Cells.CountLarge > 1 Then Exit Sub
    Set ws = Target.Worksheet
    r = Target.Row
    If r < VIEW_FIRST_DATA_ROW Then
        Application.StatusBar = "���͌��ʂł��BC��=�`�[�AD��=�̗p���f�AM��=������ҏW�ł��܂��B���f�͑����ۑ�����܂��B"
        Exit Sub
    End If
    If Len(CellText(ws.Cells(r, VIEW_COL_ID).Value)) = 0 Then Exit Sub
    Select Case Target.Column
        Case VIEW_COL_VOUCHER
            msg = "�`�[�v�ۂł��B�v/�s�v��I�ԂƁA�`�[�˗����֑������f���܂��B"
        Case VIEW_COL_DECISION
            msg = "�̗p���f�ł��B�ʏ�͌�⏜�O���g���A������O�͍ĕ��͂���O���������T�d�Ɏg���܂��B"
        Case VIEW_COL_MEMO
            msg = "�������ł��B���f���R�E�m�F�ώ����������ƁA�ĕ��͌���ێ�����܂��B"
        Case VIEW_COL_KIND
            msg = "���ނł��B�s���o���s��I��ŕs���o���ǐՂ����s�ł��܂��B"
        Case VIEW_COL_SUMMARY
            msg = "�����v��ł��B�戵�X�A�������A�Z���E�N��E�c���}�ςȂǂ̔��f�ޗ����m�F���܂��B"
        Case VIEW_COL_DATES
            msg = "�o�����E�������ł��B�����őo���Ɏ���������ꍇ�͏o���������̏��������܂��B"
        Case Else
            msg = "���͌��s�ł��BC��ED��EM�񂾂���ҏW���A�ڍׂ͕��͖��ׂ�_�_�T�}���Ŋm�F���܂��B"
    End Select
    Application.StatusBar = msg
End Sub

Public Sub HandleAnalysisResultChange(ByVal Target As Range)
    '�h���b�v�_�E���⃁���̎���͂��A���̏�œ�����Ԃ֔��f����B
    '�u�ύX���f�v�{�^���������Y��Ă��A�ĕ��́E���ʕۑ��Ŕ��f���߂�Ȃ��悤�ɂ���B
    Static handling As Boolean
    Dim ws As Worksheet, watch As Range, hit As Range, cell As Range
    Dim lastR As Long, r As Long, voucherText As String, decisionText As String
    Dim prevEvents As Boolean
    If handling Then Exit Sub
    If Target Is Nothing Then Exit Sub
    If Target.Worksheet.Name <> SH_RESULT Then Exit Sub
    Set ws = Target.Worksheet
    lastR = LastRow(ws, VIEW_COL_ID)
    If lastR < VIEW_FIRST_DATA_ROW Then Exit Sub
    Set watch = Union(ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_VOUCHER), ws.Cells(lastR, VIEW_COL_VOUCHER)), _
                      ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_DECISION), ws.Cells(lastR, VIEW_COL_DECISION)), _
                      ws.Range(ws.Cells(VIEW_FIRST_DATA_ROW, VIEW_COL_MEMO), ws.Cells(lastR, VIEW_COL_MEMO)))
    Set hit = Intersect(Target, watch)
    If hit Is Nothing Then Exit Sub

    handling = True
    prevEvents = Application.EnableEvents
    On Error GoTo SafeExit
    Application.EnableEvents = False
    ws.Unprotect Password:=TOOL_PASSWORD

    For Each cell In hit.Cells
        r = cell.Row
        If Len(CellText(ws.Cells(r, VIEW_COL_ID).Value)) > 0 Then
            If cell.Column = VIEW_COL_VOUCHER Then
                voucherText = CellText(cell.Value)
                If voucherText <> VOUCHER_YES Then voucherText = VOUCHER_NO
                cell.Value = voucherText
                ws.Cells(r, RAW_START_COL + RES_COL_VOUCHER - 1).Value = voucherText
            ElseIf cell.Column = VIEW_COL_DECISION Then
                decisionText = NormalizeDecisionText(CellText(cell.Value))
                If Len(decisionText) = 0 Then decisionText = DECISION_USE
                cell.Value = decisionText
                If IsExcludeDecision(decisionText) Then
                    ws.Cells(r, VIEW_COL_VOUCHER).Value = VOUCHER_NO
                    ws.Cells(r, RAW_START_COL + RES_COL_VOUCHER - 1).Value = VOUCHER_NO
                End If
                ws.Cells(r, RAW_START_COL + RES_COL_SHIFT_DECISION - 1).Value = decisionText
                ws.Cells(r, RAW_START_COL + RES_COL_OPERATION_MEMO - 1).Value = ws.Cells(r, VIEW_COL_MEMO).Value
            ElseIf cell.Column = VIEW_COL_MEMO Then
                ws.Cells(r, RAW_START_COL + RES_COL_OPERATION_MEMO - 1).Value = cell.Value
            End If
        End If
    Next cell

    ColorResultRows ws, lastR
    PersistManualStateFromResultSheet True
    SyncVoucherFlagsFromResultSheet True
    BuildResultSummaryCards ws, lastR
SafeExit:
    ProtectOutputSheet ws
    Application.EnableEvents = prevEvents
    handling = False
End Sub

Public Sub ApplyVoucherFlagsFromResultSheet()
    ApplyManualEditsFromResultSheet
End Sub

Public Sub ApplyManualEditsFromResultSheet()
    If Not SheetExists(SH_RESULT) Then Exit Sub
    On Error GoTo EH
    AppBegin "�蓮�ύX�𔽉f��..."
    PersistManualStateFromResultSheet True
    SyncVoucherFlagsFromResultSheet False
    ApplyManualExclusionsFromResultSheet True
    BuildDetailOutputSheet
    BuildFlaggedTransactionSheet
    AppEnd
    MsgBox "���͌��ʃV�[�g�̎蓮�ύX�𖾍ׁE���͍ϕ\�֔��f���܂����B", vbInformation
    Exit Sub
EH:
    AppEnd
    MsgBox "�蓮�ύX���f���ɃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation
End Sub

Public Sub ReAnalyzeFromResultSheet()
    If SheetExists(SH_RESULT) Then
        PersistManualStateFromResultSheet True
        ApplyManualExclusionsFromResultSheet False
    End If
    RunAnalysis
End Sub

Public Sub ShowMainSheet()
    If SheetExists(SH_MAIN) Then
        GetSheet(SH_MAIN).Visible = xlSheetVisible
        GetSheet(SH_MAIN).Activate
    End If
End Sub

Public Sub ClearManualExclusions()
    If MsgBox("�蓮���O�������ID�ƁA���̏��O���f���������܂��B" & vbCrLf & _
              "�`�[�˗��̎蓮�ύX�⃁���͂ł��邾���ێ����܂��B��낵���ł����B", vbQuestion + vbYesNo) <> vbYes Then Exit Sub
    InitManualExcludeHeaders GetSheet(SH_MANUAL_EXCLUDE)
    ClearExcludeDecisionsInManualState
    AppendLog "�蓮���O����", "����", "W_�蓮���O�����������AW_�蓮�����̏��O���f���̗p�֖߂��܂���"
    MsgBox "�蓮���O���������܂����B�ĕ��͂���Ə��O�����ēx�܂߂Ċm�F�ł��܂��B", vbInformation
End Sub

Private Sub ClearExcludeDecisionsInManualState()
    Dim ws As Worksheet, lastR As Long, r As Long
    If Not SheetExists(SH_MANUAL_STATE) Then Exit Sub
    Set ws = GetSheet(SH_MANUAL_STATE)
    lastR = LastRow(ws, 1)
    For r = 2 To lastR
        If IsExcludeDecision(CellText(ws.Cells(r, 4).Value)) Then
            ws.Cells(r, 4).Value = DECISION_USE
            If Len(CellText(ws.Cells(r, 5).Value)) = 0 Or InStr(CellText(ws.Cells(r, 5).Value), "���O") > 0 Then
                ws.Cells(r, 5).Value = "���O�����ς�"
            End If
            ws.Cells(r, 6).Value = Now
        End If
    Next r
End Sub


Public Sub PersistManualStateFromResultSheet(Optional ByVal silent As Boolean = True)
    Dim ws As Worksheet, st As Worksheet, lastR As Long, r As Long, outR As Long
    Dim keyText As String, outIds As String, inIds As String, patternText As String
    If Not SheetExists(SH_RESULT) Then Exit Sub
    Set ws = GetSheet(SH_RESULT)
    Set st = GetSheet(SH_MANUAL_STATE)
    InitManualStateHeaders st
    lastR = LastRow(ws, VIEW_COL_ID)
    outR = 2
    For r = VIEW_FIRST_DATA_ROW To lastR
        If Len(CellText(ws.Cells(r, VIEW_COL_ID).Value)) > 0 Then
            patternText = CellText(ws.Cells(r, RAW_START_COL + RES_COL_PATTERN - 1).Value)
            outIds = CellText(ws.Cells(r, RAW_START_COL + RES_COL_OUT_IDS - 1).Value)
            inIds = CellText(ws.Cells(r, RAW_START_COL + RES_COL_IN_IDS - 1).Value)
            keyText = BuildAnalysisStateKey(patternText, outIds, inIds)
            st.Cells(outR, 1).Value = keyText
            st.Cells(outR, 2).Value = ws.Cells(r, VIEW_COL_ID).Value
            st.Cells(outR, 3).Value = ws.Cells(r, VIEW_COL_VOUCHER).Value
            st.Cells(outR, 4).Value = ws.Cells(r, VIEW_COL_DECISION).Value
            st.Cells(outR, 5).Value = ws.Cells(r, VIEW_COL_MEMO).Value
            st.Cells(outR, 6).Value = Now
            outR = outR + 1
        End If
    Next r
    If Not silent Then AppendLog "�蓮�����ۑ�", "����", "W_�蓮�����֕ۑ�"
End Sub

Public Sub SyncVoucherFlagsFromResultSheet(Optional ByVal silent As Boolean = True)
    Dim wsResult As Worksheet, wsWork As Worksheet, wsDetail As Worksheet
    Dim lastR As Long, r As Long, idText As String, voucherText As String, decisionText As String, found As Range
    If Not SheetExists(SH_RESULT) Then Exit Sub
    Set wsResult = GetSheet(SH_RESULT)
    Set wsWork = GetSheet(SH_WORK_RESULT)
    Set wsDetail = GetSheet(SH_WORK_DETAIL)
    lastR = LastRow(wsResult, VIEW_COL_ID)
    For r = VIEW_FIRST_DATA_ROW To lastR
        idText = CellText(wsResult.Cells(r, VIEW_COL_ID).Value)
        voucherText = CellText(wsResult.Cells(r, VIEW_COL_VOUCHER).Value)
        decisionText = CellText(wsResult.Cells(r, VIEW_COL_DECISION).Value)
        If IsExcludeDecision(decisionText) Then voucherText = VOUCHER_NO
        If voucherText <> VOUCHER_YES Then voucherText = VOUCHER_NO
        If Len(idText) > 0 Then
            Set found = wsWork.Columns(RES_COL_ID).Find(What:=idText, LookIn:=xlValues, LookAt:=xlWhole)
            If Not found Is Nothing Then
                wsWork.Cells(found.Row, RES_COL_VOUCHER).Value = voucherText
                wsWork.Cells(found.Row, RES_COL_SHIFT_DECISION).Value = decisionText
                wsWork.Cells(found.Row, RES_COL_OPERATION_MEMO).Value = CellText(wsResult.Cells(r, VIEW_COL_MEMO).Value)
            End If
            ApplyVoucherToDetail wsDetail, idText, voucherText
        End If
    Next r
    If Not silent Then AppendLog "�`�[�˗��t���O���f", "����", "���͌��ʃV�[�g���甽�f"
End Sub

Private Sub ApplyVoucherToDetail(ByVal wsDetail As Worksheet, ByVal analysisId As String, ByVal voucherText As String)
    Dim lastR As Long, r As Long
    lastR = LastRow(wsDetail, DET_COL_ID)
    For r = 2 To lastR
        If CellText(wsDetail.Cells(r, DET_COL_ANALYSIS_ID).Value) = analysisId Then wsDetail.Cells(r, DET_COL_VOUCHER).Value = voucherText
    Next r
End Sub

Private Sub ColorResultRows(ByVal ws As Worksheet, ByVal viewLastR As Long)
    Dim r As Long, kindText As String, colorValue As Long
    For r = VIEW_FIRST_DATA_ROW To viewLastR
        kindText = CellText(ws.Cells(r, VIEW_COL_KIND).Value)
        Select Case kindText
            Case KIND_SHIFT
                colorValue = ThemeColor("info-soft")
            Case KIND_INHERITANCE_SHIFT
                colorValue = ThemeColor("purple-soft")
            Case KIND_UNKNOWN_IN
                colorValue = ThemeColor("warning-soft")
            Case KIND_UNKNOWN_OUT
                colorValue = ThemeColor("orange-soft")
            Case Else
                colorValue = ThemeColor("locked")
        End Select
        ws.Range(ws.Cells(r, 1), ws.Cells(r, VIEW_LAST_COL)).Interior.Color = colorValue
        If IsTxExcludeDecision(CellText(ws.Cells(r, VIEW_COL_DECISION).Value)) Then
            ws.Range(ws.Cells(r, 1), ws.Cells(r, VIEW_LAST_COL)).Interior.Color = ThemeColor("locked")
            ws.Cells(r, VIEW_COL_DECISION).Interior.Color = ThemeColor("warning-text")
            ws.Cells(r, VIEW_COL_DECISION).Font.Color = vbWhite
            ws.Cells(r, VIEW_COL_DECISION).Font.Bold = True
        ElseIf IsExcludeDecision(CellText(ws.Cells(r, VIEW_COL_DECISION).Value)) Then
            ws.Range(ws.Cells(r, 1), ws.Cells(r, VIEW_LAST_COL)).Interior.Color = ThemeColor("locked")
            ws.Cells(r, VIEW_COL_DECISION).Interior.Color = ThemeColor("muted")
            ws.Cells(r, VIEW_COL_DECISION).Font.Color = vbWhite
            ws.Cells(r, VIEW_COL_DECISION).Font.Bold = True
        Else
            ws.Cells(r, VIEW_COL_DECISION).Interior.Color = ThemeColor("success-bg")
            ws.Cells(r, VIEW_COL_DECISION).Font.Color = ThemeColor("success-text")
        End If
        If CellText(ws.Cells(r, VIEW_COL_VOUCHER).Value) = VOUCHER_YES Then
            ws.Cells(r, VIEW_COL_VOUCHER).Interior.Color = ThemeColor("red")
            ws.Cells(r, VIEW_COL_VOUCHER).Font.Color = vbWhite
            ws.Cells(r, VIEW_COL_VOUCHER).Font.Bold = True
        Else
            ws.Cells(r, VIEW_COL_VOUCHER).Interior.Color = ThemeColor("warning-soft")
            ws.Cells(r, VIEW_COL_VOUCHER).Font.Color = ThemeColor("muted")
            ws.Cells(r, VIEW_COL_VOUCHER).Font.Bold = False
        End If
    Next r
End Sub

Public Sub HandleAnalysisResultDoubleClick(ByVal Target As Range, ByRef Cancel As Boolean)
    If Target Is Nothing Then Exit Sub
    If Target.CountLarge <> 1 Then Exit Sub
    If Target.Row < VIEW_FIRST_DATA_ROW Then Exit Sub
    If Target.Column <> VIEW_COL_VOUCHER And Target.Column <> VIEW_COL_DECISION Then Exit Sub
    If CellText(GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_ID).Value) = "" Then Exit Sub
    Cancel = True
    Dim prevEvents As Boolean
    prevEvents = Application.EnableEvents
    On Error GoTo SafeExit
    Application.EnableEvents = False
    GetSheet(SH_RESULT).Unprotect Password:=TOOL_PASSWORD
    If Target.Column = VIEW_COL_VOUCHER Then
        If CellText(Target.Value) = VOUCHER_YES Then
            Target.Value = VOUCHER_NO
            Target.Interior.Color = ThemeColor("warning-soft")
            Target.Font.Color = ThemeColor("muted")
            Target.Font.Bold = False
        Else
            Target.Value = VOUCHER_YES
            Target.Interior.Color = ThemeColor("red")
            Target.Font.Color = vbWhite
            Target.Font.Bold = True
        End If
        GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_VOUCHER - 1).Value = Target.Value
    ElseIf Target.Column = VIEW_COL_DECISION Then
        Select Case NormalizeDecisionText(CellText(Target.Value))
            Case DECISION_USE
                Target.Value = DECISION_EXCLUDE
                Target.Interior.Color = ThemeColor("muted")
                Target.Font.Color = vbWhite
                Target.Font.Bold = True
                GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_MEMO).Value = "��⏜�O�B�ĕ��͌�����̑g�������������O���A������̂͑����Ɏg���܂��B"
                With GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_VOUCHER)
                    .Value = VOUCHER_NO
                    .Interior.Color = ThemeColor("warning-soft")
                    .Font.Color = ThemeColor("muted")
                    .Font.Bold = False
                End With
                GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_VOUCHER - 1).Value = VOUCHER_NO
            Case DECISION_EXCLUDE
                Target.Value = DECISION_TX_EXCLUDE
                Target.Interior.Color = ThemeColor("warning-text")
                Target.Font.Color = vbWhite
                Target.Font.Bold = True
                GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_MEMO).Value = "������O�B�ĕ��͂ł��̌��Ɋ܂܂����ID���V�t�g��₩��O���܂��B"
                With GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_VOUCHER)
                    .Value = VOUCHER_NO
                    .Interior.Color = ThemeColor("warning-soft")
                    .Font.Color = ThemeColor("muted")
                    .Font.Bold = False
                End With
                GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_VOUCHER - 1).Value = VOUCHER_NO
            Case Else
                Target.Value = DECISION_USE
                Target.Interior.Color = ThemeColor("success-bg")
                Target.Font.Color = ThemeColor("success-text")
                Target.Font.Bold = False
                GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_MEMO).Value = "�̗p�ɖ߂��܂����B������O��߂��ꍇ�͏��O�������m�F���Ă��������B"
        End Select
        GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_SHIFT_DECISION - 1).Value = Target.Value
        GetSheet(SH_RESULT).Cells(Target.Row, RAW_START_COL + RES_COL_OPERATION_MEMO - 1).Value = GetSheet(SH_RESULT).Cells(Target.Row, VIEW_COL_MEMO).Value
    End If
    PersistManualStateFromResultSheet True
SafeExit:
    On Error Resume Next
    BuildResultSummaryCards GetSheet(SH_RESULT), LastRow(GetSheet(SH_RESULT), VIEW_COL_ID)
    On Error GoTo 0
    ProtectOutputSheet GetSheet(SH_RESULT)
    Application.EnableEvents = prevEvents
End Sub

Public Sub ApplyManualExclusionsFromResultSheet(Optional ByVal silent As Boolean = True)
    Dim ws As Worksheet, ex As Worksheet, lastR As Long, r As Long
    Dim idsText As String, idText As String, arr As Variant, i As Long, txId As String, outR As Long
    If Not SheetExists(SH_RESULT) Then Exit Sub
    Set ws = GetSheet(SH_RESULT)
    Set ex = GetSheet(SH_MANUAL_EXCLUDE)
    If LastRow(ex, 1) < 1 Then InitManualExcludeHeaders ex
    lastR = LastRow(ws, VIEW_COL_ID)
    outR = LastRow(ex, 1) + 1
    For r = VIEW_FIRST_DATA_ROW To lastR
        If IsTxExcludeDecision(CellText(ws.Cells(r, VIEW_COL_DECISION).Value)) Then
            idText = CellText(ws.Cells(r, VIEW_COL_ID).Value)
            idsText = JoinNonBlank(CellText(ws.Cells(r, RAW_START_COL + RES_COL_OUT_IDS - 1).Value), CellText(ws.Cells(r, RAW_START_COL + RES_COL_IN_IDS - 1).Value), ",")
            If Len(idsText) > 0 Then
                arr = Split(idsText, ",")
                For i = LBound(arr) To UBound(arr)
                    txId = Trim$(CStr(arr(i)))
                    If Len(txId) > 0 And Not ManualExcludeExists(ex, txId) Then
                        ex.Cells(outR, 1).Value = txId
                        ex.Cells(outR, 2).Value = idText
                        ex.Cells(outR, 3).Value = Now
                        ex.Cells(outR, 4).Value = "���͌��ʃV�[�g�Ŏ�����O�w��"
                        outR = outR + 1
                    End If
                Next i
            End If
        End If
    Next r
    If Not silent Then AppendLog "�蓮���O���f", "����", "���͌��ʃV�[�g����W_�蓮���O�֔��f"
End Sub

Private Function ManualExcludeExists(ByVal ws As Worksheet, ByVal txId As String) As Boolean
    Dim found As Range
    Set found = ws.Columns(1).Find(What:=txId, LookIn:=xlValues, LookAt:=xlWhole)
    ManualExcludeExists = Not found Is Nothing
End Function

Public Sub BuildFlaggedTransactionSheet()
    Dim src As Worksheet, dst As Worksheet, detail As Worksheet
    Dim lastR As Long, lastC As Long, r As Long
    Dim txId As String, flags As Object, ids As Object, vouchers As Object, memos As Object
    Set src = GetSheet(SH_WORK_TX)
    Set detail = GetSheet(SH_WORK_DETAIL)
    Set dst = GetSheet(SH_FLAGGED)
    On Error Resume Next
    dst.Unprotect Password:=TOOL_PASSWORD
    dst.Cells.UnMerge
    dst.Cells.Clear
    DeleteAllShapes dst
    On Error GoTo 0

    Set flags = CreateObject("Scripting.Dictionary")
    Set ids = CreateObject("Scripting.Dictionary")
    Set vouchers = CreateObject("Scripting.Dictionary")
    Set memos = CreateObject("Scripting.Dictionary")
    BuildFlagDictionaries detail, flags, ids, vouchers, memos

    lastR = LastRow(src, 1)
    lastC = LastUsedColumn(src)
    If lastR < 1 Then Exit Sub
    dst.Range(dst.Cells(1, 1), dst.Cells(lastR, lastC)).Value = src.Range(src.Cells(1, 1), src.Cells(lastR, lastC)).Value

    dst.Cells(1, lastC + 1).Value = "���̓t���O"
    dst.Cells(1, lastC + 2).Value = "���͌��ID"
    dst.Cells(1, lastC + 3).Value = "�`�[�˗�"
    dst.Cells(1, lastC + 4).Value = "���̓���"
    FormatHeader dst.Range(dst.Cells(1, 1), dst.Cells(1, lastC + 4)), ThemeColor("header")

    Dim colTx As Long, lastColLetter As String
    colTx = HeaderColumn(dst, "���ID", 1)
    For r = 2 To lastR
        txId = CellText(dst.Cells(r, colTx).Value)
        If flags.Exists(txId) Then
            dst.Cells(r, lastC + 1).Value = flags(txId)
            dst.Cells(r, lastC + 2).Value = ids(txId)
            dst.Cells(r, lastC + 3).Value = vouchers(txId)
            dst.Cells(r, lastC + 4).Value = memos(txId)
            ApplyFlagColor dst.Range(dst.Cells(r, 1), dst.Cells(r, lastC + 4)), CStr(flags(txId))
        End If
    Next r

    FormatBody dst.Range(dst.Cells(2, 1), dst.Cells(Application.Max(2, lastR), lastC + 4))
    dst.Range(dst.Cells(1, 1), dst.Cells(lastR, lastC + 4)).AutoFilter
    dst.Activate
    ActiveWindow.FreezePanes = False
    dst.Range("A2").Select
    ActiveWindow.FreezePanes = True
    lastColLetter = ColumnLetter(lastC + 4)
    AutoFitSheetSmart dst, "A:" & lastColLetter, 6, 34
    ThemeApplyPrintTable dst.Range(dst.Cells(1, 1), dst.Cells(lastR, lastC + 4)), 1
    ThemeCapRowHeights dst.Range(dst.Cells(2, 1), dst.Cells(lastR, lastC + 4)), 20, 72
    ThemeApplyMonochromePrint dst, dst.Range(dst.Cells(1, 1), dst.Cells(lastR, lastC + 4)).Address, True, "$1:$1", 1, 0
    ProtectOutputSheet dst
End Sub

Private Sub BuildFlagDictionaries(ByVal detail As Worksheet, ByVal flags As Object, ByVal ids As Object, ByVal vouchers As Object, ByVal memos As Object)
    Dim lastR As Long, r As Long, txId As String, kindText As String, analysisId As String
    lastR = LastRow(detail, DET_COL_ID)
    For r = 2 To lastR
        txId = CellText(detail.Cells(r, DET_COL_TX_ID).Value)
        kindText = CellText(detail.Cells(r, DET_COL_KIND).Value)
        analysisId = CellText(detail.Cells(r, DET_COL_ANALYSIS_ID).Value)
        If Len(txId) > 0 Then
            If flags.Exists(txId) Then
                If InStr(flags(txId), kindText) = 0 Then flags(txId) = flags(txId) & "," & kindText
                If InStr(ids(txId), analysisId) = 0 Then ids(txId) = ids(txId) & "," & analysisId
                If CellText(detail.Cells(r, DET_COL_VOUCHER).Value) = VOUCHER_YES Then vouchers(txId) = VOUCHER_YES
            Else
                flags(txId) = kindText
                ids(txId) = analysisId
                vouchers(txId) = CellText(detail.Cells(r, DET_COL_VOUCHER).Value)
            End If
            memos(txId) = "���͑Ώ�"
        End If
    Next r
End Sub

Private Sub ApplyFlagColor(ByVal rng As Range, ByVal flagText As String)
    If InStr(flagText, KIND_INHERITANCE_SHIFT) > 0 Then
        rng.Interior.Color = ThemeColor("purple-soft")
    ElseIf InStr(flagText, KIND_SHIFT) > 0 Then
        rng.Interior.Color = ThemeColor("info-soft")
    ElseIf InStr(flagText, KIND_UNKNOWN_IN) > 0 Then
        rng.Interior.Color = ThemeColor("warning-soft")
    ElseIf InStr(flagText, KIND_UNKNOWN_OUT) > 0 Then
        rng.Interior.Color = ThemeColor("orange-soft")
    Else
        rng.Interior.Color = ThemeColor("locked")
    End If
End Sub

Public Sub BuildDetailOutputSheet()
    Dim src As Worksheet, dst As Worksheet, lastR As Long
    Set src = GetSheet(SH_WORK_DETAIL)
    Set dst = GetSheet(SH_DETAIL)
    On Error Resume Next
    dst.Unprotect Password:=TOOL_PASSWORD
    dst.Cells.UnMerge
    dst.Cells.Clear
    DeleteAllShapes dst
    On Error GoTo 0

    lastR = LastRow(src, 1)
    dst.Range("A1:Q" & CStr(Application.Max(1, lastR))).Value = src.Range("A1:Q" & CStr(Application.Max(1, lastR))).Value
    FormatHeader dst.Range("A1:Q1"), ThemeColor("header")
    If lastR >= 2 Then
        FormatBody dst.Range("A2:Q" & CStr(lastR))
        dst.Range("E2:E" & CStr(lastR)).NumberFormatLocal = "yyyy/m/d"
        dst.Range("F2:F" & CStr(lastR)).NumberFormatLocal = "#,##0"
    End If
    dst.Range("A1:Q1").AutoFilter
    AutoFitSheetSmart dst, "A:Q", 6, 34
    ThemeApplyPrintTable dst.Range("A1:Q" & CStr(Application.Max(1, lastR))), 1
    ThemeCapRowHeights dst.Range("A2:Q" & CStr(Application.Max(2, lastR))), 20, 72
    ThemeApplyMonochromePrint dst, dst.Range("A1:Q" & CStr(Application.Max(1, lastR))).Address, True, "$1:$1", 1, 0
    ProtectOutputSheet dst
End Sub

Public Sub BuildAllVisibleOutputs()
    BuildAnalysisResultSheet
    BuildDetailOutputSheet
    BuildFlaggedTransactionSheet
    BuildInvestigationIssueSheet True
End Sub

Private Sub ProtectOutputSheet(ByVal ws As Worksheet)
    On Error Resume Next
    ThemePrepareSheetForProtection ws
    ws.Protect Password:=TOOL_PASSWORD, UserInterfaceOnly:=True, DrawingObjects:=True, Contents:=True, Scenarios:=True, AllowFiltering:=True, AllowSorting:=True
    ws.EnableSelection = xlNoRestrictions
    On Error GoTo 0
End Sub

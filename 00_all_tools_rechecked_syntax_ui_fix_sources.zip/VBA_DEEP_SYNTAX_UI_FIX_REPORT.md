# VBA構文・罫線・入力見やすさ 深掘り修正レポート

## 修正対象
- 02_cash_v10/modExternalCashOperationImport.bas
- 02_cash_v10/modUtilities.bas
- 02_cash_v10/modSetup.bas
- 02_cash_v10/modUI.bas
- 各ツール modVisualTheme.bas
- 01/03系の長い宣言・長い呼び出し数か所

## 主な修正
1. 02外部取込の長すぎた品質判定関数を撤去し、短い安全な `ExternalMapQualityScore` に置換。
2. VBAインポート時に危ない長い宣言・長い呼び出しを行継続で分割。
3. 残高推移表の空白行で罫線を消す処理を廃止。
4. 入力シート用の `RepairFinanceInputBorders` を追加し、口座情報・残高入力・取引明細・右側操作領域を強制的に閉じた罫線へ復旧。
5. `AutoFitInputSheetSmart`、`PolishInputLayout`、`RestoreToolFormatting` の流れで罫線復旧を再適用。
6. 図形ボタン・パネル背景を `xlMoveAndSize` に寄せ、列幅・行高調整後のズレを抑制。
7. VBEインポート向けに .bas/.txt は CP932 + CRLF で保存。

## 静的検査結果
- VBAテキスト検査対象: 60 ファイル
- ブロック構文検査: 問題 0
- CP932往復確認: OK
- CRLF確認: OK
- 最大行長: 235 文字
- 旧品質判定関数: VBAソース内から削除済み
- 240文字超のVBA行: 0

## 罫線対策の要点
- 残高推移表の空白行でも罫線を消さない。
- AutoFit後にも空白行の罫線を再適用する。
- 02入力シートは `RepairFinanceInputBorders` で、口座情報・残高入力・取引明細・右側操作領域の罫線をまとめて復旧する。
- 右上操作パネルの背景・ラベル・ボタンをセル追従に寄せ、レイアウト崩れを抑える。

## 実機確認手順
1. 既存モジュールを差し替えインポート。
2. VBEで「デバッグ → VBAProject のコンパイル」。
3. 02ツールで「書式復旧」を実行。
4. 入力シート、資金操作表、残高推移表、取扱店変換対象の罫線が途切れていないことを確認。

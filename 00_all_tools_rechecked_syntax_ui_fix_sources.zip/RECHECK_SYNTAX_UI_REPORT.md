# RECHECK_SYNTAX_UI_REPORT

再チェック結果。

## 追加修正

- `02_cash_v10/modExternalCashOperationImport.bas` の列番号変数 `cDate` を `cTxDateCol` に変更。
- `04_voucher_v5/modCommonData.bas` の列番号変数 `cDate` を `cTxDateCol` に変更。

理由: VBAは大文字小文字を区別しないため、`cDate` は組み込み変換関数 `CDate` と衝突し得ます。実機VBEで構文エラー・識別子エラーになる余地を消しました。

## 確認済み

- 旧 `ExternalImportMapQuality` 名はVBAソース内に残存なし。
- `ExternalMapQualityScore` の宣言・呼び出しは行継続形式として整合。
- CP932 / Shift-JIS でVBAソースを読み直し可能。
- `Sub` / `Function` / `Property` の対応確認済み。
- `If` / `For` / `Do` / `Select Case` / `With` の対応確認済み。
- 行継続 `_` の末尾位置・直前スペース確認済み。
- 同一ツール内のPublicプロシージャ重複なし。
- 予約語・組み込み変換関数と完全一致する変数名なし。
- 罫線消去系の `.Borders.Color` だけ指定する旧処理は検出なし。
- 02入力画面、残高推移表、操作パネルに罫線復旧処理の呼び出し経路あり。

## 未確認

この環境ではExcel実機を起動できないため、VBEの「デバッグ → VBAProject のコンパイル」と実画面表示は未実行です。
